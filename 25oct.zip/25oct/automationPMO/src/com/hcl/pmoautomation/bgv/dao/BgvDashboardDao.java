package com.hcl.pmoautomation.bgv.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.hcl.pmoautomation.bgv.model.PmoDashBoard;

public class BgvDashboardDao {

	public List<PmoDashBoard> pendingWithPmo(JdbcTemplate jdbcTemplate) {
		String sql = DataBaseQueryBGVdashboard.QUERY_TO_FETCH_pendingWithPmo;
		System.out.println("query for action status "+sql);
	 List<PmoDashBoard> listaa = jdbcTemplate.query(sql, new RowMapper<PmoDashBoard>() 
				 {
			@Override
			public PmoDashBoard mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				PmoDashBoard pendingWithPmo = new PmoDashBoard();
			
				pendingWithPmo.setPendingWithPmo(rs.getString("count(1)"));
				System.out.println("count(1)");
			
				return pendingWithPmo;
			}
	 			  	
	    });
	   System.out.println(listaa);
		 return listaa;
	}

	public List<PmoDashBoard> pendingWithCentralBgv(JdbcTemplate jdbcTemplate) {
		String sql = DataBaseQueryBGVdashboard.QUERY_TO_FETCH_pendingWithCentralBgv;
		System.out.println("query for action status "+sql);
	 List<PmoDashBoard> listaa = jdbcTemplate.query(sql, new RowMapper<PmoDashBoard>() 
				 {
			@Override
			public PmoDashBoard mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				PmoDashBoard pendingWithCentralBgv = new PmoDashBoard();
			
				pendingWithCentralBgv.setPendingWithCentralBgv(rs.getString("count(2)"));
				System.out.println("count(2)");
			
				return pendingWithCentralBgv;
			}
	 			  	
	    });
	  System.out.println(listaa);
		 return listaa;
	}

	public List<PmoDashBoard> pendingWithVendor(JdbcTemplate jdbcTemplate) {
		String sql = DataBaseQueryBGVdashboard.QUERY_TO_FETCH_pendingWithVendor;
		System.out.println("query for action status "+sql);
	 List<PmoDashBoard> listaa = jdbcTemplate.query(sql, new RowMapper<PmoDashBoard>() 
				 {
			@Override
			public PmoDashBoard mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				PmoDashBoard pendingWithVendor = new PmoDashBoard();
			
				pendingWithVendor.setPendingWithVendor(rs.getString("count(3)"));
				System.out.println("count(3)");
			
				return pendingWithVendor;
			}
	 			  	
	    });
	  System.out.println(listaa);
		 return listaa;
	}

	public List<PmoDashBoard> pendingWithResource(JdbcTemplate jdbcTemplate) {
		String sql = DataBaseQueryBGVdashboard.QUERY_TO_FETCH_pendingWithResource;
		System.out.println("query for action status "+sql);
	 List<PmoDashBoard> listaa = jdbcTemplate.query(sql, new RowMapper<PmoDashBoard>() 
				 {
			@Override
			public PmoDashBoard mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				PmoDashBoard pendingWithResource = new PmoDashBoard();
			
				pendingWithResource.setPendingWithResource(rs.getString("count(4)"));
				System.out.println("count(4)");
			
				return pendingWithResource;
			}
	 			  	
	    });
	  System.out.println(listaa);
		 return listaa;
	}

	/*public List<PmoDashBoard> resourcePreCheckPending(JdbcTemplate jdbcTemplate) {
		String sql = DataBaseQueryBGVdashboard.QUERY_TO_FETCH_resourcePreCheckPending;
		System.out.println("query for action status "+sql);
	 List<PmoDashBoard> listaa = jdbcTemplate.query(sql, new RowMapper<PmoDashBoard>() 
				 {
			@Override
			public PmoDashBoard mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				PmoDashBoard resourcePreCheckPending = new PmoDashBoard();
			
				resourcePreCheckPending.setResourcePreCheckPending(rs.getString("count(5)"));
				System.out.println("count(5)");
			
				return resourcePreCheckPending;
			}
	 			  	
	    });
	  System.out.println(listaa);
		 return listaa;
	}
*/
	
public List<PmoDashBoard> precheckCompleted(JdbcTemplate jdbcTemplate) {
	String sql = DataBaseQueryBGVdashboard.QUERY_TO_FETCH_precheckCompleted;
	System.out.println("query for action status "+sql);
 List<PmoDashBoard> listaa = jdbcTemplate.query(sql, new RowMapper<PmoDashBoard>() 
			 {
		@Override
		public PmoDashBoard mapRow(ResultSet rs, int rowNum) throws SQLException 
		{
			PmoDashBoard precheckCompleted = new PmoDashBoard();
		
			precheckCompleted.setPrecheckCompleted(rs.getString("count(6)"));
			System.out.println("count(6)");
		
			return precheckCompleted;
		}
 			  	
    });
 System.out.println(listaa);
	 return listaa;
	}
public List<PmoDashBoard> postcheckpending(JdbcTemplate jdbcTemplate) {
	String sql = DataBaseQueryBGVdashboard.QUERY_TO_FETCH_postcheckpending;
	System.out.println("query for action status "+sql);
 List<PmoDashBoard> listaa = jdbcTemplate.query(sql, new RowMapper<PmoDashBoard>() 
			 {
		@Override
		public PmoDashBoard mapRow(ResultSet rs, int rowNum) throws SQLException 
		{
			PmoDashBoard postcheckCompleted = new PmoDashBoard();
		
			postcheckCompleted.setPostcheckpending(rs.getString("count(7)"));
			System.out.println("count(7)");
		
			return postcheckCompleted;
		}
 			  	
    });
 System.out.println(listaa);
	 return listaa;
	}
public List<PmoDashBoard> postcheckCompleted(JdbcTemplate jdbcTemplate) {
	String sql = DataBaseQueryBGVdashboard.QUERY_TO_FETCH_postcheckCompleted;
	System.out.println("query for action status "+sql);
 List<PmoDashBoard> listaa = jdbcTemplate.query(sql, new RowMapper<PmoDashBoard>() 
			 {
		@Override
		public PmoDashBoard mapRow(ResultSet rs, int rowNum) throws SQLException 
		{
			PmoDashBoard postcheckCompleted = new PmoDashBoard();
		
			postcheckCompleted.setPostcheckCompleted(rs.getString("count(8)"));
			System.out.println("count(8)");
		
			return postcheckCompleted;
		}
 			  	
    });
 System.out.println(listaa);
	 return listaa;
	}
}

package com.hcl.pmoautomation.bgv.controller;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("*.downloadDUreferback")
public class DownloadDUforReferBack extends javax.servlet.http.HttpServlet implements
javax.servlet.Servlet  {
	private static final long serialVersionUID = 1L;
    private static final int BUFSIZE = 4096;
    String filePath;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 String finaluploadPath=(String) request.getSession().getAttribute("downloadpathsessionDUreferback");
		 if(finaluploadPath!=null){
		/*filePath="C:/uploadFiles";
		  System.out.println("changed  "+filePath);
		  filePath=filePath+"/New Text Document (2).txt";
		  System.out.println("total "+filePath);*/
		  
		  filePath=finaluploadPath;
		  System.out.println("download servlet "+filePath);
	        File file = new File(filePath);
	        int length = 0;
	        ServletOutputStream outStream = response.getOutputStream();
	        response.setContentType("text/html");
	        response.setContentLength((int) file.length());
	        String fileName = (new File(filePath)).getName();
	        response.setHeader("Content-Disposition", "attachment; filename=\""+ fileName + "\"");
	 
	        byte[] byteBuffer = new byte[BUFSIZE];
	        DataInputStream in = new DataInputStream(new FileInputStream(file));
	 
	        while ((in != null) && ((length = in.read(byteBuffer)) != -1)) {
	            outStream.write(byteBuffer, 0, length);
	        }
	 
	        in.close();
	        outStream.close();
	  }
		 else{
			 PrintWriter out = response.getWriter();
			 out.println("<html><body><script type=\"text/javascript\">alert('No Existing Document found');window.location= '../../pmoAutomation/BgvStatus/bgvStatus.php';</script></body></html>");
			
		 }
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

package com.hcl.pmoautomation.bgv.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.hcl.pmoautomation.AddAction.vo.templatevo;
import com.hcl.pmoautomation.bgv.model.DownloadPathvo;
import com.hcl.pmoautomation.bgv.model.Tsc;
import com.hcl.pmoautomation.ot.dao.DatabaseQuery;

public class YetToJoinDao {

	public List<Tsc> yettojoininitiateddetails(JdbcTemplate jdbcTemplate) 
	{
		String sql = DataBaseQueryBGVdashboard.QUERY_TO_FETCH_ytj_initiated_cases;
		System.out.println(sql);
	   
	    		 List<Tsc> listaa = jdbcTemplate.query(sql, new RowMapper<Tsc>() 
	
	    				 {
			@Override
			public Tsc mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				Tsc ytj = new Tsc();
				ytj.setCV_ID(rs.getString("CV_ID"));
				ytj.setFIRST_NAME(rs.getString("First_name"));
				ytj.setCountry(rs.getString("Country"));
				ytj.setProject_Name(rs.getString("Project_Name"));
				ytj.setInitiator_Name(rs.getString("Initiator_Name"));
				ytj.setBgv_Status(rs.getString("BGVStatus"));
				ytj.setBgv_colour(rs.getString("BGV_Status_Red_Amber_Green"));
				ytj.setBgv_Triggered_Date(rs.getDate("BGVTriggeredDate"));
				ytj.setBgv_Initiated_On(rs.getString("BGVInitiatedOn"));
				
				return ytj;
			}
	    });
	    		
	    return listaa;
	    }
	public List<Tsc> yettojoinymergingdetails(String cvid,JdbcTemplate jdbcTemplate) 
	{
		String sql = DataBaseQueryBGVdashboard.QUERY_TO_FETCH_ytj_merging_details+cvid;
		System.out.println(sql);
	   
	    		 List<Tsc> listaa = jdbcTemplate.query(sql, new RowMapper<Tsc>() 
	
	    				 {
			@Override
			public Tsc mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				Tsc ytj = new Tsc();
				ytj.setCV_ID(rs.getString("CV_ID"));
				ytj.setFIRST_NAME(rs.getString("First_name"));
				return ytj;
			}
	    });
	    		
	    return listaa;
	    }
	public List<DownloadPathvo> internalpathcheck(String uid,JdbcTemplate jdbcTemplate) 
	{
		String sql = DataBaseQueryBGVdashboard.QUERY_TO_FETCH_internal_path_check+uid+"'";
		System.out.println(sql);
	   
	    		 List<DownloadPathvo> listaa = jdbcTemplate.query(sql, new RowMapper<DownloadPathvo>() 
	
	    				 {
			@Override
			public DownloadPathvo mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				DownloadPathvo ytj = new DownloadPathvo();
				ytj.setUploadpath(rs.getString("Du_path"));
				
				return ytj;
			}
	    });
	    		
	    return listaa;
	    }
	
}



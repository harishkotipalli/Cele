package com.hcl.pmoautomation.bgv.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.hcl.pmoautomation.bgv.model.VettingSheet;

public interface BgvPmoDaoI {
	
	List<Object[]> getBgvDetails(JdbcTemplate jdbcTemplate);
	

}
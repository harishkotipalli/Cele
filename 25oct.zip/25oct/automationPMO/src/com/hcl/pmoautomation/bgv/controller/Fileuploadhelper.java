package com.hcl.pmoautomation.bgv.controller;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet(value = "*.bgvup")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
maxFileSize = 1024 * 1024 * 10, // 10MB
maxRequestSize = 1024 * 1024 * 50)
// 50MB

public class Fileuploadhelper extends HttpServlet {
	
	
	private static final long serialVersionUID = 1L;

	

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		
//		TODO:Change the location to properties file
		String uploadFilePath = "C:\\uploadsavingsheets" + File.separator;

		// creates the save directory if it does not exists
		File fileSaveDir = new File(uploadFilePath);
		if (!fileSaveDir.exists()) {
			fileSaveDir.mkdirs();
		}
		System.out.println("Upload File Directory="
				+ fileSaveDir.getAbsolutePath());

		String fileName = null, tempString = null;
		Scanner scanner = null;
		// Get all the parts from request and write it to the file on server
		String[] temp = new String[5];
	
		//Collection<Part> parts = request.getParts();`
		for (Part part : request.getParts()) {
			
			fileName = getFileName(part);
			if (fileName.equals("")) {
				break;
			}
			System.out.println(fileName);
			fileName = fileName.replace("\\", "/");
			scanner = new Scanner(fileName);
			System.out.println(fileName);
			scanner.useDelimiter("/");
			while (scanner.hasNext()) {
				tempString = scanner.next();
				if (tempString.contains(".txt")) {
					break;
				}
				
			}
			part.write(uploadFilePath + File.separator + tempString);
		}
		uploadFilePath=(uploadFilePath + tempString).replace("/","\\");
	
		request.setAttribute("successMessageForFileUpload", uploadFilePath
				+ " File uploaded successfully!");
		request.setAttribute("filePathBGV",uploadFilePath);
	
		 if(((String)request.getAttribute("fileType")).equalsIgnoreCase("Bgv_Data")){
			request.getRequestDispatcher("pmoAutomation/BgvCont/BgvExcelReadSave.php").forward(request, response);
		}
	}

	private String getFileName(Part part) {
	
		String contentDisp = part.getHeader("content-disposition");
//		System.out.println("content-disposition header= " + contentDisp);
		String[] tokens = contentDisp.split(";");
		for (String token : tokens) {
			if (token.trim().startsWith("filename")) {
				return token.substring(token.indexOf("=") + 2,
						token.length() - 1);
			}
		}
		return "";
	}
	
}

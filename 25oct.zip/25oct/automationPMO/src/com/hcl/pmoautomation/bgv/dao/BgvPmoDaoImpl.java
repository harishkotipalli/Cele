package com.hcl.pmoautomation.bgv.dao;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.hcl.pmoautomation.AddAction.vo.templatevo;
import com.hcl.pmoautomation.bgv.model.BgvVO;
import com.hcl.pmoautomation.bgv.model.VettingSheet;
import com.hcl.pmoautomation.bgv.utilities.BgvSql;
import com.hcl.pmoautomation.ot.dao.DatabaseQuery;

public class BgvPmoDaoImpl implements BgvPmoDaoI{
	

	public List<Object[]> getDownLoadExcel(JdbcTemplate jdbcTemplate){
		String sqlquery = BgvSql.getExcelDownload;
		List<Map<String, Object>> maps = jdbcTemplate.queryForList(sqlquery);
		System.out.println(maps);
		List<Object[]> list = new ArrayList<Object[]>();
		Object[] objects=null;
		for (Map tempMap : maps) {
			objects = new Object[tempMap.size()];
			
			objects[0] = ((int) tempMap.get("SAP_ID"));
			
			objects[1] = ((String) tempMap.get("EMP_FIRST_NAME"));
			
			objects[2] = ((String) tempMap.get("EMP_LAST_NAME"));
			objects[3] = ((String) tempMap.get("PREFERRED_BUSINESS_NAME"));
		
			objects[4] = ((String) tempMap.get("DATE_OF_BIRTH"));
            objects[5] = ((String) tempMap.get("GENDER"));
			
			objects[6] = ((String) tempMap.get("NATIONALITY"));
			
			objects[7] = ((String) tempMap.get("PROJECT_CODE"));
			objects[8] = ((String) tempMap.get("PROJECT_NAME"));
		
			objects[9] = ((String) tempMap.get("SECTOR"));
			objects[10] = ((String) tempMap.get("REQUEST_TYPE"));
			
			objects[11] = ((String) tempMap.get("TP_RESOURCE"));
			
			objects[12] = ((String) tempMap.get("EMP_OFFICIAL_MAIL_ID"));
			objects[13] = ((String) tempMap.get("EMP_PERSONAL_MAIL_ID"));
		
			objects[14] = ((String) tempMap.get("EMP_CLIENT_MAIL_ID"));
			objects[15] = ((String) tempMap.get("EMP_CONTACT_NUMBER"));
			
			objects[16] = ((String) tempMap.get("LOCATION"));
			
			objects[17] = ((String) tempMap.get("NEW_LOCATION"));
			objects[18] = ((String) tempMap.get("OU_CODE"));

			
				objects[19] = ((int) tempMap.get("GPN"));
			
			
			objects[20] = ((String) tempMap.get("CLIENT_HIRING_MANAGER_MAIL_ID"));
			
			objects[21] = ((int) tempMap.get("CLIENT_HIRING_MANAGER_GPN_NO"));
			
			objects[22] = ((String) tempMap.get("REGION"));
			objects[23] = ((String) tempMap.get("COUNTRY"));
		
			objects[24] = ((String) tempMap.get("ASSIGNMENT_FROM"));
			objects[25] = ((String) tempMap.get("ASSIGNMENT_TO"));
			
			objects[26] = ((String) tempMap.get("BGV_TYPE"));
			
			objects[27] = ((String) tempMap.get("REQUESTED_BY"));
			objects[28] = ((String) tempMap.get("REQUESTED_DATE"));
		
			objects[29] = ((String) tempMap.get("PRE_START_CHECK_WITH_PMO"));
			
			objects[30] = ((String) tempMap.get("PRE_START_CHECK_WITH_PMO_DATE"));
			
			objects[31] = ((String) tempMap.get("PRE_START_CHECK_WITH_CENTRAL_BGV"));
			
			objects[32] = ((String) tempMap.get("PRE_START_CHECK_WITH_CENTRAL_BGV_DATE"));
			objects[33] = ((String) tempMap.get("PRE_START_CHECK_WITH_RESOURCE"));
		
			objects[34] = ((String) tempMap.get("PRE_START_CHECK_WITH_RESOURCE_DATE"));
			objects[35] = ((String) tempMap.get("VENDOR_INITIATED_PRECHECK"));
			
			objects[36] = ((String) tempMap.get("VENDOR_INITIATED_DATE_PRECHECK"));
			
			objects[37] = ((String) tempMap.get("PRE_START_CHECK_STATUS"));
			objects[38] = ((String) tempMap.get("PRE_START_CHECK_COMP_DATE"));
		
			objects[39] = ((String) tempMap.get("BGV_PRESTART_COLOR"));
			objects[40] = ((String) tempMap.get("BGV_POST_CHECK_COMPLETED_DATE"));
			objects[41] = ((String) tempMap.get("BGV_FINAL_REPORT_COLOUR"));
			list.add(objects);
			System.out.println(tempMap);
			}
		System.out.println(sqlquery);
		System.out.println(list);
		return list;
	}
	
	
	
	public List<BgvVO> downloadBGVpre(JdbcTemplate jdbcTemplate) 
	{
		
	 	String sql = BgvSql.getExcelDownload;
		
		
		
		System.out.println(sql);
	   
	    		 List<BgvVO> listaa = jdbcTemplate.query(sql, new RowMapper<BgvVO>() 
	
	    				 {
			@Override
			public BgvVO mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				BgvVO mailtemp = new BgvVO();
					
			
				
	            	
					mailtemp.setSAP_ID(rs.getInt("sap_Id"));
				mailtemp.setEMP_FIRST_NAME(rs.getString("emp_first_name"));
				mailtemp.setPROJECT_NAME(rs.getString("project_name"));
				mailtemp.setOU_CODE(rs.getString("ou_code"));
				mailtemp.setREQUESTED_DATE(rs.getTimestamp("requested_date"));
				return mailtemp;
			}
	 
			
			
			
			
			
			
	    });
	    		
	    		
	    return listaa;
	    
	  
	    
	    }

	@Override
	public List<Object[]> getBgvDetails(JdbcTemplate jdbcTemplate) {
		String sqlquery = BgvSql.getbgv_details_Sql;
		
		List<Map<String, Object>> maps = jdbcTemplate.queryForList(sqlquery);
		List<Object[]> list = new ArrayList<Object[]>();
		Object[] objects=null;
		for (Map tempMap : maps) {
			objects = new Object[tempMap.size()];
			
			objects[0] = ((int) tempMap.get("sap_Id"));
			//objects[1] = ((String) tempMap.get("request_type"));
			objects[1] = ((String) tempMap.get("emp_first_name"));
			//objects[3] = ((String) tempMap.get("project_code"));
			objects[2] = ((String) tempMap.get("project_name"));
			objects[3] = ((String) tempMap.get("ou_code"));
			//objects[6] = ((String) tempMap.get("location"));
			//objects[7] = ((String) tempMap.get("country"));
			//objects[8] = ((String) tempMap.get("mailtriggered"));
			objects[4] = ((String) tempMap.get("requested_date"));
			objects[5] = ((String) tempMap.get("pre_start_check_with_pmo"));
			objects[6] = ((long) tempMap.get("no_of_days_pending"));
			
			list.add(objects);
			System.out.println(tempMap);
			}
		System.out.println(sqlquery);
		System.out.println(list);
		return list;
	}
	
	public List<Object[]> getfinalBgvDetails(JdbcTemplate jdbcTemplate){
    String sqlquery = BgvSql.getfinalbgv_details_Sql;
		
		List<Map<String, Object>> maps = jdbcTemplate.queryForList(sqlquery);
		List<Object[]> list = new ArrayList<Object[]>();
		Object[] objects=null;
		for (Map tempMap : maps) {
			objects = new Object[tempMap.size()];
			
			objects[0] = ((int) tempMap.get("sap_Id"));
			objects[1] = ((String) tempMap.get("request_type"));
			objects[2] = ((String) tempMap.get("emp_first_name"));
			objects[3] = ((String) tempMap.get("project_code"));
			objects[4] = ((String) tempMap.get("project_name"));
			objects[5] = ((String) tempMap.get("ou_code"));
			objects[6] = ((String) tempMap.get("location"));
			objects[7] = ((String) tempMap.get("country"));
			objects[8] = ((String) tempMap.get("BGV_PRESTART_COLOR"));
			objects[9] = ((String) tempMap.get("BGV_FINAL_REPORT_COLOUR"));
			
			list.add(objects);
			System.out.println(tempMap);
			}
		System.out.println(sqlquery);
		System.out.println(list);
		return list;
	}
	
	
	public List<Object[]> getYetToJoineeBgvdetails(JdbcTemplate jdbcTemplate){
		String sqlquery = BgvSql.getyettojoinee_details_Sql;
		
		List<Map<String, Object>> maps = jdbcTemplate.queryForList(sqlquery);
		List<Object[]> list = new ArrayList<Object[]>();
		Object[] objects=null;
		for (Map tempMap : maps) {
			objects = new Object[tempMap.size()];
			
			
			
			objects[0] = ((String) tempMap.get("emp_first_name"));
			objects[1] = ((String) tempMap.get("project_code"));
			objects[2] = ((String) tempMap.get("project_name"));
			objects[3] = ((String) tempMap.get("ou_code"));
			objects[4] = ((String) tempMap.get("location"));
			objects[5] = ((String) tempMap.get("country"));
			
			
			list.add(objects);
			System.out.println(tempMap);
			}
		System.out.println(sqlquery);
		System.out.println(list);
		return list;
	}
	
	public boolean saveFinalBgvDetails(JdbcTemplate jdbcTemplate, int parseInt, String color,String finalrem,String date) {
		boolean flag=false;
		
		if(color.equalsIgnoreCase("green")){
		 flag=jdbcTemplate.update("update bgv set BGV_FINAL_REPORT_COLOUR= ?, INITIATE_GPN='N',BGV_Status='COMPLETED', BGV_POST_CHECK_COMPLETED_DATE=?  where SAP_ID=?",
				new Object[]{color,convert2Date(date),parseInt})>0?true:false;
		}
		if(color.equalsIgnoreCase("amber")){
			 flag=jdbcTemplate.update("update bgv set BGV_FINAL_REPORT_COLOUR= ?, INITIATE_GPN='Y',FINALREMARKS=?, BGV_POST_CHECK_COMPLETED_DATE=?  where SAP_ID=?",
					new Object[]{color,finalrem,convert2Date(date),parseInt})>0?true:false;
			}
		if(color.equalsIgnoreCase("orange")){
			 flag=jdbcTemplate.update("update bgv set BGV_FINAL_REPORT_COLOUR= ?, INITIATE_GPN='Y',FINALREMARKS=?, BGV_POST_CHECK_COMPLETED_DATE=?  where SAP_ID=?",
					new Object[]{color,finalrem,convert2Date(date),parseInt})>0?true:false;
			}
		
		if(color.equalsIgnoreCase("red")){
			 flag=jdbcTemplate.update("update bgv set BGV_FINAL_REPORT_COLOUR= ? ,TERMINATE_GPN='Y', INITIATE_GPN='N',FINALREMARKS=?, BGV_POST_CHECK_COMPLETED_DATE=? where SAP_ID=?",
					new Object[]{color,finalrem,convert2Date(date),parseInt})>0?true:false;
			}
		return flag;
		
	}
	public boolean saveBgvDetails(JdbcTemplate jdbcTemplate, int parseInt,
			String color,String yesradio,String remarks) {
//		System.out.println(Arrays.asList(bgvDetail));
		boolean flag = false;
		if(color.equalsIgnoreCase("green")){
			 flag=jdbcTemplate.update("update bgv set BGV_PRESTART_COLOR= ?, ACTIVE_FLAG='N', INITIATE_GPN='Y' where SAP_ID=?",
					new Object[]{color,parseInt})>0?true:false;
		}
		
		 if(color.equalsIgnoreCase("amber")&&yesradio.equalsIgnoreCase("y")){
			 flag=jdbcTemplate.update("update bgv set BGV_PRESTART_COLOR= ?, ACTIVE_FLAG='N', INITIATE_GPN='Y',REMARKS=? where SAP_ID=?",
						new Object[]{color,remarks,parseInt})>0?true:false;
		}
		
		 if(color.equalsIgnoreCase("red")){
			 flag=jdbcTemplate.update("update bgv set BGV_PRESTART_COLOR= ?, ACTIVE_FLAG='N', INITIATE_GPN='N',REMARKS=? where SAP_ID=?",
						new Object[]{color,remarks,parseInt})>0?true:false;
		}
				
		return flag;
	}
	public boolean bgvpersonmailyes(JdbcTemplate jdbcTemplate, int parseInt) {
		boolean flag = false;
		
		 flag=jdbcTemplate.update("update bgv set mailtriggered= 'YES' where SAP_ID=?",
				new Object[]{parseInt})>0?true:false;
	
	return flag;
		
	}
	public boolean preCheckApproval(JdbcTemplate jdbcTemplate, int parseInt,
			String yesradio,String color,String date){
		boolean flag = false;
		/*flag=jdbcTemplate.update("update bgv set  ACTIVEFLAG_PRECHECK='N', INITIATE_GPN='Y' where SAP_ID=?",
				new Object[]{parseInt})>0?true:false;*/
				
				if(color.equalsIgnoreCase("green")){
				
					 flag=jdbcTemplate.update("update bgv set BGV_PRESTART_COLOR= ?, ACTIVEFLAG_PRECHECK='N', INITIATE_GPN=?,PRE_START_CHECK_STATUS='completed',PRE_START_CHECK_COMP_DATE=? where SAP_ID=?",
							new Object[]{color,yesradio,convert2Date(date),parseInt})>0?true:false;
				}
				
				 if(color.equalsIgnoreCase("amber")){
				
					 flag=jdbcTemplate.update("update bgv set BGV_PRESTART_COLOR= ?, ACTIVEFLAG_PRECHECK='Y', INITIATE_GPN=?,PRE_START_CHECK_STATUS='notcompleted',PRE_START_CHECK_COMP_DATE=? where SAP_ID=?",
								new Object[]{color,yesradio,convert2Date(date),parseInt})>0?true:false;
				}
				
				 if(color.equalsIgnoreCase("red")){
					 flag=jdbcTemplate.update("update bgv set BGV_PRESTART_COLOR= ?, ACTIVEFLAG_PRECHECK='Y', INITIATE_GPN=?,PRE_START_CHECK_STATUS='notcompleted',PRE_START_CHECK_COMP_DATE=? where SAP_ID=?",
								new Object[]{color,yesradio,convert2Date(date),parseInt})>0?true:false;
				}
		return flag;
		
	}
	
	public boolean YTJpreCheckApproval(JdbcTemplate jdbcTemplate, int parseInt,
			String color,String date){
		boolean flag = false;
		/*flag=jdbcTemplate.update("update bgv set  ACTIVEFLAG_PRECHECK='N', INITIATE_GPN='Y' where SAP_ID=?",
				new Object[]{parseInt})>0?true:false;*/
				
				if(color.equalsIgnoreCase("green")){
				
					 flag=jdbcTemplate.update("update bgv set BGV_PRESTART_COLOR= ?, ACTIVEFLAG_PRECHECK='N',PRE_START_CHECK_STATUS='completed',PRE_START_CHECK_COMP_DATE=? where SAP_ID=?",
							new Object[]{color,convert2Date(date),parseInt})>0?true:false;
				}
				
				 if(color.equalsIgnoreCase("amber")){
				
					 flag=jdbcTemplate.update("update bgv set BGV_PRESTART_COLOR= ?, ACTIVEFLAG_PRECHECK='Y',PRE_START_CHECK_STATUS='notcompleted',PRE_START_CHECK_COMP_DATE=? where SAP_ID=?",
								new Object[]{color,convert2Date(date),parseInt})>0?true:false;
				}
				
				 if(color.equalsIgnoreCase("red")){
					 flag=jdbcTemplate.update("update bgv set BGV_PRESTART_COLOR= ?, ACTIVEFLAG_PRECHECK='Y',PRE_START_CHECK_STATUS='notcompleted',PRE_START_CHECK_COMP_DATE=? where SAP_ID=?",
								new Object[]{color,convert2Date(date),parseInt})>0?true:false;
				}
		return flag;
		
	}
	Date convert2Date(String date)
	{

		SimpleDateFormat simDate = null;
		java.util.Date dateobj1 = null;
		java.sql.Date newDate = null;

		try 
		{
			
			if (date.indexOf("/")>0)
			{
				simDate=new SimpleDateFormat("MM/dd/yyyy");
				dateobj1 = simDate.parse(date);		
				newDate = new java.sql.Date(dateobj1.getTime());
			
			}
			else if(date.indexOf("-")>0)
			{
				simDate = new SimpleDateFormat("yyyy-MM-dd");
				dateobj1 = simDate.parse(date);		
				newDate = new java.sql.Date(dateobj1.getTime());
		
				
			}
			else{
				date=null;
			}
			

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}		
		
		return newDate;
	}
	public List<Object[]> getVendorDetails(JdbcTemplate jdbcTemplate) {
		
String sqlquery = BgvSql.getvendor_initiate_Sql;
		
		List<Map<String, Object>> maps = jdbcTemplate.queryForList(sqlquery);
		List<Object[]> list = new ArrayList<Object[]>();
		Object[] objects=null;
		for (Map tempMap : maps) {
			objects = new Object[tempMap.size()];
			
			objects[0] = ((int) tempMap.get("sap_Id"));
			objects[1] = ((String) tempMap.get("emp_first_name"));
			objects[2] = ((String) tempMap.get("ou_code"));
			
			list.add(objects);
			System.out.println(tempMap);
			}
		System.out.println(sqlquery);
		System.out.println(list);
		return list;
	}
	public List<Object[]> preCheckCentralBGV(JdbcTemplate jdbcTemplate) {
		
    String sqlquery = BgvSql.getPreCheckCentralBGV;
		
		List<Map<String, Object>> maps = jdbcTemplate.queryForList(sqlquery);
		List<Object[]> list = new ArrayList<Object[]>();
		Object[] objects=null;
		for (Map tempMap : maps) {
			objects = new Object[tempMap.size()];
			
			
			objects[0] = ((int) tempMap.get("sap_Id"));
			objects[1] = ((String) tempMap.get("emp_first_name"));
			
			objects[2] = ((String) tempMap.get("project_name"));
			objects[3] = ((String) tempMap.get("ou_code"));
			objects[4] = ((String) tempMap.get("PRE_START_CHECK_WITH_PMO"));
			objects[5] = ((String) tempMap.get("PRE_START_CHECK_WITH_PMO_DATE"));
			objects[6] = ((String) tempMap.get("PRE_START_CHECK_WITH_CENTRAL_BGV"));
			objects[7] = ((long) tempMap.get("no_of_days_pending"));
	
			
			
			list.add(objects);
			System.out.println(tempMap);
			}
		System.out.println(sqlquery);
		System.out.println(list);
		return list;
	}
	public List<Object[]> preCheckVendorBGV(JdbcTemplate jdbcTemplate) {
		
		 String sqlquery = BgvSql.preCheckVendorBGV;
			
			List<Map<String, Object>> maps = jdbcTemplate.queryForList(sqlquery);
			List<Object[]> list = new ArrayList<Object[]>();
			Object[] objects=null;
			for (Map tempMap : maps) {
				objects = new Object[tempMap.size()];
				
				
				objects[0] = ((int) tempMap.get("sap_Id"));
				objects[1] = ((String) tempMap.get("emp_first_name"));
				
				objects[2] = ((String) tempMap.get("project_name"));
				objects[3] = ((String) tempMap.get("ou_code"));
				objects[4] = ((String) tempMap.get("PRE_START_CHECK_WITH_RESOURCE"));
				objects[5] = ((String) tempMap.get("PRE_START_CHECK_WITH_RESOURCE_DATE"));
				objects[6] = ((String) tempMap.get("VENDOR_INITIATED_PRECHECK"));
				objects[7] = ((long) tempMap.get("no_of_days_pending"));
		
				
				
				list.add(objects);
				System.out.println(tempMap);
				}
			System.out.println(sqlquery);
			System.out.println(list);
			return list;
	}
	
	public List<Object[]> preCheckResourceBGV(JdbcTemplate jdbcTemplate) {
		String sqlquery = BgvSql.preCheckResourceBGV;
		
		List<Map<String, Object>> maps = jdbcTemplate.queryForList(sqlquery);
		List<Object[]> list = new ArrayList<Object[]>();
		Object[] objects=null;
		for (Map tempMap : maps) {
			objects = new Object[tempMap.size()];
			
			
			objects[0] = ((int) tempMap.get("sap_Id"));
			objects[1] = ((String) tempMap.get("emp_first_name"));
			
			objects[2] = ((String) tempMap.get("project_name"));
			objects[3] = ((String) tempMap.get("ou_code"));
			objects[4] = ((String) tempMap.get("PRE_START_CHECK_WITH_CENTRAL_BGV"));
			objects[5] = ((String) tempMap.get("PRE_START_CHECK_WITH_CENTRAL_BGV_DATE"));
			objects[6] = ((String) tempMap.get("PRE_START_CHECK_WITH_RESOURCE"));
			objects[7] = ((long) tempMap.get("no_of_days_pending"));
			
	
			
			
			list.add(objects);
			System.out.println(tempMap);
			}
		System.out.println(sqlquery);
		System.out.println(list);
		return list;
	}
	
	/*public List<Object[]> preCheckPmoPending(JdbcTemplate jdbcTemplate) {
String sqlquery = BgvSql.preCheckPmoPending;
		
		List<Map<String, Object>> maps = jdbcTemplate.queryForList(sqlquery);
		List<Object[]> list = new ArrayList<Object[]>();
		Object[] objects=null;
		for (Map tempMap : maps) {
			objects = new Object[tempMap.size()];
			
			
			objects[0] = ((int) tempMap.get("sap_Id"));
			objects[1] = ((String) tempMap.get("emp_first_name"));
			
			objects[2] = ((String) tempMap.get("project_name"));
			objects[3] = ((String) tempMap.get("ou_code"));
			objects[4] = ((String) tempMap.get("VENDOR_INITIATED_PRECHECK"));
			objects[5] = ((String) tempMap.get("VENDOR_INITIATED_DATE_PRECHECK"));
			objects[6] = ((String) tempMap.get("PRE_START_CHECK_STATUS"));
			objects[7] = ((long) tempMap.get("no_of_days_pending"));
			
	
			
			
			list.add(objects);
			System.out.println(tempMap);
			}
		System.out.println(sqlquery);
		System.out.println(list);
		return list;
	}*/
	
	public List<Object[]> preCheckPmo(JdbcTemplate jdbcTemplate) {
	
		String sqlquery = BgvSql.preCheckPmo;
		
		List<Map<String, Object>> maps = jdbcTemplate.queryForList(sqlquery);
		List<Object[]> list = new ArrayList<Object[]>();
		Object[] objects=null;
		for (Map tempMap : maps) {
			objects = new Object[tempMap.size()];
			
			
			objects[0] = ((int) tempMap.get("sap_Id"));
			objects[1] = ((String) tempMap.get("emp_first_name"));
			
			objects[2] = ((String) tempMap.get("project_name"));
			objects[3] = ((String) tempMap.get("ou_code"));
			objects[4] = ((String) tempMap.get("PRE_START_CHECK_WITH_RESOURCE"));
			objects[5] = ((String) tempMap.get("PRE_START_CHECK_WITH_RESOURCE_DATE"));
			objects[6] = ((String) tempMap.get("PRE_START_CHECK_STATUS"));
			objects[7] = ((String) tempMap.get("BGV_PRESTART_COLOR"));
			objects[8] = ((long) tempMap.get("no_of_days_pending"));
	
			
			
			list.add(objects);
			System.out.println(tempMap);
			}
		System.out.println(sqlquery);
		System.out.println(list);
		return list;
	}
	public List<Object[]> YTJpreCheckPmo(JdbcTemplate jdbcTemplate) {
		
		String sqlquery = BgvSql.YTJpreCheckPmo;
		
		List<Map<String, Object>> maps = jdbcTemplate.queryForList(sqlquery);
		List<Object[]> list = new ArrayList<Object[]>();
		Object[] objects=null;
		for (Map tempMap : maps) {
			objects = new Object[tempMap.size()];
			
			
			objects[0] = ((int) tempMap.get("sap_Id"));
			objects[1] = ((String) tempMap.get("emp_first_name"));
			
			objects[2] = ((String) tempMap.get("project_name"));
			objects[3] = ((String) tempMap.get("ou_code"));
			objects[4] = ((String) tempMap.get("PRE_START_CHECK_WITH_CENTRAL_BGV"));
			objects[5] = ((String) tempMap.get("PRE_START_CHECK_WITH_CENTRAL_BGV_DATE"));
			objects[6] = ((String) tempMap.get("PRE_START_CHECK_STATUS"));
			objects[7] = ((String) tempMap.get("BGV_PRESTART_COLOR"));
			objects[8] = ((long) tempMap.get("no_of_days_pending"));
	
			
			
			list.add(objects);
			System.out.println(tempMap);
			}
		System.out.println(sqlquery);
		System.out.println(list);
		return list;
	}
	
public List<Object[]> YTJGpnInitiate(JdbcTemplate jdbcTemplate) {
		
		String sqlquery = BgvSql.YTJGpnInitiate;
		
		List<Map<String, Object>> maps = jdbcTemplate.queryForList(sqlquery);
		List<Object[]> list = new ArrayList<Object[]>();
		Object[] objects=null;
		for (Map tempMap : maps) {
			objects = new Object[tempMap.size()];
			
			
			objects[0] = ((int) tempMap.get("sap_Id"));
			objects[1] = ((String) tempMap.get("emp_first_name"));
			
			objects[2] = ((String) tempMap.get("project_name"));
			objects[3] = ((String) tempMap.get("ou_code"));
			objects[4] = ((String) tempMap.get("PRE_START_CHECK_STATUS"));
			objects[5] = ((String) tempMap.get("BGV_PRESTART_COLOR"));
			
	
			
			
			list.add(objects);
			System.out.println(tempMap);
			}
		System.out.println(sqlquery);
		System.out.println(list);
		return list;
	}
	public List<Object[]> preCheckcompleted(JdbcTemplate jdbcTemplate) {
		
		String sqlquery = BgvSql.preCheckPmoCompleted;
		
		List<Map<String, Object>> maps = jdbcTemplate.queryForList(sqlquery);
		List<Object[]> list = new ArrayList<Object[]>();
		Object[] objects=null;
		for (Map tempMap : maps) {
			objects = new Object[tempMap.size()];
			
			
			objects[0] = ((int) tempMap.get("sap_Id"));
			objects[1] = ((String) tempMap.get("emp_first_name"));
			
			objects[2] = ((String) tempMap.get("project_name"));
			objects[3] = ((String) tempMap.get("ou_code"));
			objects[4] = ((String) tempMap.get("PRE_START_CHECK_WITH_RESOURCE"));
			objects[5] = ((String) tempMap.get("PRE_START_CHECK_WITH_RESOURCE_DATE"));
			objects[6] = ((String) tempMap.get("PRE_START_CHECK_STATUS"));
			objects[7] = ((String) tempMap.get("BGV_PRESTART_COLOR"));
		//	objects[8] = ((long) tempMap.get("no_of_days_pending"));
	
			
			
			list.add(objects);
			System.out.println(tempMap);
			}
		System.out.println(sqlquery);
		System.out.println(list);
		return list;
	}
	
public List<Object[]> preCheckcompleteddetailsforDownload(JdbcTemplate jdbcTemplate) {
		
		String sqlquery = BgvSql.bgvcompleteddetailsfordownload;
		
		List<Map<String, Object>> maps = jdbcTemplate.queryForList(sqlquery);
		List<Object[]> list = new ArrayList<Object[]>();
		Object[] objects=null;
		for (Map tempMap : maps) {
			objects = new Object[tempMap.size()];
			
			
			objects[0] = ((int) tempMap.get("SAP_ID"));
			objects[1] = ((String) tempMap.get("EMP_FIRST_NAME"));
			
			objects[2] = ((String) tempMap.get("PROJECT_CODE"));
			
			objects[3] = ((String) tempMap.get("PROJECT_NAME"));
			objects[4] = ((String) tempMap.get("ONSHORE_OFFSHORE"));
			objects[5] = ((String) tempMap.get("LOCATION"));
			objects[6] = ((String) tempMap.get("REGION"));
			objects[7] = ((String) tempMap.get("COUNTRY"));
			objects[8] = ((String) tempMap.get("BGV_TYPE"));
			
			objects[9] = ((String) tempMap.get("PRE_START_CHECK_WITH_PMO_DATE"));
			objects[10] = ((String) tempMap.get("PRE_START_CHECK_COMP_DATE"));
			objects[11] = ((String) tempMap.get("BGV_PRESTART_COLOR"));
			objects[12] = ((String) tempMap.get("BGV_POST_CHECK_COMPLETED_DATE"));
			objects[13] = ((String) tempMap.get("BGV_FINAL_REPORT_COLOUR"));
			objects[14] = ((String) tempMap.get("BGV_Status"));
	
			
			
			list.add(objects);
			System.out.println(tempMap);
			}
		System.out.println(sqlquery);
		System.out.println(list);
		return list;
	}
	public List<Object[]> postCheckPending(JdbcTemplate jdbcTemplate) {
		
		String sqlquery = BgvSql.postCheckPending;
		
		List<Map<String, Object>> maps = jdbcTemplate.queryForList(sqlquery);
		List<Object[]> list = new ArrayList<Object[]>();
		Object[] objects=null;
		for (Map tempMap : maps) {
			objects = new Object[tempMap.size()];
			
			
			objects[0] = ((int) tempMap.get("sap_Id"));
			objects[1] = ((String) tempMap.get("emp_first_name"));
			
			objects[2] = ((String) tempMap.get("project_name"));
			objects[3] = ((String) tempMap.get("ou_code"));
			
			objects[4] = ((String) tempMap.get("PRE_START_CHECK_COMP_DATE"));
			objects[5] = ((String) tempMap.get("PRE_START_CHECK_STATUS"));
			objects[6] = ((String) tempMap.get("BGV_PRESTART_COLOR"));
			objects[7] = ((long) tempMap.get("no_of_days_pending"));
	
			
			
			list.add(objects);
			System.out.println(tempMap);
			}
		System.out.println(sqlquery);
		System.out.println(list);
		return list;
	}
public List<Object[]> postCheckCompleted(JdbcTemplate jdbcTemplate) {
		
		String sqlquery = BgvSql.postCheckcompleted;
		
		List<Map<String, Object>> maps = jdbcTemplate.queryForList(sqlquery);
		List<Object[]> list = new ArrayList<Object[]>();
		Object[] objects=null;
		for (Map tempMap : maps) {
			objects = new Object[tempMap.size()];
			
			
			objects[0] = ((int) tempMap.get("sap_Id"));
			objects[1] = ((String) tempMap.get("emp_first_name"));
			
			objects[2] = ((String) tempMap.get("project_name"));
			objects[3] = ((String) tempMap.get("ou_code"));
			
			objects[4] = ((String) tempMap.get("BGV_POST_CHECK_COMPLETED_DATE"));
			objects[5] = ((String) tempMap.get("BGV_FINAL_REPORT_COLOUR"));
			
	
			
			
			list.add(objects);
			System.out.println(tempMap);
			}
		System.out.println(sqlquery);
		System.out.println(list);
		return list;
	}
	public List<Object[]> preCheckPmoReport(JdbcTemplate jdbcTemplate) {
		
		String sqlquery = BgvSql.preCheckPmoReport;
		
		List<Map<String, Object>> maps = jdbcTemplate.queryForList(sqlquery);
		List<Object[]> list = new ArrayList<Object[]>();
		Object[] objects=null;
		for (Map tempMap : maps) {
			objects = new Object[tempMap.size()];
			
			
			objects[0] = ((int) tempMap.get("sap_Id"));
			objects[1] = ((String) tempMap.get("emp_first_name"));
			
			objects[2] = ((String) tempMap.get("project_name"));
			
	
			
			
			list.add(objects);
			System.out.println(tempMap);
			}
		System.out.println(sqlquery);
		System.out.println(list);
		return list;
	}
	public List<Object[]> preCheckPmoDetails(JdbcTemplate jdbcTemplate) {
		
String sqlquery = BgvSql.preCheckPmoDetails;
		
		List<Map<String, Object>> maps = jdbcTemplate.queryForList(sqlquery);
		List<Object[]> list = new ArrayList<Object[]>();
		Object[] objects=null;
		for (Map tempMap : maps) {
			objects = new Object[tempMap.size()];
			
			
			objects[0] = ((int) tempMap.get("sap_Id"));
			objects[1] = ((String) tempMap.get("emp_first_name"));
			
			objects[2] = ((String) tempMap.get("project_name"));
			objects[3] = ((String) tempMap.get("ou_code"));
			objects[4] = ((String) tempMap.get("REQUESTED_DATE"));
			
			
	
			
			
			list.add(objects);
			System.out.println(tempMap);
			}
		System.out.println(sqlquery);
		System.out.println(list);
		return list;
	}
	public List<Object[]> managerpendingwithpmo(int sapid,JdbcTemplate jdbcTemplate) {
String sqlquery = BgvSql.getbgv_details_Sql_Manager+sapid+BgvSql.getbgv_details_Sql_Manager_cntd;
		
		List<Map<String, Object>> maps = jdbcTemplate.queryForList(sqlquery);
		List<Object[]> list = new ArrayList<Object[]>();
		Object[] objects=null;
		for (Map tempMap : maps) {
			objects = new Object[tempMap.size()];
			
			objects[0] = ((int) tempMap.get("sap_Id"));
			//objects[1] = ((String) tempMap.get("request_type"));
			objects[1] = ((String) tempMap.get("emp_first_name"));
			//objects[3] = ((String) tempMap.get("project_code"));
			objects[2] = ((String) tempMap.get("project_name"));
			objects[3] = ((String) tempMap.get("ou_code"));
			//objects[6] = ((String) tempMap.get("location"));
			//objects[7] = ((String) tempMap.get("country"));
			//objects[8] = ((String) tempMap.get("mailtriggered"));
			objects[4] = ((String) tempMap.get("requested_date"));
			objects[5] = ((String) tempMap.get("pre_start_check_with_pmo"));
			objects[6] = ((long) tempMap.get("no_of_days_pending"));
			
			list.add(objects);
			System.out.println(tempMap);
			}
		System.out.println(sqlquery);
		System.out.println(list);
		return list;
	}
	public List<Object[]> preCheckCentralBGVManager(int sapid, JdbcTemplate jdbcTemplate) {
String sqlquery = BgvSql.getPreCheckCentralBGVManager+sapid+BgvSql.getPreCheckCentralBGVManager_cntd;
		
		List<Map<String, Object>> maps = jdbcTemplate.queryForList(sqlquery);
		List<Object[]> list = new ArrayList<Object[]>();
		Object[] objects=null;
		for (Map tempMap : maps) {
			objects = new Object[tempMap.size()];
			
			
			objects[0] = ((int) tempMap.get("sap_Id"));
			objects[1] = ((String) tempMap.get("emp_first_name"));
			
			objects[2] = ((String) tempMap.get("project_name"));
			objects[3] = ((String) tempMap.get("ou_code"));
			objects[4] = ((String) tempMap.get("PRE_START_CHECK_WITH_PMO"));
			objects[5] = ((String) tempMap.get("PRE_START_CHECK_WITH_PMO_DATE"));
			objects[6] = ((String) tempMap.get("PRE_START_CHECK_WITH_CENTRAL_BGV"));
			objects[7] = ((long) tempMap.get("no_of_days_pending"));
	
			
			
			list.add(objects);
			System.out.println(tempMap);
			}
		System.out.println(sqlquery);
		System.out.println(list);
		return list;
	}
	public List<Object[]> preCheckVendorBGVManager(int sapid, JdbcTemplate jdbcTemplate) {
		 String sqlquery = BgvSql.preCheckVendorBGVManager+sapid+BgvSql.preCheckVendorBGVManager_cntd;
			
			List<Map<String, Object>> maps = jdbcTemplate.queryForList(sqlquery);
			List<Object[]> list = new ArrayList<Object[]>();
			Object[] objects=null;
			for (Map tempMap : maps) {
				objects = new Object[tempMap.size()];
				
				
				objects[0] = ((int) tempMap.get("sap_Id"));
				objects[1] = ((String) tempMap.get("emp_first_name"));
				
				objects[2] = ((String) tempMap.get("project_name"));
				objects[3] = ((String) tempMap.get("ou_code"));
				objects[4] = ((String) tempMap.get("PRE_START_CHECK_WITH_RESOURCE"));
				objects[5] = ((String) tempMap.get("PRE_START_CHECK_WITH_RESOURCE_DATE"));
				objects[6] = ((String) tempMap.get("PRE_START_CHECK_STATUS"));
				objects[7] = ((long) tempMap.get("no_of_days_pending"));
		
				
				
				list.add(objects);
				System.out.println(tempMap);
				}
			System.out.println(sqlquery);
			System.out.println(list);
			return list;
	}
	public List<Object[]> preCheckResourceBGVManager(int sapid, JdbcTemplate jdbcTemplate) {
	String sqlquery = BgvSql.preCheckResourceBGVManager+sapid+BgvSql.preCheckResourceBGVManager_cntd;
		
		List<Map<String, Object>> maps = jdbcTemplate.queryForList(sqlquery);
		List<Object[]> list = new ArrayList<Object[]>();
		Object[] objects=null;
		for (Map tempMap : maps) {
			objects = new Object[tempMap.size()];
			
			
			objects[0] = ((int) tempMap.get("sap_Id"));
			objects[1] = ((String) tempMap.get("emp_first_name"));
			
			objects[2] = ((String) tempMap.get("project_name"));
			objects[3] = ((String) tempMap.get("ou_code"));
			objects[4] = ((String) tempMap.get("PRE_START_CHECK_WITH_CENTRAL_BGV"));
			objects[5] = ((String) tempMap.get("PRE_START_CHECK_WITH_CENTRAL_BGV_DATE"));
			objects[6] = ((String) tempMap.get("PRE_START_CHECK_WITH_RESOURCE"));
			objects[7] = ((long) tempMap.get("no_of_days_pending"));
			
	
			
			
			list.add(objects);
			System.out.println(tempMap);
			}
		System.out.println(sqlquery);
		System.out.println(list);
		return list;
	}
	public List<Object[]> preCheckPmoPendingManager(int sapid, JdbcTemplate jdbcTemplate) {
String sqlquery = BgvSql.preCheckPmoPendingManager+sapid+BgvSql.preCheckPmoPendingManager_cntd;
		
		List<Map<String, Object>> maps = jdbcTemplate.queryForList(sqlquery);
		List<Object[]> list = new ArrayList<Object[]>();
		Object[] objects=null;
		for (Map tempMap : maps) {
			objects = new Object[tempMap.size()];
			
			
			objects[0] = ((int) tempMap.get("sap_Id"));
			objects[1] = ((String) tempMap.get("emp_first_name"));
			
			objects[2] = ((String) tempMap.get("project_name"));
			objects[3] = ((String) tempMap.get("ou_code"));
			objects[4] = ((String) tempMap.get("VENDOR_INITIATED_PRECHECK"));
			objects[5] = ((String) tempMap.get("VENDOR_INITIATED_DATE_PRECHECK"));
			objects[6] = ((String) tempMap.get("PRE_START_CHECK_STATUS"));
			objects[7] = ((long) tempMap.get("no_of_days_pending"));
			
	
			
			
			list.add(objects);
			System.out.println(tempMap);
			}
		System.out.println(sqlquery);
		System.out.println(list);
		return list;
	}
	public List<Object[]> ManagerpreCheckPmocompleted(int sapid, JdbcTemplate jdbcTemplate) {
String sqlquery = BgvSql.preCheckPmoManager+sapid+BgvSql.preCheckPmoManager_cntd;
		
		List<Map<String, Object>> maps = jdbcTemplate.queryForList(sqlquery);
		List<Object[]> list = new ArrayList<Object[]>();
		Object[] objects=null;
		for (Map tempMap : maps) {
			objects = new Object[tempMap.size()];
			
			
			objects[0] = ((int) tempMap.get("sap_Id"));
			objects[1] = ((String) tempMap.get("emp_first_name"));
			
			objects[2] = ((String) tempMap.get("project_name"));
			objects[3] = ((String) tempMap.get("ou_code"));
			objects[4] = ((String) tempMap.get("PRE_START_CHECK_WITH_RESOURCE"));
			objects[5] = ((String) tempMap.get("PRE_START_CHECK_WITH_RESOURCE_DATE"));
			objects[6] = ((String) tempMap.get("PRE_START_CHECK_STATUS"));
			objects[7] = ((String) tempMap.get("BGV_PRESTART_COLOR"));
			objects[8] = ((long) tempMap.get("no_of_days_pending"));
	
			
			
			list.add(objects);
			System.out.println(tempMap);
			}
		System.out.println(sqlquery);
		System.out.println(list);
		return list;
	}
	public List<Object[]> ManagerpostCheckpending(int sapid, JdbcTemplate jdbcTemplate) {
		String sqlquery = BgvSql.postCheckPending_manager+sapid+BgvSql.postCheckPending_manager_cntd;
				
				List<Map<String, Object>> maps = jdbcTemplate.queryForList(sqlquery);
				List<Object[]> list = new ArrayList<Object[]>();
				Object[] objects=null;
				for (Map tempMap : maps) {
					objects = new Object[tempMap.size()];
					
					objects[0] = ((int) tempMap.get("sap_Id"));
					objects[1] = ((String) tempMap.get("emp_first_name"));
					
					objects[2] = ((String) tempMap.get("project_name"));
					objects[3] = ((String) tempMap.get("ou_code"));
					
					objects[4] = ((String) tempMap.get("PRE_START_CHECK_COMP_DATE"));
					objects[5] = ((String) tempMap.get("PRE_START_CHECK_STATUS"));
					objects[6] = ((String) tempMap.get("BGV_PRESTART_COLOR"));
					objects[7] = ((long) tempMap.get("no_of_days_pending"));
			
					
					
					list.add(objects);
					System.out.println(tempMap);
					}
				System.out.println(sqlquery);
				System.out.println(list);
				return list;
			}
	
	public List<Object[]> ManagerpostCheckcompleted(int sapid, JdbcTemplate jdbcTemplate) {
		String sqlquery = BgvSql.postCheckcompleted_manager+sapid;
				
				List<Map<String, Object>> maps = jdbcTemplate.queryForList(sqlquery);
				List<Object[]> list = new ArrayList<Object[]>();
				Object[] objects=null;
				for (Map tempMap : maps) {
					objects = new Object[tempMap.size()];
					
					objects[0] = ((int) tempMap.get("sap_Id"));
					objects[1] = ((String) tempMap.get("emp_first_name"));
					
					objects[2] = ((String) tempMap.get("project_name"));
					objects[3] = ((String) tempMap.get("ou_code"));
					
					objects[4] = ((String) tempMap.get("BGV_POST_CHECK_COMPLETED_DATE"));
					objects[5] = ((String) tempMap.get("BGV_FINAL_REPORT_COLOUR"));
			
					
					
					list.add(objects);
					System.out.println(tempMap);
					}
				System.out.println(sqlquery);
				System.out.println(list);
				return list;
			}
}


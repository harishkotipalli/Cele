package com.hcl.pmoautomation.bgv.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.hcl.pmoautomation.AddAction.dao.DataBaseQueryForAddAction;




public class BGVActiondao {
	
	public List<Dashboardvo> referBackStatus(int sapid, JdbcTemplate jdbcTemplate) 
	{
		String sql = DataBaseQueryBGVdashboard.QUERY_TO_FETCH_bgvreferback+sapid;
	 List<Dashboardvo> listaa = jdbcTemplate.query(sql, new RowMapper<Dashboardvo>() 
				 {
			@Override
			public Dashboardvo mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				Dashboardvo bgvreferback = new Dashboardvo();
			
				bgvreferback.setReferback(rs.getString("count(1)"));
				System.out.println("count(1)");
			
				return bgvreferback;
			}
	 			  	
	    });//---------------new Object[]{year, month});
	   
		 return listaa;
	}

	
	
	
	public List<Dashboardvo> pendingWithPmo(int sapid,JdbcTemplate jdbcTemplate) 
	{
		String sql = DataBaseQueryBGVdashboard.QUERY_TO_FETCH_managerPendingWithPmo+sapid;
		System.out.println("query for action status "+sql);
	 List<Dashboardvo> listaa = jdbcTemplate.query(sql, new RowMapper<Dashboardvo>() 
				 {
			@Override
			public Dashboardvo mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				Dashboardvo pendingWithPmo = new Dashboardvo();
			
				pendingWithPmo.setPendingWithPmo(rs.getString("count(2)"));
				System.out.println("count(2)");
			
				return pendingWithPmo;
			}
	 			  	
	    });
	   
		 return listaa;
	}
	public List<Dashboardvo> pendingWithCentralBgv(int sapid,JdbcTemplate jdbcTemplate) 
	{
		String sql = DataBaseQueryBGVdashboard.QUERY_TO_FETCH_managerPendingWithCentralBgv+sapid;
	 List<Dashboardvo> listaa = jdbcTemplate.query(sql, new RowMapper<Dashboardvo>() 
				 {
			@Override
			public Dashboardvo mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				Dashboardvo pendingWithCentralBgv = new Dashboardvo();
			
				pendingWithCentralBgv.setPendingWithCentralBgv(rs.getString("count(3)"));
			
				return pendingWithCentralBgv;
			}
	 			  	
	    });
	   
		 return listaa;
	}
	public List<Dashboardvo> pendingWithVendor(int sapid, JdbcTemplate jdbcTemplate) 
	{
		String sql = DataBaseQueryBGVdashboard.QUERY_TO_FETCH_managerpendingWithVendor+sapid;
	 List<Dashboardvo> listaa = jdbcTemplate.query(sql, new RowMapper<Dashboardvo>() 
				 {
			@Override
			public Dashboardvo mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				Dashboardvo pendingWithVendor = new Dashboardvo();
			
				pendingWithVendor.setPendingWithVendor(rs.getString("count(4)"));
				
			
				return pendingWithVendor;
			}
	 			  	
	    });
	   
		 return listaa;
	}

	public List<Dashboardvo> pendingWithResource(int sapid, JdbcTemplate jdbcTemplate) {
		
			String sql = DataBaseQueryBGVdashboard.QUERY_TO_FETCH_managerPendingWithResource+sapid;
		 List<Dashboardvo> listaa = jdbcTemplate.query(sql, new RowMapper<Dashboardvo>() 
					 {
				@Override
				public Dashboardvo mapRow(ResultSet rs, int rowNum) throws SQLException 
				{
					Dashboardvo pendingWithResource = new Dashboardvo();
				
					pendingWithResource.setPendingWithResource(rs.getString("count(5)"));
					
				
					return pendingWithResource;
				}
		 			  	
		    });
		   
			 return listaa;
		}




	/*public List<Dashboardvo> resourcePreCheckPending(int sapid, JdbcTemplate jdbcTemplate) {
		String sql = DataBaseQueryBGVdashboard.QUERY_TO_FETCH_managerResourcePreCheckPending+sapid;
		 List<Dashboardvo> listaa = jdbcTemplate.query(sql, new RowMapper<Dashboardvo>() 
					 {
				@Override
				public Dashboardvo mapRow(ResultSet rs, int rowNum) throws SQLException 
				{
					Dashboardvo resourcePreCheckPending = new Dashboardvo();
				
					resourcePreCheckPending.setResourcePreCheckPending(rs.getString("count(6)"));
					
				
					return resourcePreCheckPending;
				}
		 			  	
		    });
		   
			 return listaa;
		}

*/


	public List<Dashboardvo> precheckCompleted(int sapid, JdbcTemplate jdbcTemplate) {
		String sql = DataBaseQueryBGVdashboard.QUERY_TO_FETCH_managerPrecheckCompleted+sapid;
		 List<Dashboardvo> listaa = jdbcTemplate.query(sql, new RowMapper<Dashboardvo>() 
					 {
				@Override
				public Dashboardvo mapRow(ResultSet rs, int rowNum) throws SQLException 
				{
					Dashboardvo precheckCompleted = new Dashboardvo();
				
					precheckCompleted.setPrecheckCompleted(rs.getString("count(7)"));
					
				
					return precheckCompleted;
				}
		 			  	
		    });
		   
			 return listaa;
		}
	public List<Dashboardvo> postcheckpending(int sapid, JdbcTemplate jdbcTemplate) {
		String sql = DataBaseQueryBGVdashboard.QUERY_TO_FETCH_managerpostcheckpending+sapid;
		 List<Dashboardvo> listaa = jdbcTemplate.query(sql, new RowMapper<Dashboardvo>() 
					 {
				@Override
				public Dashboardvo mapRow(ResultSet rs, int rowNum) throws SQLException 
				{
					Dashboardvo precheckCompleted = new Dashboardvo();
				
					precheckCompleted.setPostcheckpending(rs.getString("count(8)"));
					
				
					return precheckCompleted;
				}
		 			  	
		    });
		   
			 return listaa;
		}
	public List<Dashboardvo> postcheckCompleted(int sapid, JdbcTemplate jdbcTemplate) {
		String sql = DataBaseQueryBGVdashboard.QUERY_TO_FETCH_managerpostcheckCompleted+sapid;
		 List<Dashboardvo> listaa = jdbcTemplate.query(sql, new RowMapper<Dashboardvo>() 
					 {
				@Override
				public Dashboardvo mapRow(ResultSet rs, int rowNum) throws SQLException 
				{
					Dashboardvo precheckCompleted = new Dashboardvo();
				
					precheckCompleted.setPostcheckCompleted(rs.getString("count(9)"));
					
				
					return precheckCompleted;
				}
		 			  	
		    });
		   
			 return listaa;
		}
	public String getbgvtypeusingregulatoryregion(JdbcTemplate jdbcTemplate, String parameter) {
		System.out.println("getbgvtypeusingregulatoryregion");
		return jdbcTemplate.queryForObject(DataBaseQueryBGVdashboard.QUERY_TO_FETCH_bgvtype_using_regulatoryregion+parameter+"'", String.class);
		
	}
	
}

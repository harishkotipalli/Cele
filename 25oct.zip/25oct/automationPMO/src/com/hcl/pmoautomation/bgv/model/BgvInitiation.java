package com.hcl.pmoautomation.bgv.model;

import java.util.List;

public class BgvInitiation {
	List<EmployeeNewJoining> employeeNewJoinings;
	List<EmployeeYetToJoining> employeeYetToJoinings;
	public List<EmployeeNewJoining> getEmployeeNewJoinings() {
		return employeeNewJoinings;
	}
	public void setEmployeeNewJoinings(
			List<EmployeeNewJoining> employeeNewJoinings) {
		this.employeeNewJoinings = employeeNewJoinings;
	}
	public List<EmployeeYetToJoining> getEmployeeYetToJoinings() {
		return employeeYetToJoinings;
	}
	public void setEmployeeYetToJoinings(
			List<EmployeeYetToJoining> employeeYetToJoinings) {
		this.employeeYetToJoinings = employeeYetToJoinings;
	}
	@Override
	public String toString() {
		return "BgvInitiation [employeeNewJoinings=" + employeeNewJoinings
				+ ", employeeYetToJoinings=" + employeeYetToJoinings + "]";
	}


}

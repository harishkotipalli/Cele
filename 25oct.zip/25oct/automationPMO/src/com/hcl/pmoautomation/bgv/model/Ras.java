package com.hcl.pmoautomation.bgv.model;

import java.sql.Date;

public class Ras {

	private int ID;
	private int	SAPCODE;
	private Date CURRENT_DAY;
	private String EMPNAME;
	private String BAND;
	private String SUB_BAND;
	private String FRESHER_LATERAL_TP;
	private String DESIG;
	private int REP_MGR_CODE;
	private String REP_MGR_NAME;
	private int LOB_CODE;
	private int SBU_CODE;
	private int BU_CODE;
	private int TOTAL_EXPERIENCE;
	private int RELATIVE_EXP;
	private String LOB_DESC;
	private String SBU_DESC;
	private String BU_DESC;
	private String LOCATION;
	private String ONSITE_OR_OFFSHORE;
	private int PROJ_COUNT;
	private String PROJECT_CODE;
	private String PROJECT_NAME;
	private Date RES_STSRT_DATE;
	private Date RES_END_DATE;
	private Date LAST_BILLED;
	private int PROJ_LOB_CODE;
	private Date PROJ_LOB_DESC;
	private int PROJ_SBU_CODE;
	private String PROJ_SBU_DESC;
	private int SPROJ_BU_CODE;
	private String PROJ_BU_DESC;
	private int LASTBILLED_AMT;
	private int BILLED_YTD;
	private Date BILLED_TILLDATE;
	private int PM_CODE;
	private String PM_NAME;
	private int SPM_CODE;
	private String SPM_NAME;
	private int CUSTOMER_CODE;
	private String CUSTOMER_NAME;
	private String BILLED_REASONS;
	private String BILLED_STATUS;
	private String ALLOCATION;
	private int GFTE;
	private char ACTIVE_FLAG;
	private String MODIFIED_BY;
	private Date MODIFIED_DATE;
	private int CV_ID;
	
	
	
}

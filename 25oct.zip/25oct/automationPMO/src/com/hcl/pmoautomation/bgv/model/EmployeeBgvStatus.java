package com.hcl.pmoautomation.bgv.model;

public class EmployeeBgvStatus {
	public int sapId;
	public int bgvId;
	public String resourceName;
	public String projectName;
	public String projectCode;
	public String remarks;
	public int getSapId() {
		return sapId;
	}
	public void setSapId(int sapId) {
		this.sapId = sapId;
	}
	public String getResourceName() {
		return resourceName;
	}
	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getProjectCode() {
		return projectCode;
	}
	public void setProjectCode(String projectCode) {
		this.projectCode = projectCode;
	}
	
	
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	
	public int getBgvId() {
		return bgvId;
	}
	public void setBgvId(int bgvId) {
		this.bgvId = bgvId;
	}
	@Override
	public String toString() {
		return "EmployeeBgvStatus [sapId=" + sapId + ", bgvId=" + bgvId + ", resourceName=" + resourceName
				+ ", projectName=" + projectName + ", projectCode=" + projectCode + ", remarks=" + remarks + "]";
	}

	

}

package com.hcl.pmoautomation.bgv.service;

import java.util.List;
import org.springframework.jdbc.core.JdbcTemplate;

public interface Bgvservice{
	public boolean saveBGVDump(String BGVFilePath, String BGVSHEETNAME,
		String BGVTABLENAME, JdbcTemplate jdbcTemplate);

public List<Object[]> getRASDataWithNOSRMapped(JdbcTemplate jdbcTemplate,
		String pmCode);

public boolean saveSRRASMapping(JdbcTemplate jdbcTemplate, int sapCode, String srID);


}

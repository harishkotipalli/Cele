package com.hcl.pmoautomation.bgv.service;

import org.springframework.jdbc.core.JdbcTemplate;

import com.hcl.pmoautomation.bgv.dao.ReferBackDaoImpl;
import com.hcl.pmoautomation.bgv.model.BgvStatus;


public class ReferBackServiceImpl implements ReferBackServiceI {

	@Override
	public boolean referBackPmo(JdbcTemplate jdbcTemplate, String remarks,int parseInt) {
		
		ReferBackDaoImpl referBackDaoImpl = new ReferBackDaoImpl();
		
		return referBackDaoImpl.referBackPmo(jdbcTemplate, remarks,parseInt);
	}
}

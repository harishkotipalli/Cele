package com.hcl.pmoautomation.bgv.dao;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.hcl.pmoautomation.bgv.model.EmployeeBgvStatus;

public class BgvReferRowMapper implements RowMapper<EmployeeBgvStatus>, Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public EmployeeBgvStatus mapRow(ResultSet neJoingResultSet, int arg1) throws SQLException {
		
		EmployeeBgvStatus employeeBgvStatus = new EmployeeBgvStatus();
		employeeBgvStatus.setProjectName(neJoingResultSet.getString("PROJECT_NAME"));
		employeeBgvStatus.setProjectCode(neJoingResultSet.getString("PROJECT_CODE"));
		employeeBgvStatus.setRemarks(neJoingResultSet.getString("REFER_BACK_REMARKS"));
		employeeBgvStatus.setResourceName(neJoingResultSet.getString("EMP_FIRST_NAME"));
		employeeBgvStatus.setSapId(neJoingResultSet.getInt("SAP_ID"));
		employeeBgvStatus.setBgvId(neJoingResultSet.getInt("ID"));
		return employeeBgvStatus;
	}

}

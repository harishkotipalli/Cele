package com.hcl.pmoautomation.bgv.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collections;
import java.util.LinkedList;

import org.springframework.jdbc.core.RowMapper;

import com.hcl.pmoautomation.bgv.model.VettingSheet;


public class VettingRowMapper implements RowMapper<VettingSheet> {

 
	@Override
	public VettingSheet mapRow(ResultSet vettingResultSet, int noofrecords) throws SQLException {
		VettingSheet sheet=new VettingSheet();
		
		sheet.setContact_Number(vettingResultSet.getString(("Contact_Number")));
		sheet.setlast_Name(vettingResultSet.getString("Last_Name"));
		sheet.setcountry(vettingResultSet.getString("Country"));
		sheet.setgender(vettingResultSet.getString("Gender"));
		sheet.setproject_Code(vettingResultSet.getString("Project_Code"));
		sheet.setproject_Name(vettingResultSet.getString("Project_Name"));
        //sheet.settype_Of_Hires(vettingResultSet.getString("Type_Of_Hires"));      
        sheet.setemail(vettingResultSet.getString("Email"));
		
		return sheet;
	}

}



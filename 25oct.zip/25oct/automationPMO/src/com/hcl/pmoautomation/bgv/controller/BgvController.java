package com.hcl.pmoautomation.bgv.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.hcl.pmoautomation.AddAction.dao.DataDao;
import com.hcl.pmoautomation.bgv.dao.BGVActiondao;
import com.hcl.pmoautomation.bgv.dao.BgvDaoImpl;
import com.hcl.pmoautomation.bgv.dao.BgvDashboardDao;
import com.hcl.pmoautomation.bgv.dao.BgvMailDao;
import com.hcl.pmoautomation.bgv.dao.BgvStatusSearchDao;
import com.hcl.pmoautomation.bgv.dao.Dashboardvo;
import com.hcl.pmoautomation.bgv.dao.DownloadPathDao;
import com.hcl.pmoautomation.bgv.model.Bgv;
import com.hcl.pmoautomation.bgv.model.BgvStatusSearchVO;
import com.hcl.pmoautomation.bgv.model.Bgvhclmailvo;
import com.hcl.pmoautomation.bgv.model.DownloadPathvo;
import com.hcl.pmoautomation.bgv.model.PmoDashBoard;
import com.hcl.pmoautomation.bgv.model.ResourcePersonalDetails;
import com.hcl.pmoautomation.bgv.model.VettingSheet;
import com.hcl.pmoautomation.bgv.model.bgvdetailsmailvettingvo;
import com.hcl.pmoautomation.bgv.service.BgvServiceI;
import com.hcl.pmoautomation.bgv.service.BgvServiceImpl;
import com.hcl.pmoautomation.bgv.service.BgvServiceUpImp;
import com.hcl.pmoautomation.bgv.service.Bgvservice;
import com.hcl.pmoautomation.bgv.utilities.BgvSql;
import com.hcl.pmoautomation.bgv.utilities.ExcelSheetConstant;
import com.hcl.pmoautomation.email.App;
import com.hcl.pmoautomation.ot.dao.mailDao;
import com.hcl.pmoautomation.ot.service.ExcaliburService;
import com.hcl.pmoautomation.ot.service.ExcaliburServiceImpl;
import com.hcl.pmoautomation.ot.utility.ExcelSheetConstants;


@Controller
@RequestMapping("pmoAutomation/BgvCont")
public class BgvController {
	
/*	@ExceptionHandler(NullPointerException.class)
    public ModelAndView myError(Exception exception) {
    ModelAndView e = new ModelAndView();
    e.addObject("exception", exception);
    e.setViewName("Login/Error");
    return e;
}*/
	

	@InitBinder
	public void initBinder( WebDataBinder binder )
	{
	    // tell spring to set empty values as null instead of empty string.
		
	    binder.registerCustomEditor( String.class, new StringTrimmerEditor( true ));
	    SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM-dd");
	    simpleDateFormat.setLenient(false);
	    binder.registerCustomEditor( Date.class, new CustomDateEditor( simpleDateFormat,false));
        System.out.println("working");
	}
	@Autowired
	JdbcTemplate jdbcTemplate;

	// BgvServiceI bgvServiceI;
	@InitBinder
	@RequestMapping("/bgvUpdate.php")
	public ModelAndView bgvUpdate(@ModelAttribute("vettingSheet1") Bgv bgv,
			HttpServletRequest request)  {
		System.out.println(jdbcTemplate);
		System.out.println(bgv.getVettingSheet());
		System.out.println(request.getSession().getAttribute("managerId"));
		return new ModelAndView("Bgv/YetToJoinRequest", "listOfEmployees",
				(new BgvServiceImpl()).bgvUpdate(bgv, (int) request
						.getSession().getAttribute("managerId"),
						jdbcTemplate));
	}

	@InitBinder
	@ExceptionHandler
	/*@RequestMapping(value="/bgvUpdateforras.php",  method = {RequestMethod.POST,RequestMethod.GET})
	
	 * public ModelAndView bgvUpdateForRas(@ModelAttribute("bgv") Bgv
	 * bgv,BindingResult resultBgv,HttpServletRequest request){
	 
	public ModelAndView bgvUpdateForRas(
			@ModelAttribute("vettingSheet1") Bgv bgv, HttpServletRequest request,HttpServletResponse response)throws NullPointerException, ServletException, IOException {

		System.out.println("bgv upadte for ras working fine!!!!!!!!!!1111");

		
//		System.out.println();
		System.out.println(request.getSession().getAttribute("ras_id"));
		System.out.println(request.getSession().getAttribute("sap_id"));
		System.out.println(bgv.getVettingSheet());
		System.out.println(bgv.getResourcePersonalDetails());
		System.out.println(jdbcTemplate);
		jdbcTemplate.update(BgvSql.updateBgvSatusintorassql2+"'IN PROGRESS'"+BgvSql.updateBgvSatusintorassql3+request.getSession().getAttribute("sap_id"));
		

		
		
		
		return new ModelAndView("Bgv/newRequest", "listOfEmployees",
				(new BgvServiceImpl()).bgvUpdateForRas(bgv, (int) request
						.getSession().getAttribute("managerId"), (int)request
						.getSession().getAttribute("sap_id"), (int)request.getSession()
						.getAttribute("ras_id"), jdbcTemplate, request));
		 
		
			}*/
	
	@RequestMapping(value="/bgvUpdateforras.php",  method = {RequestMethod.POST,RequestMethod.GET})
	/*
	 * public ModelAndView bgvUpdateForRas(@ModelAttribute("bgv") Bgv
	 * bgv,BindingResult resultBgv,HttpServletRequest request){
	 */
	public String bgvUpdateForRas(
			 HttpServletRequest request,HttpServletResponse response)throws NullPointerException, ServletException, IOException {
		try{	
			String sap=request.getParameter("sapid");
			
			System.out.println("hiiiiiiiiiiiiiiiii "+sap);
			int rasid=(int) request.getSession().getAttribute("ras_id");
			System.out.println("hiiiiiiiiiiiiiiiii 1"+rasid);
			String employeename=request.getParameter("EmlployeName");
			System.out.println("hiiiiiiiiiiiiiiiii 2"+employeename);
			String projectcode=request.getParameter("proCode");
			String projectname=request.getParameter("proName");
			String sector=request.getParameter("sector");
			String tpresource=request.getParameter("yesno");
			String typeof=request.getParameter("radiohire");
			String personalmailid=request.getParameter("personal_Mail_Id");
			System.out.println("hiiiiiiiiiiiiiiiii 3"+personalmailid);
			String officialmailid=request.getParameter("official_Mail_id");
			String contactnumber=request.getParameter("contact_Number");
			String ubsmailid=request.getParameter("ubs_Mail");
			String gpn=request.getParameter("gpn");
			String startdate=request.getParameter("rasstartdate");
			String enddate=request.getParameter("rasenddate");
			String newlocation=request.getParameter("newLocation");
			String regulatoryregion=request.getParameter("regulatoryregion");
			System.out.println("hiiiiiiiiiiiiiiiii 4"+regulatoryregion);
			String country=request.getParameter("countrys");
			String vendortype=request.getParameter("vendortype");
			String ubshiringmailid=request.getParameter("ubs_Hiring_Manager_email_Id");
			String ubsgpn=request.getParameter("ubs_Hiring_Manager_Gpn");
			/*String lfname=request.getParameter("legalFname");*/
			//String llname=request.getParameter("legalLname");
			String nationality=request.getParameter("nationality");
			String pbname=request.getParameter("prefered_business_name");
			String gender=request.getParameter("gender");
			String dob=request.getParameter("DOB");
			String doucode=request.getParameter("department_Ou_Code");
			String clocation=request.getParameter("currentlocation");
			String reqby=request.getParameter("requestedby");
			String reqdate=request.getParameter("requesteddate");
			
			
			
			String addQuery = "insert into mydb.bgv (SAP_ID,RAS_ID,EMP_FIRST_NAME,PROJECT_CODE,PROJECT_NAME,SECTOR,TP_RESOURCE,EMP_PERSONAL_MAIL_ID,EMP_OFFICIAL_MAIL_ID,EMP_CONTACT_NUMBER,EMP_CLIENT_MAIL_ID,GPN,ASSIGNMENT_FROM,ASSIGNMENT_TO,REQUEST_TYPE,New_Location,REGION,COUNTRY,BGV_TYPE,CLIENT_HIRING_MANAGER_MAIL_ID,CLIENT_HIRING_MANAGER_GPN_NO,NATIONALITY,PREFERRED_BUSINESS_NAME,GENDER,DATE_OF_BIRTH,OU_CODE,LOCATION,REQUESTED_BY,REQUESTED_DATE) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,current_timestamp())";
	this.jdbcTemplate.update(addQuery,  new Object[] {sap,rasid,employeename,projectcode,projectname,sector,tpresource,personalmailid,officialmailid,contactnumber,ubsmailid,gpn,startdate,enddate,typeof,newlocation,regulatoryregion,country,vendortype,ubshiringmailid,ubsgpn,nationality,pbname,gender,dob,doucode,clocation,reqby});
	jdbcTemplate.update(BgvSql.updateBgvSatusintorassql2+"'IN PROGRESS'"+BgvSql.updateBgvSatusintorassql3+sap);	
		
	 BgvMailDao b= new BgvMailDao();
	int managerId=  (int) request.getSession().getAttribute("managerId");
		List<Bgvhclmailvo> bgvmail= b.list(managerId, jdbcTemplate);
		App mailtriggerbgv = new App();
		String[] array = new String[bgvmail.size()];
		int index = 0;
		for (Object value : bgvmail) {
			array[index] = String.valueOf( value );
			
			List<bgvdetailsmailvettingvo> bgvmaildetails=b.listoftemplatedata(rasid, jdbcTemplate, request);
	mailtriggerbgv.Mailtrigger("celeritas@hcl.com",array[index], "Details of Resource to Initiate BGV ",null, "/VettingSheetsudmittemplate.jsp",bgvmaildetails, null);

		}
		
		
		}
		catch(Exception e){
		return "forward:../../pmoAutomation/Login/errorPage.php";
		//	e.printStackTrace();
				}

	return "forward:../../pmoAutomation/Bgv/getAllEmployee.php";

	
		
		
		
	}
	
	@RequestMapping(value="/internalvettingsheetsubmit.php",  method = {RequestMethod.POST,RequestMethod.GET})
	/*
	 * public ModelAndView bgvUpdateForRas(@ModelAttribute("bgv") Bgv
	 * bgv,BindingResult resultBgv,HttpServletRequest request){
	 */
	public String internalresourcesvettingsheetsubmit(
			 HttpServletRequest request,HttpServletResponse response)throws NullPointerException, ServletException, IOException {
		try{	
			String sap=request.getParameter("sapid");
			
			System.out.println("hiiiiiiiiiiiiiiiii "+sap);
			String employeename=request.getParameter("EmlployeName");
			System.out.println("hiiiiiiiiiiiiiiiii 2"+employeename);
			String projectcode=request.getParameter("proCode");
			String projectname=request.getParameter("proName");
			String sector=request.getParameter("sector");
			String tpresource=request.getParameter("yesno");
			String typeof=request.getParameter("radiohire");
			String personalmailid=request.getParameter("personal_Mail_Id");
			System.out.println("hiiiiiiiiiiiiiiiii 3"+personalmailid);
			String officialmailid=request.getParameter("official_Mail_id");
			String contactnumber=request.getParameter("contact_Number");
			String ubsmailid=request.getParameter("ubs_Mail");
			String gpn=request.getParameter("gpn");
			String startdate=request.getParameter("rasstartdate");
			String enddate=request.getParameter("rasenddate");
			String newlocation=request.getParameter("newLocation");
			String regulatoryregion=request.getParameter("regulatoryregion");
			System.out.println("hiiiiiiiiiiiiiiiii 4"+regulatoryregion);
			String country=request.getParameter("countrys");
			String vendortype=request.getParameter("vendortype");
			String ubshiringmailid=request.getParameter("ubs_Hiring_Manager_email_Id");
			String ubsgpn=request.getParameter("ubs_Hiring_Manager_Gpn");
			/*String lfname=request.getParameter("legalFname");*/
			//String llname=request.getParameter("legalLname");
			String nationality=request.getParameter("nationality");
			String pbname=request.getParameter("prefered_business_name");
			String gender=request.getParameter("gender");
			String dob=request.getParameter("DOB");
			String doucode=request.getParameter("department_Ou_Code");
			String clocation=request.getParameter("currentlocation");
			String reqby=request.getParameter("requestedby");
			String reqdate=request.getParameter("requesteddate");
			
			
			
			String addQuery = "insert into mydb.bgv (SAP_ID,EMP_FIRST_NAME,PROJECT_CODE,"
					+ "PROJECT_NAME,SECTOR,TP_RESOURCE,EMP_PERSONAL_MAIL_ID,"
					+ "EMP_OFFICIAL_MAIL_ID,EMP_CONTACT_NUMBER,EMP_CLIENT_MAIL_ID,"
					+ "GPN,ASSIGNMENT_FROM,ASSIGNMENT_TO,REQUEST_TYPE,New_Location,"
					+ "REGION,COUNTRY,BGV_TYPE,CLIENT_HIRING_MANAGER_MAIL_ID,"
					+ "CLIENT_HIRING_MANAGER_GPN_NO,NATIONALITY,PREFERRED_BUSINESS_NAME,"
					+ "GENDER,DATE_OF_BIRTH,OU_CODE,LOCATION,REQUESTED_BY,REQUESTED_DATE) "
					+ "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,current_timestamp())";
	this.jdbcTemplate.update(addQuery,  new Object[] {sap,employeename,projectcode,
			projectname,sector,tpresource,personalmailid,
			officialmailid,contactnumber,ubsmailid,gpn,startdate,enddate,typeof,
			newlocation,regulatoryregion,country,vendortype,ubshiringmailid,ubsgpn,
			nationality,pbname,gender,dob,doucode,clocation,reqby});
	//jdbcTemplate.update(BgvSql.updateBgvSatusintorassql2+"'IN PROGRESS'"+BgvSql.updateBgvSatusintorassql3+sap);	
		
	/* BgvMailDao b= new BgvMailDao();
	int managerId=  (int) request.getSession().getAttribute("managerId");
		List<Bgvhclmailvo> bgvmail= b.list(managerId, jdbcTemplate);
		App mailtriggerbgv = new App();
		String[] array = new String[bgvmail.size()];
		int index = 0;
		for (Object value : bgvmail) {
			array[index] = String.valueOf( value );
			
			List<bgvdetailsmailvettingvo> bgvmaildetails=b.listoftemplatedata(rasid, jdbcTemplate, request);
	mailtriggerbgv.Mailtrigger("celeritas@hcl.com",array[index], "Details of Resource to Initiate BGV ",null, "/VettingSheetsudmittemplate.jsp",bgvmaildetails, null);

		}*/
		
		
		}
		catch(Exception e){
		//return "forward:../../pmoAutomation/Login/errorPage.php";
	e.printStackTrace();
				}

	return "forward:../../pmoAutomation/Bgv/getAllEmployee.php";

	
		
		
		
	}
	
	@RequestMapping(value = "/bgvUpdateforras.php",params="uploadtp", method = {RequestMethod.POST,RequestMethod.GET})
	public void tpUpload(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		System.out.println("hi iam in controller");
	/*	// Internally hitting another Servlet
      String upload = request.getParameter("sap_id");
		int bgvperson=Integer.parseInt(upload);
		System.out.println("controller     "+bgvperson);
		HttpSession session = request.getSession();
        session.setAttribute("pdfbgvUploadId", bgvperson);*/
		// TODO:Spring Multipart enable it,Servlet disable it
		request.setAttribute("fileTypepdftp", "pdfuploadtp");
		request.getRequestDispatcher("/fileUploadbgv.bgvupload").forward(request,
				response);
	}
	@RequestMapping(value = "/bgvUpdateforras.php",params="uploadDU", method = {RequestMethod.POST,RequestMethod.GET})
	public void DUUpload(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		System.out.println("hi iam in controller DU");
	
		request.setAttribute("fileTypepdfDU", "pdfuploadDU");
		request.getRequestDispatcher("/fileUploadbgv.bgvuploadDU").forward(request,
				response);
	}
	@RequestMapping(value = "/bgvUpdateforras.php",params="uploadDUreferback", method = {RequestMethod.POST,RequestMethod.GET})
	public void uploadDUreferback(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		System.out.println("hi iam in controller DU");
	
		request.setAttribute("fileTypepdfDUrefer", "pdfuploadDUrefer");
		request.getRequestDispatcher("/fileUploadbgv.bgvuploadDUrefer").forward(request,
				response);
	}
	@RequestMapping(value = "/bgvUpdateforras.php",params="uploadtpreferback", method = {RequestMethod.POST,RequestMethod.GET})
	public void tpUploadreferback(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		System.out.println("hi iam in referback controller");
	/*	// Internally hitting another Servlet
      String upload = request.getParameter("sap_id");
		int bgvperson=Integer.parseInt(upload);
		System.out.println("controller     "+bgvperson);
		HttpSession session = request.getSession();
        session.setAttribute("pdfbgvUploadId", bgvperson);*/
		// TODO:Spring Multipart enable it,Servlet disable it
		request.setAttribute("fileTypepdftpreferback", "pdfuploadtpreferback");
		request.getRequestDispatcher("/fileUploadbgv.referbackbgvupload").forward(request,
				response);
	}
	@RequestMapping(value = "/uploadBgvTp.php")
	public String tpUploadsam(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String sapID=request.getParameter("searchsapforupload");
				int sapIDfrmVettingSheet=Integer.parseInt(sapID);
				HttpSession session = request.getSession();
		        session.setAttribute("sapIDVettingSheet", sapIDfrmVettingSheet);
		return "Bgv/TpUpload";
		
	}
	@RequestMapping(value = "/uploadBgvTpDU.php")
	public String tpUploadsamDU(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String sapID=request.getParameter("searchsapforuploadDU");
				int sapIDfrmVettingSheet=Integer.parseInt(sapID);
				HttpSession session = request.getSession();
		        session.setAttribute("sapIDVettingSheetDU", sapIDfrmVettingSheet);
		return "Bgv/DUupload";
		
	}
	@RequestMapping(value = "/uploadBgvTpDUreferback.php")
	public String uploadBgvTpDUreferback(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String sapID=request.getParameter("searchsapforuploadDUrefer");
				int sapIDfrmVettingSheet=Integer.parseInt(sapID);
				HttpSession session = request.getSession();
		        session.setAttribute("sapIDVettingSheetDUrefer", sapIDfrmVettingSheet);
		return "Bgv/DUuploadReferBack";
		
	}
	@RequestMapping(value = "/referbackuploadBgvTp.php")
	public String refertpUploadsam(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String sapID=request.getParameter("referbackuploadtp");
				int sapIDfrmreferVettingSheet=Integer.parseInt(sapID);
				HttpSession session = request.getSession();
		        session.setAttribute("sapIDreferVettingSheet", sapIDfrmreferVettingSheet);
		return "Bgv/ReferBackTpUplaod";
		
	}
	 @RequestMapping(value = "/uploadpagetp.php")
	    public void uploadpagetp(HttpServletRequest request,
	    		HttpServletResponse response) throws ServletException, IOException 
	    {
		 PrintWriter out = response.getWriter();
	 int sapid=(int) request.getSession().getAttribute("sapIDVettingSheet");
	 
		 String finaluploadPathbgv=(String) request.getSession().getAttribute("finaluploadPathbgv");
		 if(finaluploadPathbgv!=null){
			 
		 
	        System.out.println("servlet sapbgv "+sapid);
	        System.out.println("final path in controller bgv   "+finaluploadPathbgv);
	        jdbcTemplate.update("update mydb.ras set ras.Upload_Path_BGV_TP='"+finaluploadPathbgv+"' where ras.SAPCODE="+sapid);
		 request.setAttribute("message", "File successfully uploaded!!!");
		
		 out.println("<html><body><script>window.alert('File successfully uploaded!!!');window.close();</script></body></html>");
	}
else{
	 out.println("<html><body><script>alert('Error in uploading File!!!');window.location= '../../pmoAutomation/BgvCont/uploadBgvTp.php';</script></body></html>");
}
	    		
	    	//return " out.println("<html><body><script>alert('No Existing Document found');window.location= '../../pmoAutomation/Bgv/newBgvApproval.php';</script></body></html>");";
	    	}
	 @RequestMapping(value = "/uploadpageDU.php")
	    public void uploadpageDU(HttpServletRequest request,
	    		HttpServletResponse response) throws ServletException, IOException 
	    {
		 PrintWriter out = response.getWriter();
	 int sapid=(int) request.getSession().getAttribute("sapIDVettingSheetDU");
	 
		 String finaluploadPathbgv=(String) request.getSession().getAttribute("finaluploadPathbgvDU");
		 if(finaluploadPathbgv!=null){
			 
		 
	        System.out.println("servlet sapbgv du"+sapid);
	        System.out.println("final path in controller bgv  du "+finaluploadPathbgv);
	        jdbcTemplate.update("update mydb.ras set ras.Upload_Path_BGV_DU='"+finaluploadPathbgv+"' where ras.SAPCODE="+sapid);
		 request.setAttribute("message", "File successfully uploaded!!!");
		
		 out.println("<html><body><script>window.alert('File successfully uploaded!!!');window.location='../../pmoAutomation/VettingCont/againgetVetttingSheet.php';</script></body></html>");
	}
else{
	 out.println("<html><body><script>alert('Error in uploading File!!!');window.location= '../../pmoAutomation/BgvCont/uploadBgvTpDU.php';</script></body></html>");
}
	    		
	    	//return " out.println("<html><body><script>alert('No Existing Document found');window.location= '../../pmoAutomation/Bgv/newBgvApproval.php';</script></body></html>");";
	    	}
	 @RequestMapping(value = "/uploadpageDUrefer.php")
	    public void uploadpageDUrefer(HttpServletRequest request,
	    		HttpServletResponse response) throws ServletException, IOException 
	    {
		 PrintWriter out = response.getWriter();
	 int sapid=(int) request.getSession().getAttribute("sapIDVettingSheetDUrefer");
	 
		 String finaluploadPathbgv=(String) request.getSession().getAttribute("finaluploadPathbgvDUreferback");
		 if(finaluploadPathbgv!=null){
			 
		 
	        System.out.println("servlet sapbgv du"+sapid);
	        System.out.println("final path in controller bgv  du "+finaluploadPathbgv);
	        jdbcTemplate.update("update mydb.ras set ras.Upload_Path_BGV_DU='"+finaluploadPathbgv+"' where ras.SAPCODE="+sapid);
		 request.setAttribute("message", "File successfully uploaded!!!");
		
		 out.println("<html><body><script>window.alert('File successfully uploaded!!!');window.close();</script></body></html>");
	}
else{
	 out.println("<html><body><script>alert('Error in uploading File!!!');window.location= '../../pmoAutomation/BgvCont/uploadBgvTpDUreferback.php';</script></body></html>");
}
	    		
	    	//return " out.println("<html><body><script>alert('No Existing Document found');window.location= '../../pmoAutomation/Bgv/newBgvApproval.php';</script></body></html>");";
	    	}
	 @RequestMapping(value = "/ReferBackuploadpagetp.php")
	    public void ReferBackuploadpagetp(HttpServletRequest request,
	    		HttpServletResponse response) throws ServletException, IOException 
	    {
		 PrintWriter out = response.getWriter();
	 int sapid=(int) request.getSession().getAttribute("sapIDreferVettingSheet");
	 
		 String finaluploadPathbgv=(String) request.getSession().getAttribute("ReferbackfinaluploadPathbgv");
		 if(finaluploadPathbgv!=null){
			 
		 
	        System.out.println("servlet sapbgv refer "+sapid);
	        System.out.println("final path in controller bgv refer  "+finaluploadPathbgv);
	        jdbcTemplate.update("update mydb.ras set ras.Upload_Path_BGV_TP='"+finaluploadPathbgv+"' where ras.SAPCODE="+sapid);
		 request.setAttribute("message", "File successfully uploaded!!!");
		
		 out.println("<html><body><script>window.alert('File successfully uploaded!!!');window.close();</script></body></html>");
	}
else{
	 out.println("<html><body><script>alert('Error in uploading File!!!');window.close();</script></body></html>");
}
	    		
	    	//return " out.println("<html><body><script>alert('No Existing Document found');window.location= '../../pmoAutomation/Bgv/newBgvApproval.php';</script></body></html>");";
	    	}
	 @RequestMapping(value = "/pdfdownloadTp.php")
		public void pdfdownloadTP(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			
		
			String sapid=request.getParameter("searchsapforuploadtp");
			int sapidconvert=Integer.parseInt(sapid);
			System.out.println("controller sap from jsp    "+sapid);
			DownloadPathDao path=new DownloadPathDao();
			List<DownloadPathvo> downloadPathlink=path.DownloadPathTp(sapidconvert, jdbcTemplate);
			
			String[] array = new String[downloadPathlink.size()];
			int index = 0;
			for (Object value : downloadPathlink) {
				array[index] = String.valueOf( value );
			}
			
			HttpSession session = request.getSession();
	        session.setAttribute("downloadpathsessionTp", array[index]);
			// TODO:Spring Multipart enable it,Servlet disable it
			request.setAttribute("fileTypepdfdown", "pdfdownload");
			
			request.getRequestDispatcher("/fileUpload.downloadTp").forward(request,
					response);
			
	 }
	 @RequestMapping(value = "/pdfdownloadTpReport.php")
		public void pdfdownloadTpReport(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			
		
			String sapid=request.getParameter("searchsapforuploadtpReport");
			int sapidconvert=Integer.parseInt(sapid);
			System.out.println("controller sap from jsp    "+sapid);
			DownloadPathDao path=new DownloadPathDao();
			List<DownloadPathvo> downloadPathlink=path.DownloadPathTp(sapidconvert, jdbcTemplate);
			
			String[] array = new String[downloadPathlink.size()];
			int index = 0;
			for (Object value : downloadPathlink) {
				array[index] = String.valueOf( value );
			}
			
			HttpSession session = request.getSession();
	        session.setAttribute("downloadpathsessionTpReport", array[index]);
			// TODO:Spring Multipart enable it,Servlet disable it
			request.setAttribute("fileTypepdfdown", "pdfdownload");
			
			request.getRequestDispatcher("/fileUpload.downloadTpReport").forward(request,
					response);
			
	 }
	 
	 @RequestMapping(value = "/pdfdownloadDU.php")
		public void pdfdownloadDU(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			
		
			String sapid=request.getParameter("searchsapforuploadDU");
			int sapidconvert=Integer.parseInt(sapid);
			System.out.println("controller sap from jsp  du  "+sapid);
			DownloadPathDao path=new DownloadPathDao();
			List<DownloadPathvo> downloadPathlink=path.DownloadPathDU(sapidconvert, jdbcTemplate);
			
			String[] array = new String[downloadPathlink.size()];
			int index = 0;
			for (Object value : downloadPathlink) {
				array[index] = String.valueOf( value );
			}
			
			HttpSession session = request.getSession();
	        session.setAttribute("downloadpathsessionDU", array[index]);
			// TODO:Spring Multipart enable it,Servlet disable it
			request.setAttribute("fileTypepdfdown", "pdfdownload");
			
			request.getRequestDispatcher("/fileUpload.downloadDU").forward(request,
					response);
			
	 }
	 @RequestMapping(value = "/pdfdownloadDUreferback.php")
		public void pdfdownloadDUreferback(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			
		
			String sapid=request.getParameter("searchsapforuploadDUreferback");
			int sapidconvert=Integer.parseInt(sapid);
			System.out.println("controller sap from jsp  du  "+sapid);
			DownloadPathDao path=new DownloadPathDao();
			List<DownloadPathvo> downloadPathlink=path.DownloadPathDU(sapidconvert, jdbcTemplate);
			
			String[] array = new String[downloadPathlink.size()];
			int index = 0;
			for (Object value : downloadPathlink) {
				array[index] = String.valueOf( value );
			}
			
			HttpSession session = request.getSession();
	        session.setAttribute("downloadpathsessionDUreferback", array[index]);
			// TODO:Spring Multipart enable it,Servlet disable it
			request.setAttribute("fileTypepdfdown", "pdfdownload");
			
			request.getRequestDispatcher("/fileUpload.downloadDUreferback").forward(request,
					response);
			
	 }
	 @RequestMapping(value = "/pdfdownloadDUReport.php")
		public void pdfdownloadDUReport(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			
		
			String sapid=request.getParameter("searchsapforuploadDUReport");
			int sapidconvert=Integer.parseInt(sapid);
			System.out.println("controller sap from jsp  du  "+sapid);
			DownloadPathDao path=new DownloadPathDao();
			List<DownloadPathvo> downloadPathlink=path.DownloadPathDU(sapidconvert, jdbcTemplate);
			
			String[] array = new String[downloadPathlink.size()];
			int index = 0;
			for (Object value : downloadPathlink) {
				array[index] = String.valueOf( value );
			}
			
			HttpSession session = request.getSession();
	        session.setAttribute("downloadpathsessionDUReport", array[index]);
			// TODO:Spring Multipart enable it,Servlet disable it
			request.setAttribute("fileTypepdfdown", "pdfdownload");
			
			request.getRequestDispatcher("/fileUpload.downloadDUReport").forward(request,
					response);
			
	 }
	 
	 @RequestMapping(value = "/ReferBackdownloadTp.php")
		public void ReferBackdownloadTp(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			
		
			String sapid=request.getParameter("ReferBacksapforupload");
			int sapidconvert=Integer.parseInt(sapid);
			System.out.println("controller sap from jsp    "+sapid);
			DownloadPathDao path=new DownloadPathDao();
			List<DownloadPathvo> downloadPathlink=path.DownloadPathTp(sapidconvert, jdbcTemplate);
			
			String[] array = new String[downloadPathlink.size()];
			int index = 0;
			for (Object value : downloadPathlink) {
				array[index] = String.valueOf( value );
			}
			
			HttpSession session = request.getSession();
	        session.setAttribute("ReferBackdownloadpathsessionTp", array[index]);
			// TODO:Spring Multipart enable it,Servlet disable it
			request.setAttribute("fileTypepdfdown", "pdfdownload");
			
			request.getRequestDispatcher("/fileUpload.ReferBackdownloadTp").forward(request,
					response);
			
	 }
	 @RequestMapping(value = "/pdfdownloadviewvetting.php")
		public void pdfdownloadviewvetting(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			
		
			String sapid=request.getParameter("searchsapforviewvetting");
			int sapidconvert=Integer.parseInt(sapid);
			System.out.println("controller sap from jsp    "+sapid);
			DownloadPathDao path=new DownloadPathDao();
			List<DownloadPathvo> downloadPathlink=path.DownloadPathTp(sapidconvert, jdbcTemplate);
			
			String[] array = new String[downloadPathlink.size()];
			int index = 0;
			for (Object value : downloadPathlink) {
				array[index] = String.valueOf( value );
			}
			
			HttpSession session = request.getSession();
	        session.setAttribute("downloadpathsessionviewvetting", array[index]);
			// TODO:Spring Multipart enable it,Servlet disable it
			request.setAttribute("fileTypepdfdown", "pdfdownload");
			
			request.getRequestDispatcher("/fileUpload.downloadviewvetting").forward(request,
					response);
			
	 }
	 
	 @RequestMapping(value = "/pdfdownloadviewDU.php")
		public void pdfdownloadviewDU(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			
		
			String sapid=request.getParameter("searchsapforviewDU");
			int sapidconvert=Integer.parseInt(sapid);
			System.out.println("controller sap from jsp    "+sapid);
			DownloadPathDao path=new DownloadPathDao();
			List<DownloadPathvo> downloadPathlink=path.DownloadPathDU(sapidconvert, jdbcTemplate);
			
			String[] array = new String[downloadPathlink.size()];
			int index = 0;
			for (Object value : downloadPathlink) {
				array[index] = String.valueOf( value );
			}
			
			HttpSession session = request.getSession();
	        session.setAttribute("downloadpathsessionviewDU", array[index]);
			// TODO:Spring Multipart enable it,Servlet disable it
			request.setAttribute("fileTypepdfdown", "pdfdownload");
			
			request.getRequestDispatcher("/fileUpload.downloadviewDU").forward(request,
					response);
			
	 }
	 
	 
	@RequestMapping("/referbackupdate.php")
	public ModelAndView referBackUpdate(@ModelAttribute("EditVettingSheet1") Bgv bgv,HttpServletRequest request, HttpServletResponse response){
		
		System.out.println(request.getSession().getAttribute("sap_id"));
		
		System.out.println("check");
		System.out.println(bgv.getEditVettingSheet());
		
		

		
		
		
		
		String Name=request.getParameter("empname");
		String pjname = request.getParameter("pj");
		System.out.println("------------------------------"+pjname);
		//ReferBackServiceImpl refer=new ReferBackServiceImpl();
	//	refer.referBackPmo(jdbcTemplate, remarkReferBack, Integer.parseInt(obj));

		/*String pmoteam1="millie.p@hcl.com";
		String pmoteam2="abdulkarim.b@hcl.com";
		String manager="nagendrappan@hcl.com";
		String[] mails = {manager,pmoteam2,pmoteam1};*/
		
		
		
		
		return new ModelAndView("forward:../../pmoAutomation/BgvStatus/bgvStatus.php", "listOfEmployeeStatus",
				(new BgvServiceImpl()).referbackupdate(bgv, (int) request
				.getSession().getAttribute("managerId"), (int)request
				.getSession().getAttribute("sap_id"),
				jdbcTemplate, request)) ;
	}
	
	 @RequestMapping(value = "/DashboardStatus.php")
	    public String statuspage(HttpServletRequest request,
	    		HttpServletResponse response) throws ServletException, IOException 
	    {
		 try{
	    int sapid=(int) request.getSession().getAttribute("managerId");
	    
	    	String loginName = (String)request.getSession().getAttribute("LOGINNAME");
			request.setAttribute("LOGINNAME", loginName);
	    	
	    
	    	
	    	
	    	
	    	
	    	BGVActiondao  bgvManagerDashboard =new BGVActiondao();
	    	List<Dashboardvo> referback=bgvManagerDashboard.referBackStatus(sapid, jdbcTemplate);
	    	List<Dashboardvo> pendingWithPmo=bgvManagerDashboard.pendingWithPmo(sapid, jdbcTemplate);
	    	List<Dashboardvo> pendingWithCentralBgv=bgvManagerDashboard.pendingWithCentralBgv(sapid, jdbcTemplate);
	    	List<Dashboardvo> pendingWithVendor=bgvManagerDashboard.pendingWithVendor(sapid, jdbcTemplate);
	    	List<Dashboardvo> pendingWithResource=bgvManagerDashboard.pendingWithResource(sapid, jdbcTemplate);
	  //  	List<Dashboardvo> resourcePreCheckPending=bgvManagerDashboard.resourcePreCheckPending(sapid, jdbcTemplate);
	    	List<Dashboardvo> precheckCompleted=bgvManagerDashboard.precheckCompleted(sapid, jdbcTemplate);
	    	List<Dashboardvo> resourcePostCheckPending=bgvManagerDashboard.postcheckpending(sapid, jdbcTemplate);
	    	List<Dashboardvo> postcheckCompleted=bgvManagerDashboard.postcheckCompleted(sapid, jdbcTemplate);
	    	
	    	request.setAttribute("statusreferback",referback);
	    	System.out.println("referBackStatus" +referback);
	    	request.setAttribute("statuspendingWithPmo",pendingWithPmo);
	    	System.out.println("pendingWithPmo" +pendingWithPmo);
	    	request.setAttribute("statuspendingWithCentralBgv", pendingWithCentralBgv);
	    	System.out.println("1" +pendingWithCentralBgv);
	    	request.setAttribute("statuspendingWithVendor", pendingWithVendor);
	    	System.out.println("2" +pendingWithVendor);
	    	request.setAttribute("statuspendingWithResource", pendingWithResource);
	    	System.out.println("3" +pendingWithResource);
	  //  	request.setAttribute("statusresourcePreCheckPending", resourcePreCheckPending);
	   // 	System.out.println("4" +resourcePreCheckPending);
	    	request.setAttribute("statusprecheckCompleted", precheckCompleted);
	    	System.out.println("5" +precheckCompleted);
	    	request.setAttribute("statusresourcePostCheckPending", resourcePostCheckPending);
	    	System.out.println("4" +resourcePostCheckPending);
	    	request.setAttribute("statuspostcheckCompleted", postcheckCompleted);
	    	System.out.println("5" +postcheckCompleted);
	    	
		 }
		 catch(Exception e){
			 /*return "forward:../../pmoAutomation/Login/errorPage.php";*/
		 }
	    		return "Bgv/BGVdashboard";

	    	}
	 @RequestMapping(value = "/pmoDashboardStatus.php")
	    public String pmoDashboardStatus(HttpServletRequest request,
	    		HttpServletResponse response) throws ServletException, IOException 
	    {
		 try{
	   
	        BgvDashboardDao  bgvDashboard =new BgvDashboardDao();
	    	List<PmoDashBoard> pendingWithPmo=bgvDashboard.pendingWithPmo( jdbcTemplate);
	    	List<PmoDashBoard> pendingWithCentralBgv=bgvDashboard.pendingWithCentralBgv(jdbcTemplate);	    	
	    	List<PmoDashBoard> pendingWithResource=bgvDashboard.pendingWithResource( jdbcTemplate);
	    	List<PmoDashBoard> pendingWithVendor=bgvDashboard.pendingWithVendor( jdbcTemplate);
	    //	List<PmoDashBoard> resourcePreCheckPending=bgvDashboard.resourcePreCheckPending( jdbcTemplate);
	    	List<PmoDashBoard> precheckCompleted=bgvDashboard.precheckCompleted( jdbcTemplate);
	    	List<PmoDashBoard> postcheckpending=bgvDashboard.postcheckpending( jdbcTemplate);
	    	List<PmoDashBoard> postcheckcompleted=bgvDashboard.postcheckCompleted( jdbcTemplate);
	    	request.setAttribute("statuspendingWithPmo",pendingWithPmo);
	    	System.out.println("pendingWithPmo" +pendingWithPmo);
	    	request.setAttribute("statuspendingWithCentralBgv", pendingWithCentralBgv);
	    	System.out.println("1" +pendingWithCentralBgv);
	    	request.setAttribute("statuspendingWithVendor", pendingWithVendor);
	    	System.out.println("2" +pendingWithVendor);
	    	request.setAttribute("statuspendingWithResource", pendingWithResource);
	    	System.out.println("3" +pendingWithResource);
	    //	request.setAttribute("statusresourcePreCheckPending", resourcePreCheckPending);
	    //	System.out.println("4" +resourcePreCheckPending);
	    	request.setAttribute("statusprecheckCompleted", precheckCompleted);
	    	System.out.println("5" +precheckCompleted);
	    	request.setAttribute("statuspostcheckpending", postcheckpending);
	    	System.out.println("6" +postcheckpending);
	    	request.setAttribute("statuspostcheckCompleted", postcheckcompleted);
	    	System.out.println("7" +postcheckcompleted);
	    	
	    	
		 }
		 catch(Exception e){
	return "forward:../../pmoAutomation/Login/errorPage.php";
			// e.printStackTrace();
		 }
	    		return "Bgv/Bgvinitpmoapl";

	    	}
	 
	 

	 @RequestMapping(value = "/getbgvtypeusingregulatoryregion.php", method = RequestMethod.GET)
		public void getbgvtypeusingregulatoryregion(HttpServletRequest request,
				HttpServletResponse response) throws Exception,ServletException, IOException {
System.out.println("entered.........");
		 BGVActiondao  BGVAction =new BGVActiondao();
	    			response.getWriter().print(
	    					BGVAction.getbgvtypeusingregulatoryregion(jdbcTemplate,
							(String) request.getParameter("regulatoryregion")));
			
		}
	 @RequestMapping(value = "/uploadpage.php")
	    public String uploadpage(HttpServletRequest request,
	    		HttpServletResponse response) throws ServletException, IOException 
	    {
		 
	    		//return "redirect:../../pmoAutomation/Bgv/newBgvApproval.php";
	    	return "Bgv/uploadjsp";
	    	}
		
	 @RequestMapping(value = "/pdfUpload.php", method = RequestMethod.POST)
		public void excaliburUpload(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			System.out.println("hi iam in controller");
			// Internally hitting another Servlet

			// TODO:Spring Multipart enable it,Servlet disable it
			request.setAttribute("fileTypepdf", "pdfupload");
			request.getRequestDispatcher("/fileUpload.assspx").forward(request,
					response);
	 }
	 @RequestMapping(value = "/pdfdownload.php")
		public void pdfdownload(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			System.out.println("hi iam in controller");
			// Internally hitting another Servlet

			// TODO:Spring Multipart enable it,Servlet disable it
			request.setAttribute("fileTypepdfdown", "pdfdownload");
			request.getRequestDispatcher("/fileUpload.assspxd").forward(request,
					response);
	 }
	 @RequestMapping(value = "/downloadpage.php")
	    public String downloadpage(HttpServletRequest request,
	    		HttpServletResponse response) throws ServletException, IOException 
	    {
		 
	    		//return "redirect:../../pmoAutomation/Bgv/newBgvApproval.php";
	    		return "Bgv/sample";
	    	}
	 
	 
	 @RequestMapping(value = "/BGVuploadpage.php", method = RequestMethod.GET)
	 	public String BGVUpload(HttpServletRequest request,
	 			HttpServletResponse response) throws ServletException, IOException 
	 	{

	 			return "Bgv/BgvUploadP";

	 		}

	 		@RequestMapping(value = "/BgvExcelUpload.php", method = RequestMethod.POST)
	 		public void uplaodRASFile(HttpServletRequest request,
	 				HttpServletResponse response) throws ServletException, IOException {

	 			
	 			
	 			
	 			request.setAttribute("fileType", "Bgv_Data");
	 			request.getRequestDispatcher("/fileUpload.bgvup").forward(request,
	 					response);

	 		
	 		
	 	}
	 	  
	 	@RequestMapping(value = "/BgvExcelReadSave.php", method = RequestMethod.POST)
	 	public String rasExcelRedingAndSaving(HttpServletRequest request,
	 			HttpServletResponse response) throws ServletException, IOException {
System.out.println("con path  "+(String) request.getAttribute("filePathBGV"));
	 		Bgvservice rasService = new BgvServiceUpImp();
	 		boolean resultFlag = rasService.saveBGVDump(
	 				(String) request.getAttribute("filePathBGV"),
	 				ExcelSheetConstant.BGVSHEETNAME,
	 				ExcelSheetConstant.BGVTABLENAME, jdbcTemplate);
	 		String excaliburSaveResult = resultFlag == true ? "Successfully Uploaded!!!"
	 				: "Error!!!Uploading the File";
	 		request.setAttribute("uploadDataSaveResult", excaliburSaveResult);
	 		return "Bgv/BgvUploadP";

	 	}
		@RequestMapping(value = "/BGVUPLOAD.php", method = RequestMethod.POST)
	 	public String BGVUPLOAD(HttpServletRequest request,
	 			HttpServletResponse response) throws ServletException, IOException {

	 	
	 		return "Bgv/BgvUploadP";

	 	}
	@RequestMapping(value="/searchDetails.php")
		
		public String bgvSearch(HttpServletRequest request,
	 			HttpServletResponse response) throws ServletException {
		try{
			String sapid = request.getParameter("search");
			BgvStatusSearchDao status=new BgvStatusSearchDao();
			List<BgvStatusSearchVO> search=status.list(sapid, jdbcTemplate);
			
			request.setAttribute("search",search);

			boolean resultflag=search.isEmpty();
	
		
		if (resultflag) {
			request.setAttribute("searchrecordsnotfound", "No Record Found For Search SapID");

		} else {
			request.setAttribute("searchrecordsfound", "Record found");
		}
		
		
			 BgvDashboardDao  bgvDashboard =new BgvDashboardDao();
		    	List<PmoDashBoard> pendingWithPmo=bgvDashboard.pendingWithPmo( jdbcTemplate);
		    	List<PmoDashBoard> pendingWithCentralBgv=bgvDashboard.pendingWithCentralBgv(jdbcTemplate);
		    	List<PmoDashBoard> pendingWithVendor=bgvDashboard.pendingWithVendor( jdbcTemplate);
		    	List<PmoDashBoard> pendingWithResource=bgvDashboard.pendingWithResource( jdbcTemplate);
		    //	List<PmoDashBoard> resourcePreCheckPending=bgvDashboard.resourcePreCheckPending( jdbcTemplate);
		    	List<PmoDashBoard> precheckCompleted=bgvDashboard.precheckCompleted( jdbcTemplate);
		    	List<PmoDashBoard> postcheckpending=bgvDashboard.postcheckpending( jdbcTemplate);
		    	List<PmoDashBoard> postcheckcompleted=bgvDashboard.postcheckCompleted( jdbcTemplate);
		    	request.setAttribute("statuspendingWithPmo",pendingWithPmo);
		    	System.out.println("pendingWithPmo" +pendingWithPmo);
		    	request.setAttribute("statuspendingWithCentralBgv", pendingWithCentralBgv);
		    	System.out.println("1" +pendingWithCentralBgv);
		    	request.setAttribute("statuspendingWithVendor", pendingWithVendor);
		    	System.out.println("2" +pendingWithVendor);
		    	request.setAttribute("statuspendingWithResource", pendingWithResource);
		    	System.out.println("3" +pendingWithResource);
		    //	request.setAttribute("statusresourcePreCheckPending", resourcePreCheckPending);
		    //	System.out.println("4" +resourcePreCheckPending);
		    	request.setAttribute("statusprecheckCompleted", precheckCompleted);
		    	System.out.println("5" +precheckCompleted);
		    	request.setAttribute("statuspostcheckpending", postcheckpending);
		    	System.out.println("6" +postcheckpending);
		    	request.setAttribute("statuspostcheckCompleted", postcheckcompleted);
		    	System.out.println("7" +postcheckcompleted);
	 }
	 catch(Exception e){
	return "forward:../../pmoAutomation/Login/errorPage.php";
	 }
			
			return "Bgv/Bgvinitpmoapl";
			
		}
	@RequestMapping(value="/viewdetailsforbgvstatus.php")
	
	public String viewdetailsforbgvstatus(HttpServletRequest request,
 			HttpServletResponse response) throws ServletException {
	try{
		String sapid = request.getParameter("viewdetailsusingsapforbgv");
		BgvStatusSearchDao status=new BgvStatusSearchDao();
		List<BgvStatusSearchVO> search=status.list(sapid, jdbcTemplate);
		
		request.setAttribute("search",search);

 }
 catch(Exception e){
return "forward:../../pmoAutomation/Login/errorPage.php";
 }
		
		return "Bgv/Bgvstatusindashboard";
		
	}
	
	@RequestMapping(value="/searchDetailsformanagersap.php")
	
	public String searchDetailsformanagersap(HttpServletRequest request,
 			HttpServletResponse response) throws ServletException {
	try{
		String sapids = request.getParameter("search");
		int sapid = Integer.parseInt(sapids);
		BgvStatusSearchDao status=new BgvStatusSearchDao();
		int loginid = (int)request.getSession().getAttribute("managerId");
		List<BgvStatusSearchVO> search=status.searchdatabasedonmanagersap(sapid, loginid, jdbcTemplate);
		
		request.setAttribute("search",search);

		boolean resultflag=search.isEmpty();

	
		if (resultflag) {
			request.setAttribute("searchrecordsnotfound", "No Record Found For Search SapID");

		} else {
			request.setAttribute("searchrecordsfound", "Record found");
		}
	
	

	BGVActiondao  bgvManagerDashboard =new BGVActiondao();
	List<Dashboardvo> referback=bgvManagerDashboard.referBackStatus(loginid, jdbcTemplate);
	List<Dashboardvo> pendingWithPmo=bgvManagerDashboard.pendingWithPmo(loginid, jdbcTemplate);
	List<Dashboardvo> pendingWithCentralBgv=bgvManagerDashboard.pendingWithCentralBgv(loginid, jdbcTemplate);
	List<Dashboardvo> pendingWithVendor=bgvManagerDashboard.pendingWithVendor(loginid, jdbcTemplate);
	List<Dashboardvo> pendingWithResource=bgvManagerDashboard.pendingWithResource(loginid, jdbcTemplate);
	//List<Dashboardvo> resourcePreCheckPending=bgvManagerDashboard.resourcePreCheckPending(loginid, jdbcTemplate);
	List<Dashboardvo> precheckCompleted=bgvManagerDashboard.precheckCompleted(loginid, jdbcTemplate);
	List<Dashboardvo> resourcePostCheckPending=bgvManagerDashboard.postcheckpending(loginid, jdbcTemplate);
	List<Dashboardvo> postcheckCompleted=bgvManagerDashboard.postcheckCompleted(loginid, jdbcTemplate);
	
	request.setAttribute("statusreferback",referback);
	System.out.println("referBackStatus" +referback);
	request.setAttribute("statuspendingWithPmo",pendingWithPmo);
	System.out.println("pendingWithPmo" +pendingWithPmo);
	request.setAttribute("statuspendingWithCentralBgv", pendingWithCentralBgv);
	System.out.println("1" +pendingWithCentralBgv);
	request.setAttribute("statuspendingWithVendor", pendingWithVendor);
	System.out.println("2" +pendingWithVendor);
	request.setAttribute("statuspendingWithResource", pendingWithResource);
	System.out.println("3" +pendingWithResource);
//	request.setAttribute("statusresourcePreCheckPending", resourcePreCheckPending);
//	System.out.println("4" +resourcePreCheckPending);
	request.setAttribute("statusprecheckCompleted", precheckCompleted);
	System.out.println("5" +precheckCompleted);
	request.setAttribute("statusresourcePostCheckPending", resourcePostCheckPending);
	System.out.println("4" +resourcePostCheckPending);
	request.setAttribute("statuspostcheckCompleted", postcheckCompleted);
	System.out.println("5" +postcheckCompleted);
 }
 catch(Exception e){
return "forward:../../pmoAutomation/Login/errorPage.php";
 }
		
		return "Bgv/BGVdashboard";
		
	}

@RequestMapping(value="/viewDetailsformanagersap.php")
	
	public String viewDetailsformanagersap(HttpServletRequest request,
 			HttpServletResponse response) throws ServletException {
	try{
		String sapids = request.getParameter("viewdetailsusingsapforbgv");
		int sapid = Integer.parseInt(sapids);
		BgvStatusSearchDao status=new BgvStatusSearchDao();
		int loginid = (int)request.getSession().getAttribute("managerId");
		List<BgvStatusSearchVO> search=status.searchdatabasedonmanagersap(sapid, loginid, jdbcTemplate);
		
		request.setAttribute("search",search);

		

	
	

	
 }
 catch(Exception e){
return "forward:../../pmoAutomation/Login/errorPage.php";
 }
		
		return "Bgv/Bgvstatusindashboardformanager";
		
	}
}



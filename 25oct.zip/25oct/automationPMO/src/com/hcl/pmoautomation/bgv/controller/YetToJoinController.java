package com.hcl.pmoautomation.bgv.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hcl.pmoautomation.bgv.dao.YetToJoinDao;
import com.hcl.pmoautomation.bgv.model.Tsc;

import jdk.nashorn.internal.ir.RuntimeNode.Request;


@Controller
@RequestMapping("pmoAutomation/YTJCont")
public class YetToJoinController {
	@Autowired
	 JdbcTemplate jdbcTemplate;
		
	
	@RequestMapping(value = "/YTJInitiatedCases.php")
	public String YTJinitiated(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		YetToJoinDao ytj=new YetToJoinDao();
		List<Tsc> initiatedcasesytj=ytj.yettojoininitiateddetails(jdbcTemplate);
		request.setAttribute("initiatedytjcases", initiatedcasesytj);
		return "Bgv/YTJInitiatedCases";
		
	}
		

		@RequestMapping(value = "/yettojoinymovingtosapid.php")
		public String yettojoinymovingtosap(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			String viewdetailsusingcvidytj=request.getParameter("viewdetailsusingcvidforytj");
			YetToJoinDao ytj=new YetToJoinDao();
			List<Tsc> mergingytj=ytj.yettojoinymergingdetails(viewdetailsusingcvidytj,jdbcTemplate);
			request.setAttribute("mergingytjdetails", mergingytj);
			
		 	System.out.println("viewdetails   "+viewdetailsusingcvidytj);
			return "Bgv/yettojoinymovingtosapid";
			
	}
		@RequestMapping(value = "/yettojoinymovedtobgv.php") 
		public void yettojoinymovedtobgv(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			try{
		String sapid=request.getParameter("sapid");
		String cvid=request.getParameter("cvid");
		jdbcTemplate.update("update mydb.yettojoin set yettojoin.Sap_id="+sapid+", yettojoin.Active_Flag='Y' where  yettojoin.CV_ID="+cvid);
		
	jdbcTemplate.update("update mydb.bgv set "
			+ "bgv.REQUESTED_DATE_BY_DEL=(select yettojoin.BGVTriggeredDate from mydb.yettojoin where yettojoin.Sap_id="+sapid+"),"
			+ "	bgv.PRE_START_CHECK_WITH_PMO='Initiated',"
			+ "bgv.PRE_START_CHECK_WITH_CENTRAL_BGV='Initiated',"
			+ "bgv.PRE_START_CHECK_WITH_CENTRAL_BGV_DATE=(select yettojoin.BGVInitiatedOn from mydb.yettojoin where yettojoin.Sap_id="+sapid+"),"
			+ "bgv.PRE_START_CHECK_WITH_RESOURCE='Y',"
			+ "bgv.Yet_to_joinee='Y' where bgv.SAP_ID="+sapid);
	
	
			}
			catch(Exception e){
				e.printStackTrace();
				/*PrintWriter out = response.getWriter();
				out.println("<html><body><script>alert('Something went wrong');window.close();</script></body></html>");
			*/}
			 PrintWriter out = response.getWriter();
			 out.println("<html><body><script type=\"text/javascript\">alert('Successfully Merged');window.location='../../pmoAutomation/YTJCont/YTJInitiatedCases.php';</script></body></html>");
			
			
		}
}


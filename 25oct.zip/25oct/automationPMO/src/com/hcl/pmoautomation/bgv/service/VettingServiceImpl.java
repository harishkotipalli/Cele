package com.hcl.pmoautomation.bgv.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.hcl.pmoautomation.bgv.dao.VettingDaoI;
import com.hcl.pmoautomation.bgv.dao.VettingDaoImpl;
import com.hcl.pmoautomation.bgv.model.Bgv1;
import com.hcl.pmoautomation.bgv.model.EditVettingSheet;
import com.hcl.pmoautomation.bgv.model.VettingSheet;


public class VettingServiceImpl implements VettingServiceI {

  VettingDaoI vettingDaoI;
	
	@Override
	public VettingSheet getVetting(int id, int sap_id,JdbcTemplate jdbcTemplet) {
System.out.println("VettingServiceImpl executed sucessfuly !!!!!!!!!!!!!!!!!!!");
System.out.println(id);
//System.out.println(jdbcTemplet);
return (new VettingDaoImpl()).getVettingSheet(id,sap_id,jdbcTemplet);
	}
	

	@Override
	public VettingSheet getVetting(int id,JdbcTemplate jdbcTemplet) {
		System.out.println("VettingServiceImpl executed sucessfuly !!!!!!!!!!!!!!!!!!!");
		System.out.println(id);
	 		 return (new VettingDaoImpl()).getVettingSheet(id,jdbcTemplet);

	}

	@Override
	public Bgv1 getVettingSheet(int sap_id, JdbcTemplate jdbcTemplet) {
		System.out.println(sap_id);
		return null;
	}


	@Override
	public EditVettingSheet getEditVettingSheet(int sap_id, JdbcTemplate jdbcTemplet) {
		
		return (new VettingDaoImpl()).getEditVettingSheet(sap_id, jdbcTemplet);
	}






	

}

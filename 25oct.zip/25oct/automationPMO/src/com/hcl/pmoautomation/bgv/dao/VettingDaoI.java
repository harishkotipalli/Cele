package com.hcl.pmoautomation.bgv.dao;

import org.springframework.jdbc.core.JdbcTemplate;

import com.hcl.pmoautomation.bgv.model.Bgv1;
import com.hcl.pmoautomation.bgv.model.EditVettingSheet;
import com.hcl.pmoautomation.bgv.model.VettingSheet;



public interface VettingDaoI {
	public VettingSheet getVettingSheet(int id, int sap_id, JdbcTemplate jdbcTemplet);
	public Bgv1 getVettingSheetView(int sap_id, JdbcTemplate jdbcTemplet);
	public EditVettingSheet getEditVettingSheet(int sap_id,JdbcTemplate jdbcTemplet);
//	public VettingSheet getVettingSheet(int id, int sap_id);

//	public Object getVettingSheet(int id);

	public VettingSheet getVettingSheet(int id,JdbcTemplate jdbcTemplet);

}

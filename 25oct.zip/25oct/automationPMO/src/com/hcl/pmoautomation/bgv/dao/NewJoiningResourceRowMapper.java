package com.hcl.pmoautomation.bgv.dao;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.hcl.pmoautomation.bgv.model.EmployeeNewJoining;



public class NewJoiningResourceRowMapper implements RowMapper<EmployeeNewJoining>, Serializable {


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public EmployeeNewJoining mapRow(ResultSet neJoingResultSet, int arg1) throws SQLException {
		EmployeeNewJoining employeeNewJoining=new EmployeeNewJoining();
		employeeNewJoining.setProject_name(neJoingResultSet.getString("PROJECT_NAME"));
		employeeNewJoining.setRas_Start_Date(neJoingResultSet.getDate("RAS_START_DATE"));
		employeeNewJoining.setRas_end_date(neJoingResultSet.getDate("RAS_END_DATE"));
		employeeNewJoining.setResource_Name(neJoingResultSet.getString("EMPNAME"));
		employeeNewJoining.setSap_Id(neJoingResultSet.getInt("SAPCODE"));
		employeeNewJoining.setCV_ID(neJoingResultSet.getInt("CV_ID"));
		employeeNewJoining.setRas_id(neJoingResultSet.getInt("id"));
		employeeNewJoining.setRas_status(neJoingResultSet.getString("RAS_Status"));
		employeeNewJoining.setGpn_status(neJoingResultSet.getString("GPN_Status"));
		System.out.println(employeeNewJoining);
		return employeeNewJoining;
	}
	
		
	
}

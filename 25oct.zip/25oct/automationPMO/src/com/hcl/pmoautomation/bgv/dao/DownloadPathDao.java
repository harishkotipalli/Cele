package com.hcl.pmoautomation.bgv.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.hcl.pmoautomation.bgv.model.DownloadPathvo;



public class DownloadPathDao {
	public List<DownloadPathvo> DownloadPath(int sapid,JdbcTemplate jdbcTemplate) 
	{
		
	 	String sql = DataBaseQueryBGVdashboard.QUERY_TO_FETCH_download_path+sapid;
		
		
		System.out.println(sql);
	   
	    		 List<DownloadPathvo> listaa = jdbcTemplate.query(sql, new RowMapper<DownloadPathvo>() 
		 {
			@Override
			public DownloadPathvo mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				DownloadPathvo dp = new DownloadPathvo();
				dp.setUploadpath(rs.getString("Upload_Path"));
				
				return dp;
			}
	 	
	    });		
	    return listaa;
	    
	    }
	
	public List<DownloadPathvo> DownloadPathDUYTJ(String sapid,JdbcTemplate jdbcTemplate) 
	{
		
	 	String sql = DataBaseQueryBGVdashboard.QUERY_TO_FETCH_download_path_DU_YTJ+sapid+"'";
		
		
		System.out.println(sql);
	   
	    		 List<DownloadPathvo> listaa = jdbcTemplate.query(sql, new RowMapper<DownloadPathvo>() 
		 {
			@Override
			public DownloadPathvo mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				DownloadPathvo dp = new DownloadPathvo();
				dp.setUploadpath(rs.getString("Du_path"));
				
				return dp;
			}
	 	
	    });		
	    return listaa;
	    
	    }
	public List<DownloadPathvo> DownloadPathTPYTJ(String sapid,JdbcTemplate jdbcTemplate) 
	{
		
	 	String sql = DataBaseQueryBGVdashboard.QUERY_TO_FETCH_download_path_TP_YTJ+sapid+"'";
		
		
		System.out.println(sql);
	   
	    		 List<DownloadPathvo> listaa = jdbcTemplate.query(sql, new RowMapper<DownloadPathvo>() 
		 {
			@Override
			public DownloadPathvo mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				DownloadPathvo dp = new DownloadPathvo();
				dp.setUploadpath(rs.getString("Tp_path"));
				
				return dp;
			}
	 	
	    });		
	    return listaa;
	    
	    }
	public List<DownloadPathvo> DownloadPathforpostcheckvetting(int sapid,JdbcTemplate jdbcTemplate) 
	{
		
	 	String sql = DataBaseQueryBGVdashboard.QUERY_TO_FETCH_download_path_vetting_post_final+sapid;
		
		
		System.out.println(sql);
	   
	    		 List<DownloadPathvo> listaa = jdbcTemplate.query(sql, new RowMapper<DownloadPathvo>() 
		 {
			@Override
			public DownloadPathvo mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				DownloadPathvo dp = new DownloadPathvo();
				dp.setUploadpath(rs.getString("Upload_Path_Vetting_postcheck"));
				
				return dp;
			}
	 	
	    });		
	    return listaa;
	    
	    }
	public List<DownloadPathvo> DownloadPathTp(int sapid,JdbcTemplate jdbcTemplate) 
	{
		
	 	String sql = DataBaseQueryBGVdashboard.QUERY_TO_FETCH_download_path_tp+sapid;
		
		
		System.out.println(sql);
	   
	    		 List<DownloadPathvo> listaa = jdbcTemplate.query(sql, new RowMapper<DownloadPathvo>() 
		 {
			@Override
			public DownloadPathvo mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				DownloadPathvo dp = new DownloadPathvo();
				dp.setUploadpath(rs.getString("Upload_Path_BGV_TP"));
				
				return dp;
			}
	 	
	    });		
	    return listaa;
	    
	    }
	public List<DownloadPathvo> DownloadPathDU(int sapid,JdbcTemplate jdbcTemplate) 
	{
		
	 	String sql = DataBaseQueryBGVdashboard.QUERY_TO_FETCH_download_path_DU+sapid;
		
		
		System.out.println(sql);
	   
	    		 List<DownloadPathvo> listaa = jdbcTemplate.query(sql, new RowMapper<DownloadPathvo>() 
		 {
			@Override
			public DownloadPathvo mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				DownloadPathvo dp = new DownloadPathvo();
				dp.setUploadpath(rs.getString("Upload_Path_BGV_DU"));
				
				return dp;
			}
	 	
	    });		
	    return listaa;
	    
	    }
	
	public List<DownloadPathvo> DownloadPathjustification(int sapid,JdbcTemplate jdbcTemplate) 
	{
		
	 	String sql = DataBaseQueryBGVdashboard.QUERY_TO_FETCH_download_path_justification+sapid;
		
		
		System.out.println(sql);
	   
	    		 List<DownloadPathvo> listaa = jdbcTemplate.query(sql, new RowMapper<DownloadPathvo>() 
		 {
			@Override
			public DownloadPathvo mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				DownloadPathvo dp = new DownloadPathvo();
				dp.setUploadpath(rs.getString("Upload_Path_justification"));
				
				return dp;
			}
	 	
	    });		
	    return listaa;
	    
	    }
	public List<DownloadPathvo> DownloadPathclearance(int sapid,JdbcTemplate jdbcTemplate) 
	{
		
	 	String sql = DataBaseQueryBGVdashboard.QUERY_TO_FETCH_download_path_Clearance+sapid;
		
		
		System.out.println(sql);
	   
	    		 List<DownloadPathvo> listaa = jdbcTemplate.query(sql, new RowMapper<DownloadPathvo>() 
		 {
			@Override
			public DownloadPathvo mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				DownloadPathvo dp = new DownloadPathvo();
				dp.setUploadpath(rs.getString("Upload_Path_Clearance"));
				
				return dp;
			}
	 	
	    });		
	    return listaa;
	    
	    }
	public List<DownloadPathvo> DownloadPathIdDocument(int sapid,JdbcTemplate jdbcTemplate) 
	{
		
	 	String sql = DataBaseQueryBGVdashboard.QUERY_TO_FETCH_download_path_IdDocument+sapid;
		
		
		System.out.println(sql);
	   
	    		 List<DownloadPathvo> listaa = jdbcTemplate.query(sql, new RowMapper<DownloadPathvo>() 
		 {
			@Override
			public DownloadPathvo mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				DownloadPathvo dp = new DownloadPathvo();
				dp.setUploadpath(rs.getString("Upload_Path_IdDocument"));
				
				return dp;
			}
	 	
	    });		
	    return listaa;
	    
	    }
	
public List<DownloadPathvo> DownloadPathpostjustification(int sapid,JdbcTemplate jdbcTemplate) 
{
	
 	String sql = DataBaseQueryBGVdashboard.QUERY_TO_FETCH_download_path_Post_justification+sapid;
	
	
	System.out.println(sql);
   
    		 List<DownloadPathvo> listaa = jdbcTemplate.query(sql, new RowMapper<DownloadPathvo>() 
	 {
		@Override
		public DownloadPathvo mapRow(ResultSet rs, int rowNum) throws SQLException 
		{
			DownloadPathvo dp = new DownloadPathvo();
			dp.setUploadpath(rs.getString("Upload_Path_Justification_Post"));
			
			return dp;
		}
 	
    });		
    return listaa;
    
    }
}
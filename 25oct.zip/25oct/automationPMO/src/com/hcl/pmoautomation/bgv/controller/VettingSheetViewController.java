package com.hcl.pmoautomation.bgv.controller;

import java.util.List;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.portlet.ModelAndView;

import com.hcl.pmoautomation.bgv.dao.VettingSheetRowmapper;
import com.hcl.pmoautomation.bgv.model.BgvVO;


@Controller
@RequestMapping(value =  "pmoAutomation/VettingSheetView")
public class VettingSheetViewController {
	@Autowired
	JdbcTemplate jdbcTemplate;
	

	@RequestMapping("/viewVetting.php")
	
		
		public String viewVettingSheet(HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException
	
	{
		
		
		
		String sapid=request.getParameter("search");
		
		VettingSheetRowmapper vb= new VettingSheetRowmapper();
	
		 List<BgvVO> view=vb.viewBGV(sapid, jdbcTemplate);	
		request.setAttribute("view",view);
		
		
		return "Bgv/vetingsheet" ;
		
	}

}

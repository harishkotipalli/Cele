package com.hcl.pmoautomation.bgv.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.hcl.pmoautomation.bgv.model.Bgv1;
import com.hcl.pmoautomation.bgv.model.BgvVO;
import com.hcl.pmoautomation.bgv.utilities.BgvSql;
import com.hcl.pmoautomation.ot.dao.DatabaseQuery;

public class VettingSheetRowmapper implements RowMapper<Bgv1>{
	

	@Override
	public Bgv1 mapRow(ResultSet rs, int index) throws SQLException {
		Bgv1 vtview = new Bgv1();
		vtview.setFirst_Name(rs.getString("first_Name"));
		vtview.setProject_Name(rs.getString("project_Name"));
		vtview.setProject_Code(rs.getString("project_Code"));
		vtview.setSector(rs.getString("sector"));
		vtview.setTp_Resource(rs.getString("tp_Resource"));
		vtview.setPersonal_Mail_Id(rs.getString("personal_Mail_Id"));
		vtview.setOfficial_Mail_id(rs.getString("official_Mail_id"));
		vtview.setContact_Number(rs.getInt("contact_Number"));
		vtview.setUbs_Mail(rs.getString("ubs_Mail"));
		vtview.setGpn(rs.getString("gpn"));
		vtview.setAssignment_Details_Start_Date(rs.getDate("assignment_Details_Start_Date"));
		vtview.setAssignment_Details_End_Date(rs.getDate("assignment_Details_End_Date"));
		vtview.setRegulatory_Region_country(rs.getString("regulatory_Region_country"));
		vtview.setCountry(rs.getString("country"));
		vtview.setUbs_Hiring_Manager_email_Id(rs.getString("ubs_Hiring_Manager_email_Id"));
		vtview.setUbs_Hiring_Manager_Gpn(rs.getInt("ubs_Hiring_Manager_Gpn"));
		vtview.setPrevisouly_Worked_With_Ubs(rs.getString("previsouly_Worked_With_Ubs"));
		vtview.setLegal_First_Name(rs.getString("legal_First_Name"));
		vtview.setLegal_Last_Name(rs.getString("legal_Last_Name"));
		vtview.setNationality(rs.getString("nationality"));
		vtview.setPrefered_business_name(rs.getString("prefered_business_name"));
		vtview.setGender(rs.getString("gender"));
		vtview.setDate_of_Birth(rs.getDate("date_of_Birth"));
		vtview.setCorrespondence_Language(rs.getString("correspondence_Language"));
		vtview.setDepartment_Ou_Code(rs.getString("department_Ou_Code"));
		vtview.setWork_Location(rs.getString("work_Location"));
		
		
		return vtview;

}
    public List<BgvVO> viewBGV( String sapid,JdbcTemplate jdbcTemplate)

    {

           String sql = BgvSql.getbgv_viewBGV+sapid+"'";

           

           List<BgvVO> bgvView = jdbcTemplate.query(sql, new RowMapper<BgvVO>() 
 {
 @Override
public BgvVO mapRow(ResultSet rs, int rowNum) throws SQLException 

           {

                        	BgvVO obj = new BgvVO();
             obj.setSAP_ID(rs.getInt("SAP_ID"));
             obj.setEMP_FIRST_NAME(rs.getString("EMP_FIRST_NAME"));
             obj.setEMP_LAST_NAME(rs.getString("EMP_LAST_NAME"));
             obj.setPREFERRED_BUSINESS_NAME(rs.getString("PREFERRED_BUSINESS_NAME"));
             obj.setGENDER(rs.getString("GENDER"));
             obj.setDATE_OF_BIRTH(rs.getDate("DATE_OF_BIRTH"));
             obj.setNATIONALITY(rs.getString("NATIONALITY"));
             obj.setCORRESPONDENCE_LANGUAGE(rs.getString("CORRESPONDENCE_LANGUAGE"));
            // obj.setPREVIOUSLY_WORKED_WITH_CLIENT(rs.getString("PREVIOUSLY_WORKED_WITH_CLIENT"));
             obj.setLEGAL_FIRST_NAME(rs.getString("EMP_FIRST_NAME"));
             obj.setLEGAL_SECOND_NAME(rs.getString("EMP_LAST_NAME"));
           //  obj.setOFFER_ACCEPTED_STATUS(rs.getString("OFFER_ACCEPTED_STATUS"));
          //   obj.setOFFER_ACCEPTED_DATE(rs.getDate("OFFER_ACCEPTED_DATE"));
             obj.setPROJECT_CODE(rs.getString("PROJECT_CODE"));
             obj.setPROJECT_NAME(rs.getString("PROJECT_NAME"));
             obj.setSECTOR(rs.getString("SECTOR"));
             obj.setREQUEST_TYPE(rs.getString("REQUEST_TYPE"));
             obj.setASSIGNMENT_FROM(rs.getDate("ASSIGNMENT_FROM"));
             obj.setASSIGNMENT_TO(rs.getDate("ASSIGNMENT_TO"));
             obj.setONSHORE_OFFSHORE(rs.getString("ONSHORE_OFFSHORE")); 
             obj.setTP_RESOURCE(rs.getString("TP_RESOURCE"));
             obj.setTP_APPROVAL(rs.getString("TP_APPROVAL"));
             obj.setEMP_OFFICIAL_MAIL_ID(rs.getString("EMP_OFFICIAL_MAIL_ID"));
             obj.setEMP_PERSONAL_MAIL_ID(rs.getString("EMP_PERSONAL_MAIL_ID"));
             obj.setEMP_CONTACT_NUMBER(rs.getLong("EMP_CONTACT_NUMBER"));
             obj.setLOCATION(rs.getString("LOCATION"));
             obj.setNew_LOCATION(rs.getString("New_Location"));
             obj.setOU_CODE(rs.getString("OU_CODE"));
             obj.setGPN(rs.getInt("GPN"));
             obj.setCLIENT_HIRING_MANAGER_MAIL_ID(rs.getString("CLIENT_HIRING_MANAGER_MAIL_ID"));
             obj.setCLIENT_HIRING_MANAGER_GPN_NO(rs.getInt("CLIENT_HIRING_MANAGER_GPN_NO"));
             obj.setREGION(rs.getString("REGION"));
             obj.setCOUNTRY(rs.getString("COUNTRY"));
             obj.setBGV_TYPE(rs.getString("BGV_TYPE"));
             obj.setREQUESTED_BY(rs.getString("REQUESTED_BY"));
             obj.setREQUESTED_DATE(rs.getTimestamp("REQUESTED_DATE"));
           
                  return obj;

}

});
      return bgvView;

    }
}

package com.hcl.pmoautomation.bgv.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hcl.pmoautomation.bgv.dao.BgvMailDao;
import com.hcl.pmoautomation.bgv.model.Bgvhclmailvo;
import com.hcl.pmoautomation.bgv.service.ReferBackServiceImpl;
import com.hcl.pmoautomation.email.App;

@Controller
@RequestMapping(value="pmoAutomation/ReferBack")
public class ReferBackController {
	@Autowired(required = true)
	JdbcTemplate jdbcTemplate;

	
@RequestMapping(value = "/referbackpmo.php", method = RequestMethod.POST)
public void referBackPmo(HttpServletRequest request,HttpServletResponse response) throws IOException	{
	try{
	String remarkReferBack =request.getParameter("remarks");
	System.out.println(remarkReferBack);
	String obj = request.getParameter("SapID");
	System.out.println(obj);
	int bgvperson=Integer.parseInt(obj);
	ReferBackServiceImpl refer=new ReferBackServiceImpl();
	refer.referBackPmo(jdbcTemplate, remarkReferBack, Integer.parseInt(obj));
	
	//System.out.println(" hey i am in refer back controller");
	
	/*String pmoteam1="millie.p@hcl.com";
	String pmoteam2="abdulkarim.b@hcl.com";
	String manager="nagendrappan@hcl.com";
	String[] mails = {manager,pmoteam1,pmoteam2};*/
	BgvMailDao b= new BgvMailDao();
	App mailtrigger = new App();
	List<Bgvhclmailvo> bgvmail= b.mailidsforbgvinitiate(bgvperson, jdbcTemplate);
	System.out.println("listttttt"+bgvmail);	 
	String[] array = new String[bgvmail.size()];
	int index = 0;
	for (Object value : bgvmail) {
		array[index] = String.valueOf( value );
	String name = request.getParameter("EmpFirstName");
	String[] strs = {obj ,name,remarkReferBack };
	List<String> referback = new ArrayList<String>(Arrays.asList(strs));



	mailtrigger.Mailtrigger("celeritas@hcl.com",array[index],  "Refer back Exceptions", null, "/referback.jsp", referback, null);
}	
}
catch(Exception e){
	PrintWriter out = response.getWriter();
	out.println("<html><body><script>alert('Mail not Triggered');window.location= '../../pmoAutomation/Bgv/preCheckPmoDetails.php';</script></body></html>");
}
PrintWriter out = response.getWriter();
out.println("<html><body><script>alert('Mail Sent Successfully To Manager!!!');window.location= '../../pmoAutomation/Bgv/preCheckPmoDetails.php';</script></body></html>");
	
}
}
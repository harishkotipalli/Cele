package com.hcl.pmoautomation.bgv.controller;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

@WebServlet("*.referbackbgvupload")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
        maxFileSize = 1024 * 1024 * 10, // 10MB
        maxRequestSize = 1024 * 1024 * 50)   // 50MB
public class ReferBackTpUpload extends HttpServlet {
	private static final String SAVE_DIR = "ReferBackuploadFiles";
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 String result = null;
		 
			//  String appPath = request.getServletContext().getRealPath("");
				        String appPathbgv="C:/";	   
				        String savePathbgv = appPathbgv + SAVE_DIR+"/";
				       
				        File fileSaveDir = new File(savePathbgv);
				        if (!fileSaveDir.exists()) {
				            fileSaveDir.mkdir();
				        }
				     
				        System.out.println("hiiiiiiibgv "+savePathbgv);
				        String fileNamebgv=null,tempString = null;
						Scanner scanner = null;String ReferbackFinalPathbgv=null;
					
				        for (Part part : request.getParts()) {
				        	fileNamebgv = extractFileName(part);
				        	 fileNamebgv = new File(fileNamebgv).getName();
							if (fileNamebgv.equals("")) {
								break;
							}
							System.out.println(fileNamebgv);
							fileNamebgv = fileNamebgv.replace("\\", "/");
							scanner = new Scanner(fileNamebgv);
							System.out.println("fielebgv   "+fileNamebgv);
							scanner.useDelimiter("/");
							while (scanner.hasNext()) {
								tempString = scanner.next();
								if (tempString.contains(".txt")) {
									break;
								}
							}
				            System.out.println(("111111111   "+savePathbgv + fileNamebgv));
				            part.write(savePathbgv +  fileNamebgv);
				        
				 	  ReferbackFinalPathbgv=savePathbgv + fileNamebgv;
				 	 
				 	 HttpSession session = request.getSession(false);
				        session.setAttribute("ReferbackfinaluploadPathbgv", ReferbackFinalPathbgv);
				 	
				        }
						
				        System.out.println("finallybgv   "+ReferbackFinalPathbgv);
				        request.setAttribute("message", "File successfully uploaded ");
				   
				       
				       if(((String)request.getAttribute("fileTypepdftpreferback")).equalsIgnoreCase("pdfuploadtpreferback")){
							request.getRequestDispatcher("pmoAutomation/BgvCont/ReferBackuploadpagetp.php").forward(request, response);	
						}
	}
	private String extractFileName(Part part) {
        String contentDisp = part.getHeader("content-disposition");
        String[] items = contentDisp.split(";");
        for (String s : items) {
            if (s.trim().startsWith("filename")) {
                return s.substring(s.indexOf("=") + 2, s.length() - 1);
            }
        }
        return "";
    }
}

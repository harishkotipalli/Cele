package com.hcl.pmoautomation.bgv.controller;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

@WebServlet("*.uploadClearanceEmailAttachment")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
maxFileSize = 1024 * 1024 * 10, // 10MB
maxRequestSize = 1024 * 1024 * 50)   // 50MB
public class ClearanceEmailUploadSer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	 private static final String SAVE_DIR = "uploadClearance";
	

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  String result = null;
			 
			//  String appPath = request.getServletContext().getRealPath("");
				        String appPathjust="C:/";	   
				        String savePathjust = appPathjust + SAVE_DIR+"/";
				       
				        File fileSaveDir = new File(savePathjust);
				        if (!fileSaveDir.exists()) {
				            fileSaveDir.mkdir();
				        }
				     
				        System.out.println("hiiiiiii "+savePathjust);
				        String fileNamejust=null,tempString = null;
						Scanner scanner = null;String FinalPathjust=null;
					
				        for (Part part : request.getParts()) {
				        	fileNamejust = extractFileName(part);
				        	 fileNamejust = new File(fileNamejust).getName();
							if (fileNamejust.equals("")) {
								break;
							}
							System.out.println(fileNamejust);
							fileNamejust = fileNamejust.replace("\\", "/");
							scanner = new Scanner(fileNamejust);
							System.out.println("fiele   "+fileNamejust);
							scanner.useDelimiter("/");
							while (scanner.hasNext()) {
								tempString = scanner.next();
								if (tempString.contains(".txt")) {
									break;
								}
							}
				            System.out.println(("111111111   "+savePathjust + fileNamejust));
				            part.write(savePathjust +  fileNamejust);
				            
				 	  FinalPathjust=savePathjust + fileNamejust;
				 	 
					 HttpSession session = request.getSession(false);
				        session.setAttribute("ClearanceuploadPath", FinalPathjust);
				 	
				        }
						
				        System.out.println("finally   "+FinalPathjust);
				        request.setAttribute("message", "File successfully uploaded ");
				   
				       
				        if(((String)request.getAttribute("ClearanceEmailupload")).equalsIgnoreCase("pdfuploadClear")){
							request.getRequestDispatcher("pmoAutomation/Bgv/Clearanceuploadpage.php").forward(request, response);
				        }
		
	}
	private String extractFileName(Part part) {
        String contentDisp = part.getHeader("content-disposition");
        String[] items = contentDisp.split(";");
        for (String s : items) {
            if (s.trim().startsWith("filename")) {
                return s.substring(s.indexOf("=") + 2, s.length() - 1);
            }
        }
        return "";
    }
}

package com.hcl.pmoautomation.bgv.controller;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.hcl.pmoautomation.bgv.dao.BgvPmoDaoImpl;

@Controller
@RequestMapping(value = "pmoAutomation/BgvExcel")
public class ExcelExport {
	private static final int BUFSIZE = 4096;
	@Autowired(required = true)
	JdbcTemplate jdbcTemplate;
	
	@RequestMapping(value = "/downloadExcel.php", method = RequestMethod.GET)
	   public String downloadExcel(HttpServletRequest request) {
	    BgvPmoDaoImpl imp=new BgvPmoDaoImpl();
		List<Object[]> listBooks = imp.getDownLoadExcel(jdbcTemplate);
		System.out.println(listBooks);
request.setAttribute("listBooks", listBooks);
		// return a view which will be resolved by an excel view resolver
		return "forward:../../pmoAutomation/BgvExcel/BgvExceldown.php";
/*return new ModelAndView ("excelView","listBooks",listBooks);*/
	}
	@RequestMapping(value = "/BgvExceldown.php")
		public void uplaodRASFile(HttpServletRequest request,
				Map<String, Object> model,HttpServletResponse response) throws ServletException, IOException {
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-ddHH-mm-ss");
		Date date = new Date();
	String d=	dateFormat.format(date);
		 final String FILE_NAME1 = "Bgv_Excel"+d+".xlsx";
		 String FILE_NAME=FILE_NAME1;
		//  final String FILE_NAME = "D:/MyFirstExcel.xlsx";
		  System.out.println("file date"+FILE_NAME);
List<Object[]> s = (List<Object[]>) model.get("listBooks");
		System.out.println("hiiiiiiiiiiiiiii "+s);
		List<Object[]> listBooks=(List<Object[]>) request.getAttribute("listBooks");
		System.out.println("hiiiiiiiiiiiiiii1 "+listBooks);
		// create a new Excel sheet
/*		HSSFSheet sheet = workbook.createSheet("Bgv Data");
		sheet.setDefaultColumnWidth(30);*/
		  XSSFWorkbook workbook = new XSSFWorkbook();
	        XSSFSheet sheetbook = workbook.createSheet("Bgv_Data");

		// create style for header cells
		CellStyle style = workbook.createCellStyle();
		Font font = workbook.createFont();
		font.setFontName("Arial");
		style.setFillForegroundColor(HSSFColor.BLUE.index);
		style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		font.setColor(HSSFColor.WHITE.index);
		style.setFont(font);
		
		// create header row
		XSSFRow header = sheetbook.createRow(0);
		
		header.createCell(0).setCellValue("SAP ID");
		header.getCell(0).setCellStyle(style);
		
		header.createCell(1).setCellValue("EMP_FIRST_NAME");
		header.getCell(1).setCellStyle(style);
		
		header.createCell(2).setCellValue("EMP_LAST_NAME");
		header.getCell(2).setCellStyle(style);
		
		header.createCell(3).setCellValue("PREFERRED_BUSINESS_NAME");
		header.getCell(3).setCellStyle(style);
		
		header.createCell(4).setCellValue("DATE_OF_BIRTH");
		header.getCell(4).setCellStyle(style);
		
		header.createCell(5).setCellValue("GENDER");
		header.getCell(5).setCellStyle(style);
		
		header.createCell(6).setCellValue("NATIONALITY");
		header.getCell(6).setCellStyle(style);
		
		header.createCell(7).setCellValue("PROJECT_CODE");
		header.getCell(7).setCellStyle(style);
		
		header.createCell(8).setCellValue("PROJECT_NAME");
		header.getCell(8).setCellStyle(style);
		
		header.createCell(9).setCellValue("SECTOR");
		header.getCell(9).setCellStyle(style);
		
		header.createCell(10).setCellValue("REQUEST_TYPE");
		header.getCell(10).setCellStyle(style);
		
		header.createCell(11).setCellValue("TP_RESOURCE");
		header.getCell(11).setCellStyle(style);
		
		header.createCell(12).setCellValue("EMP_OFFICIAL_MAIL_ID");
		header.getCell(12).setCellStyle(style);
		
		header.createCell(13).setCellValue("EMP_PERSONAL_MAIL_ID");
		header.getCell(13).setCellStyle(style);
		
		header.createCell(14).setCellValue("EMP_CLIENT_MAIL_ID");
		header.getCell(14).setCellStyle(style);
		
		header.createCell(15).setCellValue("EMP_CONTACT_NUMBER");
		header.getCell(15).setCellStyle(style);
		
		header.createCell(16).setCellValue("LOCATION");
		header.getCell(16).setCellStyle(style);
		
		header.createCell(17).setCellValue("NEW_LOCATION");
		header.getCell(17).setCellStyle(style);
		
		header.createCell(18).setCellValue("OU_CODE");
		header.getCell(18).setCellStyle(style);
		
		header.createCell(19).setCellValue("GPN");
		header.getCell(19).setCellStyle(style);
		
		header.createCell(20).setCellValue("CLIENT_HIRING_MANAGER_MAIL_ID");
		header.getCell(20).setCellStyle(style);
		
		header.createCell(21).setCellValue("CLIENT_HIRING_MANAGER_GPN_NO");
		header.getCell(21).setCellStyle(style);
		
		header.createCell(22).setCellValue("REGION");
		header.getCell(22).setCellStyle(style);
		
		header.createCell(23).setCellValue("COUNTRY");
		header.getCell(23).setCellStyle(style);
		
		header.createCell(24).setCellValue("ASSIGNMENT_FROM");
		header.getCell(24).setCellStyle(style);
		
		header.createCell(25).setCellValue("ASSIGNMENT_TO");
		header.getCell(25).setCellStyle(style);
		
		header.createCell(26).setCellValue("BGV_TYPE");
		header.getCell(26).setCellStyle(style);
		
		header.createCell(27).setCellValue("REQUESTED_BY");
		header.getCell(27).setCellStyle(style);
		
		header.createCell(28).setCellValue("REQUESTED_DATE");
		header.getCell(28).setCellStyle(style);
		
		header.createCell(29).setCellValue("PRE_START_CHECK_WITH_PMO");
		header.getCell(29).setCellStyle(style);
		
		header.createCell(30).setCellValue("PRE_START_CHECK_WITH_PMO_DATE");
		header.getCell(30).setCellStyle(style);
		
		header.createCell(31).setCellValue("PRE_START_CHECK_WITH_CENTRAL_BGV");
		header.getCell(31).setCellStyle(style);
		
		header.createCell(32).setCellValue("PRE_START_CHECK_WITH_CENTRAL_BGV_DATE");
		header.getCell(32).setCellStyle(style);
		
		header.createCell(33).setCellValue("PRE_START_CHECK_WITH_RESOURCE");
		header.getCell(33).setCellStyle(style);
		
		header.createCell(34).setCellValue("PRE_START_CHECK_WITH_RESOURCE_DATE");
		header.getCell(34).setCellStyle(style);
		
		
		
		// create data rows
		int rowCount = 1;
		
		for (Object[] aBook : listBooks) {
			XSSFRow aRow = sheetbook.createRow(rowCount++);
			aRow.createCell(0).setCellValue((int)aBook[0]);
			aRow.createCell(1).setCellValue((String)aBook[1]);
			aRow.createCell(2).setCellValue((String)aBook[2]);
			aRow.createCell(3).setCellValue((String)aBook[3]);
			aRow.createCell(4).setCellValue((String)aBook[4]);
			aRow.createCell(5).setCellValue((String)aBook[5]);
			aRow.createCell(6).setCellValue((String)aBook[6]);
			aRow.createCell(7).setCellValue((String)aBook[7]);
			aRow.createCell(8).setCellValue((String)aBook[8]);
			aRow.createCell(9).setCellValue((String)aBook[9]);
			aRow.createCell(10).setCellValue((String)aBook[10]);
			aRow.createCell(11).setCellValue((String)aBook[11]);
			aRow.createCell(12).setCellValue((String)aBook[12]);
			aRow.createCell(13).setCellValue((String)aBook[13]);
			aRow.createCell(14).setCellValue((String)aBook[14]);
			aRow.createCell(15).setCellValue((String)aBook[15]);
			aRow.createCell(16).setCellValue((String)aBook[16]);
			aRow.createCell(17).setCellValue((String)aBook[17]);
			aRow.createCell(18).setCellValue((String)aBook[18]);
			aRow.createCell(19).setCellValue((int)aBook[19]);
			aRow.createCell(20).setCellValue((String)aBook[20]);
			aRow.createCell(21).setCellValue((int)aBook[21]);
			aRow.createCell(22).setCellValue((String)aBook[22]);
			aRow.createCell(23).setCellValue((String)aBook[23]);
			aRow.createCell(24).setCellValue((String)aBook[24]);
			aRow.createCell(25).setCellValue((String)aBook[25]);
			aRow.createCell(26).setCellValue((String)aBook[26]);
			aRow.createCell(27).setCellValue((String)aBook[27]);
			aRow.createCell(28).setCellValue((String)aBook[28]);
			aRow.createCell(29).setCellValue((String)aBook[29]);
			aRow.createCell(30).setCellValue((String)aBook[30]);
			aRow.createCell(31).setCellValue((String)aBook[31]);
			aRow.createCell(32).setCellValue((String)aBook[32]);
			aRow.createCell(33).setCellValue((String)aBook[33]);
			aRow.createCell(34).setCellValue((String)aBook[34]);
			
		}
		 File file = new File(FILE_NAME);
		    // Retrieve the workbook for the main report
		    XSSFWorkbook workbookfile;
		    // Check file existence 
		    if (file.exists() == false) {
		        // Create new file if it does not exist
		        workbookfile = new XSSFWorkbook();
		    } else {
		        try ( 
		            // Make current input to exist file
		            InputStream is = new FileInputStream(file)) {
		                workbook = new XSSFWorkbook(is);
		            }
		    }
/*
	
	try {
	            FileOutputStream outputStream = new FileOutputStream(new File(FILE_NAME));
	            
	            workbook.write(outputStream);
	            outputStream.close();
	        } catch (FileNotFoundException e) {
	            e.printStackTrace();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }*/
		    
		    response.setContentType("application/vnd.ms-excel");
		    response.setHeader("Content-Disposition", "attachment; filename=\""+ FILE_NAME + "\"");
	       
		    workbook.write(response.getOutputStream()); // Write workbook to response.
		
		    
	/*return "Bgv/Bgvinitpmoapl";*/
	//return "<html><body><script>alert('Downloaded');window.location= '../../pmoAutomation/Bgv/preBGVPage.php';</script></body></html>";
//	PrintWriter out = response.getWriter();
//	out.println("<html><body><script>alert('Downloaded');window.location= '../../pmoAutomation/BgvCont/pmoDashboardStatus.php';</script></body></html>");

	}
		
	@RequestMapping(value = "/downloadExcelforprecompleted.php", method = RequestMethod.GET)
	   public String downloadExcelforprecompleted(HttpServletRequest request) {
	    BgvPmoDaoImpl imp=new BgvPmoDaoImpl();
		List<Object[]> listBooks = imp.preCheckcompleted(jdbcTemplate);
		System.out.println(listBooks);
request.setAttribute("listBooks", listBooks);
		// return a view which will be resolved by an excel view resolver
		return "forward:../../pmoAutomation/BgvExcel/downloadedExcelforprecompleted.php";
/*return new ModelAndView ("excelView","listBooks",listBooks);*/
	}	
			
	@RequestMapping(value = "/downloadedExcelforprecompleted.php")
	public void downloadedExcelforprecompleted(HttpServletRequest request,
			Map<String, Object> model,HttpServletResponse response) throws ServletException, IOException {
	
	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-ddHH-mm-ss");
	Date date = new Date();
String d=	dateFormat.format(date);
	 final String FILE_NAME1 = "Bgv_Pre_Check_completed"+d+".xlsx";
	 String FILE_NAME=FILE_NAME1;
	//  final String FILE_NAME = "D:/MyFirstExcel.xlsx";
	  System.out.println("file date"+FILE_NAME);
List<Object[]> s = (List<Object[]>) model.get("listBooks");
	System.out.println("hiiiiiiiiiiiiiii "+s);
	List<Object[]> listBooks=(List<Object[]>) request.getAttribute("listBooks");
	System.out.println("hiiiiiiiiiiiiiii1 "+listBooks);
	// create a new Excel sheet
/*		HSSFSheet sheet = workbook.createSheet("Bgv Data");
	sheet.setDefaultColumnWidth(30);*/
	  XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheetbook = workbook.createSheet("Bgv_Data");

	// create style for header cells
	CellStyle style = workbook.createCellStyle();
	Font font = workbook.createFont();
	font.setFontName("Arial");
	style.setFillForegroundColor(HSSFColor.BLUE.index);
	style.setFillPattern(CellStyle.SOLID_FOREGROUND);
	font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
	font.setColor(HSSFColor.WHITE.index);
	style.setFont(font);
	
	// create header row
	XSSFRow header = sheetbook.createRow(0);
	
	header.createCell(0).setCellValue("SAP ID");
	header.getCell(0).setCellStyle(style);
	
	header.createCell(1).setCellValue("EMP_FIRST_NAME");
	header.getCell(1).setCellStyle(style);
	
	header.createCell(2).setCellValue("PROJECT_NAME");
	header.getCell(2).setCellStyle(style);
	
	header.createCell(3).setCellValue("ou_code");
	header.getCell(3).setCellStyle(style);
	
	header.createCell(4).setCellValue("PRE_START_CHECK_WITH_RESOURCE");
	header.getCell(4).setCellStyle(style);
	
	header.createCell(5).setCellValue("PRE_START_CHECK_WITH_RESOURCE_DATE");
	header.getCell(5).setCellStyle(style);
	
	header.createCell(6).setCellValue("PRE_START_CHECK_STATUS");
	header.getCell(6).setCellStyle(style);
	
	header.createCell(7).setCellValue("BGV_PRESTART_COLOR");
	header.getCell(7).setCellStyle(style);
	
	
	
	
	

	
	// create data rows
	int rowCount = 1;
	
	for (Object[] aBook : listBooks) {
		XSSFRow aRow = sheetbook.createRow(rowCount++);
		aRow.createCell(0).setCellValue((int)aBook[0]);
		aRow.createCell(1).setCellValue((String)aBook[1]);
		aRow.createCell(2).setCellValue((String)aBook[2]);
		aRow.createCell(3).setCellValue((String)aBook[3]);
		aRow.createCell(4).setCellValue((String)aBook[4]);
		aRow.createCell(5).setCellValue((String)aBook[5]);
		aRow.createCell(6).setCellValue((String)aBook[6]);
		aRow.createCell(7).setCellValue((String)aBook[7]);
		
		

	}
	 File file = new File(FILE_NAME);
	    // Retrieve the workbook for the main report
	    XSSFWorkbook workbookfile;
	    // Check file existence 
	    if (file.exists() == false) {
	        // Create new file if it does not exist
	        workbookfile = new XSSFWorkbook();
	    } else {
	        try ( 
	            // Make current input to exist file
	            InputStream is = new FileInputStream(file)) {
	                workbook = new XSSFWorkbook(is);
	            }
	    }

	    
	    response.setContentType("application/vnd.ms-excel");
	    response.setHeader("Content-Disposition", "attachment; filename=\""+ FILE_NAME + "\"");
       
	    workbook.write(response.getOutputStream()); // Write workbook to response.
	
	    

}	

	@RequestMapping(value = "/downloadExcelforcompleteddetails.php", method = RequestMethod.GET)
	   public String downloadExcelforcompleteddetails(HttpServletRequest request) {
	    BgvPmoDaoImpl imp=new BgvPmoDaoImpl();
		List<Object[]> listBooks = imp.preCheckcompleteddetailsforDownload(jdbcTemplate);
		System.out.println(listBooks);
request.setAttribute("listBooks", listBooks);
		// return a view which will be resolved by an excel view resolver
		return "forward:../../pmoAutomation/BgvExcel/downloadedExcelforpostcompleted.php";
/*return new ModelAndView ("excelView","listBooks",listBooks);*/
	}		
	
	@RequestMapping(value = "/downloadedExcelforpostcompleted.php")
	public void downloadedExcelforpostcompleted(HttpServletRequest request,
			Map<String, Object> model,HttpServletResponse response) throws ServletException, IOException {
	
	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-ddHH-mm-ss");
	Date date = new Date();
String d=	dateFormat.format(date);
	 final String FILE_NAME1 = "Bgv_completed"+d+".xlsx";
	 String FILE_NAME=FILE_NAME1;
	//  final String FILE_NAME = "D:/MyFirstExcel.xlsx";
	  System.out.println("file date"+FILE_NAME);
List<Object[]> s = (List<Object[]>) model.get("listBooks");
	System.out.println("hiiiiiiiiiiiiiii "+s);
	List<Object[]> listBooks=(List<Object[]>) request.getAttribute("listBooks");
	System.out.println("hiiiiiiiiiiiiiii1 "+listBooks);
	// create a new Excel sheet
/*		HSSFSheet sheet = workbook.createSheet("Bgv Data");
	sheet.setDefaultColumnWidth(30);*/
	  XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheetbook = workbook.createSheet("Bgv_Data");

	// create style for header cells
	CellStyle style = workbook.createCellStyle();
	Font font = workbook.createFont();
	font.setFontName("Arial");
	style.setFillForegroundColor(HSSFColor.BLUE.index);
	style.setFillPattern(CellStyle.SOLID_FOREGROUND);
	font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
	font.setColor(HSSFColor.WHITE.index);
	style.setFont(font);
	
	// create header row	
	
	XSSFRow header = sheetbook.createRow(0);
	
	header.createCell(0).setCellValue("SAP ID");
	header.getCell(0).setCellStyle(style);
	
	header.createCell(1).setCellValue("EMP_FIRST_NAME");
	header.getCell(1).setCellStyle(style);
	
	header.createCell(2).setCellValue("PROJECT_CODE");
	header.getCell(2).setCellStyle(style);
	
	header.createCell(3).setCellValue("PROJECT_NAME");
	header.getCell(3).setCellStyle(style);
	
	header.createCell(4).setCellValue("ONSHORE_OFFSHORE");
	header.getCell(4).setCellStyle(style);
	
	header.createCell(5).setCellValue("LOCATION");
	header.getCell(5).setCellStyle(style);
	
	header.createCell(6).setCellValue("REGION");
	header.getCell(6).setCellStyle(style);
	
	header.createCell(7).setCellValue("COUNTRY");
	header.getCell(7).setCellStyle(style);
	
	header.createCell(8).setCellValue("VENDOR_TYPE");
	header.getCell(8).setCellStyle(style);
	
	header.createCell(9).setCellValue("PRE_CHECK_INITIATION_DATE");
	header.getCell(9).setCellStyle(style);
	
	header.createCell(10).setCellValue("PRE_START_CHECK_COMP_DATE");
	header.getCell(10).setCellStyle(style);
	
	header.createCell(11).setCellValue("BGV_PRESTART_COLOR");
	header.getCell(11).setCellStyle(style);
	
	header.createCell(12).setCellValue("BGV_POST_CHECK_COMPLETED_DATE");
	header.getCell(12).setCellStyle(style);
	
	header.createCell(13).setCellValue("BGV_FINAL_REPORT_COLOUR");
	header.getCell(13).setCellStyle(style);
	
	header.createCell(14).setCellValue("BGV_Status");
	header.getCell(14).setCellStyle(style);
	

	
	// create data rows
	int rowCount = 1;
	
	for (Object[] aBook : listBooks) {
		XSSFRow aRow = sheetbook.createRow(rowCount++);
		aRow.createCell(0).setCellValue((int)aBook[0]);
		aRow.createCell(1).setCellValue((String)aBook[1]);
		aRow.createCell(2).setCellValue((String)aBook[2]);
		aRow.createCell(3).setCellValue((String)aBook[3]);
		aRow.createCell(4).setCellValue((String)aBook[4]);
		aRow.createCell(5).setCellValue((String)aBook[5]);
		aRow.createCell(6).setCellValue((String)aBook[6]);
		aRow.createCell(7).setCellValue((String)aBook[7]);
		aRow.createCell(8).setCellValue((String)aBook[8]);
		aRow.createCell(9).setCellValue((String)aBook[9]);
		aRow.createCell(10).setCellValue((String)aBook[10]);
		aRow.createCell(11).setCellValue((String)aBook[11]);
		aRow.createCell(12).setCellValue((String)aBook[12]);
		aRow.createCell(13).setCellValue((String)aBook[13]);
		aRow.createCell(14).setCellValue((String)aBook[14]);

	}
	 File file = new File(FILE_NAME);
	    // Retrieve the workbook for the main report
	    XSSFWorkbook workbookfile;
	    // Check file existence 
	    if (file.exists() == false) {
	        // Create new file if it does not exist
	        workbookfile = new XSSFWorkbook();
	    } else {
	        try ( 
	            // Make current input to exist file
	            InputStream is = new FileInputStream(file)) {
	                workbook = new XSSFWorkbook(is);
	            }
	    }

	    
	    response.setContentType("application/vnd.ms-excel");
	    response.setHeader("Content-Disposition", "attachment; filename=\""+ FILE_NAME + "\"");
       
	    workbook.write(response.getOutputStream()); // Write workbook to response.
	
	    

}	
}

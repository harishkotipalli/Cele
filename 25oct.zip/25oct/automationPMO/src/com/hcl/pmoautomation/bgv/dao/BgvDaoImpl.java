package com.hcl.pmoautomation.bgv.dao;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.hcl.pmoautomation.bgv.model.Bgv;
import com.hcl.pmoautomation.bgv.model.BgvInitiation;
import com.hcl.pmoautomation.bgv.model.Bgvhclmailvo;
import com.hcl.pmoautomation.bgv.model.VettingSheet;
import com.hcl.pmoautomation.bgv.model.bgvdetailsmailvettingvo;
import com.hcl.pmoautomation.bgv.utilities.BgvSql;
import com.hcl.pmoautomation.email.App;
import com.hcl.pmoautomation.ot.dao.DatabaseQuery;




public class BgvDaoImpl implements BgvDaoI {



//BgvInitiationDaoI bgvInitiationDaoI;
	@Override
	public BgvInitiation bgvUpdate(Bgv bgv,int managerId,JdbcTemplate jdbcTemplet) {
		
		Object[] param={
				bgv.getVettingSheet().getFirst_Name(),
				bgv.getVettingSheet().getlast_Name(),
				bgv.getVettingSheet().getgender(),
				bgv.getVettingSheet().getcountry(),
				bgv.getVettingSheet().getproject_Code(),
				bgv.getVettingSheet().getproject_Name(),
		        bgv.getVettingSheet().getContact_Number(),
		        bgv.getVettingSheet().gettype_Of_Hires(),
	            bgv.getVettingSheet().getemail()
		};
		 
		System.out.println(jdbcTemplet);
		System.out.println("notworking");
		 if(jdbcTemplet.update(BgvSql.update_tsc_Tracker_Sql,param)>0)
			 System.out.println("updated successfully");
			 return new BgvInitiationDaoImpl().getAllYetToJoinBgvRequest(managerId,jdbcTemplet);
		
		
		
		
		
	
		 
	}

	@Override
	public Object bgvUpdateForRas(Bgv bgv, int managerId,int sap_id,int ras_id,JdbcTemplate jdbcTemplet,HttpServletRequest request) {

		System.out.println(bgv.getVettingSheet().getAssignment_Details_Start_Date());
		System.out.println("the ras bgv update sucessful!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"+ras_id);
		System.out.println("bgvInitiationDaoI");
		System.out.println(bgv);
		Object[] param={
				sap_id,
				ras_id,
				bgv.getVettingSheet().getFirst_Name(),
				bgv.getVettingSheet().getproject_Code(),
				bgv.getVettingSheet().getproject_Name(),
				bgv.getVettingSheet().getSector(),
				bgv.getVettingSheet().getTp_Resource(),
				bgv.getResourcePersonalDetails().getPersonal_Mail_Id(),
				bgv.getResourcePersonalDetails().getOfficial_Mail_id(),
				bgv.getVettingSheet().getContact_Number(),
				bgv.getResourcePersonalDetails().getUbs_Mail(),
				bgv.getResourcePersonalDetails().getGpn(),
				bgv.getVettingSheet().getAssignment_Details_Start_Date(),
	            bgv.getVettingSheet().getAssignment_Details_End_Date(),
				bgv.getVettingSheet().gettype_Of_Hires(),
				bgv.getVettingSheet().getRegulatory_Region_country(),
				bgv.getVettingSheet().getCountry(),
				bgv.getVettingSheet().getBgv_type(),
				bgv.getVettingSheet().getUbs_Hiring_Manager_email_Id(),
				bgv.getVettingSheet().getUbs_Hiring_Manager_Gpn(),
                bgv.getResourcePersonalDetails().getPrevisouly_Worked_With_Ubs(),
                //bgv.getResourcePersonalDetails().getLegal_First_Name(),
                bgv.getResourcePersonalDetails().getLegal_Last_Name(),
                bgv.getResourcePersonalDetails().getNationality(),
                bgv.getResourcePersonalDetails().getPrefered_business_name(),
                bgv.getVettingSheet().getGender(),
                bgv.getResourcePersonalDetails().getDate_Of_Birth(),
               // bgv.getResourcePersonalDetails().getCorrespondence_Language(),
                bgv.getVettingSheet().getDepartment_Ou_Code(),
                bgv.getVettingSheet().getWork_Location(),
                bgv.getVettingSheet().getJoining_Location(),
                bgv.getVettingSheet().getRequested_by(),
                
                
                
               
				
		};
		System.out.println(jdbcTemplet);
		
		HttpSession session=request.getSession(false);  
		       int rasid=(int)session.getAttribute("ras_id");
		      
System.out.println("rasssssssssssssssid "+rasid);
	 
		
		
		
		
		if(jdbcTemplet.update(BgvSql.update_ras_Tracker_Sql,param)>0)

			
	
			
			
			System.out.println("ras tracker updated sucessfuly!!!!!!!!!!!!!!!!!!!!!!!!");
		    System.out.println(managerId +"managerId for upadte and find remaning data !!!!!!!");
			
		  BgvMailDao b= new BgvMailDao();
			List<Bgvhclmailvo> bgvmail= b.list(managerId, jdbcTemplet);
			App mailtriggerbgv = new App();
			String[] array = new String[bgvmail.size()];
			int index = 0;
			for (Object value : bgvmail) {
				array[index] = String.valueOf( value );
				
				List<bgvdetailsmailvettingvo> bgvmaildetails=b.listoftemplatedata(rasid, jdbcTemplet, request);
		mailtriggerbgv.Mailtrigger("pmoappadmin_ou@hcl.com",array[index], "Details of Resource to Initiate BGV ","Harish", "/VettingSheetsudmittemplate.jsp",bgvmaildetails, null);
				
				
			//S	s.method("shyamsunder.p@hcl.com",array[index], "Checking Email Triggering", "/vettingsheetsubmit.vm",bgvmaildetails);
			}
		    
		    return new BgvInitiationDaoImpl().getAllBgvRequest(managerId,jdbcTemplet);
		
	
	}

	@Override
	public Object referbackupdate(Bgv bgv, int managerId, int sap_id, JdbcTemplate jdbcTemplet,
			HttpServletRequest request) {

		
	
		Object[] param={
				
				
				bgv.getEditVettingSheet().getEMP_FIRST_NAME(),
				bgv.getEditVettingSheet().getPROJECT_NAME(),
				bgv.getEditVettingSheet().getPROJECT_CODE(),
				
				bgv.getEditVettingSheet().getSECTOR(),
				bgv.getEditVettingSheet().getTP_RESOURCE(),
				bgv.getEditVettingSheet().getREQUEST_TYPE(),
				bgv.getEditVettingSheet().getEMP_PERSONAL_MAIL_ID(),
				bgv.getEditVettingSheet().getEMP_OFFICIAL_MAIL_ID(),
				bgv.getEditVettingSheet().getEMP_CONTACT_NUMBER(),
				bgv.getEditVettingSheet().getEMP_CLIENT_MAIL_ID(),
				bgv.getEditVettingSheet().getGPN(),
				bgv.getEditVettingSheet().getASSIGNMENT_FROM(),
	            bgv.getEditVettingSheet().getASSIGNMENT_TO(),
				
				bgv.getEditVettingSheet().getREGION(),
				bgv.getEditVettingSheet().getCOUNTRY(),
				bgv.getEditVettingSheet().getBGV_TYPE(),
				bgv.getEditVettingSheet().getCLIENT_HIRING_MANAGER_MAIL_ID(),
				bgv.getEditVettingSheet().getCLIENT_HIRING_MANAGER_GPN_NO(),
            //  bgv.getEditVettingSheet().getPREVIOUSLY_WORKED_WITH_CLIENT(),
				bgv.getEditVettingSheet().getNATIONALITY(),
				bgv.getEditVettingSheet().getPREFERRED_BUSINESS_NAME(),
	            bgv.getEditVettingSheet().getGENDER(),
	            bgv.getEditVettingSheet().getDATE_OF_BIRTH(),
	         // bgv.getResourcePersonalDetails().getCorrespondence_Language(),
	            bgv.getEditVettingSheet().getOU_CODE(),
	            bgv.getEditVettingSheet().getLOCATION(),
	            bgv.getEditVettingSheet().getJOINING_LOCATION(),
	            bgv.getEditVettingSheet().getREQUESTED_BY(),
	           // bgv.getEditVettingSheet().getREQUESTED_DATE(),
	            sap_id
            //    bgv.getEditVettingSheet().getLEGAL_FIRST_NAME(),
            //    bgv.getEditVettingSheet().getLEGAL_SECOND_NAME()
               
               
               
                
				
		};
		
		
	
		jdbcTemplet.update(BgvSql.updatereferback,param);
			 
		int sapid=(int)request.getSession().getAttribute("sap_id");
		String str = Integer.toString(sapid);
	BgvMailDao b= new BgvMailDao();
		App mailtrigger = new App();
		List<Bgvhclmailvo> bgvmail= b.mailidsforbgvinitiate(sapid, jdbcTemplet);
		System.out.println("listttttt"+bgvmail);	 
		String[] array = new String[bgvmail.size()];
		int index = 0;
		for (Object value : bgvmail) {
			array[index] = String.valueOf( value );
	//	String name = request.getParameter("EmpFirstName");
	//	String[] strs = {str,Name,pjname};
		List<bgvdetailsmailvettingvo> referback = b.listoftemplatedataforreferbackupdate(sapid, jdbcTemplet);


	
		mailtrigger.Mailtrigger("celeritas@hcl.com",array[index],  "Refer back Changes Done", null, "/ReferBackSubmit.jsp", referback, null);
	}	
	
		
			 System.out.println("updated successfully");
			 return new BgvStatusDaoImpl().getAllBgvReferredStatus(managerId, jdbcTemplet);
	}

}



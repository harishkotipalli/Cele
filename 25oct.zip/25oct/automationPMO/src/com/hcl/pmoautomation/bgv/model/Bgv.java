package com.hcl.pmoautomation.bgv.model;

import java.util.Date;

public class Bgv {
	private EmployeeNewJoining employeeNewJoining;
	private EmployeeYetToJoining employeeYetToJoining;
		
	private VettingSheet vettingSheet;
	private ResourcePersonalDetails resourcePersonalDetails;
	private int id;
	private String PREVIOUSLY_WORKED_WITH_CLIENT;
	private String OFFER_ACCEPTED_STATUS;
	private Date RAS_END_DATE;
	private String ONSHORE_OFFSHORE;
	private String REGION;
	private String COUNTRY;
	private String BGV_TYPE;
	private Date GPN_START_DATE;

	private String GPN_STATUS;
	private EmployeeBgvStatus employeeBgvStatus;
	private EditVettingSheet editVettingSheet;

	


	@Override
	public String toString() {
		return "Bgv [employeeNewJoining=" + employeeNewJoining + ", employeeYetToJoining=" + employeeYetToJoining
				+ ", vettingSheet=" + vettingSheet + ", resourcePersonalDetails=" + resourcePersonalDetails + ", id="
				+ id + ", PREVIOUSLY_WORKED_WITH_CLIENT=" + PREVIOUSLY_WORKED_WITH_CLIENT + ", OFFER_ACCEPTED_STATUS="
				+ OFFER_ACCEPTED_STATUS + ", RAS_END_DATE=" + RAS_END_DATE + ", ONSHORE_OFFSHORE=" + ONSHORE_OFFSHORE
				+ ", REGION=" + REGION + ", COUNTRY=" + COUNTRY + ", BGV_TYPE=" + BGV_TYPE + ", GPN_START_DATE="
				+ GPN_START_DATE + ", GPN_STATUS=" + GPN_STATUS + ", employeeBgvStatus=" + employeeBgvStatus
				+ ", editVettingSheet=" + editVettingSheet + ", INITIATE_GPN=" + INITIATE_GPN + ", RAS_ID=" + RAS_ID
				+ ", BGV_FINAL_REPORT_COLOUR=" + BGV_FINAL_REPORT_COLOUR + ", BGV_COUNCIL_APPROVAL_RECEIVED_STATUS="
				+ BGV_COUNCIL_APPROVAL_RECEIVED_STATUS + ", BGV_COUNCIL_APPROVAL_RECEIVED_DATE="
				+ BGV_COUNCIL_APPROVAL_RECEIVED_DATE + ", RESOURCE_JUSTIFICATION_RECEIVED_STATUS="
				+ RESOURCE_JUSTIFICATION_RECEIVED_STATUS + ", RESOURCE_JUSTIFICATION_RECEIVED_DATE="
				+ RESOURCE_JUSTIFICATION_RECEIVED_DATE + ", ACTIVE_FLAG=" + ACTIVE_FLAG + ", MODIFIED_ON=" + MODIFIED_ON
				+ ", MODIFIED_BY=" + MODIFIED_BY + "]";
	}

	public EditVettingSheet getEditVettingSheet() {
		return editVettingSheet;
	}

	public void setEditVettingSheet(EditVettingSheet editVettingSheet) {
		this.editVettingSheet = editVettingSheet;
	}

	public EmployeeNewJoining getEmployeeNewJoining() {
		return employeeNewJoining;
	}

	public void setEmployeeNewJoining(EmployeeNewJoining employeeNewJoining) {
		this.employeeNewJoining = employeeNewJoining;
	}

	public EmployeeYetToJoining getEmployeeYetToJoining() {
		return employeeYetToJoining;
	}

	public void setEmployeeYetToJoining(
			EmployeeYetToJoining employeeYetToJoining) {
		this.employeeYetToJoining = employeeYetToJoining;
	}

	public VettingSheet getVettingSheet() {
		return vettingSheet;
	}

	public void setVettingSheet(VettingSheet vettingSheet) {
		this.vettingSheet = vettingSheet;
	}

	public ResourcePersonalDetails getResourcePersonalDetails() {
		return resourcePersonalDetails;
	}
	

	public EmployeeBgvStatus getEmployeeBgvStatus() {
		return employeeBgvStatus;
	}

	public void setEmployeeBgvStatus(EmployeeBgvStatus employeeBgvStatus) {
		this.employeeBgvStatus = employeeBgvStatus;
	}

	public void setResourcePersonalDetails(
			ResourcePersonalDetails resourcePersonalDetails) {
		this.resourcePersonalDetails = resourcePersonalDetails;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPREVIOUSLY_WORKED_WITH_CLIENT() {
		return PREVIOUSLY_WORKED_WITH_CLIENT;
	}

	public void setPREVIOUSLY_WORKED_WITH_CLIENT(
			String pREVIOUSLY_WORKED_WITH_CLIENT) {
		PREVIOUSLY_WORKED_WITH_CLIENT = pREVIOUSLY_WORKED_WITH_CLIENT;
	}

	public String getOFFER_ACCEPTED_STATUS() {
		return OFFER_ACCEPTED_STATUS;
	}

	public void setOFFER_ACCEPTED_STATUS(String oFFER_ACCEPTED_STATUS) {
		OFFER_ACCEPTED_STATUS = oFFER_ACCEPTED_STATUS;
	}

	public Date getRAS_END_DATE() {
		return RAS_END_DATE;
	}

	public void setRAS_END_DATE(Date rAS_END_DATE) {
		RAS_END_DATE = rAS_END_DATE;
	}

	public String getONSHORE_OFFSHORE() {
		return ONSHORE_OFFSHORE;
	}

	public void setONSHORE_OFFSHORE(String oNSHORE_OFFSHORE) {
		ONSHORE_OFFSHORE = oNSHORE_OFFSHORE;
	}

	public String getREGION() {
		return REGION;
	}

	public void setREGION(String rEGION) {
		REGION = rEGION;
	}

	public String getCOUNTRY() {
		return COUNTRY;
	}

	public void setCOUNTRY(String cOUNTRY) {
		COUNTRY = cOUNTRY;
	}

	public String getBGV_TYPE() {
		return BGV_TYPE;
	}

	public void setBGV_TYPE(String bGV_TYPE) {
		BGV_TYPE = bGV_TYPE;
	}

	public Date getGPN_START_DATE() {
		return GPN_START_DATE;
	}

	public void setGPN_START_DATE(Date gPN_START_DATE) {
		GPN_START_DATE = gPN_START_DATE;
	}

	public String getGPN_STATUS() {
		return GPN_STATUS;
	}

	public void setGPN_STATUS(String gPN_STATUS) {
		GPN_STATUS = gPN_STATUS;
	}

	public char getINITIATE_GPN() {
		return INITIATE_GPN;
	}

	public void setINITIATE_GPN(char iNITIATE_GPN) {
		INITIATE_GPN = iNITIATE_GPN;
	}

	public int getRAS_ID() {
		return RAS_ID;
	}

	public void setRAS_ID(int rAS_ID) {
		RAS_ID = rAS_ID;
	}

	public String getBGV_FINAL_REPORT_COLOUR() {
		return BGV_FINAL_REPORT_COLOUR;
	}

	public void setBGV_FINAL_REPORT_COLOUR(String bGV_FINAL_REPORT_COLOUR) {
		BGV_FINAL_REPORT_COLOUR = bGV_FINAL_REPORT_COLOUR;
	}

	public String getBGV_COUNCIL_APPROVAL_RECEIVED_STATUS() {
		return BGV_COUNCIL_APPROVAL_RECEIVED_STATUS;
	}

	public void setBGV_COUNCIL_APPROVAL_RECEIVED_STATUS(
			String bGV_COUNCIL_APPROVAL_RECEIVED_STATUS) {
		BGV_COUNCIL_APPROVAL_RECEIVED_STATUS = bGV_COUNCIL_APPROVAL_RECEIVED_STATUS;
	}

	public Date getBGV_COUNCIL_APPROVAL_RECEIVED_DATE() {
		return BGV_COUNCIL_APPROVAL_RECEIVED_DATE;
	}

	public void setBGV_COUNCIL_APPROVAL_RECEIVED_DATE(
			Date bGV_COUNCIL_APPROVAL_RECEIVED_DATE) {
		BGV_COUNCIL_APPROVAL_RECEIVED_DATE = bGV_COUNCIL_APPROVAL_RECEIVED_DATE;
	}

	public String getRESOURCE_JUSTIFICATION_RECEIVED_STATUS() {
		return RESOURCE_JUSTIFICATION_RECEIVED_STATUS;
	}

	public void setRESOURCE_JUSTIFICATION_RECEIVED_STATUS(
			String rESOURCE_JUSTIFICATION_RECEIVED_STATUS) {
		RESOURCE_JUSTIFICATION_RECEIVED_STATUS = rESOURCE_JUSTIFICATION_RECEIVED_STATUS;
	}

	public Date getRESOURCE_JUSTIFICATION_RECEIVED_DATE() {
		return RESOURCE_JUSTIFICATION_RECEIVED_DATE;
	}

	public void setRESOURCE_JUSTIFICATION_RECEIVED_DATE(
			Date rESOURCE_JUSTIFICATION_RECEIVED_DATE) {
		RESOURCE_JUSTIFICATION_RECEIVED_DATE = rESOURCE_JUSTIFICATION_RECEIVED_DATE;
	}

	public char getACTIVE_FLAG() {
		return ACTIVE_FLAG;
	}

	public void setACTIVE_FLAG(char aCTIVE_FLAG) {
		ACTIVE_FLAG = aCTIVE_FLAG;
	}

	public Date getMODIFIED_ON() {
		return MODIFIED_ON;
	}

	public void setMODIFIED_ON(Date mODIFIED_ON) {
		MODIFIED_ON = mODIFIED_ON;
	}

	public String getMODIFIED_BY() {
		return MODIFIED_BY;
	}

	public void setMODIFIED_BY(String mODIFIED_BY) {
		MODIFIED_BY = mODIFIED_BY;
	}

	private char INITIATE_GPN;
	private int RAS_ID;

	private String BGV_FINAL_REPORT_COLOUR;

	private String BGV_COUNCIL_APPROVAL_RECEIVED_STATUS;
	private Date BGV_COUNCIL_APPROVAL_RECEIVED_DATE;
	private String RESOURCE_JUSTIFICATION_RECEIVED_STATUS;
	private Date RESOURCE_JUSTIFICATION_RECEIVED_DATE;
	private char ACTIVE_FLAG;
	private Date MODIFIED_ON;
	private String MODIFIED_BY;
	

}

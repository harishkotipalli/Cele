package com.hcl.pmoautomation.bgv.model;


import java.util.Date;

public class StatusDetails {
	private int sap_Id;
	private String bgv_Id;

	private String vendor_Case_Ref_Id;

	private String status;

	private Date status_Date;

	private int active_flag;

	private String modified_By;

	private Date modified_On;

	public int getSap_Id() {
		return sap_Id;
	}

	public void setSap_Id(int sap_Id) {
		this.sap_Id = sap_Id;
	}

	public String getBgv_Id() {
		return bgv_Id;
	}

	public void setBgv_Id(String bgv_Id) {
		this.bgv_Id = bgv_Id;
	}

	public String getVendor_Case_Ref_Id() {
		return vendor_Case_Ref_Id;
	}

	public void setVendor_Case_Ref_Id(String vendor_Case_Ref_Id) {
		this.vendor_Case_Ref_Id = vendor_Case_Ref_Id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getStatus_Date() {
		return status_Date;
	}

	public void setStatus_Date(Date status_Date) {
		this.status_Date = status_Date;
	}

	public int getActive_flag() {
		return active_flag;
	}

	public void setActive_flag(int active_flag) {
		this.active_flag = active_flag;
	}

	public String getModified_By() {
		return modified_By;
	}

	public void setModified_By(String modified_By) {
		this.modified_By = modified_By;
	}

	public Date getModified_On() {
		return modified_On;
	}

	public void setModified_On(Date modified_On) {
		this.modified_On = modified_On;
	}

	@Override
	public String toString() {
		return "Status_Details [sap_Id=" + sap_Id + ", bgv_Id=" + bgv_Id
				+ ", vendor_Case_Ref_Id=" + vendor_Case_Ref_Id + ", status="
				+ status + ", status_Date=" + status_Date + ", active_flag="
				+ active_flag + ", modified_By=" + modified_By
				+ ", modified_On=" + modified_On + "]";
	}

}

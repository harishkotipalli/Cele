package com.hcl.pmoautomation.bgv.dao;

import javax.servlet.http.HttpServletRequest;

import org.springframework.jdbc.core.JdbcTemplate;

import com.hcl.pmoautomation.bgv.model.Bgv;
import com.hcl.pmoautomation.bgv.model.BgvInitiation;



public interface BgvDaoI {
public BgvInitiation bgvUpdate(Bgv bgv, int managerId,JdbcTemplate jdbcTemplet);

public Object bgvUpdateForRas(Bgv bgv, int managerId,int sap_id, int ras_id,JdbcTemplate jdbcTemplet,HttpServletRequest request);

public Object referbackupdate(Bgv bgv, int managerId,int sap_id,JdbcTemplate jdbcTemplet,HttpServletRequest request);

}

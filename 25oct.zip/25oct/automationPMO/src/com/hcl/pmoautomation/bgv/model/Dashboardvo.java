package com.hcl.pmoautomation.bgv.model;

public class Dashboardvo {
	private String Bgvintiated;
	private String bgvprecheck;
	private String bgvcompleted;
	private String referback;
	private String count;
	public String getBgvintiated() {
		return Bgvintiated;
	}
	public void setBgvintiated(String bgvintiated) {
		Bgvintiated = bgvintiated;
	}
	public String getBgvprecheck() {
		return bgvprecheck;
	}
	public void setBgvprecheck(String bgvprecheck) {
		this.bgvprecheck = bgvprecheck;
	}
	public String getBgvcompleted() {
		return bgvcompleted;
	}
	public void setBgvcompleted(String bgvcompleted) {
		this.bgvcompleted = bgvcompleted;
	}
	public String getReferback() {
		return referback;
	}
	public void setReferback(String referback) {
		this.referback = referback;
	}
	public String getCount() {
		return count;
	}
	public void setCount(String count) {
		this.count = count;
	}
	@Override
	public String toString() {
		return "Dashboardvo [Bgvintiated=" + Bgvintiated + ", bgvprecheck=" + bgvprecheck + ", bgvcompleted="
				+ bgvcompleted + ", referback=" + referback + ", count=" + count + "]";
	}
	


}

package com.hcl.pmoautomation.bgv.model;

public class bgvinitiatetempvo {
	
	private int sapcod;
	private String empname;
	private String emphclmail;
	public int getSapcod() {
		return sapcod;
	}
	public void setSapcod(int sapcod) {
		this.sapcod = sapcod;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public String getEmphclmail() {
		return emphclmail;
	}
	public void setEmphclmail(String emphclmail) {
		this.emphclmail = emphclmail;
	}
	@Override
	public String toString() {
		return "bgvinitiatetempvo [sapcod=" + sapcod + ", empname=" + empname + ", emphclmail=" + emphclmail + "]";
	}
	

}

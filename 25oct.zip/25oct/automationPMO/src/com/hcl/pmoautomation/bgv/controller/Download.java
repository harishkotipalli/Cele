package com.hcl.pmoautomation.bgv.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Download {
	
	



		public static void main(String[] args) throws Exception 
		   {
			
		      Class.forName("com.mysql.jdbc.Driver");
		      Connection connect = DriverManager.getConnection( 
		      "jdbc:mysql://localhost:3306/mydb" , 
		      "root" , 
		      "root"
		      );
		      Statement statement = connect.createStatement();
		      ResultSet resultSet = statement
		      .executeQuery("select SAP_ID,EMP_FIRST_NAME,DATE_OF_BIRTH from bgv");
		      XSSFWorkbook workbook = new XSSFWorkbook(); 
		      XSSFSheet spreadsheet = workbook
		      .createSheet("employe db");
		      XSSFRow row=spreadsheet.createRow(1);
		      XSSFCell cell;
		      cell=row.createCell(1);
		      cell.setCellValue("SAP_ID");
		      cell=row.createCell(2);
		      cell.setCellValue("EMP_FIRST_NAME");
		      cell=row.createCell(3);
		      cell.setCellValue("DATE_OF_BIRTH");
		      
		      int i=2;
		      while(resultSet.next())
		      {
		         row=spreadsheet.createRow(i);
		         cell=row.createCell(1);
		         cell.setCellValue(resultSet.getInt("SAP_ID"));
		         System.out.println(resultSet.getInt("SAP_ID"));
		         cell=row.createCell(2);
		         cell.setCellValue(resultSet.getString("EMP_FIRST_NAME"));
		         cell=row.createCell(3);
		         cell.setCellValue(resultSet.getString("DATE_OF_BIRTH"));
		         System.out.println(resultSet.getDate("DATE_OF_BIRTH"));
		         
		         i++;
		      }
		      FileOutputStream out = new FileOutputStream(
		      new File("D:\\exceldatabase.xlsx"));
		      workbook.write(out);
		      out.close();
		      System.out.println(
		      "exceldatabase.xlsx written successfully");
		   }


	}




package com.hcl.pmoautomation.bgv.service;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.hcl.pmoautomation.bgv.dao.BgvPmoDaoImpl;
import com.hcl.pmoautomation.rnc.dao.RncNewAccessDaoImpl;

public class BgvPmoServiceImpl {
	

	public List<Object[]> getBgvDetails(JdbcTemplate jdbcTemplate){
		BgvPmoDaoImpl bgvPmoImpl = new BgvPmoDaoImpl();
		return bgvPmoImpl.getBgvDetails(jdbcTemplate);
		
	}
	public List<Object[]> managerpendingwithpmo(int sapid,JdbcTemplate jdbcTemplate){
		BgvPmoDaoImpl bgvPmoImpl = new BgvPmoDaoImpl();
		return bgvPmoImpl.managerpendingwithpmo(sapid,jdbcTemplate);
		
	}
	public List<Object[]> getfinalBgvDetails(JdbcTemplate jdbcTemplate){
		BgvPmoDaoImpl bgvPmoImpl = new BgvPmoDaoImpl();
		
		return bgvPmoImpl.getfinalBgvDetails(jdbcTemplate);
		
	}
	
	public List<Object[]> getYetToJoineeBgvdetails(JdbcTemplate jdbcTemplate){
		BgvPmoDaoImpl bgvPmoImpl = new BgvPmoDaoImpl();
		return bgvPmoImpl.getYetToJoineeBgvdetails(jdbcTemplate);
	}
	public boolean saveFinalBgvDetails(JdbcTemplate jdbcTemplate, int parseInt, String color,String finalrem,String date) {
		BgvPmoDaoImpl bgvPmoImpl = new BgvPmoDaoImpl();
		return bgvPmoImpl.saveFinalBgvDetails(jdbcTemplate, parseInt, color,finalrem,date);
		
	}
	public boolean saveBgvDetails(JdbcTemplate jdbcTemplate, int parseInt,
			String yesradio,String color,String date) {
		BgvPmoDaoImpl bgvPmoImpl = new BgvPmoDaoImpl();
		return bgvPmoImpl.preCheckApproval(jdbcTemplate, parseInt,yesradio,color,date);
		
	}
	
	public boolean YTJsaveBgvDetails(JdbcTemplate jdbcTemplate, int parseInt,
			String color,String date) {
		BgvPmoDaoImpl bgvPmoImpl = new BgvPmoDaoImpl();
		return bgvPmoImpl.YTJpreCheckApproval(jdbcTemplate, parseInt,color,date);
		
	}
	public boolean bgvpersonupdatemailyes(JdbcTemplate jdbcTemplate, int parseInt
			) {
		BgvPmoDaoImpl bgvPmoImpl = new BgvPmoDaoImpl();
		return bgvPmoImpl.bgvpersonmailyes(jdbcTemplate, parseInt);
		
	}

	public static boolean saveBgvdetails(JdbcTemplate jdbcTemplate, String sap_Id, String string) {
		// TODO Auto-generated method stub
		return false;
	}
	
	public List<Object[]> getDownLoadExcel(JdbcTemplate jdbcTemplate){
		BgvPmoDaoImpl bgvPmoImpl = new BgvPmoDaoImpl();
		return bgvPmoImpl.getDownLoadExcel(jdbcTemplate);
		
	}

	public List<Object[]> getpreCheckCentralBGV(JdbcTemplate jdbcTemplate) {
		BgvPmoDaoImpl bgvPmoImpl = new BgvPmoDaoImpl();
		return bgvPmoImpl.preCheckCentralBGV(jdbcTemplate);
	}
	public List<Object[]> getpreCheckCentralBGVManager(int sapid,JdbcTemplate jdbcTemplate) {
		BgvPmoDaoImpl bgvPmoImpl = new BgvPmoDaoImpl();
		return bgvPmoImpl.preCheckCentralBGVManager(sapid,jdbcTemplate);
	}
	public List<Object[]> getpreCheckVendorBGV(JdbcTemplate jdbcTemplate) {
		BgvPmoDaoImpl bgvPmoImpl = new BgvPmoDaoImpl();
		return bgvPmoImpl.preCheckVendorBGV(jdbcTemplate);
	}
	public List<Object[]> getpreCheckVendorBGVManager(int sapid,JdbcTemplate jdbcTemplate) {
		BgvPmoDaoImpl bgvPmoImpl = new BgvPmoDaoImpl();
		return bgvPmoImpl.preCheckVendorBGVManager(sapid,jdbcTemplate);
	}
	public List<Object[]> getpreCheckResourceBGV(JdbcTemplate jdbcTemplate) {
		BgvPmoDaoImpl bgvPmoImpl = new BgvPmoDaoImpl();
		return bgvPmoImpl.preCheckResourceBGV(jdbcTemplate) ;
	}
	public List<Object[]> getpreCheckResourceBGVManager(int sapid,JdbcTemplate jdbcTemplate) {
		BgvPmoDaoImpl bgvPmoImpl = new BgvPmoDaoImpl();
		return bgvPmoImpl.preCheckResourceBGVManager(sapid,jdbcTemplate) ;
	}
/*	public List<Object[]> getpreCheckPmoPending(JdbcTemplate jdbcTemplate) {
		BgvPmoDaoImpl bgvPmoImpl = new BgvPmoDaoImpl();
		return bgvPmoImpl.preCheckPmoPending(jdbcTemplate);
	}
*/
	public List<Object[]> getpreCheckPmoPendingManager(int sapid,JdbcTemplate jdbcTemplate) {
		BgvPmoDaoImpl bgvPmoImpl = new BgvPmoDaoImpl();
		return bgvPmoImpl.preCheckPmoPendingManager(sapid,jdbcTemplate);
	}
	public List<Object[]>  getpreCheckPmo(JdbcTemplate jdbcTemplate) {
		BgvPmoDaoImpl bgvPmoImpl = new BgvPmoDaoImpl();
		return bgvPmoImpl.preCheckPmo(jdbcTemplate);
	}
	public List<Object[]>  YTJgetpreCheckPmo(JdbcTemplate jdbcTemplate) {
		BgvPmoDaoImpl bgvPmoImpl = new BgvPmoDaoImpl();
		return bgvPmoImpl.YTJpreCheckPmo(jdbcTemplate);
	}
	public List<Object[]>  YTJGpnInitiate(JdbcTemplate jdbcTemplate) {
		BgvPmoDaoImpl bgvPmoImpl = new BgvPmoDaoImpl();
		return bgvPmoImpl.YTJGpnInitiate(jdbcTemplate);
	}
	public List<Object[]>  getpreCheckcompleted(JdbcTemplate jdbcTemplate) {
		BgvPmoDaoImpl bgvPmoImpl = new BgvPmoDaoImpl();
		return bgvPmoImpl.preCheckcompleted(jdbcTemplate);
	}
	public List<Object[]>  getpostcheckpending(JdbcTemplate jdbcTemplate) {
		BgvPmoDaoImpl bgvPmoImpl = new BgvPmoDaoImpl();
		return bgvPmoImpl.postCheckPending(jdbcTemplate);
	}
	public List<Object[]>  getpostcheckcompleted(JdbcTemplate jdbcTemplate) {
		BgvPmoDaoImpl bgvPmoImpl = new BgvPmoDaoImpl();
		return bgvPmoImpl.postCheckCompleted(jdbcTemplate);
	}
	public List<Object[]>  ManagerpreCheckPmocompleted(int sapid,JdbcTemplate jdbcTemplate) {
		BgvPmoDaoImpl bgvPmoImpl = new BgvPmoDaoImpl();
		return bgvPmoImpl.ManagerpreCheckPmocompleted(sapid,jdbcTemplate);
	}
	public List<Object[]>  ManagerpostCheckpending(int sapid,JdbcTemplate jdbcTemplate) {
		BgvPmoDaoImpl bgvPmoImpl = new BgvPmoDaoImpl();
		return bgvPmoImpl.ManagerpostCheckpending(sapid,jdbcTemplate);
	}
	public List<Object[]>  ManagerpostCheckcompleted(int sapid,JdbcTemplate jdbcTemplate) {
		BgvPmoDaoImpl bgvPmoImpl = new BgvPmoDaoImpl();
		return bgvPmoImpl.ManagerpostCheckcompleted(sapid,jdbcTemplate);
	}
	public List<Object[]>  getpreCheckPmoReport(JdbcTemplate jdbcTemplate) {
		BgvPmoDaoImpl bgvPmoImpl = new BgvPmoDaoImpl();
		return bgvPmoImpl.preCheckPmoReport(jdbcTemplate);
	}
	public List<Object[]> getpreCheckPmoDetails(JdbcTemplate jdbcTemplate) {
		BgvPmoDaoImpl bgvPmoImpl = new BgvPmoDaoImpl();
		return bgvPmoImpl.preCheckPmoDetails(jdbcTemplate);
	}

	


	
	
}

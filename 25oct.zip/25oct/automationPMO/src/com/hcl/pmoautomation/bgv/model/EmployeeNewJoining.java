package com.hcl.pmoautomation.bgv.model;

import java.io.Serializable;
import java.sql.*;

@SuppressWarnings("serial")
public class EmployeeNewJoining implements Serializable {
	private Date ras_end_date;
	private int ras_id;
	private int sap_Id;
	private String resource_Name;
	private Date ras_Start_Date;
	private String project_name;
	private int CV_ID;
	private String ras_status;
	private String gpn_status;


	public int getRas_id() {
		return ras_id;
	}

	public void setRas_id(int ras_id) {
		this.ras_id = ras_id;
	}

	
	public int getCV_ID() {
		return CV_ID;
	}

	public Date getRas_end_date() {
		return ras_end_date;
	}

	public void setRas_end_date(Date ras_end_date) {
		this.ras_end_date = ras_end_date;
	}

	public void setCV_ID(int CV_ID) {
		this.CV_ID = CV_ID;
	}

	public int getSap_Id() {
		return sap_Id;
	}

	public void setSap_Id(int sap_Id) {
		this.sap_Id = sap_Id;
	}

	public String getResource_Name() {
		return resource_Name;
	}

	public void setResource_Name(String resource_Name) {
		this.resource_Name = resource_Name;
	}

	public Date getRas_Start_Date() {
		return ras_Start_Date;
	}

	public void setRas_Start_Date(Date ras_Start_Date) {
		this.ras_Start_Date = ras_Start_Date;
	}

	public String getProject_name() {
		return project_name;
	}

	public void setProject_name(String project_name) {
		this.project_name = project_name;
	}

	public String getRequest_Type() {
		return request_Type;
	}

	public void setRequest_Type(String request_Type) {
		this.request_Type = request_Type;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	private String request_Type;
	private String remark;
	

	public String getRas_status() {
		return ras_status;
	}

	public void setRas_status(String ras_status) {
		this.ras_status = ras_status;
	}

	public String getGpn_status() {
		return gpn_status;
	}

	public void setGpn_status(String gpn_status) {
		this.gpn_status = gpn_status;
	}

	@Override
	public String toString() {
		return "EmployeeNewJoining [ras_end_date=" + ras_end_date + ", ras_id=" + ras_id + ", sap_Id=" + sap_Id
				+ ", resource_Name=" + resource_Name + ", ras_Start_Date=" + ras_Start_Date + ", project_name="
				+ project_name + ", CV_ID=" + CV_ID + ", ras_status=" + ras_status + ", gpn_status=" + gpn_status
				+ ", request_Type=" + request_Type + ", remark=" + remark + "]";
	}



}

package com.hcl.pmoautomation.bgv.model;

public class DownloadPathvo {

	private String uploadpath;

	public String getUploadpath() {
		return uploadpath;
	}

	public void setUploadpath(String uploadpath) {
		this.uploadpath = uploadpath;
	}

	@Override
	public String toString() {
		return  uploadpath;
	}

	
}

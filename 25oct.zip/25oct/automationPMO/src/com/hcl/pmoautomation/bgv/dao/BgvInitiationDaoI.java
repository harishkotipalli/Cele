package com.hcl.pmoautomation.bgv.dao;

import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;

import com.hcl.pmoautomation.bgv.model.BgvInitiation;
import com.hcl.pmoautomation.bgv.model.EmployeeNewJoining;
import com.hcl.pmoautomation.bgv.model.EmployeeYetToJoining;



public interface BgvInitiationDaoI {
	
public BgvInitiation	getAllBgvRequest(int managerId,JdbcTemplate jdbcTemplet);
public List<EmployeeNewJoining> getAllNewBgvRequest(int managerId, JdbcTemplate jdbcTemplet);

public BgvInitiation getAllYetToJoinBgvRequest(int managerId,JdbcTemplate jdbcTemplet);
public List<EmployeeYetToJoining> getAllNewYetToJoinBgvRequest(int managerId, JdbcTemplate jdbcTemplet);
}

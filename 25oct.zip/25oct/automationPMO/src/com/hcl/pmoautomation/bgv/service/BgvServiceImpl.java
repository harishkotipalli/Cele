package com.hcl.pmoautomation.bgv.service;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.hcl.pmoautomation.bgv.dao.BgvDaoI;
import com.hcl.pmoautomation.bgv.dao.BgvDaoImpl;
import com.hcl.pmoautomation.bgv.model.Bgv;



public class BgvServiceImpl implements BgvServiceI {

 BgvDaoI bgvDaoI;
	
	
	@Override
	public Object bgvUpdate(Bgv bgv, int managerId, JdbcTemplate jdbcTemplet ) {
		// TODO Auto-generated method stub
			return (new BgvDaoImpl()).bgvUpdate(bgv,managerId,jdbcTemplet);

	}


	@Override
	public Object bgvUpdateForRas(Bgv bgv, int managerId,int sap_id,int ras_id, JdbcTemplate jdbcTemplet,HttpServletRequest request) {
		// TODO Auto-generated method stub
		return (new BgvDaoImpl()).bgvUpdateForRas(bgv,managerId,sap_id,ras_id,jdbcTemplet,request);
	}


	@Override
	public Object referbackupdate(Bgv bgv, int managerId, int sap_id, JdbcTemplate jdbcTemplet,
			HttpServletRequest request) {
		// TODO Auto-generated method stub
		return (new BgvDaoImpl()).referbackupdate(bgv, managerId, sap_id, jdbcTemplet, request) ;
	}



}

package com.hcl.pmoautomation.bgv.model;


import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.springframework.web.servlet.view.document.AbstractExcelView;

/**
 * This class builds an Excel spreadsheet document using Apache POI library.
 * @author www.codejava.net
 *
 */
public class ExcelBuilder extends AbstractExcelView {

	@Override
	protected void buildExcelDocument(Map<String, Object> model,
			HSSFWorkbook workbook, HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
		response.setHeader("Content-Disposition", "attachment; filename=\"my-xls-file.xls\"");
		// get data model which is passed by the Spring container
		@SuppressWarnings("unchecked")
		List<Object[]> listBooks = (List<Object[]>) model.get("listBooks");
		System.out.println("!!!!!!!!!!!!!!!!!!! 111111111111"+listBooks);
		// create a new Excel sheet
		
		HSSFSheet sheet = workbook.createSheet("Java Books");
		sheet.setDefaultColumnWidth(30);
		
		// create style for header cells
		CellStyle style = workbook.createCellStyle();
		Font font = workbook.createFont();
		font.setFontName("Arial");
		style.setFillForegroundColor(HSSFColor.BLUE.index);
		style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		font.setColor(HSSFColor.WHITE.index);
		style.setFont(font);
		
		// create header row
		HSSFRow header = sheet.createRow(0);
		
		header.createCell(0).setCellValue("sapid");
		header.getCell(0).setCellStyle(style);
		
		header.createCell(1).setCellValue("empfirstname");
		header.getCell(1).setCellStyle(style);
		
		header.createCell(2).setCellValue("projectname");
		header.getCell(2).setCellStyle(style);
		
		header.createCell(3).setCellValue("oucode");
		header.getCell(3).setCellStyle(style);
		
		header.createCell(4).setCellValue("requesteddate");
		header.getCell(4).setCellStyle(style);
		
		// create data rows
		int rowCount = 1;
		
		for (Object[] aBook  : listBooks) {
			HSSFRow aRow = sheet.createRow(rowCount++);
			aRow.createCell(0).setCellValue((int)aBook[0]);
			aRow.createCell(1).setCellValue((String)aBook[1]);
			aRow.createCell(2).setCellValue((String)aBook[2]);
			aRow.createCell(3).setCellValue((String)aBook[3]);
			aRow.createCell(4).setCellValue((String)aBook[4]);
			
		}
	}

}
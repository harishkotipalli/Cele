package com.hcl.pmoautomation.bgv.model;


import java.util.Date;

public class EmployeeYetToJoining {
	private String project_code;
	private Date offer_Date;
	private Date expected_Date_of_Joining;
	private String request_Type;
	private String remark;
	private int CV_ID ;
	public int getCV_ID() {
	return CV_ID;
}

public void setCV_ID(int cV_ID) {
	CV_ID = cV_ID;
}
	public String getProject_code() {
		return project_code;
	}

	@Override
	public String toString() {
		return "Employee_YetTo_Joining [project_code=" + project_code
				+ ", offer_Date=" + offer_Date + ", expected_Date_of_Joining="
				+ expected_Date_of_Joining + ", request_Type=" + request_Type
				+ ", remark=" + remark + "]";
	}

	public void setProject_code(String project_code) {
		this.project_code = project_code;
	}

	public Date getOffer_Date() {
		return offer_Date;
	}

	public void setOffer_Date(Date offer_Date) {
		this.offer_Date = offer_Date;
	}

	public Date getExpected_Date_of_Joining() {
		return expected_Date_of_Joining;
	}

	public void setExpected_Date_of_Joining(Date expected_Date_of_Joining) {
		this.expected_Date_of_Joining = expected_Date_of_Joining;
	}

	public String getRequest_Type() {
		return request_Type;
	}

	public void setRequest_Type(String request_Type) {
		this.request_Type = request_Type;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}
}

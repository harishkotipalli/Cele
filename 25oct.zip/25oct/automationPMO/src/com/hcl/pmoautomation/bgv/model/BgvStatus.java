package com.hcl.pmoautomation.bgv.model;

import java.util.List;

public class BgvStatus {
	List<EmployeeBgvStatus> employeeBgvStatus;
	List<EmployeeBgvStatus> employeeBgvprecheckStatus;
	List<EmployeeBgvStatus> employeeBgvcompletedStatus;
	List<EmployeeBgvStatus> employeeBgvrefferedStatus;
	

	public List<EmployeeBgvStatus> getEmployeeBgvStatus() {
		return employeeBgvStatus;
	}

	public void setEmployeeBgvStatus(List<EmployeeBgvStatus> employeeBgvStatus) {
		this.employeeBgvStatus = employeeBgvStatus;
	}
	
	

	public List<EmployeeBgvStatus> getEmployeeBgvprecheckStatus() {
		return employeeBgvprecheckStatus;
	}

	public void setEmployeeBgvprecheckStatus(List<EmployeeBgvStatus> employeeBgvprecheckStatus) {
		this.employeeBgvprecheckStatus = employeeBgvprecheckStatus;
	}
	

	public List<EmployeeBgvStatus> getEmployeeBgvcompletedStatus() {
		return employeeBgvcompletedStatus;
	}

	public void setEmployeeBgvcompletedStatus(List<EmployeeBgvStatus> employeeBgvcompletedStatus) {
		this.employeeBgvcompletedStatus = employeeBgvcompletedStatus;
	}

	
	
	
	public List<EmployeeBgvStatus> getEmployeeBgvrefferedStatus() {
		return employeeBgvrefferedStatus;
	}

	public void setEmployeeBgvrefferedStatus(List<EmployeeBgvStatus> employeeBgvrefferedStatus) {
		this.employeeBgvrefferedStatus = employeeBgvrefferedStatus;
	}

	@Override
	public String toString() {
		return "BgvStatus [employeeBgvStatus=" + employeeBgvStatus + ", employeeBgvprecheckStatus="
				+ employeeBgvprecheckStatus + ", employeeBgvcompletedStatus=" + employeeBgvcompletedStatus
				+ ", employeeBgvrefferedStatus=" + employeeBgvrefferedStatus + "]";
	}

	



	
	

}

package com.hcl.pmoautomation.bgv.service;

import org.springframework.jdbc.core.JdbcTemplate;

import com.hcl.pmoautomation.bgv.model.BgvInitiation;




public interface BgvInitiationServiceI {
	
	
	public BgvInitiation getAllNewBgvRequest(int managerId, JdbcTemplate jdbcTemplet);
	public BgvInitiation getAllNewYetToJoinBgvRequest(int managerId,JdbcTemplate jdbcTemplet);
	

}

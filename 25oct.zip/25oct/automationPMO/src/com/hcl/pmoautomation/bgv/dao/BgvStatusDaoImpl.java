package com.hcl.pmoautomation.bgv.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.hcl.pmoautomation.bgv.model.BgvStatus;
import com.hcl.pmoautomation.bgv.model.EmployeeBgvStatus;
import com.hcl.pmoautomation.bgv.utilities.BgvSql;

public class BgvStatusDaoImpl implements BgvStatusDaoI{

	@Override
	public BgvStatus getAllBgvStatus(int managerId, JdbcTemplate jdbcTemplet) {
		BgvStatus bgvStatus = new BgvStatus();
		try{
			
			//bgvStatus.setEmployeeBgvStatus(getAllNewBgvStatus(managerId,jdbcTemplet ));
			//bgvStatus.setEmployeeBgvprecheckStatus(getAllNewBgvPrecheckStatus(managerId,jdbcTemplet));
		    //bgvStatus.setEmployeeBgvcompletedStatus(getAllNewBgvcompletedStatus(managerId, jdbcTemplet));
		    bgvStatus.setEmployeeBgvrefferedStatus(getAllNewBgvrefferedStatus(managerId, jdbcTemplet));
			System.out.println("statusbgvoutput  "+getAllNewBgvrefferedStatus(managerId, jdbcTemplet));
					  
			}catch(Exception e){
				e.printStackTrace();
			}
			return bgvStatus;
	}

	@Override
	public List<EmployeeBgvStatus> getAllNewBgvStatus(int managerId, JdbcTemplate jdbcTemplet) {
		Object[] params = {managerId,"Y"};
		 System.out.println(jdbcTemplet); 
	       System.out.println(managerId);

		return jdbcTemplet.query(BgvSql.getBgvStatus,params,new BgvStatusRowmapper());
	}

	@Override
	public BgvStatus getAllBgvPrecheckStatus(int managerId, JdbcTemplate jdbcTemplet) {
		BgvStatus bgvStatus = new BgvStatus();
		try{
			bgvStatus.setEmployeeBgvprecheckStatus(getAllNewBgvPrecheckStatus(managerId, jdbcTemplet));
		  
			}catch(Exception e){
				e.printStackTrace();
			}
			return bgvStatus;
	}

	@Override
	public List<EmployeeBgvStatus> getAllNewBgvPrecheckStatus(int managerId, JdbcTemplate jdbcTemplet) {
		 Object[] params = {managerId,"N"};
		
		 return jdbcTemplet.query(BgvSql.getBgvPrecheckStatus,params,new BgvStatusRowmapper());
	}

	@Override
	public BgvStatus getAllBgvcompletedStatus(int managerId, JdbcTemplate jdbcTemplet) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<EmployeeBgvStatus> getAllNewBgvcompletedStatus(int managerId, JdbcTemplate jdbcTemplet) {
		// TODO Auto-generated method stub
		Object[] params={managerId,"green"};
		return jdbcTemplet.query(BgvSql.getBgvPrecompletedStatus,params,new BgvStatusRowmapper());
	}
	
	@Override
	public BgvStatus getAllBgvReferredStatus(int managerId, JdbcTemplate jdbcTemplet) {
		BgvStatus bgvStatus = new BgvStatus();
try{
			
			bgvStatus.setEmployeeBgvrefferedStatus(getAllNewBgvrefferedStatus(managerId, jdbcTemplet));
			
		   }catch(Exception e){
				e.printStackTrace();
			}
			return bgvStatus;
	}

	@Override
	public List<EmployeeBgvStatus> getAllNewBgvrefferedStatus(int managerId, JdbcTemplate jdbcTemplet) {
		Object[] params={managerId,"YES"};
		 System.out.println(jdbcTemplet); 
	       System.out.println(managerId);
	       System.out.println(params);

		return jdbcTemplet.query(BgvSql.getBgvReferStatus,params,new BgvReferRowMapper());
	}


	

}

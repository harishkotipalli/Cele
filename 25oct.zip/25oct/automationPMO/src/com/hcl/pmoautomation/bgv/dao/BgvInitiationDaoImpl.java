package com.hcl.pmoautomation.bgv.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.hcl.pmoautomation.bgv.model.BgvInitiation;
import com.hcl.pmoautomation.bgv.model.EmployeeNewJoining;
import com.hcl.pmoautomation.bgv.model.EmployeeYetToJoining;
import com.hcl.pmoautomation.bgv.utilities.BgvSql;
import com.hcl.pmoautomation.ot.vo.Excalibur;



@Component
public class BgvInitiationDaoImpl implements BgvInitiationDaoI {
	
	

	public BgvInitiation getAllBgvRequest(int managerId) {
		BgvInitiation bgvInitiation = new BgvInitiation();
		//try{
//		bgvInitiation.setEmployeeNewJoinings(getAllNewBgvRequest(managerId));
//		bgvInitiation.setEmployeeYetToJoinings(getAllYetBgvRequest(managerId));
		//}/*catch(Exception e){
			//e.printStackTrace();
		//}*/
		return bgvInitiation;
		
	}
	private List<EmployeeYetToJoining> getAllYetBgvRequest(int managerId, JdbcTemplate jdbcTemplet) {
		Object[] param = { managerId,"YES" };
      // System.out.println(jdbcTemplet);  
		return jdbcTemplet.query(BgvSql.getyetTOJoinResourcesql, param,
				new YetToJoiningResourceRowMapper());
		
				
	}
	public List<EmployeeNewJoining> getAllNewBgvRequest(int managerId, JdbcTemplate jdbcTemplet){
		Object[] param = { managerId,"NOT INITIATED" };
//System.out.println(jdbcTemplet);
		return jdbcTemplet.query(BgvSql.getnewResourcesql, param,
				new NewJoiningResourceRowMapper());
				
	}
	@Override
	public BgvInitiation getAllBgvRequest(int managerId,
			JdbcTemplate jdbcTemplet) {
		//System.out.println("HERE");
		BgvInitiation bgvInitiation = new BgvInitiation();
		try{
		bgvInitiation.setEmployeeNewJoinings(getAllNewBgvRequest(managerId,jdbcTemplet));
	   // bgvInitiation.setEmployeeYetToJoinings(getYetToJoinRequest(managerId, jdbcTemplet));
		}catch(Exception e){
			e.printStackTrace();
		}
		return bgvInitiation;
	}
	
	@Override
	public List<EmployeeYetToJoining> getAllNewYetToJoinBgvRequest(int managerId,
			JdbcTemplate jdbcTemplet) {
		Object[] param = { managerId,"YES" };
	       System.out.println(jdbcTemplet); 
	       System.out.println(managerId);

	       //System.out.println(BgvSql.getyetTOJoinResourcesql);
			return jdbcTemplet.query(BgvSql.getyetTOJoinResourcesql, param,
					new YetToJoiningResourceRowMapper());
		
			 
	}
	@Override
	public BgvInitiation  getAllYetToJoinBgvRequest(int managerId,
			JdbcTemplate jdbcTemplet) {
		
		System.out.println("HERE");
		BgvInitiation bgvInitiation = new BgvInitiation();
		try{
			System.out.println(getAllNewYetToJoinBgvRequest(managerId, jdbcTemplet));
	     bgvInitiation.setEmployeeYetToJoinings(getAllNewYetToJoinBgvRequest(managerId, jdbcTemplet));
		}catch(Exception e){
			e.printStackTrace();
		}
		return bgvInitiation;
	}
	


}

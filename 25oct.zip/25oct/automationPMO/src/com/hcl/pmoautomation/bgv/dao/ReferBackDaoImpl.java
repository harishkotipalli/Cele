package com.hcl.pmoautomation.bgv.dao;



import org.springframework.jdbc.core.JdbcTemplate;



public class ReferBackDaoImpl implements ReferBackDaoI {
	

	@Override
	public boolean referBackPmo(JdbcTemplate jdbcTemplate,String remarks,int parseInt) {
		boolean flag = false;
		
	 flag = jdbcTemplate.update("update bgv set REFER_BACK_REMARKS=?, REFER_BACK ='YES', PRE_START_CHECK_WITH_PMO='NOTINITIATED', ACTIVEFLAG_PRECHECK_REFERBACK='Y',ACTIVEFLAG_PRECHECK='N' where SAP_ID=?",
			new Object[]{remarks,parseInt})>0?true:false;
			return flag;
	}
}
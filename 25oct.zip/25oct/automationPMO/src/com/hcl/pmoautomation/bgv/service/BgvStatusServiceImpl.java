package com.hcl.pmoautomation.bgv.service;

import org.springframework.jdbc.core.JdbcTemplate;

import com.hcl.pmoautomation.bgv.dao.BgvStatusDaoI;
import com.hcl.pmoautomation.bgv.dao.BgvStatusDaoImpl;
import com.hcl.pmoautomation.bgv.model.BgvStatus;

public class BgvStatusServiceImpl implements BgvStatusServiceI{

	@Override
	public BgvStatus getAllBgvStatus(int managerId, JdbcTemplate jdbcTemplet) {
	  BgvStatusDaoI bgvStatusDaoI = new BgvStatusDaoImpl();
	  return bgvStatusDaoI.getAllBgvStatus(managerId, jdbcTemplet);
	}

	@Override
	public BgvStatus getAllBgvPrecheckStatus(int managerId, JdbcTemplate jdbcTemplet) {
		  BgvStatusDaoI bgvStatusDaoI = new BgvStatusDaoImpl();
		return bgvStatusDaoI.getAllBgvPrecheckStatus(managerId, jdbcTemplet);
	}
	
	
	
	

}

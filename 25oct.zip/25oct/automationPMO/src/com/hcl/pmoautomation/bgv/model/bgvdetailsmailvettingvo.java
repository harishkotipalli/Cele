package com.hcl.pmoautomation.bgv.model;

public class bgvdetailsmailvettingvo {
	private int sapcode;
	private String empname;
	private String projectname;
	public int getSapcode() {
		return sapcode;
	}
	public void setSapcode(int sapcode) {
		this.sapcode = sapcode;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	
	public String getProjectname() {
		return projectname;
	}
	public void setProjectname(String projectname) {
		this.projectname = projectname;
	}
	@Override
	public String toString() {
		return "bgvdetailsmailvettingvo [sapcode=" + sapcode + ", empname=" + empname + ", projectname=" + projectname
				+ "]";
	}
	
	
}

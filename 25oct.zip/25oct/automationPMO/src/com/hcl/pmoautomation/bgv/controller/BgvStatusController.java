package com.hcl.pmoautomation.bgv.controller;



import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.hcl.pmoautomation.bgv.service.BgvStatusServiceImpl;

@Controller
@RequestMapping(value =  "pmoAutomation/BgvStatus")

public class BgvStatusController {
	@ExceptionHandler(NullPointerException.class)
    public ModelAndView myError(Exception exception) {
    ModelAndView e = new ModelAndView();
    e.addObject("exception", exception);
    e.setViewName("Login/Error");
    return e;
}
	
	@Autowired(required = true)
	JdbcTemplate jdbcTemplate;
	
	@RequestMapping(value =  "/bgvStatus.php")
		public ModelAndView getBgvStatus(HttpServletRequest request)throws NullPointerException{
		
		System.out.println(request.getAttribute("getAllBgvStatus"));
		
		return new ModelAndView("Bgv/BgvStatus","listOfEmployeeStatus",(new BgvStatusServiceImpl().getAllBgvStatus((int) request
						.getSession().getAttribute("managerId"), jdbcTemplate))); 
			
		}
	@RequestMapping(value =  "/Bgvintiated.php")
public ModelAndView getBgvintiated(HttpServletRequest request)throws NullPointerException{
		
		System.out.println(request.getSession().getAttribute("managerId"));
		System.out.println(request.getAttribute("getAllBgvStatus"));
		
		return new ModelAndView("Bgv/BGVintiated","listOfEmployeeStatus",(new BgvStatusServiceImpl().getAllBgvStatus((int) request
						.getSession().getAttribute("managerId"), jdbcTemplate))); 
			
		}
	@RequestMapping(value =  "/Bgvprecheck.php")
public ModelAndView getBgvprecheck(HttpServletRequest request)throws NullPointerException{
		
		System.out.println(request.getSession().getAttribute("managerId"));
		System.out.println(request.getAttribute("getAllBgvStatus"));
		
		return new ModelAndView("Bgv/BGVprecheck","listOfEmployeeStatus",(new BgvStatusServiceImpl().getAllBgvStatus((int) request
						.getSession().getAttribute("managerId"), jdbcTemplate))); 
			
		}
	@RequestMapping(value =  "/Bgvcompleted.php")
public ModelAndView getBgvcompleted(HttpServletRequest request)throws NullPointerException{
		
		System.out.println(request.getSession().getAttribute("managerId"));
		System.out.println(request.getAttribute("getAllBgvStatus"));
		
		return new ModelAndView("Bgv/BGVcompleted","listOfEmployeeStatus",(new BgvStatusServiceImpl().getAllBgvStatus((int) request
						.getSession().getAttribute("managerId"), jdbcTemplate))); 
			
		}
	@RequestMapping(value =  "/Bgvreferback.php")
public ModelAndView getBgvreferback(HttpServletRequest request)throws NullPointerException{
		
		System.out.println(request.getSession().getAttribute("managerId"));
		System.out.println(request.getAttribute("getAllBgvStatus"));
		
		return new ModelAndView("Bgv/BGVreferback","listOfEmployeeStatus",(new BgvStatusServiceImpl().getAllBgvStatus((int) request
						.getSession().getAttribute("managerId"), jdbcTemplate))); 
			
		}

	}



package com.hcl.pmoautomation.bgv.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.hcl.pmoautomation.bgv.dao.BgvMailDao;
import com.hcl.pmoautomation.bgv.dao.BgvPmoDaoImpl;
import com.hcl.pmoautomation.bgv.dao.DownloadPathDao;
import com.hcl.pmoautomation.bgv.dao.YetToJoinDao;
import com.hcl.pmoautomation.bgv.model.BgvInitiation;
import com.hcl.pmoautomation.bgv.model.BgvVO;
import com.hcl.pmoautomation.bgv.model.Bgvhclmailvo;
import com.hcl.pmoautomation.bgv.model.DownloadPathvo;
import com.hcl.pmoautomation.bgv.model.EmployeeNewJoining;
import com.hcl.pmoautomation.bgv.model.bgvdetailsmailvettingvo;
import com.hcl.pmoautomation.bgv.model.bgvinitiatetempvo;
import com.hcl.pmoautomation.bgv.service.BgvInitiationServiceI;
import com.hcl.pmoautomation.bgv.service.BgvInitionServiceImpl;
import com.hcl.pmoautomation.bgv.service.BgvPmoServiceImpl;
import com.hcl.pmoautomation.email.App;
import com.hcl.pmoautomation.ot.service.SRMappingService;
import com.hcl.pmoautomation.ot.service.SRMappingServiceImpl;
import com.hcl.pmoautomation.rnc.service.RncNewOdcServiceImpl;

import jdk.nashorn.internal.ir.RuntimeNode.Request;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.apache.velocity.app.VelocityEngine; 



@Controller
@RequestMapping(value = "pmoAutomation/Bgv")
public class BgvInitiationController {
	
	/*@ExceptionHandler(NullPointerException.class)
    public ModelAndView myError(Exception exception) {
    ModelAndView e = new ModelAndView();
    e.addObject("exception", exception);
    e.setViewName("Login/Error");
    return e;
}*/
	
	@Autowired(required = true)
	JdbcTemplate jdbcTemplate;
	private ServletResponse response;

	@RequestMapping("/getAllEmployee.php")
	public ModelAndView getAllNewBgvRequest(HttpServletRequest request) throws NullPointerException{
		// request.getSession().setAttribute("managerId", id);
		System.out
				.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
		// System.out.println();
		// int managerId = (int)request.getSession().getAttribute("managerId");
		System.out.println(request.getSession().getAttribute("managerId"));
		System.out.println(request.getSession().getAttribute("ras_id"));
		// BgvInitiation bgvInitiation =
		// bgvInitionServiceI.getAllNewBgvRequest(managerId);
		request.setAttribute("searchrecordsnotfound", "No Records Found");
		request.setAttribute("searchrecordsfound", "Records found");
		return new ModelAndView("Bgv/newRequest", "listOfEmployees",
				(new BgvInitionServiceImpl()).getAllNewBgvRequest((int) request
						.getSession().getAttribute("managerId"), jdbcTemplate));
	}
	@RequestMapping(value = "/internalResourceVetting.php")
	public String internalResourceVetting(HttpServletRequest request) {
		 String uniqueID = UUID.randomUUID().toString().substring(0,7);
		    System.out.println(uniqueID);
		    String uid= "Y"+uniqueID;
		    String addQuery="insert into mydb.uniqueid_internal_resouces(Unique_Id) values(?)";
		     this.jdbcTemplate.update(addQuery,  new Object[]{uid});
		     request.setAttribute("uniqueIDinternal", uid);
		     HttpSession session = request.getSession(false);
		        session.setAttribute("UIdinternalvetting", uid);
		     YetToJoinDao  dao =new YetToJoinDao();
		     List<DownloadPathvo> path=dao.internalpathcheck(uid, jdbcTemplate);
		     System.out.println("---------"+path);
		     request.setAttribute("dupath", path);
		    
		return "Bgv/InternalResVetting";
	

	}
	@RequestMapping(value = "/internalResourceVettingreload.php")
	public String internalResourceVettingR(HttpServletRequest request) {
		
		 
		 String uid=(String) request.getSession().getAttribute("UIdinternalvetting");
		 request.setAttribute("uniqueIDinternal", uid);
		System.out.println("0000 "+uid);
		 YetToJoinDao  dao =new YetToJoinDao();
		     List<DownloadPathvo> path=dao.internalpathcheck(uid, jdbcTemplate);
		     System.out.println("---------"+path);
		     request.setAttribute("dupath", path);
		     String finalname=(String) request.getSession().getAttribute("uniquename");
		     System.out.println("name reload "+finalname);
		     request.setAttribute("namereload", finalname);
		     String projectname=(String) request.getSession().getAttribute("projectName");
		     System.out.println("name  "+projectname);
		     request.setAttribute("projectNamereload", projectname);
		     String projectcode=(String) request.getSession().getAttribute("projectCode");
		     System.out.println("code  "+projectcode);
		     request.setAttribute("projectCodereload", projectcode);
		     
		     String SApid=(String) request.getSession().getAttribute("SAPid");
		     System.out.println("id  "+SApid);
		     request.setAttribute("SAPidreload", SApid);
		     
		     
		return "Bgv/InternalResVetting";
	

	}
	@RequestMapping(value = "/newBgvApproval.php")
	public String pmoBgvApproval(HttpServletRequest request) {
		try{
		BgvPmoServiceImpl impl = new BgvPmoServiceImpl();
		System.out.println(jdbcTemplate);
		System.out.println("hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii");
		request.setAttribute("getBgvDetails", impl.getBgvDetails(jdbcTemplate));
		}
		catch(Exception e){
			 //return "forward:../../pmoAutomation/Login/errorPage.php";
			e.printStackTrace();
		}
		return "Bgv/BGVInitiatePmo";
		//return "Bgv/Bgvinitpmoapl";

	}
	@RequestMapping(value = "/managerpendingwithpmo.php")
	public String managerpendingwithpmo(HttpServletRequest request) {
		try{
			 int sapid=(int) request.getSession().getAttribute("managerId");
		BgvPmoServiceImpl impl = new BgvPmoServiceImpl();
		System.out.println(jdbcTemplate);
		System.out.println("hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii");
		request.setAttribute("ManagergetBgvDetails", impl.managerpendingwithpmo(sapid,jdbcTemplate));
		}
		catch(Exception e){
			 //return "forward:../../pmoAutomation/Login/errorPage.php";
			e.printStackTrace();
		}
		return "Bgv/BgvManagerPendingPmo";
		//return "Bgv/Bgvinitpmoapl";

	}
	@RequestMapping(value = "/preCheckCentralBGV.php")
	public String preCheckCentralBGV(HttpServletRequest request) {
		try{
		BgvPmoServiceImpl impl = new BgvPmoServiceImpl();
		System.out.println(jdbcTemplate);
		System.out.println("hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii");
		request.setAttribute("getBgvDetails", impl.getpreCheckCentralBGV(jdbcTemplate));
		}
		catch(Exception e){
		return "forward:../../pmoAutomation/Login/errorPage.php";
		//	e.printStackTrace();
		}
		return "Bgv/BGVCentral";
		

	}
	@RequestMapping(value = "/ManagerpreCheckCentralBGV.php")
	public String ManagerpreCheckCentralBGV(HttpServletRequest request) {
		try{
			 int sapid=(int) request.getSession().getAttribute("managerId");
		BgvPmoServiceImpl impl = new BgvPmoServiceImpl();
		System.out.println(jdbcTemplate);
		System.out.println("hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii");
		request.setAttribute("ManagergetBgvDetails", impl.getpreCheckCentralBGVManager(sapid,jdbcTemplate));
		}
		catch(Exception e){
		return "forward:../../pmoAutomation/Login/errorPage.php";
		//	e.printStackTrace();
		}
		return "Bgv/BgvManagerPendingCentral";
		

	}
	@RequestMapping(value = "/preCheckVendorBGV.php")
	public String preCheckVendorBGV(HttpServletRequest request) {
		try{ 
		BgvPmoServiceImpl impl = new BgvPmoServiceImpl();
		System.out.println(jdbcTemplate);
		System.out.println("hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii");
		request.setAttribute("getBgvDetails", impl.getpreCheckVendorBGV(jdbcTemplate));
		}
		catch(Exception e){
		return "forward:../../pmoAutomation/Login/errorPage.php";
		//	e.printStackTrace();
		}
		return "Bgv/BgvPreVendor";
		

	}
	@RequestMapping(value = "/ManagerpreCheckVendorBGV.php")
	public String ManagerpreCheckVendorBGV(HttpServletRequest request) {
		try{int sapid=(int) request.getSession().getAttribute("managerId");
		BgvPmoServiceImpl impl = new BgvPmoServiceImpl();
		System.out.println(jdbcTemplate);
		System.out.println("hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii");
		request.setAttribute("ManagervendorgetBgvDetails", impl.getpreCheckVendorBGVManager(sapid,jdbcTemplate));
		}
		catch(Exception e){
		return "forward:../../pmoAutomation/Login/errorPage.php";
			//e.printStackTrace();
		}
		return "Bgv/BgvMnagerPendingVendor";
		

	}
	@RequestMapping(value = "/preCheckResourceBGV.php")
	public String preCheckResourceBGV(HttpServletRequest request) {
		try{
		BgvPmoServiceImpl impl = new BgvPmoServiceImpl();
		System.out.println(jdbcTemplate);
		System.out.println("hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii");
		request.setAttribute("getBgvDetails", impl.getpreCheckResourceBGV(jdbcTemplate));
		}
		catch(Exception e){
		return "forward:../../pmoAutomation/Login/errorPage.php";
		//	e.printStackTrace();
		}
		return "Bgv/BgvPreResource";
		

	}
	
	@RequestMapping(value = "/ManagerpreCheckResourceBGV.php")
	public String ManagerpreCheckResourceBGV(HttpServletRequest request) {
		try{int sapid=(int) request.getSession().getAttribute("managerId");
		BgvPmoServiceImpl impl = new BgvPmoServiceImpl();
		System.out.println(jdbcTemplate);
		System.out.println("hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii");
		request.setAttribute("ManagerresourcegetBgvDetails", impl.getpreCheckResourceBGVManager(sapid,jdbcTemplate));
		}
		catch(Exception e){
		return "forward:../../pmoAutomation/Login/errorPage.php";
		//	e.printStackTrace();
		}
		return "Bgv/BgvManagerPendingResource";
		

	}
/*	@RequestMapping(value = "/preCheckPmoPending.php")
	public String preCheckPmoPending(HttpServletRequest request) {
		try{
		BgvPmoServiceImpl impl = new BgvPmoServiceImpl();
		System.out.println(jdbcTemplate);
		System.out.println("hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii");
		request.setAttribute("getBgvDetails", impl.getpreCheckPmoPending(jdbcTemplate));
		}
		catch(Exception e){
	return "forward:../../pmoAutomation/Login/errorPage.php";
		//	e.printStackTrace();
		}
		return "Bgv/BgvPmoPending";
		

	}*/
	@RequestMapping(value = "/ManagerpreCheckPmoPending.php")
	public String ManagerpreCheckPmoPending(HttpServletRequest request) {
		try{int sapid=(int) request.getSession().getAttribute("managerId");
		BgvPmoServiceImpl impl = new BgvPmoServiceImpl();
		System.out.println(jdbcTemplate);
		System.out.println("hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii");
		request.setAttribute("getBgvDetails", impl.getpreCheckPmoPendingManager(sapid,jdbcTemplate));
		}
		catch(Exception e){
		return "forward:../../pmoAutomation/Login/errorPage.php";
	//		e.printStackTrace();
		}
		return "Bgv/BgvManagerPendingresult";
		

	}
	@RequestMapping(value = "/preCheckPmo.php")
	public String preCheckPmo(HttpServletRequest request) {
		try{
		BgvPmoServiceImpl impl = new BgvPmoServiceImpl();
		System.out.println(jdbcTemplate);
		System.out.println("hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii");
		request.setAttribute("getBgvDetails", impl.getpreCheckPmo(jdbcTemplate));
		}
		catch(Exception e){
	return "forward:../../pmoAutomation/Login/errorPage.php";
		//	e.printStackTrace();
		}
		return "Bgv/BgvPmo";
		

	}
	@RequestMapping(value = "/YTJpreCheckPmo.php")
	public String YTJpreCheckPmo(HttpServletRequest request) {
		try{
		BgvPmoServiceImpl impl = new BgvPmoServiceImpl();
		System.out.println(jdbcTemplate);
		System.out.println("hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii");
		request.setAttribute("getBgvDetails", impl.YTJgetpreCheckPmo(jdbcTemplate));
		request.setAttribute("getYTJgpnDetails", impl.YTJGpnInitiate(jdbcTemplate));
		}
		catch(Exception e){
	return "forward:../../pmoAutomation/Login/errorPage.php";
		//	e.printStackTrace();
		}
		return "Bgv/BgvPmoYTJ";
		

	}
	
	@RequestMapping(value = "/preCheckcompleted.php")
	public String preCheckcompleted(HttpServletRequest request) {
		try{
		BgvPmoServiceImpl impl = new BgvPmoServiceImpl();
		System.out.println(jdbcTemplate);
		System.out.println("hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii");
		request.setAttribute("getBgvDetails", impl.getpreCheckcompleted(jdbcTemplate));
		
		}
		catch(Exception e){
	//return "forward:../../pmoAutomation/Login/errorPage.php";
	e.printStackTrace();
		}
		return "Bgv/Bgvprecheckcompleted";
		

	}
	@RequestMapping(value = "/postcheckpending.php")
	public String postcheckpending(HttpServletRequest request) {
		try{
		BgvPmoServiceImpl impl = new BgvPmoServiceImpl();
		System.out.println(jdbcTemplate);
		System.out.println("hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii");
		request.setAttribute("getBgvDetails", impl.getpostcheckpending(jdbcTemplate));
		}
		catch(Exception e){
		//return "forward:../../pmoAutomation/Login/errorPage.php";
			e.printStackTrace();
		}
		return "Bgv/postcheckpending";
		

	}
	@RequestMapping(value = "/postcheckcompleted.php")
	public String postcheckcompleted(HttpServletRequest request) {
		try{
		BgvPmoServiceImpl impl = new BgvPmoServiceImpl();
		System.out.println(jdbcTemplate);
		System.out.println("hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii");
		request.setAttribute("getBgvDetails", impl.getpostcheckcompleted(jdbcTemplate));
		}
		catch(Exception e){
		//return "forward:../../pmoAutomation/Login/errorPage.php";
			e.printStackTrace();
		}
		return "Bgv/postcheckcompleted";
		

	}
	@RequestMapping(value = "/ManagerpreCheckPmocompleted.php")
	public String ManagerpreCheckPmocompleted(HttpServletRequest request) {
		try{int sapid=(int) request.getSession().getAttribute("managerId");
		BgvPmoServiceImpl impl = new BgvPmoServiceImpl();
		System.out.println(jdbcTemplate);
		System.out.println("hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii");
		request.setAttribute("getBgvDetails", impl.ManagerpreCheckPmocompleted(sapid,jdbcTemplate));
		}
		catch(Exception e){
		//return "forward:../../pmoAutomation/Login/errorPage.php";
			e.printStackTrace();
		}
		return "Bgv/BgvManagerPendingCompleted";
		

	}
	
	@RequestMapping(value = "/ManagerpostCheckpending.php")
	public String ManagerpostCheckpending(HttpServletRequest request) {
		try{int sapid=(int) request.getSession().getAttribute("managerId");
		BgvPmoServiceImpl impl = new BgvPmoServiceImpl();
		System.out.println(jdbcTemplate);
		System.out.println("hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii");
		request.setAttribute("getBgvDetails", impl.ManagerpostCheckpending(sapid,jdbcTemplate));
		}
		catch(Exception e){
		//return "forward:../../pmoAutomation/Login/errorPage.php";
			e.printStackTrace();
		}
		return "Bgv/postcheckpendingmanager";
		

	}
	
	@RequestMapping(value = "/ManagerpostCheckcompleted.php")
	public String ManagerpostCheckcompleted(HttpServletRequest request) {
		try{int sapid=(int) request.getSession().getAttribute("managerId");
		BgvPmoServiceImpl impl = new BgvPmoServiceImpl();
		System.out.println(jdbcTemplate);
		System.out.println("hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii");
		request.setAttribute("getBgvDetails", impl.ManagerpostCheckcompleted(sapid,jdbcTemplate));
		}
		catch(Exception e){
		//return "forward:../../pmoAutomation/Login/errorPage.php";
			e.printStackTrace();
		}
		return "Bgv/postcheckcompletedmanager";
		

	}
	@RequestMapping(value = "/preCheckPmoReport.php")
	public String preCheckPmoReport(HttpServletRequest request) {
		try{
		BgvPmoServiceImpl impl = new BgvPmoServiceImpl();
		System.out.println(jdbcTemplate);
		System.out.println("hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii");
		request.setAttribute("getBgvDetailsReport", impl.getpreCheckPmoReport(jdbcTemplate));
		}
		catch(Exception e){
		//return "forward:../../pmoAutomation/Login/errorPage.php";
			e.printStackTrace();
		}
		return "Bgv/BgvPmoReport";
		

	}
	@RequestMapping(value = "/preCheckPmoDetails.php")
	public String preCheckPmoDetails(HttpServletRequest request) {
		try{
		BgvPmoServiceImpl impl = new BgvPmoServiceImpl();
		System.out.println(impl.getpreCheckPmoDetails(jdbcTemplate));
		System.out.println("hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii");
		request.setAttribute("getBgvDetails", impl.getpreCheckPmoDetails(jdbcTemplate));
		}
		catch(Exception e){
		//return "forward:../../pmoAutomation/Login/errorPage.php";
			e.printStackTrace();
		}
		return "Bgv/BgvPmoTeam";
		

	}
	
	
	@RequestMapping(value = "/preBGVPage.php")
	public String preBGVPage(HttpServletRequest request) {
		
		return "Bgv/Bgvinitpmoapl";
	}
	
	@RequestMapping(value = "/savePmo.php", method = RequestMethod.POST)
	public void pmoBgvApprovall(HttpServletRequest request,HttpServletResponse response) throws IOException{
		
		
			try{
				
			String sapid=request.getParameter("sapAdmin"+request.getParameter("sapHid"));
			System.out.println(request.getParameter("sapHid"));
			
			System.out.println(sapid);
			int bgvperson=Integer.parseInt(sapid);
		String updQuery = "update mydb.bgv set PRE_START_CHECK_WITH_PMO='INITIATED',PRE_START_CHECK_WITH_PMO_DATE=current_timestamp()  where SAP_ID=?;";
			this.jdbcTemplate.update(updQuery,  new Object[] {sapid});
				System.out.println(updQuery);
			BgvMailDao b= new BgvMailDao();
				App mailtrigger = new App();
			//	 String[] a1 = { "kotipalliv@hcl.com","kranthikiran.m@hcl.com"  };
				 
					List<Bgvhclmailvo> bgvmail= b.mailidsforbgvinitiate(bgvperson, jdbcTemplate);
					System.out.println("listttttt"+bgvmail);	 
					String[] array = new String[bgvmail.size()];
					int index = 0;
					for (Object value : bgvmail) {
						array[index] = String.valueOf( value );
					List<bgvinitiatetempvo> initiatebgvmaildetails=b.listoftemplatedataforinitiatebgv(bgvperson, jdbcTemplate);
					
				
					mailtrigger.Mailtrigger("celeritas@hcl.com", array[index],  "BGV INITIATED FOR BELOW RESOURCE", null, "/INITIATEBGVTEMP.jsp", initiatebgvmaildetails, null);
			     //  s.method("shyamsunder.p@hcl.com",a1[i], "Checking Email Triggering", "/initiatebgv.vm",initiatebgvmaildetails);
				
						}	
				
					
			}
			catch(Exception e){
				PrintWriter out = response.getWriter();
				out.println("<html><body><script>alert('Mail not Triggered');window.location= '../../pmoAutomation/Bgv/preCheckPmoDetails.php';</script></body></html>");
			}
			PrintWriter out = response.getWriter();
			out.println("<html><body><script>alert('Mail Sent Successfully To Manager!!!');window.location= '../../pmoAutomation/Bgv/preCheckPmoDetails.php';</script></body></html>");
				
		
		
		
		
	}
	@RequestMapping(value = "/centralBgvSubmit.php")
	public String centralBgvSubmit(HttpServletRequest request){
		
			
			
			String sapid=request.getParameter("sapAdmin"+request.getParameter("sapHid"));
			System.out.println(request.getParameter("sapHid"));
			
			System.out.println(sapid);
			
			
			String flag="N";
			
					
			String updQuery = "update mydb.bgv set PENDING_WITH_CENTRAL_BGV=?,PENDING_WITH_CENTRAL_BGV_DATE=current_timestamp()  where SAP_ID=?;";
			this.jdbcTemplate.update(updQuery,  new Object[] {flag,sapid});
				System.out.println(updQuery);
				
		
		
		
		
		return "redirect:../../pmoAutomation/Bgv/preCheckCentralBGV.php";
		
	}
	
	@RequestMapping(value = "/resourceBgvSubmit.php")
	public String resourceBgvSubmit(HttpServletRequest request){
		
			
			
			String sapid=request.getParameter("sapAdmin"+request.getParameter("sapHid"));
			System.out.println(request.getParameter("sapHid"));
			
			System.out.println(sapid);
			
			
			String flag="N";
			
					
			String updQuery = "update mydb.bgv set PENDING_WITH_RESOURCE=?,PENDING_WITH_RESOURCE_DATE=current_timestamp()  where SAP_ID=?;";
			this.jdbcTemplate.update(updQuery,  new Object[] {flag,sapid});
				System.out.println(updQuery);
				
		
		
		
		
		return "redirect:../../pmoAutomation/Bgv/preCheckResourceBGV.php";
		
	}
	@RequestMapping(value = "/finalBgvApproval.php")
	public String pmoBgvFinalApproval(HttpServletRequest request){
		BgvPmoServiceImpl impl = new BgvPmoServiceImpl();
		
		System.out.println(jdbcTemplate);
		request.setAttribute("getfinalBgvDetails", impl.getfinalBgvDetails(jdbcTemplate) );
		
		return "Bgv/BgvFinal";
		
	}
	
	@RequestMapping(value = "/yetToJoineeApproval.php", method = RequestMethod.GET)
	public String pmoBgvYetToJoinApproval(HttpServletRequest request){
		BgvPmoServiceImpl impl = new BgvPmoServiceImpl();
		System.out.println(jdbcTemplate);
		//System.out.println(impl.getYetToJoineeBgvdetails(jdbcTemplate));
		request.setAttribute("getYetToJoineeBgvdetails", impl.getYetToJoineeBgvdetails(jdbcTemplate));
		return "Bgv/BgvYtgPmo";
		
	}

	@RequestMapping(value = "/savebgv.php",params="bgvInitiation", method ={RequestMethod.POST,RequestMethod.GET})
	public String saveBgvDetails(Model model,HttpServletRequest request,HttpServletResponse response)throws NullPointerException {
		
			
		
			try{
				
			
		String bgvDetail = request.getParameter("sapBGV"
				+request.getParameter("cou")
				);
		System.out.println(bgvDetail);
		String color = request.getParameter("radColor");
		String yesradio = request.getParameter("yesno");
		String date=request.getParameter("datebgv");
		//String remarks = request.getParameter("remarks");
		System.out.println("radioooooooooyn "+yesradio+"remarkssssss "+color+"dateeeeeeeee "+date);
	
		BgvPmoServiceImpl impl = new BgvPmoServiceImpl();
		// System.out.println("ASAAS"+(int)bgvDetail[0]);
		impl.saveBgvDetails(jdbcTemplate, Integer.parseInt(bgvDetail), yesradio,color,date);
			}
			catch(Exception e){ 
				//return "forward:../../pmoAutomation/Login/errorPage.php";
				e.printStackTrace();
			}
		return "forward:../../pmoAutomation/Bgv/preCheckPmo.php";
		
		
		
		
	}
	
	@RequestMapping(value = "/YTJsavebgv.php", method ={RequestMethod.POST,RequestMethod.GET})
	public String YTJsaveBgvDetails(Model model,HttpServletRequest request,HttpServletResponse response)throws NullPointerException {
		
			
		
			try{
				
			
		String bgvDetail = request.getParameter("sapBGV"
				+request.getParameter("cou")
				);
		System.out.println(bgvDetail);
		String color = request.getParameter("radColor");
		//String yesradio = request.getParameter("yesno");
		String date=request.getParameter("datebgv");
		//String remarks = request.getParameter("remarks");
		System.out.println("remarkssssss "+color+"dateeeeeeeee "+date);
	
		BgvPmoServiceImpl impl = new BgvPmoServiceImpl();
		// System.out.println("ASAAS"+(int)bgvDetail[0]);
		impl.YTJsaveBgvDetails(jdbcTemplate, Integer.parseInt(bgvDetail),color,date);
			}
			catch(Exception e){ 
				//return "forward:../../pmoAutomation/Login/errorPage.php";
				e.printStackTrace();
			}
		return "forward:../../pmoAutomation/Bgv/YTJpreCheckPmo.php";
		
		
		
		
	}
	@RequestMapping(value = "/YTJgpninitiation.php", method ={RequestMethod.POST,RequestMethod.GET})
	public String YTJgpninitiation(Model model,HttpServletRequest request,HttpServletResponse response)throws NullPointerException {
		
			
		
			try{
				
			
		String gpnDetail = request.getParameter("sapgpn"
				+request.getParameter("cou")
				);
		System.out.println(gpnDetail);
		
		
	jdbcTemplate.update("update mydb.bgv set bgv.INITIATE_GPN='Y',GPN_Initiation_Date=current_date() where bgv.SAP_ID="+gpnDetail);
			}
			catch(Exception e){ 
				//return "forward:../../pmoAutomation/Login/errorPage.php";
				e.printStackTrace();
			}
		return "forward:../../pmoAutomation/Bgv/YTJpreCheckPmo.php";
		
		
		
		
	}
	
	@RequestMapping(value = "/savebgv.php",params="pdfuploading", method = {RequestMethod.POST,RequestMethod.GET})
	public void interimreportupload(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
	/*	System.out.println("hi iam in controller");
		// Internally hitting another Servlet
        String bgvDetail = request.getParameter("sapBGV"+ request.getParameter("email"));
		int bgvperson=Integer.parseInt(bgvDetail);
		System.out.println("controller     "+bgvperson);
		HttpSession session = request.getSession();
        session.setAttribute("pdfUploadId", bgvperson);
        
		// TODO:Spring Multipart enable it,Servlet disable it
*/		request.setAttribute("fileTypepdf", "pdfupload");
		request.getRequestDispatcher("/fileUpload.upload").forward(request,
				response);
 }
	
	@RequestMapping(value = "/savebgv.php",params="JustificationEmailAttachment", method = {RequestMethod.POST,RequestMethod.GET})
	public void JustificationEmailAttachment(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		System.out.println("hi iam in controller just");
		// Internally hitting another Servlet
      /*  String bgvDetailjust = request.getParameter("sapBGV"+ request.getParameter("just"));
		int bgvpersonjust=Integer.parseInt(bgvDetailjust);
		System.out.println("controller just     "+bgvpersonjust);
		HttpSession session = request.getSession();
        session.setAttribute("JustificationEmailAttachmentID", bgvpersonjust);
		// TODO:Spring Multipart enable it,Servlet disable it
*/		request.setAttribute("JustificationEmailupload", "pdfuploadjust");
		request.getRequestDispatcher("/fileUpload.uploadJustificationEmailAttachment").forward(request,
				response);
 }
	@RequestMapping(value = "/savebgv.php",params="Clearanceuploading", method = {RequestMethod.POST,RequestMethod.GET})
	public void ClearanceEmailAttachment(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		System.out.println("hi iam in controller clear");
		// Internally hitting another Servlet
      /*  String bgvDetailjust = request.getParameter("sapBGV"+ request.getParameter("just"));
		int bgvpersonjust=Integer.parseInt(bgvDetailjust);
		System.out.println("controller just     "+bgvpersonjust);
		HttpSession session = request.getSession();
        session.setAttribute("JustificationEmailAttachmentID", bgvpersonjust);
		// TODO:Spring Multipart enable it,Servlet disable it
*/		request.setAttribute("ClearanceEmailupload", "pdfuploadClear");
		request.getRequestDispatcher("/fileUpload.uploadClearanceEmailAttachment").forward(request,
				response);
 }
	@RequestMapping(value = "/savebgv.php",params="IdDocumentuploading", method = {RequestMethod.POST,RequestMethod.GET})
	public void IdDocumentEmailAttachment(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		System.out.println("hi iam in controller clear");
		// Internally hitting another Servlet
      /*  String bgvDetailjust = request.getParameter("sapBGV"+ request.getParameter("just"));
		int bgvpersonjust=Integer.parseInt(bgvDetailjust);
		System.out.println("controller just     "+bgvpersonjust);
		HttpSession session = request.getSession();
        session.setAttribute("JustificationEmailAttachmentID", bgvpersonjust);
		// TODO:Spring Multipart enable it,Servlet disable it
*/		request.setAttribute("IdDocumentEmailupload", "pdfuploadIdDocument");
		request.getRequestDispatcher("/fileUpload.uploadIdDocumentEmailAttachment").forward(request,
				response);
 }
	
	@RequestMapping(value = "/interimreportupload.php")
	public String interimreportuploadpre(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String sapID=request.getParameter("interimuploadSap");
		
		System.out.println("checking in con   "+sapID);
				int sapIDfrminterimMail=Integer.parseInt(sapID);
				HttpSession session = request.getSession();
		        session.setAttribute("sapIDinterim", sapIDfrminterimMail);
		return "Bgv/interimreportuploadprecheck";
		
	}
	@RequestMapping(value = "/uploadClearanceMail.php")
	public String uploadClearanceMail(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String sapID=request.getParameter("ClearanceFormUpload");
		
		System.out.println("checking in clearance con  "+sapID);
				int sapIDfrminterimMail=Integer.parseInt(sapID);
				HttpSession session = request.getSession();
		        session.setAttribute("sapIDClearance", sapIDfrminterimMail);
		return "Bgv/Clearancereportuploadprecheck";
		
	}
	@RequestMapping(value = "/uploadIdDocumentMail.php")
	public String uploadIdDocumentMail(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String sapID=request.getParameter("IdDocumentuploadSap");
		
		System.out.println("checking in IdDocument con  "+sapID);
				int sapIDfrminterimMail=Integer.parseInt(sapID);
				HttpSession session = request.getSession();
		        session.setAttribute("sapIDIdDocument", sapIDfrminterimMail);
		return "Bgv/IdDocumentreportuploadprecheck";
		
	}
	@RequestMapping(value = "/uploadjustificationMail.php")
	public String uploadjustificationMail(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String sapID=request.getParameter("JustificationuploadSap");
		
		System.out.println("checking in con   "+sapID);
				int sapIDfrmjustificationMail=Integer.parseInt(sapID);
				HttpSession session = request.getSession();
		        session.setAttribute("sapIDJust", sapIDfrmjustificationMail);
		return "Bgv/JustificationMailUploadforBgvPreCheck";
		
	}
	 @RequestMapping(value = "/uploadpage.php")
	    public void uploadpage(HttpServletRequest request,
	    		HttpServletResponse response) throws ServletException, IOException 
	    {
		 PrintWriter out = response.getWriter();
	 int sapid=(int) request.getSession().getAttribute("sapIDinterim");
		 String finaluploadPath=(String) request.getSession().getAttribute("finaluploadPath");
		 if(finaluploadPath!=null){
			 
		 
	        System.out.println("servlet sap "+sapid);
	        System.out.println("final path in controller    "+finaluploadPath);
	        jdbcTemplate.update("update mydb.bgv set bgv.Upload_Path='"+finaluploadPath+"' where bgv.SAP_ID="+sapid);
		 request.setAttribute("message", "File successfully uploaded!!!");
		
		 out.println("<html><body><script>alert('File successfully uploaded!!!');window.close();</script></body></html>");
	}
else{
	 out.println("<html><body><script>alert('Error in uploading File!!!');window.close();</script></body></html>");
}
	    		
	    	//return " out.println("<html><body><script>alert('No Existing Document found');window.location= '../../pmoAutomation/Bgv/newBgvApproval.php';</script></body></html>");";
	    	}
	 
	 @RequestMapping(value = "/IdDocumentpage.php")
	    public void IdDocumentpage(HttpServletRequest request,
	    		HttpServletResponse response) throws ServletException, IOException 
	    {
		 PrintWriter out = response.getWriter();
	 int sapid=(int) request.getSession().getAttribute("sapIDIdDocument");
		 String finaluploadPath=(String) request.getSession().getAttribute("finalIdDocumentPath");
		 if(finaluploadPath!=null){
			 
		 
	        System.out.println("servlet sap "+sapid);
	        System.out.println("final path in controller    "+finaluploadPath);
	        jdbcTemplate.update("update mydb.bgv set bgv.Upload_Path_IdDocument='"+finaluploadPath+"' where bgv.SAP_ID="+sapid);
		 request.setAttribute("message", "File successfully uploaded!!!");
		
		 out.println("<html><body><script>alert('File successfully uploaded!!!');window.close();</script></body></html>");
	}
else{
	 out.println("<html><body><script>alert('Error in uploading File!!!');window.close();</script></body></html>");
}
	    		
	    	//return " out.println("<html><body><script>alert('No Existing Document found');window.location= '../../pmoAutomation/Bgv/newBgvApproval.php';</script></body></html>");";
	    	}
	 
	 @RequestMapping(value = "/justificationuploadpage.php")
	    public void justificationuploadpage(HttpServletRequest request,
	    		HttpServletResponse response) throws ServletException, IOException 
	    {
		 PrintWriter out = response.getWriter();
	 int sapid=(int) request.getSession().getAttribute("sapIDJust");
		 String finaluploadPath=(String) request.getSession().getAttribute("justificationuploadPath");
		 System.out.println(sapid+" !!!!!!!!!!!!!! "+finaluploadPath);
		 if(finaluploadPath!=null){
			 
		 
	        System.out.println("servlet sap "+sapid);
	        System.out.println("final path in controller    "+finaluploadPath);
	        jdbcTemplate.update("update mydb.bgv set bgv.Upload_Path_justification='"+finaluploadPath+"' where bgv.SAP_ID="+sapid);
		 request.setAttribute("message", "File successfully uploaded!!!");
		
		 out.println("<html><body><script>alert('File successfully uploaded!!!');window.close();</script></body></html>");
	}
else{
	 out.println("<html><body><script>alert('Error in uploading File!!!');window.close();</script></body></html>");
}
	    		
	    	//return " out.println("<html><body><script>alert('No Existing Document found');window.location= '../../pmoAutomation/Bgv/newBgvApproval.php';</script></body></html>");";
	    	}
	 @RequestMapping(value = "/Clearanceuploadpage.php")
	    public void Clearanceuploadpage(HttpServletRequest request,
	    		HttpServletResponse response) throws ServletException, IOException 
	    {
		 PrintWriter out = response.getWriter();
	 int sapid=(int) request.getSession().getAttribute("sapIDClearance");
		 String finaluploadPath=(String) request.getSession().getAttribute("ClearanceuploadPath");
		 System.out.println(sapid+" !!!!!!!!!!!!!! "+finaluploadPath);
		 if(finaluploadPath!=null){
			 
		 
	        System.out.println("servlet sap "+sapid);
	        System.out.println("final path in controller    "+finaluploadPath);
	        jdbcTemplate.update("update mydb.bgv set bgv.Upload_Path_Clearance='"+finaluploadPath+"' where bgv.SAP_ID="+sapid);
		 request.setAttribute("message", "File successfully uploaded!!!");
		
		 out.println("<html><body><script>alert('File successfully uploaded!!!');window.close();</script></body></html>");
	}
else{
	 out.println("<html><body><script>alert('Error in uploading File!!!');window.close();</script></body></html>");
}
	    		
	    	//return " out.println("<html><body><script>alert('No Existing Document found');window.location= '../../pmoAutomation/Bgv/newBgvApproval.php';</script></body></html>");";
	    	}
	 
	 @RequestMapping(value = "/pdfdownload.php")
		public void pdfdownload(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			
		
			String sapid=request.getParameter("searchsapforlink");
			int sapidconvert=Integer.parseInt(sapid);
			System.out.println("controller sap from jsp    "+sapid);
			DownloadPathDao path=new DownloadPathDao();
			List<DownloadPathvo> downloadPathlink=path.DownloadPath(sapidconvert, jdbcTemplate);
			
			String[] array = new String[downloadPathlink.size()];
			int index = 0;
			for (Object value : downloadPathlink) {
				array[index] = String.valueOf( value );
			}
			
			HttpSession session = request.getSession();
	        session.setAttribute("downloadpathsession", array[index]);
			// TODO:Spring Multipart enable it,Servlet disable it
			request.setAttribute("fileTypepdfdown", "pdfdownload");
			
			request.getRequestDispatcher("/fileUpload.download").forward(request,
					response);
			
	 }
	 @RequestMapping(value = "/pdfdownloadreport.php")
		public void pdfdownloadreport(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			
		
			String sapid=request.getParameter("searchsapforlinkreport");
			int sapidconvert=Integer.parseInt(sapid);
			System.out.println("controller sap from jsp    "+sapid);
			DownloadPathDao path=new DownloadPathDao();
			List<DownloadPathvo> downloadPathlink=path.DownloadPath(sapidconvert, jdbcTemplate);
			
			String[] array = new String[downloadPathlink.size()];
			int index = 0;
			for (Object value : downloadPathlink) {
				array[index] = String.valueOf( value );
			}
			
			HttpSession session = request.getSession();
	        session.setAttribute("downloadpathsessionreport", array[index]);
			// TODO:Spring Multipart enable it,Servlet disable it
			request.setAttribute("fileTypepdfdown", "pdfdownload");
			
			request.getRequestDispatcher("/fileUpload.downloadreport").forward(request,
					response);
			
	 }
	 @RequestMapping(value = "/pdfdownloadjustification.php")
		public void pdfdownloadjustification(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			
		
			String sapid=request.getParameter("justificationdownloadlink");
			int sapidconvert=Integer.parseInt(sapid);
			System.out.println("controller sap from jsp    "+sapid);
			DownloadPathDao path=new DownloadPathDao();
			List<DownloadPathvo> downloadPathlink=path.DownloadPathjustification(sapidconvert, jdbcTemplate);
			
			String[] array = new String[downloadPathlink.size()];
			int index = 0;
			for (Object value : downloadPathlink) {
				array[index] = String.valueOf( value );
			}
			
			HttpSession session = request.getSession();
	        session.setAttribute("downloadpathjustification", array[index]);
			// TODO:Spring Multipart enable it,Servlet disable it
			request.setAttribute("fileTypepdfdown", "pdfdownload");
			
			request.getRequestDispatcher("/fileUpload.downloadjustification").forward(request,
					response);
			
	 }
	 @RequestMapping(value = "/pdfdownloadjustificationReport.php")
		public void pdfdownloadjustificationReport(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			
		
			String sapid=request.getParameter("justificationdownloadlinkReport");
			int sapidconvert=Integer.parseInt(sapid);
			System.out.println("controller sap from jsp    "+sapid);
			DownloadPathDao path=new DownloadPathDao();
			List<DownloadPathvo> downloadPathlink=path.DownloadPathjustification(sapidconvert, jdbcTemplate);
			
			String[] array = new String[downloadPathlink.size()];
			int index = 0;
			for (Object value : downloadPathlink) {
				array[index] = String.valueOf( value );
			}
			
			HttpSession session = request.getSession();
	        session.setAttribute("downloadpathjustificationReport", array[index]);
			// TODO:Spring Multipart enable it,Servlet disable it
			request.setAttribute("fileTypepdfdown", "pdfdownload");
			
			request.getRequestDispatcher("/fileUpload.downloadjustificationReport").forward(request,
					response);
			
	 }
	 @RequestMapping(value = "/pdfdownloadClearance.php")
		public void pdfdownloadClearance(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			
		
			String sapid=request.getParameter("Clearancedownloadlink");
			int sapidconvert=Integer.parseInt(sapid);
			System.out.println("controller sap from jsp    "+sapid);
			DownloadPathDao path=new DownloadPathDao();
			List<DownloadPathvo> downloadPathlink=path.DownloadPathclearance(sapidconvert, jdbcTemplate);
			
			String[] array = new String[downloadPathlink.size()];
			int index = 0;
			for (Object value : downloadPathlink) {
				array[index] = String.valueOf( value );
			}
			
			HttpSession session = request.getSession();
	        session.setAttribute("downloadpathClearance", array[index]);
			// TODO:Spring Multipart enable it,Servlet disable it
			request.setAttribute("fileTypepdfdown", "pdfdownload");
			
			request.getRequestDispatcher("/fileUpload.downloadClearance").forward(request,
					response);
			
	 }
	 @RequestMapping(value = "/pdfdownloadClearanceReport.php")
		public void pdfdownloadClearanceReport(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			
		
			String sapid=request.getParameter("ClearancedownloadlinkReport");
			int sapidconvert=Integer.parseInt(sapid);
			System.out.println("controller sap from jsp    "+sapid);
			DownloadPathDao path=new DownloadPathDao();
			List<DownloadPathvo> downloadPathlink=path.DownloadPathclearance(sapidconvert, jdbcTemplate);
			
			String[] array = new String[downloadPathlink.size()];
			int index = 0;
			for (Object value : downloadPathlink) {
				array[index] = String.valueOf( value );
			}
			
			HttpSession session = request.getSession();
	        session.setAttribute("downloadpathClearanceReport", array[index]);
			// TODO:Spring Multipart enable it,Servlet disable it
			request.setAttribute("fileTypepdfdown", "pdfdownload");
			
			request.getRequestDispatcher("/fileUpload.downloadClearanceReport").forward(request,
					response);
			
	 }
	 
	 @RequestMapping(value = "/pdfdownloadIdDocument.php")
		public void pdfdownloadIdDocument(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			
		
			String sapid=request.getParameter("IdDocumentdownloadlink");
			int sapidconvert=Integer.parseInt(sapid);
			System.out.println("controller sap from jsp    "+sapid);
			DownloadPathDao path=new DownloadPathDao();
			List<DownloadPathvo> downloadPathlink=path.DownloadPathIdDocument(sapidconvert, jdbcTemplate);
			
			String[] array = new String[downloadPathlink.size()];
			int index = 0;
			for (Object value : downloadPathlink) {
				array[index] = String.valueOf( value );
			}
			
			HttpSession session = request.getSession();
	        session.setAttribute("downloadpathIdDocument", array[index]);
			// TODO:Spring Multipart enable it,Servlet disable it
			request.setAttribute("fileTypepdfdown", "pdfdownload");
			
			request.getRequestDispatcher("/fileUpload.downloadIdDocument").forward(request,
					response);
			
	 }
	 
	 @RequestMapping(value = "/pdfdownloadIdDocumentReport.php")
		public void pdfdownloadIdDocumentReport(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			
		
			String sapid=request.getParameter("IdDocumentdownloadlinkReport");
			int sapidconvert=Integer.parseInt(sapid);
			System.out.println("controller sap from jsp    "+sapid);
			DownloadPathDao path=new DownloadPathDao();
			List<DownloadPathvo> downloadPathlink=path.DownloadPathIdDocument(sapidconvert, jdbcTemplate);
			
			String[] array = new String[downloadPathlink.size()];
			int index = 0;
			for (Object value : downloadPathlink) {
				array[index] = String.valueOf( value );
			}
			
			HttpSession session = request.getSession();
	        session.setAttribute("downloadpathIdDocumentReport", array[index]);
			// TODO:Spring Multipart enable it,Servlet disable it
			request.setAttribute("fileTypepdfdown", "pdfdownload");
			
			request.getRequestDispatcher("/fileUpload.downloadIdDocumentreport").forward(request,
					response);
			
	 }
	@RequestMapping(value = "/mail.php", method = RequestMethod.POST)
	public void mail(HttpServletRequest request,HttpServletResponse response) throws IOException {
		PrintWriter out = response.getWriter();
		try{
		String bgvDetail = request.getParameter("sapBGV"+ request.getParameter("email"));
		System.out.println("bgvtriggedto "+bgvDetail);
		int bgvperson=Integer.parseInt(bgvDetail);
		  String realPath = request.getRealPath("");

		/*BgvMailDao b= new BgvMailDao();
			App mailtrigger = new App();
			 String[] a1 = { "kotipalliv@hcl.com","kranthikiran.m@hcl.com"  };

					 
			for(int i=0;i<=a1.length-1;i++){
				List<bgvinitiatetempvo> initiatebgvmaildetails=b.listoftemplatedataforinitiatebgv(bgvperson, jdbcTemplate);
				System.out.println("listttttt"+initiatebgvmaildetails);
			
				mailtrigger.Mailtrigger("pmoappadmin_ou@hcl.com", a1[i],  "Initiate BGV for Following Resource", "harish", "/INITIATEBGVTEMP.jsp", initiatebgvmaildetails, null);
		     //  s.method("shyamsunder.p@hcl.com",a1[i], "Checking Email Triggering", "/initiatebgv.vm",initiatebgvmaildetails);
			
					}	*/
			
			BgvPmoServiceImpl impl = new BgvPmoServiceImpl();
			impl.bgvpersonupdatemailyes(jdbcTemplate, bgvperson);
			
			request.setAttribute("getBgvDetails", impl.getBgvDetails(jdbcTemplate));
		}
		catch(Exception e){
			out.println("<html><body><script>alert('Mail not Triggered');window.location= '../../pmoAutomation/Bgv/newBgvApproval.php';</script></body></html>");
		}
		out.println("<html><body><script>alert('Mail Sent Successfully!!!');window.location= '../../pmoAutomation/Bgv/newBgvApproval.php';</script></body></html>");
			
	}
	
	@RequestMapping(value = "/savefinalbgv.php",params="bgvfinalsubmit", method = {RequestMethod.POST,RequestMethod.GET})
	public String saveFinalBgvDetails(Model model,HttpServletRequest request,HttpServletResponse response)throws NullPointerException{
		try{
		String bgvDetail = request.getParameter("sapBGV"
				+ request.getParameter("cou"));
		System.out.println(bgvDetail);
		System.out.println(request.getParameter("radColor"));
		String color = request.getParameter("radColor");
		String finalremarks=request.getParameter("finalremarks");
		String date =request.getParameter("datefinalbgv");
		System.out.println(finalremarks);
		BgvPmoServiceImpl impl = new BgvPmoServiceImpl();
		impl.saveFinalBgvDetails(jdbcTemplate, Integer.parseInt(bgvDetail), color,finalremarks,date);
		}
		catch(Exception e){
			return "forward:../../pmoAutomation/Login/errorPage.php";
		}
		return "forward:../../pmoAutomation/Bgv/finalBgvApproval.php";
	}
	@RequestMapping(value = "/savefinalbgv.php",params="PostvettingEmailAttachment", method = {RequestMethod.POST,RequestMethod.GET})
	public void uploadforvettingpostcheck(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		System.out.println("hi iam in controller post check");
		// Internally hitting another Servlet
      /*  String bgvDetail = request.getParameter("sapBGV"+ request.getParameter("sapNUM"));
		int bgvperson=Integer.parseInt(bgvDetail);
		System.out.println("controller  post   "+bgvperson);
		HttpSession session = request.getSession();
        session.setAttribute("postcheckuploadSap", bgvperson);*/
        
		// TODO:Spring Multipart enable it,Servlet disable it
		request.setAttribute("vettingpostcheck", "postcheckvetting");
		request.getRequestDispatcher("/fileUpload.postvettingupload").forward(request,
				response);
 }
	
	
	 @RequestMapping(value = "/uploadpostvettingMail.php")
		public String uploadpostvettingMail(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			String sapID=request.getParameter("PostvettinguploadSap");
			
			System.out.println("checking in con   "+sapID);
					int sapIDfrmpostjustificationMail=Integer.parseInt(sapID);
					HttpSession session = request.getSession();
			        session.setAttribute("sapIDvettingPost", sapIDfrmpostjustificationMail);
			return "Bgv/PostvettingMailUploadforBgvPostCheck";
			
		}
	 @RequestMapping(value = "/uploadpagepostfinal.php")
	    public void uploadpagepostfinal(HttpServletRequest request,
	    		HttpServletResponse response) throws ServletException, IOException 
	    {
		 PrintWriter out = response.getWriter();
	 int sapid=(int) request.getSession().getAttribute("sapIDvettingPost");
		 String finaluploadPath=(String) request.getSession().getAttribute("finalpostcheckvetting");
		 if(finaluploadPath!=null){
			 
		 
	        System.out.println("servlet sap "+sapid);
	        System.out.println("final path in controller    "+finaluploadPath);
	        jdbcTemplate.update("update mydb.bgv set bgv.Upload_Path_Vetting_postcheck='"+finaluploadPath+"' where bgv.SAP_ID="+sapid);
		 request.setAttribute("message", "File successfully uploaded!!!");
		
		 out.println("<html><body><script>alert('File successfully uploaded!!!');window.close();</script></body></html>");
	}
else{
	 out.println("<html><body><script>alert('Error in uploading File!!!');window.location= '../../pmoAutomation/Bgv/finalBgvApproval.php';</script></body></html>");
}
	    		
	    	//return " out.println("<html><body><script>alert('No Existing Document found');window.location= '../../pmoAutomation/Bgv/newBgvApproval.php';</script></body></html>");";
	    	}
	 @RequestMapping(value = "/postcheckvettingmaildownload.php")
		public void postcheckvettingmaildownload(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			
		
			String sapid=request.getParameter("postcheckfinal");
			int sapidconvert=Integer.parseInt(sapid);
			System.out.println("controller sap from jsp    "+sapid);
			DownloadPathDao path=new DownloadPathDao();
			List<DownloadPathvo> downloadPathlink=path.DownloadPathforpostcheckvetting(sapidconvert, jdbcTemplate);
			
			String[] array = new String[downloadPathlink.size()];
			int index = 0;
			for (Object value : downloadPathlink) {
				array[index] = String.valueOf( value );
			}
			
			HttpSession session = request.getSession();
	        session.setAttribute("downloadpathpostchecksession", array[index]);
			// TODO:Spring Multipart enable it,Servlet disable it
			request.setAttribute("postcheckreport", "pdfdownloadpostcheck");
			
			request.getRequestDispatcher("/fileUpload.downloadpostcheckreport").forward(request,
					response);
			
	 }
	 @RequestMapping(value = "/uploadpostjustificationMail.php")
		public String uploadpostjustificationMail(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			String sapID=request.getParameter("PostJustificationuploadSap");
			
			System.out.println("checking in con   "+sapID);
					int sapIDfrmpostjustificationMail=Integer.parseInt(sapID);
					HttpSession session = request.getSession();
			        session.setAttribute("sapIDJustPost", sapIDfrmpostjustificationMail);
			return "Bgv/PostJustificationMailUploadforBgvPreCheck";
			
		}
	 @RequestMapping(value = "/savefinalbgv.php",params="PostJustificationEmailAttachment", method = {RequestMethod.POST,RequestMethod.GET})
		public void PostJustificationEmailAttachment(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			System.out.println("hi iam in controller just post");
			// Internally hitting another Servlet
	      /*  String bgvDetailjust = request.getParameter("sapBGV"+ request.getParameter("just"));
			int bgvpersonjust=Integer.parseInt(bgvDetailjust);
			System.out.println("controller just     "+bgvpersonjust);
			HttpSession session = request.getSession();
	        session.setAttribute("JustificationEmailAttachmentID", bgvpersonjust);
			// TODO:Spring Multipart enable it,Servlet disable it
	*/		request.setAttribute("PostJustificationEmailupload", "pdfuploadjustpost");
			request.getRequestDispatcher("/fileUpload.PostuploadJustificationEmailAttachment").forward(request,
					response);
	 }
	 @RequestMapping(value = "/postjustificationuploadpage.php")
	    public void postjustificationuploadpage(HttpServletRequest request,
	    		HttpServletResponse response) throws ServletException, IOException 
	    {
		 PrintWriter out = response.getWriter();
	 int sapid=(int) request.getSession().getAttribute("sapIDJustPost");
		 String finaluploadPath=(String) request.getSession().getAttribute("postjustificationuploadPath");
		 System.out.println(sapid+" !!!!!!!!!!!!!! "+finaluploadPath);
		 if(finaluploadPath!=null){
			 
		 
	        System.out.println("servlet sap "+sapid);
	        System.out.println("final path in controller    "+finaluploadPath);
	        jdbcTemplate.update("update mydb.bgv set bgv.Upload_Path_Justification_Post='"+finaluploadPath+"' where bgv.SAP_ID="+sapid);
		 request.setAttribute("message", "File successfully uploaded!!!");
		
		 out.println("<html><body><script>alert('File successfully uploaded!!!');window.close();</script></body></html>");
	}
else{
	 out.println("<html><body><script>alert('Error in uploading File!!!');window.location= '../../pmoAutomation/Bgv/finalBgvApproval.php';</script></body></html>");
}
	    		
	    	//return " out.println("<html><body><script>alert('No Existing Document found');window.location= '../../pmoAutomation/Bgv/newBgvApproval.php';</script></body></html>");";
	    	}
	 @RequestMapping(value = "/pdfdownloadpostjustification.php")
		public void pdfdownloadpostjustification(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			
		
			String sapid=request.getParameter("postjustificationdownloadlink");
			int sapidconvert=Integer.parseInt(sapid);
			System.out.println("controller sap from jsp    "+sapid);
			DownloadPathDao path=new DownloadPathDao();
			List<DownloadPathvo> downloadPathlink=path.DownloadPathpostjustification(sapidconvert, jdbcTemplate);
			
			String[] array = new String[downloadPathlink.size()];
			int index = 0;
			for (Object value : downloadPathlink) {
				array[index] = String.valueOf( value );
			}
			
			HttpSession session = request.getSession();
	        session.setAttribute("downloadpathjustificationpost", array[index]);
			// TODO:Spring Multipart enable it,Servlet disable it
			request.setAttribute("fileTypepdfdown", "pdfdownload");
			
			request.getRequestDispatcher("/fileUpload.downloadpostjustification").forward(request,
					response);
			
	 }
	@RequestMapping(value= "/getYetToJoin.php")
	public ModelAndView getAllYetToJoinBgvRequest(HttpServletRequest request) {
		//System.out.println(request.getSession().getAttribute("managerId"));
		//System.out.println("working");
	
	
		return new ModelAndView("Bgv/YetToJoinRequest", "listOfEmployees",
				(new BgvInitionServiceImpl()).getAllNewYetToJoinBgvRequest((int) request
						.getSession().getAttribute("managerId"), jdbcTemplate));
		
	}
	
	@RequestMapping(value = "/downloadExcel.php", method = RequestMethod.GET)
   
		public ModelAndView downloadExcel() {
		BgvPmoDaoImpl imp=new BgvPmoDaoImpl();
			List<Object[]> listBooks = imp.getDownLoadExcel(jdbcTemplate);
			System.out.println(listBooks);

			// return a view which will be resolved by an excel view resolver
			return new ModelAndView("excelView", "listBooks", listBooks);
		}
	
	
	@RequestMapping(value = "/bgvytjprecheckcases.php")
	public String BGVYTJPRECHECKCASES(HttpServletRequest request){
		
		return "Bgv/BgvYtjPreCheck";
		
	}
    }
	


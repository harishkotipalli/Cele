package com.hcl.pmoautomation.bgv.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.hcl.pmoautomation.bgv.dao.BgvInitiationDaoI;
import com.hcl.pmoautomation.bgv.dao.BgvInitiationDaoImpl;
import com.hcl.pmoautomation.bgv.model.BgvInitiation;

@Service
@Component


public class BgvInitionServiceImpl implements BgvInitiationServiceI{

	@Override
	public BgvInitiation getAllNewBgvRequest(int managerId, JdbcTemplate jdbcTemplet) {
		BgvInitiationDaoI bgvInitiationDaoI=new BgvInitiationDaoImpl();
		return bgvInitiationDaoI.getAllBgvRequest(managerId,jdbcTemplet);
	}



	@Override
	public BgvInitiation getAllNewYetToJoinBgvRequest(int managerId,
			JdbcTemplate jdbcTemplet) {
		BgvInitiationDaoI bgvInitiationDaoI=new BgvInitiationDaoImpl();
		//System.out.println(bgvInitiationDaoI.getAllYetToJoinBgvRequest(managerId, jdbcTemplet));
		 	return bgvInitiationDaoI.getAllYetToJoinBgvRequest(managerId, jdbcTemplet);
	}

	
	
}

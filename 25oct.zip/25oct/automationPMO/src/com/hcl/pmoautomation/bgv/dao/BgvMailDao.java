package com.hcl.pmoautomation.bgv.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.hcl.pmoautomation.bgv.model.Bgvhclmailvo;
import com.hcl.pmoautomation.bgv.model.bgvdetailsmailvettingvo;
import com.hcl.pmoautomation.bgv.model.bgvinitiatetempvo;
import com.hcl.pmoautomation.bgv.utilities.BgvSql;


public class BgvMailDao {

	
	public List<Bgvhclmailvo> list(int sapid,JdbcTemplate jdbcTemplate) 
	{
		
		String sql = BgvSql.getHCLMAIL_details_Sql+sapid;
		System.out.println(sql);
	   
	    		 List<Bgvhclmailvo> listaa = jdbcTemplate.query(sql, new RowMapper<Bgvhclmailvo>() 
	{
			@Override
			public Bgvhclmailvo mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				Bgvhclmailvo mail = new Bgvhclmailvo();
				mail.setHclmailid(rs.getString("Hcl_Mail_Id"));
				return mail;
			}
	  }); return listaa; 
	    
	}
	
	public List<Bgvhclmailvo> mailidsforbgvinitiate(int sapid,JdbcTemplate jdbcTemplate) 
	{
		
		String sql = BgvSql.getHCLMAIL_details_Sql_INITIATEBGV+sapid+BgvSql.getHCLMAIL_details_Sql_INITIATEBGV_cntd;
		System.out.println(sql);
	   
	    		 List<Bgvhclmailvo> listaa = jdbcTemplate.query(sql, new RowMapper<Bgvhclmailvo>() 
	{
			@Override
			public Bgvhclmailvo mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				Bgvhclmailvo mail = new Bgvhclmailvo();
				mail.setHclmailid(rs.getString("Hcl_Mail_Id"));
				return mail;
			}
	  }); return listaa; 
	    
	}
	
	public List<bgvdetailsmailvettingvo> listoftemplatedata(int rasid,JdbcTemplate jdbcTemplate, HttpServletRequest request) 
	{
		
		String sql = BgvSql.getHCLMAIL_details_namesapcode+rasid;
		
		
		
		System.out.println(sql);
	   
	    		 List<bgvdetailsmailvettingvo> listaa = jdbcTemplate.query(sql, new RowMapper<bgvdetailsmailvettingvo>() 
	
	    				 {
			@Override
			public bgvdetailsmailvettingvo mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				bgvdetailsmailvettingvo mail = new bgvdetailsmailvettingvo();
					
			
				
	            	
				mail.setSapcode(rs.getInt("SAPCODE"));
				mail.setEmpname(rs.getString("EMPNAME"));
				
				/*	mail.setPm_mail_id(rs.getString(""));*/
					
				
				return mail;
			}
	 
			
			
			
			
			
			
	    });
	    		
	    		
	    return listaa;
	    
	  
	    
	    }
	public List<bgvdetailsmailvettingvo> listoftemplatedataforreferbackupdate(int sapid,JdbcTemplate jdbcTemplate) 
	{
		
		String sql = BgvSql.getHCLMAIL_details_namesapcode_referbackupdate+sapid;
		
		
		
		System.out.println(sql);
	   
	    		 List<bgvdetailsmailvettingvo> listaa = jdbcTemplate.query(sql, new RowMapper<bgvdetailsmailvettingvo>() 
	
	    				 {
			@Override
			public bgvdetailsmailvettingvo mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				bgvdetailsmailvettingvo mail = new bgvdetailsmailvettingvo();
					
			
				
	            	
				mail.setSapcode(rs.getInt("SAP_ID"));
				mail.setEmpname(rs.getString("EMP_FIRST_NAME"));
				mail.setProjectname(rs.getString("PROJECT_NAME"));
				/*	mail.setPm_mail_id(rs.getString(""));*/
					
				
				return mail;
			}
	 
			
			
			
			
			
			
	    });
	    		
	    		
	    return listaa;
	    
	  
	    
	    }
	public List<bgvinitiatetempvo> listoftemplatedataforinitiatebgv(int sapid,JdbcTemplate jdbcTemplate) 
	{
		
		String sql = BgvSql.getbgvinitiatetemplate_details+sapid;
		
		
		
		System.out.println(sql);
	   
	    		 List<bgvinitiatetempvo> listaa = jdbcTemplate.query(sql, new RowMapper<bgvinitiatetempvo>() 
	
	    				 {
			@Override
			public bgvinitiatetempvo mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				bgvinitiatetempvo mail = new bgvinitiatetempvo();
					
			
				
	            	
				mail.setEmphclmail(rs.getString("EMP_OFFICIAL_MAIL_ID"));
				mail.setEmpname(rs.getString("EMP_FIRST_NAME"));
				mail.setSapcod(rs.getInt("SAP_ID"));
				
				
				/*	mail.setPm_mail_id(rs.getString(""));*/
					
				
				return mail;
			}
	 
			
			
			
			
			
			
	    });
	    		
	    		
	    return listaa;
	    
	  
	    
	    }

}

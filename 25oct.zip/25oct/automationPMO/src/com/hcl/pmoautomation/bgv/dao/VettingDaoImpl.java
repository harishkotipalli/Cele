package com.hcl.pmoautomation.bgv.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.hcl.pmoautomation.bgv.model.Bgv1;
import com.hcl.pmoautomation.bgv.model.EditVettingSheet;
import com.hcl.pmoautomation.bgv.model.VettingSheet;
import com.hcl.pmoautomation.bgv.utilities.BgvSql;



public class VettingDaoImpl implements VettingDaoI {

	
	@Override
	public VettingSheet getVettingSheet(int id, int sap_id, JdbcTemplate jdbcTemplet) {
//		System.out.println("this is ras vettingsheet impl for ras");
//		System.out.println("this id data is updated in ras table and id no is  "+id);
		Object[] param={id};
		Object[] param2={"NOT INITIATED",id};	
//		System.out.println(jdbcTemplet);
		
		int updatedRow=jdbcTemplet.update(BgvSql.updateBgvSatusintorassql,param2);
		System.out.println(updatedRow);
		return (VettingSheet) jdbcTemplet.queryForObject(BgvSql.getVettingShetfromrassql,param, new VettingRowMapperForRas());
	}

	@Override
	public VettingSheet getVettingSheet(int id, JdbcTemplate jdbcTemplet) {
		Object[] param={id};
		Object[] param2={"YES",id};	
		int updatedRow=jdbcTemplet.update(BgvSql.updateBgvSatusintotscsql,param2);
		System.out.println(updatedRow +"sucessfully reached to the dao for fetching the data "+id);
		return (VettingSheet) jdbcTemplet.queryForObject(BgvSql.getVettingShetfromtscsql,param, new VettingRowMapper());
	}

	@Override
	public Bgv1 getVettingSheetView(int sap_id, JdbcTemplate jdbcTemplet) {
		
		String sql = "select * from bgv where sap_id=?";
		Object[] params = {sap_id};
		try{
			return jdbcTemplet.queryForObject(sql, new VettingSheetRowmapper(), params);
		}catch(EmptyResultDataAccessException ex){
			return null;
		
		
		
	
	}
	}

	@Override
	public EditVettingSheet getEditVettingSheet(int sap_id, JdbcTemplate jdbcTemplet) {
    Object[] param = {sap_id};
	
		
		return (EditVettingSheet) jdbcTemplet.queryForObject(BgvSql.getEditVettingSheet, param,  new EditVettingSheetRowmapper());
	}
	
}

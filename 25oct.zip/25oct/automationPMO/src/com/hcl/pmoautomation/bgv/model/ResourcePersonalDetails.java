package com.hcl.pmoautomation.bgv.model;


import java.util.ArrayList;
import java.util.Date;

public class ResourcePersonalDetails {
	private String legal_First_Name;
	private String legal_Last_Name;

	private String nationality;

	private String prefered_business_name;

	private String correspondence_Language;

	private String gender;
	private Date date_Of_Birth;

	private String personal_Mail_Id;

	private String official_Mail_id;

	private int contact_Number;
	private String ubs_Mail;

	private String gpn;
	private String previsouly_Worked_With_Ubs;
	private String region;

	public String getLegal_First_Name() {
		return legal_First_Name;
	}

	public void setLegal_First_Name(String legal_First_Name) {
		this.legal_First_Name = legal_First_Name;
	}

	public String getLegal_Last_Name() {
		return legal_Last_Name;
	}

	public void setLegal_Last_Name(String legal_Last_Name) {
		this.legal_Last_Name = legal_Last_Name;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getPrefered_business_name() {
		return prefered_business_name;
	}

	public void setPrefered_business_name(String prefered_business_name) {
		this.prefered_business_name = prefered_business_name;
	}

	public String getCorrespondence_Language() {
		return correspondence_Language;
	}

	public void setCorrespondence_Language(
			String correspondence_Language) {
		this.correspondence_Language = correspondence_Language;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Date getDate_Of_Birth() {
		return date_Of_Birth;
	}

	public void setDate_Of_Birth(Date date_Of_Birth) {
		this.date_Of_Birth = date_Of_Birth;
	}

	public String getPersonal_Mail_Id() {
		return personal_Mail_Id;
	}

	public String getPrevisouly_Worked_With_Ubs() {
		return previsouly_Worked_With_Ubs;
	}

	public void setPrevisouly_Worked_With_Ubs(String previsouly_Worked_With_Ubs) {
		this.previsouly_Worked_With_Ubs = previsouly_Worked_With_Ubs;
	}

	public void setPersonal_Mail_Id(String personal_Mail_Id) {
		this.personal_Mail_Id = personal_Mail_Id;
	}

	public String getOfficial_Mail_id() {
		return official_Mail_id;
	}

	public void setOfficial_Mail_id(String official_Mail_id) {
		this.official_Mail_id = official_Mail_id;
	}

	public int getContact_Number() {
		return contact_Number;
	}

	public void setContact_Number(int contact_Number) {
		this.contact_Number = contact_Number;
	}

	public String getUbs_Mail() {
		return ubs_Mail;
	}

	public void setUbs_Mail(String ubs_Mail) {
		this.ubs_Mail = ubs_Mail;
	}

	public String getGpn() {
		return gpn;
	}

	public void setGpn(String gpn) {
		this.gpn = gpn;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	@Override
	public String toString() {
		return "ResourcePersonalDetails [legal_First_Name=" + legal_First_Name
				+ ", legal_Last_Name=" + legal_Last_Name + ", nationality="
				+ nationality + ", prefered_business_name="
				+ prefered_business_name + ", correspondence_Language="
				+ correspondence_Language + ", gender=" + gender
				+ ", date_Of_Birth=" + date_Of_Birth + ", personal_Mail_Id="
				+ personal_Mail_Id + ", official_Mail_id=" + official_Mail_id
				+ ", contact_Number=" + contact_Number + ", ubs_Mail="
				+ ubs_Mail + ", gpn=" + gpn + ", previsouly_Worked_With_Ubs="
				+ previsouly_Worked_With_Ubs + ", region=" + region + "]";
	}



	
}

/*package com.hcl.pmoautomation.bgv.controller;
import java.io.*;       
 import java.util.ArrayList;       
         
 public abstract class FileReaderUtility implements Runnable {       
         
         
   private static StringBuilder listFiles = new StringBuilder();       
          
    private final String path;      
          
          
    public FileReaderUtility(String path) { //      
      this.path = path;     
    }     
          
          
   public static void main(String[] args) {      
          
          
      System.out.println("Debug--> you are running the tool for these args " + args);     
          
      FileReaderUtility file = new FileReaderUtility(args[0]);    
          
      for(String pathToAnalize:args){   
          
        int i = 0;  
          
        System.out.println("Info--> Creating thread for path " +  i + " " + pathToAnalize);   
          
        file.path = pathToAnalize;  
        Thread t = new Thread(file);  
          
        System.out.println("Info--> Initianing thread for path " +  i + " " + pathToAnalize);   
          
        t.start();  
          
        System.out.println("Info--> Finish thread for path " +  i + " " + pathToAnalize); 
          
      i++;  
          
      }   
          
     System.out.println(listFiles);    
      System.exit(0);     
          
    }     
         
    public  ArrayList fileList(String path){      
          
      ArrayList result = null;    
      if(path!=null){   
        File filepath = new File(path); 
        File[] files = filepath.listFiles();  
        for(int i=0;i<files.length;i++){  
          listFiles.append(files[i] + ""); 
          
          
      }   
         
     
    }
	return result;  
    }
          
          
    public void run() {     
      this.fileList(this.path);   
    }     
          
          
         
         
  }       
          




 





*/
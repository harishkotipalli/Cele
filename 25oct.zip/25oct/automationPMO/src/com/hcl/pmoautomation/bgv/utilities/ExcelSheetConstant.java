package com.hcl.pmoautomation.bgv.utilities;

public interface ExcelSheetConstant {
	
	public int[] EXCALIBUR_MANDATORY_FIELDS_INDEXS={3,6,7,8,9,10,11,12,13,14,25};
	public int[] SR_MANDATORY_FIELDS_INDEXS={16,17,18,19,20,21,22,23,24};
	public String KEY_FIELD_EXCALIBURID="EXCALIBUR / SFA ID";
	public String SS_SHEET_NAME = "Bgv_Data";
	public String SS_TABLE_NAME = "Bgvupload";
	public String BGVSHEETNAME = "Bgv_Data";
	public String BGVTABLENAME = "bgv";

}

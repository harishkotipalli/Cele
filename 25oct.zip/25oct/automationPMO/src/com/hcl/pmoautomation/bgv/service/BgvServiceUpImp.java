package com.hcl.pmoautomation.bgv.service;

import org.springframework.jdbc.core.JdbcTemplate;
import java.util.List;
import com.hcl.pmoautomation.bgv.dao.BgvDaoImp;
import com.hcl.pmoautomation.bgv.dao.BgvDaoUp;
import com.hcl.pmoautomation.ot.utility.ExcelGenericReader;




public class BgvServiceUpImp implements Bgvservice {

	@Override
	public boolean saveBGVDump(String BGVFilePath, String BGVSHEETNAME, String BGVTABLENAME,
			JdbcTemplate jdbcTemplate) {
		BgvDaoUp rasDao = new BgvDaoImp();
		boolean resultFlag = false;
		try {
			resultFlag = rasDao.saveBGVDumpData(ExcelGenericReader
					.readExcelAllDynamically(BGVFilePath, BGVSHEETNAME,
							BGVTABLENAME, jdbcTemplate), BGVTABLENAME,
					jdbcTemplate);
			System.out.println("sevice layer      "+rasDao.saveBGVDumpData(ExcelGenericReader
					.readExcelAllDynamically(BGVFilePath, BGVSHEETNAME,
							BGVTABLENAME, jdbcTemplate), BGVTABLENAME,
					jdbcTemplate));
		} catch (Exception e) {
			e.printStackTrace();
		}

		return resultFlag;
	}

	@Override
	public List<Object[]> getRASDataWithNOSRMapped(JdbcTemplate jdbcTemplate, String pmCode) {
		BgvDaoUp rasDao = new BgvDaoImp();
		
		return rasDao.getRASDataWithNOSRMapped(jdbcTemplate,pmCode);

	}

	@Override
	public boolean saveSRRASMapping(JdbcTemplate jdbcTemplate, int sapCode, String srID) {
		BgvDaoUp rasDao = new BgvDaoImp();
		return rasDao.saveSRRASMapping(jdbcTemplate,sapCode,srID);
	} 

}

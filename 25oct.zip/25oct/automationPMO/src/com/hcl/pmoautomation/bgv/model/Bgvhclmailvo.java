package com.hcl.pmoautomation.bgv.model;

public class Bgvhclmailvo {
	
	private String hclmailid;
	
	

	public String getHclmailid() {
		return hclmailid;
	}

	public void setHclmailid(String hclmailid) {
		this.hclmailid = hclmailid;
	}



	@Override
	public String toString() {
		return  hclmailid;
	}

	

}

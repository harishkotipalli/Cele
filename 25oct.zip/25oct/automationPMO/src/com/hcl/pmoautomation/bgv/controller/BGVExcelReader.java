package com.hcl.pmoautomation.bgv.controller;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.springframework.web.servlet.view.document.AbstractExcelView;



public class BGVExcelReader extends AbstractExcelView {


	@Override
	protected void buildExcelDocument(Map<String, Object> model,
			HSSFWorkbook workbook, HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
List<Object[]> listBooks = (List<Object[]>) model.get("listBooks");
		
		// create a new Excel sheet
		HSSFSheet sheet = workbook.createSheet("Bgv_Data");
		sheet.setDefaultColumnWidth(30);
		
		// create style for header cells
		CellStyle style = workbook.createCellStyle();
		Font font = workbook.createFont();
		font.setFontName("Arial");
		style.setFillForegroundColor(HSSFColor.BLUE.index);
		style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		font.setColor(HSSFColor.WHITE.index);
		style.setFont(font);
		
		// create header row
		HSSFRow header = sheet.createRow(0);
		
		header.createCell(0).setCellValue("SAP ID");
		header.getCell(0).setCellStyle(style);
		
		header.createCell(1).setCellValue("EMP_FIRST_NAME");
		header.getCell(1).setCellStyle(style);
		
		header.createCell(2).setCellValue("EMP_LAST_NAME");
		header.getCell(2).setCellStyle(style);
		
		header.createCell(3).setCellValue("PREFERRED_BUSINESS_NAME");
		header.getCell(3).setCellStyle(style);
		
		header.createCell(4).setCellValue("DATE_OF_BIRTH");
		header.getCell(4).setCellStyle(style);
		
		header.createCell(5).setCellValue("GENDER");
		header.getCell(5).setCellStyle(style);
		
		header.createCell(6).setCellValue("NATIONALITY");
		header.getCell(6).setCellStyle(style);
		
		header.createCell(7).setCellValue("PROJECT_CODE");
		header.getCell(7).setCellStyle(style);
		
		header.createCell(8).setCellValue("PROJECT_NAME");
		header.getCell(8).setCellStyle(style);
		
		header.createCell(9).setCellValue("SECTOR");
		header.getCell(9).setCellStyle(style);
		
		header.createCell(10).setCellValue("REQUEST_TYPE");
		header.getCell(10).setCellStyle(style);
		
		header.createCell(11).setCellValue("TP_RESOURCE");
		header.getCell(11).setCellStyle(style);
		
		header.createCell(12).setCellValue("EMP_OFFICIAL_MAIL_ID");
		header.getCell(12).setCellStyle(style);
		
		header.createCell(13).setCellValue("EMP_PERSONAL_MAIL_ID");
		header.getCell(13).setCellStyle(style);
		
		header.createCell(14).setCellValue("EMP_CLIENT_MAIL_ID");
		header.getCell(14).setCellStyle(style);
		
		header.createCell(15).setCellValue("EMP_CONTACT_NUMBER");
		header.getCell(15).setCellStyle(style);
		
		header.createCell(16).setCellValue("LOCATION");
		header.getCell(16).setCellStyle(style);
		
		header.createCell(17).setCellValue("NEW_LOCATION");
		header.getCell(17).setCellStyle(style);
		
		header.createCell(18).setCellValue("OU_CODE");
		header.getCell(18).setCellStyle(style);
		
		header.createCell(19).setCellValue("GPN");
		header.getCell(19).setCellStyle(style);
		
		header.createCell(20).setCellValue("CLIENT_HIRING_MANAGER_MAIL_ID");
		header.getCell(20).setCellStyle(style);
		
		header.createCell(21).setCellValue("CLIENT_HIRING_MANAGER_GPN_NO");
		header.getCell(21).setCellStyle(style);
		
		header.createCell(22).setCellValue("REGION");
		header.getCell(22).setCellStyle(style);
		
		header.createCell(23).setCellValue("COUNTRY");
		header.getCell(23).setCellStyle(style);
		
		header.createCell(24).setCellValue("ASSIGNMENT_FROM");
		header.getCell(24).setCellStyle(style);
		
		header.createCell(25).setCellValue("ASSIGNMENT_TO");
		header.getCell(25).setCellStyle(style);
		
		header.createCell(26).setCellValue("BGV_TYPE");
		header.getCell(26).setCellStyle(style);
		
		header.createCell(27).setCellValue("REQUESTED_BY");
		header.getCell(27).setCellStyle(style);
		
		header.createCell(28).setCellValue("REQUESTED_DATE");
		header.getCell(28).setCellStyle(style);
		
		header.createCell(29).setCellValue("PRE_START_CHECK_WITH_PMO");
		header.getCell(29).setCellStyle(style);
		
		header.createCell(30).setCellValue("PRE_START_CHECK_WITH_PMO_DATE");
		header.getCell(30).setCellStyle(style);
		
		header.createCell(31).setCellValue("PRE_START_CHECK_WITH_CENTRAL_BGV");
		header.getCell(31).setCellStyle(style);
		
		header.createCell(32).setCellValue("PRE_START_CHECK_WITH_CENTRAL_BGV_DATE");
		header.getCell(32).setCellStyle(style);
		
		header.createCell(33).setCellValue("VENDOR_INITIATED_PRECHECK");
		header.getCell(33).setCellStyle(style);
		
		header.createCell(34).setCellValue("VENDOR_INITIATED_DATE_PRECHECK");
		header.getCell(34).setCellStyle(style);
		
		header.createCell(35).setCellValue("PRE_START_CHECK_WITH_RESOURCE");
		header.getCell(35).setCellStyle(style);
		
		header.createCell(36).setCellValue("PRE_START_CHECK_WITH_RESOURCE_DATE");
		header.getCell(36).setCellStyle(style);
		
		header.createCell(37).setCellValue("PRE_START_CHECK_STATUS");
		header.getCell(37).setCellStyle(style);
		
		header.createCell(38).setCellValue("PRE_START_CHECK_COMP_DATE");
		header.getCell(38).setCellStyle(style);
		
		header.createCell(39).setCellValue("BGV_PRESTART_COLOR");
		header.getCell(39).setCellStyle(style);
		
		// create data rows
		int rowCount = 1;
		
		for (Object[] aBook : listBooks) {
			HSSFRow aRow = sheet.createRow(rowCount++);
			aRow.createCell(0).setCellValue((int)aBook[0]);
			aRow.createCell(1).setCellValue((String)aBook[1]);
			aRow.createCell(2).setCellValue((String)aBook[2]);
			aRow.createCell(3).setCellValue((String)aBook[3]);
			aRow.createCell(4).setCellValue((String)aBook[4]);
			aRow.createCell(5).setCellValue((String)aBook[5]);
			aRow.createCell(6).setCellValue((String)aBook[6]);
			aRow.createCell(7).setCellValue((String)aBook[7]);
			aRow.createCell(8).setCellValue((String)aBook[8]);
			aRow.createCell(9).setCellValue((String)aBook[9]);
			aRow.createCell(10).setCellValue((String)aBook[10]);
			aRow.createCell(11).setCellValue((String)aBook[11]);
			aRow.createCell(12).setCellValue((String)aBook[12]);
			aRow.createCell(13).setCellValue((String)aBook[13]);
			aRow.createCell(14).setCellValue((String)aBook[14]);
			aRow.createCell(15).setCellValue((String)aBook[15]);
			aRow.createCell(16).setCellValue((String)aBook[16]);
			aRow.createCell(17).setCellValue((String)aBook[17]);
			aRow.createCell(18).setCellValue((String)aBook[18]);
			aRow.createCell(19).setCellValue((int)aBook[19]);
			aRow.createCell(20).setCellValue((String)aBook[20]);
			aRow.createCell(21).setCellValue((int)aBook[21]);
			aRow.createCell(22).setCellValue((String)aBook[22]);
			aRow.createCell(23).setCellValue((String)aBook[23]);
			aRow.createCell(24).setCellValue((String)aBook[24]);
			aRow.createCell(25).setCellValue((String)aBook[25]);
			aRow.createCell(26).setCellValue((String)aBook[26]);
			aRow.createCell(27).setCellValue((String)aBook[27]);
			aRow.createCell(28).setCellValue((String)aBook[28]);
			aRow.createCell(29).setCellValue((String)aBook[29]);
			aRow.createCell(30).setCellValue((String)aBook[30]);
			aRow.createCell(31).setCellValue((String)aBook[31]);
			aRow.createCell(32).setCellValue((String)aBook[32]);
			aRow.createCell(33).setCellValue((String)aBook[33]);
			aRow.createCell(34).setCellValue((String)aBook[34]);
			aRow.createCell(35).setCellValue((String)aBook[35]);
			aRow.createCell(36).setCellValue((String)aBook[36]);
			aRow.createCell(37).setCellValue((String)aBook[37]);
			aRow.createCell(38).setCellValue((String)aBook[38]);
			aRow.createCell(39).setCellValue((String)aBook[39]);
		}
	}
		
		
	}



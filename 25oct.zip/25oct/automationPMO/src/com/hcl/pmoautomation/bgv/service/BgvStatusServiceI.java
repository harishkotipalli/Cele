package com.hcl.pmoautomation.bgv.service;

import org.springframework.jdbc.core.JdbcTemplate;

import com.hcl.pmoautomation.bgv.model.BgvStatus;

public interface BgvStatusServiceI {
	
	public BgvStatus getAllBgvStatus(int managerId, JdbcTemplate jdbcTemplet);
	public BgvStatus getAllBgvPrecheckStatus(int managerId, JdbcTemplate jdbcTemplet);
	

}


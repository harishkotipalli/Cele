package com.hcl.pmoautomation.bgv.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

import com.hcl.pmoautomation.bgv.model.EmployeeYetToJoining;



public class YetToJoiningResourceRowMapper implements RowMapper<EmployeeYetToJoining> {

	@Override
	public EmployeeYetToJoining mapRow(ResultSet yetToJoinResultSet, int arg1)
			throws SQLException {
		EmployeeYetToJoining employeeYetToJoining=new EmployeeYetToJoining();
		employeeYetToJoining.setCV_ID(yetToJoinResultSet.getInt("cv_id"));
		employeeYetToJoining.setExpected_Date_of_Joining(yetToJoinResultSet.getDate("Expected_Joining_Date"));
		employeeYetToJoining.setOffer_Date(yetToJoinResultSet.getDate("Offer_Sent_Date"));
		employeeYetToJoining.setProject_code(yetToJoinResultSet.getString("Project_Code"));
		//employeeYetToJoining.setRequest_Type(yetToJoinResultSet.getString("Type_Of_Hires"));
		
		return employeeYetToJoining;
	}

	

}



package com.hcl.pmoautomation.bgv.model;

import java.util.Date;

public class Bgv1 {
	private int ubs_Hiring_Manager_Gpn;
	private String ubs_Hiring_Manager_email_Id;
	private String department_Ou_Code;
	private String regulatory_Region_country;
	private Date assignment_Details_Start_Date;

	private Date assignment_Details_End_Date;
	private int ras_id;
	private int sap_id;
	
	private String project_Name;
	private String project_Code;
	private String email;
	private int contact_Number;
	private String type_Of_Hires;
	private String first_Name;
	private String last_Name;
	private String country;
	private String gender;
	private Date date_of_Birth;
	private String Joining_Location;
	private String Work_Location;
	private String sector;
	private String tp_Resource;
	private String tp_Approved_Mail;
	private String legal_First_Name;
	private String legal_Last_Name;

	private String nationality;

	private String prefered_business_name;

	private String correspondence_Language;

	
	private Date date_Of_Birth;

	private String personal_Mail_Id;

	private String official_Mail_id;

	
	private String ubs_Mail;

	private String gpn;
	private String previsouly_Worked_With_Ubs;
	private String region;
	public int getUbs_Hiring_Manager_Gpn() {
		return ubs_Hiring_Manager_Gpn;
	}
	public void setUbs_Hiring_Manager_Gpn(int ubs_Hiring_Manager_Gpn) {
		this.ubs_Hiring_Manager_Gpn = ubs_Hiring_Manager_Gpn;
	}
	public String getUbs_Hiring_Manager_email_Id() {
		return ubs_Hiring_Manager_email_Id;
	}
	public void setUbs_Hiring_Manager_email_Id(String ubs_Hiring_Manager_email_Id) {
		this.ubs_Hiring_Manager_email_Id = ubs_Hiring_Manager_email_Id;
	}
	public String getDepartment_Ou_Code() {
		return department_Ou_Code;
	}
	public void setDepartment_Ou_Code(String department_Ou_Code) {
		this.department_Ou_Code = department_Ou_Code;
	}
	public String getRegulatory_Region_country() {
		return regulatory_Region_country;
	}
	public void setRegulatory_Region_country(String regulatory_Region_country) {
		this.regulatory_Region_country = regulatory_Region_country;
	}
	public Date getAssignment_Details_Start_Date() {
		return assignment_Details_Start_Date;
	}
	public void setAssignment_Details_Start_Date(Date assignment_Details_Start_Date) {
		this.assignment_Details_Start_Date = assignment_Details_Start_Date;
	}
	public Date getAssignment_Details_End_Date() {
		return assignment_Details_End_Date;
	}
	public void setAssignment_Details_End_Date(Date assignment_Details_End_Date) {
		this.assignment_Details_End_Date = assignment_Details_End_Date;
	}
	public int getRas_id() {
		return ras_id;
	}
	public void setRas_id(int ras_id) {
		this.ras_id = ras_id;
	}
	public String getProject_Name() {
		return project_Name;
	}
	public void setProject_Name(String project_Name) {
		this.project_Name = project_Name;
	}
	public String getProject_Code() {
		return project_Code;
	}
	public void setProject_Code(String project_Code) {
		this.project_Code = project_Code;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getContact_Number() {
		return contact_Number;
	}
	public void setContact_Number(int contact_Number) {
		this.contact_Number = contact_Number;
	}
	public String getType_Of_Hires() {
		return type_Of_Hires;
	}
	public void setType_Of_Hires(String type_Of_Hires) {
		this.type_Of_Hires = type_Of_Hires;
	}
	public String getFirst_Name() {
		return first_Name;
	}
	public void setFirst_Name(String first_Name) {
		this.first_Name = first_Name;
	}
	public String getLast_Name() {
		return last_Name;
	}
	public void setLast_Name(String last_Name) {
		this.last_Name = last_Name;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Date getDate_of_Birth() {
		return date_of_Birth;
	}
	public void setDate_of_Birth(Date date_of_Birth) {
		this.date_of_Birth = date_of_Birth;
	}
	public String getJoining_Location() {
		return Joining_Location;
	}
	public void setJoining_Location(String joining_Location) {
		Joining_Location = joining_Location;
	}
	public String getWork_Location() {
		return Work_Location;
	}
	public void setWork_Location(String work_Location) {
		Work_Location = work_Location;
	}
	public String getSector() {
		return sector;
	}
	public void setSector(String sector) {
		this.sector = sector;
	}
	public String getTp_Resource() {
		return tp_Resource;
	}
	public void setTp_Resource(String tp_Resource) {
		this.tp_Resource = tp_Resource;
	}
	public String getTp_Approved_Mail() {
		return tp_Approved_Mail;
	}
	public void setTp_Approved_Mail(String tp_Approved_Mail) {
		this.tp_Approved_Mail = tp_Approved_Mail;
	}
	public String getLegal_First_Name() {
		return legal_First_Name;
	}
	public void setLegal_First_Name(String legal_First_Name) {
		this.legal_First_Name = legal_First_Name;
	}
	public String getLegal_Last_Name() {
		return legal_Last_Name;
	}
	public void setLegal_Last_Name(String legal_Last_Name) {
		this.legal_Last_Name = legal_Last_Name;
	}
	public String getNationality() {
		return nationality;
	}
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	public String getPrefered_business_name() {
		return prefered_business_name;
	}
	public void setPrefered_business_name(String prefered_business_name) {
		this.prefered_business_name = prefered_business_name;
	}
	public String getCorrespondence_Language() {
		return correspondence_Language;
	}
	public void setCorrespondence_Language(String correspondence_Language) {
		this.correspondence_Language = correspondence_Language;
	}
	public Date getDate_Of_Birth() {
		return date_Of_Birth;
	}
	public void setDate_Of_Birth(Date date_Of_Birth) {
		this.date_Of_Birth = date_Of_Birth;
	}
	public String getPersonal_Mail_Id() {
		return personal_Mail_Id;
	}
	public void setPersonal_Mail_Id(String personal_Mail_Id) {
		this.personal_Mail_Id = personal_Mail_Id;
	}
	public String getOfficial_Mail_id() {
		return official_Mail_id;
	}
	public void setOfficial_Mail_id(String official_Mail_id) {
		this.official_Mail_id = official_Mail_id;
	}
	public String getUbs_Mail() {
		return ubs_Mail;
	}
	public void setUbs_Mail(String ubs_Mail) {
		this.ubs_Mail = ubs_Mail;
	}
	public String getGpn() {
		return gpn;
	}
	public void setGpn(String gpn) {
		this.gpn = gpn;
	}
	public String getPrevisouly_Worked_With_Ubs() {
		return previsouly_Worked_With_Ubs;
	}
	public void setPrevisouly_Worked_With_Ubs(String previsouly_Worked_With_Ubs) {
		this.previsouly_Worked_With_Ubs = previsouly_Worked_With_Ubs;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	
	public int getSap_id() {
		return sap_id;
	}
	public void setSap_id(int sap_id) {
		this.sap_id = sap_id;
	}
	@Override
	public String toString() {
		return "Bgv1 [ubs_Hiring_Manager_Gpn=" + ubs_Hiring_Manager_Gpn
				+ ", ubs_Hiring_Manager_email_Id="
				+ ubs_Hiring_Manager_email_Id + ", department_Ou_Code="
				+ department_Ou_Code + ", regulatory_Region_country="
				+ regulatory_Region_country
				+ ", assignment_Details_Start_Date="
				+ assignment_Details_Start_Date
				+ ", assignment_Details_End_Date="
				+ assignment_Details_End_Date + ", ras_id=" + ras_id
				+ ", sap_id=" + sap_id + ", project_Name=" + project_Name
				+ ", project_Code=" + project_Code + ", email=" + email
				+ ", contact_Number=" + contact_Number + ", type_Of_Hires="
				+ type_Of_Hires + ", first_Name=" + first_Name + ", last_Name="
				+ last_Name + ", country=" + country + ", gender=" + gender
				+ ", date_of_Birth=" + date_of_Birth + ", Joining_Location="
				+ Joining_Location + ", Work_Location=" + Work_Location
				+ ", sector=" + sector + ", tp_Resource=" + tp_Resource
				+ ", tp_Approved_Mail=" + tp_Approved_Mail
				+ ", legal_First_Name=" + legal_First_Name
				+ ", legal_Last_Name=" + legal_Last_Name + ", nationality="
				+ nationality + ", prefered_business_name="
				+ prefered_business_name + ", correspondence_Language="
				+ correspondence_Language + ", date_Of_Birth=" + date_Of_Birth
				+ ", personal_Mail_Id=" + personal_Mail_Id
				+ ", official_Mail_id=" + official_Mail_id + ", ubs_Mail="
				+ ubs_Mail + ", gpn=" + gpn + ", previsouly_Worked_With_Ubs="
				+ previsouly_Worked_With_Ubs + ", region=" + region + "]";
	}
	

}

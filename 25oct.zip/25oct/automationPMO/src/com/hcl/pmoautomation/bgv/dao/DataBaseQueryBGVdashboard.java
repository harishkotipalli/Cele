package com.hcl.pmoautomation.bgv.dao;

public interface DataBaseQueryBGVdashboard {
	public String QUERY_TO_FETCH_bgvintiated="select count(1) from mydb.bgv where bgv.ACTIVE_FLAG='Y' and bgv.REQUESTED_BY=";
	public String QUERY_TO_FETCH_bgvprecheck="select count(2) from mydb.bgv  where bgv.ACTIVE_FLAG='N' and bgv.REQUESTED_BY=";
	public String QUERY_TO_FETCH_bgvcompleted="select count(3) from mydb.bgv  where bgv.BGV_FINAL_REPORT_COLOUR='green' and bgv.REQUESTED_BY=" ;
	
	public String QUERY_TO_FETCH_bgvtype_using_regulatoryregion="SELECT BgvType FROM mydb.bgvtype_regulatoryregion where Regulatory_Region='";
	public String QUERY_TO_FETCH_download_path="select Upload_Path FROM mydb.bgv where bgv.SAP_ID=";
	public String QUERY_TO_FETCH_download_path_tp="select Upload_Path_BGV_TP FROM mydb.ras where ras.SAPCODE=";
	public String QUERY_TO_FETCH_download_path_DU="select Upload_Path_BGV_DU FROM mydb.ras where ras.SAPCODE=";
	public String QUERY_TO_FETCH_download_path_justification="select Upload_Path_justification FROM mydb.bgv where bgv.SAP_ID=";
	public String QUERY_TO_FETCH_download_path_vetting_post_final="select Upload_Path_Vetting_postcheck FROM mydb.bgv where bgv.SAP_ID=";
	public String QUERY_TO_FETCH_download_path_Post_justification="select Upload_Path_Justification_Post FROM mydb.bgv where bgv.SAP_ID=";
	public String QUERY_TO_FETCH_download_path_Clearance="select Upload_Path_Clearance FROM mydb.bgv where bgv.SAP_ID=";
	public String QUERY_TO_FETCH_download_path_IdDocument="select Upload_Path_IdDocument FROM mydb.bgv where bgv.SAP_ID=";
	public String QUERY_TO_FETCH_bgv_status_search="select bgv.SAP_ID,bgv.EMP_FIRST_NAME,bgv.PROJECT_NAME,bgv.PRE_START_CHECK_WITH_PMO,bgv.PRE_START_CHECK_WITH_PMO_DATE,"
            +"bgv.PRE_START_CHECK_WITH_CENTRAL_BGV ,bgv.PRE_START_CHECK_WITH_CENTRAL_BGV_DATE,bgv.VENDOR_INITIATED_PRECHECK,bgv.VENDOR_INITIATED_DATE_PRECHECK,"
            +"bgv.PRE_START_CHECK_WITH_RESOURCE,bgv.PRE_START_CHECK_WITH_RESOURCE_DATE,bgv.PRE_START_CHECK_STATUS,bgv.PRE_START_CHECK_COMP_DATE,bgv.BGV_POST_CHECK_COMPLETED_DATE,bgv.BGV_FINAL_REPORT_COLOUR from mydb.bgv where bgv.SAP_ID=";
	public String QUERY_TO_FETCH_bgv_status_search_manager="select bgv.SAP_ID,bgv.EMP_FIRST_NAME,bgv.PROJECT_NAME,bgv.PRE_START_CHECK_WITH_PMO,bgv.PRE_START_CHECK_WITH_PMO_DATE,"
            +"bgv.PRE_START_CHECK_WITH_CENTRAL_BGV ,bgv.PRE_START_CHECK_WITH_CENTRAL_BGV_DATE,bgv.VENDOR_INITIATED_PRECHECK,bgv.VENDOR_INITIATED_DATE_PRECHECK,"
            +"bgv.PRE_START_CHECK_WITH_RESOURCE,bgv.PRE_START_CHECK_WITH_RESOURCE_DATE,bgv.PRE_START_CHECK_STATUS,bgv.PRE_START_CHECK_COMP_DATE,bgv.BGV_POST_CHECK_COMPLETED_DATE,bgv.BGV_FINAL_REPORT_COLOUR from mydb.bgv where bgv.SAP_ID=";
	
	public String QUERY_TO_FETCH_bgv_status_search_manager_cntd=" and bgv.REQUESTED_BY=";
	public String QUERY_TO_FETCH_pendingWithPmo = "select count(1) from mydb.bgv where PRE_START_CHECK_WITH_PMO='NOTINITIATED' and ACTIVEFLAG_PRECHECK='y'";
	public String QUERY_TO_FETCH_pendingWithCentralBgv = "select count(2) from mydb.bgv where PRE_START_CHECK_WITH_PMO='initiated' and PRE_START_CHECK_WITH_CENTRAL_BGV='notinitiated'";
	public String QUERY_TO_FETCH_pendingWithVendor = "select "
			+ "count(3) "
			+"from mydb.bgv where PRE_START_CHECK_WITH_PMO='initiated'"
					+ " and PRE_START_CHECK_WITH_CENTRAL_BGV='initiated'"
					+ " and PRE_START_CHECK_WITH_RESOURCE='Y'"
					+ " and PRE_START_CHECK_STATUS='notcompleted'";
	public String QUERY_TO_FETCH_pendingWithResource = "select count(4)"
			+ " from mydb.bgv where PRE_START_CHECK_WITH_PMO='initiated'"
			+ " and PRE_START_CHECK_WITH_CENTRAL_BGV='initiated'"
			+ " and PRE_START_CHECK_WITH_RESOURCE='N'";
	
	
	public String QUERY_TO_FETCH_download_path_DU_YTJ="select Du_path FROM mydb.uniqueid_internal_resouces where uniqueid_internal_resouces.Unique_Id='";
	public String QUERY_TO_FETCH_download_path_TP_YTJ="select Tp_path FROM mydb.uniqueid_internal_resouces where uniqueid_internal_resouces.Unique_Id='";

	/*public String QUERY_TO_FETCH_resourcePreCheckPending = "select count(5)"
			+ " from mydb.bgv where PRE_START_CHECK_WITH_PMO='initiated'"
			+ " and PRE_START_CHECK_WITH_CENTRAL_BGV='initiated'"
			+ " and PRE_START_CHECK_WITH_RESOURCE='uploaded'"
			+ " and VENDOR_INITIATED_PRECHECK='initiated'"
			+ " and PRE_START_CHECK_STATUS='notcompleted'";*/
	
	
	
	public String QUERY_TO_FETCH_precheckCompleted = "select count(6)"
			+ " from mydb.bgv  where PRE_START_CHECK_WITH_PMO='initiated'"
			+ " and PRE_START_CHECK_WITH_CENTRAL_BGV='initiated'"			
			+ " and PRE_START_CHECK_WITH_RESOURCE='Y'"
			
			+ " and PRE_START_CHECK_STATUS='completed' and  ACTIVEFLAG_PRECHECK='y'";
	
	public String QUERY_TO_FETCH_postcheckpending= "select count(7)"
			+ " from mydb.bgv  where PRE_START_CHECK_WITH_PMO='initiated'"
			+ " and PRE_START_CHECK_WITH_CENTRAL_BGV='initiated'"			
			+ " and PRE_START_CHECK_WITH_RESOURCE='Y'"
		
			+ " and PRE_START_CHECK_STATUS='completed'"
			+ " and ACTIVEFLAG_PRECHECK='N'"
			+ " and BGV_Status='INITIATED'";
	
	public String QUERY_TO_FETCH_postcheckCompleted= "select count(8)"
			+ " from mydb.bgv  where PRE_START_CHECK_WITH_PMO='initiated'"
			+ " and PRE_START_CHECK_WITH_CENTRAL_BGV='initiated'"			
			+ " and PRE_START_CHECK_WITH_RESOURCE='Y'"
		
			+ " and PRE_START_CHECK_STATUS='completed'"			
			+ " and BGV_Status='COMPLETED'"
			+ " and BGV_FINAL_REPORT_COLOUR='GREEN'";
			
	
	public String QUERY_TO_FETCH_bgvreferback="select count(1) "
			+ "from mydb.bgv  where bgv.REFER_BACK='YES'and bgv.REQUESTED_BY=";
	public String QUERY_TO_FETCH_managerPendingWithPmo = "select count(2) "
			+ "from mydb.bgv where PRE_START_CHECK_WITH_PMO='NOTINITIATED' "
			+ "and ACTIVEFLAG_PRECHECK='y' and bgv.REQUESTED_BY=";
	public String QUERY_TO_FETCH_managerPendingWithCentralBgv = "select count(3) "
			+ "from mydb.bgv where PRE_START_CHECK_WITH_PMO='initiated' "
			+ "and PRE_START_CHECK_WITH_CENTRAL_BGV='notinitiated'"
			+ "and bgv.REQUESTED_BY=";
	
	public String QUERY_TO_FETCH_managerPendingWithResource = "select count(5) "
			+ " from mydb.bgv where PRE_START_CHECK_WITH_PMO='initiated'"
			+ " and PRE_START_CHECK_WITH_CENTRAL_BGV='initiated'"
			+ " and PRE_START_CHECK_WITH_RESOURCE='N'"
			+ " and bgv.REQUESTED_BY=";
	
	public String QUERY_TO_FETCH_managerpendingWithVendor = "select count(4) "
			+"from mydb.bgv where PRE_START_CHECK_WITH_PMO='initiated'"
			+ " and PRE_START_CHECK_WITH_CENTRAL_BGV='initiated'"
			+ " and PRE_START_CHECK_WITH_RESOURCE='Y'"
			+ " and PRE_START_CHECK_STATUS='notcompleted'"
			+ " and bgv.REQUESTED_BY=";
	
	
	
	
	/*
	public String QUERY_TO_FETCH_managerResourcePreCheckPending = "select count(6) "
			+ " from mydb.bgv where PRE_START_CHECK_WITH_PMO='initiated'"
			+ " and PRE_START_CHECK_WITH_CENTRAL_BGV='initiated'"		
			+ " and PRE_START_CHECK_WITH_RESOURCE='uploaded'"
			+ " and VENDOR_INITIATED_PRECHECK='initiated'"
			+ " and PRE_START_CHECK_STATUS='notcompleted'"
			+ " and bgv.REQUESTED_BY=";*/
	public String QUERY_TO_FETCH_managerPrecheckCompleted = "select count(7) "
			+ "from mydb.bgv  where PRE_START_CHECK_WITH_PMO='initiated' "
			+ "and PRE_START_CHECK_WITH_CENTRAL_BGV='initiated' "			
			+ "and PRE_START_CHECK_WITH_RESOURCE='Y' "
			
			+ "and PRE_START_CHECK_STATUS='completed' "
			+ "and  ACTIVEFLAG_PRECHECK='y' and bgv.REQUESTED_BY=";
	public String QUERY_TO_FETCH_managerpostcheckpending= "select count(8)"
			+ " from mydb.bgv  where PRE_START_CHECK_WITH_PMO='initiated'"
			+ " and PRE_START_CHECK_WITH_CENTRAL_BGV='initiated'"			
			+ " and PRE_START_CHECK_WITH_RESOURCE='Y'"
			
			+ " and PRE_START_CHECK_STATUS='completed'"
			+ " and ACTIVEFLAG_PRECHECK='N'"
			+ " and BGV_Status='INITIATED' and bgv.REQUESTED_BY=";

	public String QUERY_TO_FETCH_managerpostcheckCompleted= "select count(9)"
			+ " from mydb.bgv  where PRE_START_CHECK_WITH_PMO='initiated'"
			+ " and PRE_START_CHECK_WITH_CENTRAL_BGV='initiated'"			
			+ " and PRE_START_CHECK_WITH_RESOURCE='Y'"
			
			+ " and PRE_START_CHECK_STATUS='completed'"			
			+ " and BGV_Status='COMPLETED'"
			+ " and BGV_FINAL_REPORT_COLOUR='GREEN' and bgv.REQUESTED_BY=";
	
	public String QUERY_TO_FETCH_ytj_initiated_cases="SELECT * FROM mydb.yettojoin where yettojoin.Active_Flag='N'";
	public String QUERY_TO_FETCH_ytj_merging_details="select CV_ID,First_name from mydb.yettojoin where CV_ID=";
	public String QUERY_TO_FETCH_internal_path_check="select Du_path from mydb.uniqueid_internal_resouces where Unique_Id='";
}

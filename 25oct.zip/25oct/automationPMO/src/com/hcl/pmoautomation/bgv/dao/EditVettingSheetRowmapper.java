package com.hcl.pmoautomation.bgv.dao;



import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.hcl.pmoautomation.bgv.model.EditVettingSheet;


public class EditVettingSheetRowmapper implements RowMapper<EditVettingSheet> {

	@Override
	public EditVettingSheet mapRow(ResultSet rs, int  noofrecords) throws SQLException {
		
		EditVettingSheet editVettingSheet = new EditVettingSheet();
		
		editVettingSheet.setSAP_ID(rs.getInt("SAP_ID"));
        editVettingSheet.setEMP_FIRST_NAME(rs.getString("EMP_FIRST_NAME"));
        editVettingSheet.setEMP_LAST_NAME(rs.getString("EMP_LAST_NAME"));
        editVettingSheet.setPREFERRED_BUSINESS_NAME(rs.getString("PREFERRED_BUSINESS_NAME"));
        editVettingSheet.setGENDER(rs.getString("GENDER"));
        editVettingSheet.setDATE_OF_BIRTH(rs.getDate("DATE_OF_BIRTH"));
        editVettingSheet.setNATIONALITY(rs.getString("NATIONALITY"));
        editVettingSheet.setCORRESPONDENCE_LANGUAGE(rs.getString("CORRESPONDENCE_LANGUAGE"));
      //  editVettingSheet.setPREVIOUSLY_WORKED_WITH_CLIENT(rs.getString("PREVIOUSLY_WORKED_WITH_CLIENT"));
        editVettingSheet.setLEGAL_FIRST_NAME(rs.getString("EMP_FIRST_NAME"));
        editVettingSheet.setLEGAL_SECOND_NAME(rs.getString("EMP_LAST_NAME"));
       // editVettingSheet.setOFFER_ACCEPTED_STATUS(rs.getString("OFFER_ACCEPTED_STATUS"));
       // editVettingSheet.setOFFER_ACCEPTED_DATE(rs.getDate("OFFER_ACCEPTED_DATE"));
        editVettingSheet.setPROJECT_CODE(rs.getString("PROJECT_CODE"));
        editVettingSheet.setPROJECT_NAME(rs.getString("PROJECT_NAME"));
        editVettingSheet.setSECTOR(rs.getString("SECTOR"));
        editVettingSheet.setREQUEST_TYPE(rs.getString("REQUEST_TYPE"));
        editVettingSheet.setASSIGNMENT_FROM(rs.getDate("ASSIGNMENT_FROM"));
        editVettingSheet.setASSIGNMENT_TO(rs.getDate("ASSIGNMENT_TO"));
        editVettingSheet.setONSHORE_OFFSHORE(rs.getString("ONSHORE_OFFSHORE")); 
        editVettingSheet.setTP_RESOURCE(rs.getString("TP_RESOURCE"));
        editVettingSheet.setTP_APPROVAL(rs.getString("TP_APPROVAL"));
        editVettingSheet.setEMP_OFFICIAL_MAIL_ID(rs.getString("EMP_OFFICIAL_MAIL_ID"));
        editVettingSheet.setEMP_PERSONAL_MAIL_ID(rs.getString("EMP_PERSONAL_MAIL_ID"));
        editVettingSheet.setEMP_CONTACT_NUMBER(rs.getLong("EMP_CONTACT_NUMBER"));
        editVettingSheet.setLOCATION(rs.getString("LOCATION"));
        editVettingSheet.setJOINING_LOCATION(rs.getString("New_Location"));
        editVettingSheet.setOU_CODE(rs.getString("OU_CODE"));
        editVettingSheet.setGPN(rs.getInt("GPN"));
        editVettingSheet.setCLIENT_HIRING_MANAGER_MAIL_ID(rs.getString("CLIENT_HIRING_MANAGER_MAIL_ID"));
        editVettingSheet.setCLIENT_HIRING_MANAGER_GPN_NO(rs.getInt("CLIENT_HIRING_MANAGER_GPN_NO"));
        editVettingSheet.setREGION(rs.getString("REGION"));
        editVettingSheet.setCOUNTRY(rs.getString("COUNTRY"));
        editVettingSheet.setBGV_TYPE(rs.getString("BGV_TYPE"));
        editVettingSheet.setREQUESTED_BY(rs.getString("REQUESTED_BY"));
      
       // editVettingSheet.setSAP_ID(rs.getInt("SAP_ID"));
      
             return editVettingSheet;

	}
	

}

package com.hcl.pmoautomation.bgv.dao;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.hcl.pmoautomation.AddAction.vo.ActionAdd;
import com.hcl.pmoautomation.bgv.model.BgvStatusSearchVO;



public class BgvStatusSearchDao  {

	public List<BgvStatusSearchVO> list(String sapid,JdbcTemplate jdbcTemplate)
	{
		String sql=DataBaseQueryBGVdashboard.QUERY_TO_FETCH_bgv_status_search+sapid;
		
		
		
		List<BgvStatusSearchVO> listaa = jdbcTemplate.query(sql, new RowMapper<BgvStatusSearchVO>() 
		
		 {
        @Override
        public BgvStatusSearchVO mapRow(ResultSet rs, int rowNum) throws SQLException 
        {
        	BgvStatusSearchVO bss= new BgvStatusSearchVO();
        	bss.setSAP_ID(rs.getString("SAP_ID"));
        	bss.setEMP_FIRST_NAME(rs.getString("EMP_FIRST_NAME"));
        	bss.setPROJECT_NAME(rs.getString("PROJECT_NAME"));
            bss.setPRE_START_CHECK_WITH_PMO(rs.getString("PRE_START_CHECK_WITH_PMO"));
            bss.setPRE_START_CHECK_WITH_PMO_DATE(rs.getString("PRE_START_CHECK_WITH_PMO_DATE"));
            bss.setPRE_START_CHECK_WITH_CENTRAL_BGV(rs.getString("PRE_START_CHECK_WITH_CENTRAL_BGV"));
        	bss.setPRE_START_CHECK_WITH_CENTRAL_BGV_DATE(rs.getString("PRE_START_CHECK_WITH_CENTRAL_BGV_DATE"));
        	bss.setVENDOR_INITIATED_PRECHECK(rs.getString("VENDOR_INITIATED_PRECHECK"));
        	bss.setVENDOR_INITIATED_DATE_PRECHECK(rs.getString("VENDOR_INITIATED_DATE_PRECHECK"));
        	bss.setPRE_START_CHECK_WITH_RESOURCE(rs.getString("PRE_START_CHECK_WITH_RESOURCE"));
        	bss.setPRE_START_CHECK_WITH_RESOURCE_DATE(rs.getString("PRE_START_CHECK_WITH_RESOURCE_DATE"));
        	bss.setPRE_START_CHECK_STATUS(rs.getString("PRE_START_CHECK_STATUS"));
        	bss.setPRE_START_CHECK_COMP_DATE(rs.getString("PRE_START_CHECK_COMP_DATE"));
        	bss.setPOST_START_CHECK_COMP_DATE(rs.getString("BGV_POST_CHECK_COMPLETED_DATE"));
        	bss.setBGV_FINAL_REPORT_COLOUR(rs.getString("BGV_FINAL_REPORT_COLOUR"));
            
        
		       return bss;
        }
		 });
	    return listaa;
	}
	public List<BgvStatusSearchVO> searchdatabasedonmanagersap(int sapid,int managerid,JdbcTemplate jdbcTemplate)
	{
	
		String sql=DataBaseQueryBGVdashboard.QUERY_TO_FETCH_bgv_status_search_manager+sapid+DataBaseQueryBGVdashboard.QUERY_TO_FETCH_bgv_status_search_manager_cntd+managerid;
		
		
		
		List<BgvStatusSearchVO> listaa = jdbcTemplate.query(sql, new RowMapper<BgvStatusSearchVO>() 
		
		 {
        @Override
        public BgvStatusSearchVO mapRow(ResultSet rs, int rowNum) throws SQLException 
        {
        	BgvStatusSearchVO bss= new BgvStatusSearchVO();
        	bss.setSapid(rs.getInt("SAP_ID"));
        	bss.setEMP_FIRST_NAME(rs.getString("EMP_FIRST_NAME"));
        	bss.setPROJECT_NAME(rs.getString("PROJECT_NAME"));
            bss.setPRE_START_CHECK_WITH_PMO(rs.getString("PRE_START_CHECK_WITH_PMO"));
            bss.setPRE_START_CHECK_WITH_PMO_DATE(rs.getString("PRE_START_CHECK_WITH_PMO_DATE"));
            bss.setPRE_START_CHECK_WITH_CENTRAL_BGV(rs.getString("PRE_START_CHECK_WITH_CENTRAL_BGV"));
        	bss.setPRE_START_CHECK_WITH_CENTRAL_BGV_DATE(rs.getString("PRE_START_CHECK_WITH_CENTRAL_BGV_DATE"));
        	bss.setVENDOR_INITIATED_PRECHECK(rs.getString("VENDOR_INITIATED_PRECHECK"));
        	bss.setVENDOR_INITIATED_DATE_PRECHECK(rs.getString("VENDOR_INITIATED_DATE_PRECHECK"));
        	bss.setPRE_START_CHECK_WITH_RESOURCE(rs.getString("PRE_START_CHECK_WITH_RESOURCE"));
        	bss.setPRE_START_CHECK_WITH_RESOURCE_DATE(rs.getString("PRE_START_CHECK_WITH_RESOURCE_DATE"));
        	bss.setPRE_START_CHECK_STATUS(rs.getString("PRE_START_CHECK_STATUS"));
        	bss.setPRE_START_CHECK_COMP_DATE(rs.getString("PRE_START_CHECK_COMP_DATE"));
        	bss.setPOST_START_CHECK_COMP_DATE(rs.getString("BGV_POST_CHECK_COMPLETED_DATE"));
        	bss.setBGV_FINAL_REPORT_COLOUR(rs.getString("BGV_FINAL_REPORT_COLOUR"));
            
        
		       return bss;
        }
		 });
	    return listaa;
	}	 
}

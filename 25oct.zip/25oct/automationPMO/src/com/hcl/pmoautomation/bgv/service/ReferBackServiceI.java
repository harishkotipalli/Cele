package com.hcl.pmoautomation.bgv.service;

import org.springframework.jdbc.core.JdbcTemplate;

public interface ReferBackServiceI {
	
	public boolean referBackPmo(JdbcTemplate jdbcTemplate, String remarks,int SapId);

}

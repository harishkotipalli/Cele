package com.hcl.pmoautomation.bgv.model;

import java.sql.Date;

//import com.sun.xml.internal.bind.v2.runtime.Name;

public class Tsc {
	
	
	
	
	
	private String CV_ID;
	private String Type_Of_Hires;
	private String Fullfilment_Type;
	private String FIRST_NAME;
	private String Middle_Name;
	private String Last_Name;
	private Date Offer_Sent_Date;
	private Date Offer_Accept_Date;
	private Date Expected_Joining_Date;
	private Date Joining_Date;
	private String Candidate_Source;
	private String Tagged_LOB;
	private String LOB_Delivery;
	private String Apps_ES_LOB;
	private String Final_Source;
	private String Candidate_Source_Type;
	private String Source_Details;
	private String Agency_Code;
	private String Agency_Name;
	private String Email;
	private int Contact_Number;
	private String country;
	private String Gender;
	private String TEX_Months;
	private String REX_Months;
	private String Company_Name;
	private String Job;
	private String Job_Family;
	private String Primary_Skill;
	private String Secondary_Skill;
	private String Domain_For_Infra;
	private String Sub_Domain_For_Infra;
	private String S_E_Band;
	private String E_Sub_Bad;
	 private String Designation;
	 private String  Joining_Location;
	 private String  Personal_Area;
	 private String  Personal_Sub_Area;
	 private String  Joining_L1;
	 private String Joining_L2;
	 private String  Joining_L3;
	 private String Joining_L4;
	 private String Employee_Group;
	 private Date Billing_Date;
	 private String Account_Manager;
	 private String Billing_Type;
	private String Customer_Name;
	private String project_Name;
	private Date Expected_Closure_Date;
	private Date Requisition_Date;
	private String Reporting_Manager;
	private String Requisition_Source;
	private String TAG_Manager;
	private String Recruiter;
	private Date TAG_Executive_Assign_Date;
	private Date TAG_Manager_Assign_Date;
	private String SR_Number;
	private String	 SR_Status;
	private String New_HR_Status;
	private String Joining_Status;
	private String HR_Status;
	private int Home_phone;
	private String Job_title;
	private String Department;
	private String New_Relocation;
	private String New_Relocation_From;
	private String New_Relocation_To;
	private String Screener_Name;
	private String Sourcer_Name;
	private String T_Rating;
	private Date Date_of_Birth;
	private String Willing_To_Relocate;
	private String Preferred_Locations;
	private String Notice_Period;
	private String initiator_Name;
	private int Initiator_ID;
	private String Offer_Made_Offer_Form;
	private Date Offer_Change_Details_Date;
	private String Referrer_First_Name;
	private String Referrer_Last_Name;
	private String Referrer_Email;
	private String Referral_Status;
	private String  Referral_Status_Date;
	private int Project_Code;
	private String Previous_Organization_Name;
	 //Type how to make it bean properties
	private String Track_Detail;
	private String Skill_On_TAP;
	private String Processing_Priority_Flag;
	private Date EDOJ_Offer_Accept;
	private String POFU_Purview;
	private String Modified_By;
	private Date Modified_On;
	private char Active_Flag;
	private int ID;
	private String bgv_Status;
	private String bgv_colour;
	private Date bgv_Triggered_Date;
	private String bgv_Initiated_On;
	public String getCV_ID() {
		return CV_ID;
	}
	public void setCV_ID(String cV_ID) {
		CV_ID = cV_ID;
	}
	public String getType_Of_Hires() {
		return Type_Of_Hires;
	}
	public void setType_Of_Hires(String type_Of_Hires) {
		Type_Of_Hires = type_Of_Hires;
	}
	public String getFullfilment_Type() {
		return Fullfilment_Type;
	}
	public void setFullfilment_Type(String fullfilment_Type) {
		Fullfilment_Type = fullfilment_Type;
	}
	public String getFIRST_NAME() {
		return FIRST_NAME;
	}
	public void setFIRST_NAME(String fIRST_NAME) {
		FIRST_NAME = fIRST_NAME;
	}
	public String getMiddle_Name() {
		return Middle_Name;
	}
	public void setMiddle_Name(String middle_Name) {
		Middle_Name = middle_Name;
	}
	public String getLast_Name() {
		return Last_Name;
	}
	public void setLast_Name(String last_Name) {
		Last_Name = last_Name;
	}
	public Date getOffer_Sent_Date() {
		return Offer_Sent_Date;
	}
	public void setOffer_Sent_Date(Date offer_Sent_Date) {
		Offer_Sent_Date = offer_Sent_Date;
	}
	public Date getOffer_Accept_Date() {
		return Offer_Accept_Date;
	}
	public void setOffer_Accept_Date(Date offer_Accept_Date) {
		Offer_Accept_Date = offer_Accept_Date;
	}
	public Date getExpected_Joining_Date() {
		return Expected_Joining_Date;
	}
	public void setExpected_Joining_Date(Date expected_Joining_Date) {
		Expected_Joining_Date = expected_Joining_Date;
	}
	public Date getJoining_Date() {
		return Joining_Date;
	}
	public void setJoining_Date(Date joining_Date) {
		Joining_Date = joining_Date;
	}
	public String getCandidate_Source() {
		return Candidate_Source;
	}
	public void setCandidate_Source(String candidate_Source) {
		Candidate_Source = candidate_Source;
	}
	public String getTagged_LOB() {
		return Tagged_LOB;
	}
	public void setTagged_LOB(String tagged_LOB) {
		Tagged_LOB = tagged_LOB;
	}
	public String getLOB_Delivery() {
		return LOB_Delivery;
	}
	public void setLOB_Delivery(String lOB_Delivery) {
		LOB_Delivery = lOB_Delivery;
	}
	public String getApps_ES_LOB() {
		return Apps_ES_LOB;
	}
	public void setApps_ES_LOB(String apps_ES_LOB) {
		Apps_ES_LOB = apps_ES_LOB;
	}
	public String getFinal_Source() {
		return Final_Source;
	}
	public void setFinal_Source(String final_Source) {
		Final_Source = final_Source;
	}
	public String getCandidate_Source_Type() {
		return Candidate_Source_Type;
	}
	public void setCandidate_Source_Type(String candidate_Source_Type) {
		Candidate_Source_Type = candidate_Source_Type;
	}
	public String getSource_Details() {
		return Source_Details;
	}
	public void setSource_Details(String source_Details) {
		Source_Details = source_Details;
	}
	public String getAgency_Code() {
		return Agency_Code;
	}
	public void setAgency_Code(String agency_Code) {
		Agency_Code = agency_Code;
	}
	public String getAgency_Name() {
		return Agency_Name;
	}
	public void setAgency_Name(String agency_Name) {
		Agency_Name = agency_Name;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public int getContact_Number() {
		return Contact_Number;
	}
	public void setContact_Number(int contact_Number) {
		Contact_Number = contact_Number;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		Gender = gender;
	}
	public String getTEX_Months() {
		return TEX_Months;
	}
	public void setTEX_Months(String tEX_Months) {
		TEX_Months = tEX_Months;
	}
	public String getREX_Months() {
		return REX_Months;
	}
	public void setREX_Months(String rEX_Months) {
		REX_Months = rEX_Months;
	}
	public String getCompany_Name() {
		return Company_Name;
	}
	public void setCompany_Name(String company_Name) {
		Company_Name = company_Name;
	}
	public String getJob() {
		return Job;
	}
	public void setJob(String job) {
		Job = job;
	}
	public String getJob_Family() {
		return Job_Family;
	}
	public void setJob_Family(String job_Family) {
		Job_Family = job_Family;
	}
	public String getPrimary_Skill() {
		return Primary_Skill;
	}
	public void setPrimary_Skill(String primary_Skill) {
		Primary_Skill = primary_Skill;
	}
	public String getSecondary_Skill() {
		return Secondary_Skill;
	}
	public void setSecondary_Skill(String secondary_Skill) {
		Secondary_Skill = secondary_Skill;
	}
	public String getDomain_For_Infra() {
		return Domain_For_Infra;
	}
	public void setDomain_For_Infra(String domain_For_Infra) {
		Domain_For_Infra = domain_For_Infra;
	}
	public String getSub_Domain_For_Infra() {
		return Sub_Domain_For_Infra;
	}
	public void setSub_Domain_For_Infra(String sub_Domain_For_Infra) {
		Sub_Domain_For_Infra = sub_Domain_For_Infra;
	}
	public String getS_E_Band() {
		return S_E_Band;
	}
	public void setS_E_Band(String s_E_Band) {
		S_E_Band = s_E_Band;
	}
	public String getE_Sub_Bad() {
		return E_Sub_Bad;
	}
	public void setE_Sub_Bad(String e_Sub_Bad) {
		E_Sub_Bad = e_Sub_Bad;
	}
	public String getDesignation() {
		return Designation;
	}
	public void setDesignation(String designation) {
		Designation = designation;
	}
	public String getJoining_Location() {
		return Joining_Location;
	}
	public void setJoining_Location(String joining_Location) {
		Joining_Location = joining_Location;
	}
	public String getPersonal_Area() {
		return Personal_Area;
	}
	public void setPersonal_Area(String personal_Area) {
		Personal_Area = personal_Area;
	}
	public String getPersonal_Sub_Area() {
		return Personal_Sub_Area;
	}
	public void setPersonal_Sub_Area(String personal_Sub_Area) {
		Personal_Sub_Area = personal_Sub_Area;
	}
	public String getJoining_L1() {
		return Joining_L1;
	}
	public void setJoining_L1(String joining_L1) {
		Joining_L1 = joining_L1;
	}
	public String getJoining_L2() {
		return Joining_L2;
	}
	public void setJoining_L2(String joining_L2) {
		Joining_L2 = joining_L2;
	}
	public String getJoining_L3() {
		return Joining_L3;
	}
	public void setJoining_L3(String joining_L3) {
		Joining_L3 = joining_L3;
	}
	public String getJoining_L4() {
		return Joining_L4;
	}
	public void setJoining_L4(String joining_L4) {
		Joining_L4 = joining_L4;
	}
	public String getEmployee_Group() {
		return Employee_Group;
	}
	public void setEmployee_Group(String employee_Group) {
		Employee_Group = employee_Group;
	}
	public Date getBilling_Date() {
		return Billing_Date;
	}
	public void setBilling_Date(Date billing_Date) {
		Billing_Date = billing_Date;
	}
	public String getAccount_Manager() {
		return Account_Manager;
	}
	public void setAccount_Manager(String account_Manager) {
		Account_Manager = account_Manager;
	}
	public String getBilling_Type() {
		return Billing_Type;
	}
	public void setBilling_Type(String billing_Type) {
		Billing_Type = billing_Type;
	}
	public String getCustomer_Name() {
		return Customer_Name;
	}
	public void setCustomer_Name(String customer_Name) {
		Customer_Name = customer_Name;
	}
	public String getProject_Name() {
		return project_Name;
	}
	public void setProject_Name(String project_Name) {
		this.project_Name = project_Name;
	}
	public Date getExpected_Closure_Date() {
		return Expected_Closure_Date;
	}
	public void setExpected_Closure_Date(Date expected_Closure_Date) {
		Expected_Closure_Date = expected_Closure_Date;
	}
	public Date getRequisition_Date() {
		return Requisition_Date;
	}
	public void setRequisition_Date(Date requisition_Date) {
		Requisition_Date = requisition_Date;
	}
	public String getReporting_Manager() {
		return Reporting_Manager;
	}
	public void setReporting_Manager(String reporting_Manager) {
		Reporting_Manager = reporting_Manager;
	}
	public String getRequisition_Source() {
		return Requisition_Source;
	}
	public void setRequisition_Source(String requisition_Source) {
		Requisition_Source = requisition_Source;
	}
	public String getTAG_Manager() {
		return TAG_Manager;
	}
	public void setTAG_Manager(String tAG_Manager) {
		TAG_Manager = tAG_Manager;
	}
	public String getRecruiter() {
		return Recruiter;
	}
	public void setRecruiter(String recruiter) {
		Recruiter = recruiter;
	}
	public Date getTAG_Executive_Assign_Date() {
		return TAG_Executive_Assign_Date;
	}
	public void setTAG_Executive_Assign_Date(Date tAG_Executive_Assign_Date) {
		TAG_Executive_Assign_Date = tAG_Executive_Assign_Date;
	}
	public Date getTAG_Manager_Assign_Date() {
		return TAG_Manager_Assign_Date;
	}
	public void setTAG_Manager_Assign_Date(Date tAG_Manager_Assign_Date) {
		TAG_Manager_Assign_Date = tAG_Manager_Assign_Date;
	}
	public String getSR_Number() {
		return SR_Number;
	}
	public void setSR_Number(String sR_Number) {
		SR_Number = sR_Number;
	}
	public String getSR_Status() {
		return SR_Status;
	}
	public void setSR_Status(String sR_Status) {
		SR_Status = sR_Status;
	}
	public String getNew_HR_Status() {
		return New_HR_Status;
	}
	public void setNew_HR_Status(String new_HR_Status) {
		New_HR_Status = new_HR_Status;
	}
	public String getJoining_Status() {
		return Joining_Status;
	}
	public void setJoining_Status(String joining_Status) {
		Joining_Status = joining_Status;
	}
	public String getHR_Status() {
		return HR_Status;
	}
	public void setHR_Status(String hR_Status) {
		HR_Status = hR_Status;
	}
	public int getHome_phone() {
		return Home_phone;
	}
	public void setHome_phone(int home_phone) {
		Home_phone = home_phone;
	}
	public String getJob_title() {
		return Job_title;
	}
	public void setJob_title(String job_title) {
		Job_title = job_title;
	}
	public String getDepartment() {
		return Department;
	}
	public void setDepartment(String department) {
		Department = department;
	}
	public String getNew_Relocation() {
		return New_Relocation;
	}
	public void setNew_Relocation(String new_Relocation) {
		New_Relocation = new_Relocation;
	}
	public String getNew_Relocation_From() {
		return New_Relocation_From;
	}
	public void setNew_Relocation_From(String new_Relocation_From) {
		New_Relocation_From = new_Relocation_From;
	}
	public String getNew_Relocation_To() {
		return New_Relocation_To;
	}
	public void setNew_Relocation_To(String new_Relocation_To) {
		New_Relocation_To = new_Relocation_To;
	}
	public String getScreener_Name() {
		return Screener_Name;
	}
	public void setScreener_Name(String screener_Name) {
		Screener_Name = screener_Name;
	}
	public String getSourcer_Name() {
		return Sourcer_Name;
	}
	public void setSourcer_Name(String sourcer_Name) {
		Sourcer_Name = sourcer_Name;
	}
	public String getT_Rating() {
		return T_Rating;
	}
	public void setT_Rating(String t_Rating) {
		T_Rating = t_Rating;
	}
	public Date getDate_of_Birth() {
		return Date_of_Birth;
	}
	public void setDate_of_Birth(Date date_of_Birth) {
		Date_of_Birth = date_of_Birth;
	}
	public String getWilling_To_Relocate() {
		return Willing_To_Relocate;
	}
	public void setWilling_To_Relocate(String willing_To_Relocate) {
		Willing_To_Relocate = willing_To_Relocate;
	}
	public String getPreferred_Locations() {
		return Preferred_Locations;
	}
	public void setPreferred_Locations(String preferred_Locations) {
		Preferred_Locations = preferred_Locations;
	}
	public String getNotice_Period() {
		return Notice_Period;
	}
	public void setNotice_Period(String notice_Period) {
		Notice_Period = notice_Period;
	}
	public String getInitiator_Name() {
		return initiator_Name;
	}
	public void setInitiator_Name(String initiator_Name) {
		this.initiator_Name = initiator_Name;
	}
	public int getInitiator_ID() {
		return Initiator_ID;
	}
	public void setInitiator_ID(int initiator_ID) {
		Initiator_ID = initiator_ID;
	}
	public String getOffer_Made_Offer_Form() {
		return Offer_Made_Offer_Form;
	}
	public void setOffer_Made_Offer_Form(String offer_Made_Offer_Form) {
		Offer_Made_Offer_Form = offer_Made_Offer_Form;
	}
	public Date getOffer_Change_Details_Date() {
		return Offer_Change_Details_Date;
	}
	public void setOffer_Change_Details_Date(Date offer_Change_Details_Date) {
		Offer_Change_Details_Date = offer_Change_Details_Date;
	}
	public String getReferrer_First_Name() {
		return Referrer_First_Name;
	}
	public void setReferrer_First_Name(String referrer_First_Name) {
		Referrer_First_Name = referrer_First_Name;
	}
	public String getReferrer_Last_Name() {
		return Referrer_Last_Name;
	}
	public void setReferrer_Last_Name(String referrer_Last_Name) {
		Referrer_Last_Name = referrer_Last_Name;
	}
	public String getReferrer_Email() {
		return Referrer_Email;
	}
	public void setReferrer_Email(String referrer_Email) {
		Referrer_Email = referrer_Email;
	}
	public String getReferral_Status() {
		return Referral_Status;
	}
	public void setReferral_Status(String referral_Status) {
		Referral_Status = referral_Status;
	}
	public String getReferral_Status_Date() {
		return Referral_Status_Date;
	}
	public void setReferral_Status_Date(String referral_Status_Date) {
		Referral_Status_Date = referral_Status_Date;
	}
	public int getProject_Code() {
		return Project_Code;
	}
	public void setProject_Code(int project_Code) {
		Project_Code = project_Code;
	}
	public String getPrevious_Organization_Name() {
		return Previous_Organization_Name;
	}
	public void setPrevious_Organization_Name(String previous_Organization_Name) {
		Previous_Organization_Name = previous_Organization_Name;
	}
	public String getTrack_Detail() {
		return Track_Detail;
	}
	public void setTrack_Detail(String track_Detail) {
		Track_Detail = track_Detail;
	}
	public String getSkill_On_TAP() {
		return Skill_On_TAP;
	}
	public void setSkill_On_TAP(String skill_On_TAP) {
		Skill_On_TAP = skill_On_TAP;
	}
	public String getProcessing_Priority_Flag() {
		return Processing_Priority_Flag;
	}
	public void setProcessing_Priority_Flag(String processing_Priority_Flag) {
		Processing_Priority_Flag = processing_Priority_Flag;
	}
	public Date getEDOJ_Offer_Accept() {
		return EDOJ_Offer_Accept;
	}
	public void setEDOJ_Offer_Accept(Date eDOJ_Offer_Accept) {
		EDOJ_Offer_Accept = eDOJ_Offer_Accept;
	}
	public String getPOFU_Purview() {
		return POFU_Purview;
	}
	public void setPOFU_Purview(String pOFU_Purview) {
		POFU_Purview = pOFU_Purview;
	}
	public String getModified_By() {
		return Modified_By;
	}
	public void setModified_By(String modified_By) {
		Modified_By = modified_By;
	}
	public Date getModified_On() {
		return Modified_On;
	}
	public void setModified_On(Date modified_On) {
		Modified_On = modified_On;
	}
	public char getActive_Flag() {
		return Active_Flag;
	}
	public void setActive_Flag(char active_Flag) {
		Active_Flag = active_Flag;
	}
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getBgv_Status() {
		return bgv_Status;
	}
	public void setBgv_Status(String bgv_Status) {
		this.bgv_Status = bgv_Status;
	}
	public String getBgv_colour() {
		return bgv_colour;
	}
	public void setBgv_colour(String bgv_colour) {
		this.bgv_colour = bgv_colour;
	}
	public Date getBgv_Triggered_Date() {
		return bgv_Triggered_Date;
	}
	public void setBgv_Triggered_Date(Date bgv_Triggered_Date) {
		this.bgv_Triggered_Date = bgv_Triggered_Date;
	}
	public String getBgv_Initiated_On() {
		return bgv_Initiated_On;
	}
	public void setBgv_Initiated_On(String bgv_Initiated_On) {
		this.bgv_Initiated_On = bgv_Initiated_On;
	}
	@Override
	public String toString() {
		return "Tsc [CV_ID=" + CV_ID + ", Type_Of_Hires=" + Type_Of_Hires + ", Fullfilment_Type=" + Fullfilment_Type
				+ ", FIRST_NAME=" + FIRST_NAME + ", Middle_Name=" + Middle_Name + ", Last_Name=" + Last_Name
				+ ", Offer_Sent_Date=" + Offer_Sent_Date + ", Offer_Accept_Date=" + Offer_Accept_Date
				+ ", Expected_Joining_Date=" + Expected_Joining_Date + ", Joining_Date=" + Joining_Date
				+ ", Candidate_Source=" + Candidate_Source + ", Tagged_LOB=" + Tagged_LOB + ", LOB_Delivery="
				+ LOB_Delivery + ", Apps_ES_LOB=" + Apps_ES_LOB + ", Final_Source=" + Final_Source
				+ ", Candidate_Source_Type=" + Candidate_Source_Type + ", Source_Details=" + Source_Details
				+ ", Agency_Code=" + Agency_Code + ", Agency_Name=" + Agency_Name + ", Email=" + Email
				+ ", Contact_Number=" + Contact_Number + ", country=" + country + ", Gender=" + Gender + ", TEX_Months="
				+ TEX_Months + ", REX_Months=" + REX_Months + ", Company_Name=" + Company_Name + ", Job=" + Job
				+ ", Job_Family=" + Job_Family + ", Primary_Skill=" + Primary_Skill + ", Secondary_Skill="
				+ Secondary_Skill + ", Domain_For_Infra=" + Domain_For_Infra + ", Sub_Domain_For_Infra="
				+ Sub_Domain_For_Infra + ", S_E_Band=" + S_E_Band + ", E_Sub_Bad=" + E_Sub_Bad + ", Designation="
				+ Designation + ", Joining_Location=" + Joining_Location + ", Personal_Area=" + Personal_Area
				+ ", Personal_Sub_Area=" + Personal_Sub_Area + ", Joining_L1=" + Joining_L1 + ", Joining_L2="
				+ Joining_L2 + ", Joining_L3=" + Joining_L3 + ", Joining_L4=" + Joining_L4 + ", Employee_Group="
				+ Employee_Group + ", Billing_Date=" + Billing_Date + ", Account_Manager=" + Account_Manager
				+ ", Billing_Type=" + Billing_Type + ", Customer_Name=" + Customer_Name + ", project_Name="
				+ project_Name + ", Expected_Closure_Date=" + Expected_Closure_Date + ", Requisition_Date="
				+ Requisition_Date + ", Reporting_Manager=" + Reporting_Manager + ", Requisition_Source="
				+ Requisition_Source + ", TAG_Manager=" + TAG_Manager + ", Recruiter=" + Recruiter
				+ ", TAG_Executive_Assign_Date=" + TAG_Executive_Assign_Date + ", TAG_Manager_Assign_Date="
				+ TAG_Manager_Assign_Date + ", SR_Number=" + SR_Number + ", SR_Status=" + SR_Status + ", New_HR_Status="
				+ New_HR_Status + ", Joining_Status=" + Joining_Status + ", HR_Status=" + HR_Status + ", Home_phone="
				+ Home_phone + ", Job_title=" + Job_title + ", Department=" + Department + ", New_Relocation="
				+ New_Relocation + ", New_Relocation_From=" + New_Relocation_From + ", New_Relocation_To="
				+ New_Relocation_To + ", Screener_Name=" + Screener_Name + ", Sourcer_Name=" + Sourcer_Name
				+ ", T_Rating=" + T_Rating + ", Date_of_Birth=" + Date_of_Birth + ", Willing_To_Relocate="
				+ Willing_To_Relocate + ", Preferred_Locations=" + Preferred_Locations + ", Notice_Period="
				+ Notice_Period + ", initiator_Name=" + initiator_Name + ", Initiator_ID=" + Initiator_ID
				+ ", Offer_Made_Offer_Form=" + Offer_Made_Offer_Form + ", Offer_Change_Details_Date="
				+ Offer_Change_Details_Date + ", Referrer_First_Name=" + Referrer_First_Name + ", Referrer_Last_Name="
				+ Referrer_Last_Name + ", Referrer_Email=" + Referrer_Email + ", Referral_Status=" + Referral_Status
				+ ", Referral_Status_Date=" + Referral_Status_Date + ", Project_Code=" + Project_Code
				+ ", Previous_Organization_Name=" + Previous_Organization_Name + ", Track_Detail=" + Track_Detail
				+ ", Skill_On_TAP=" + Skill_On_TAP + ", Processing_Priority_Flag=" + Processing_Priority_Flag
				+ ", EDOJ_Offer_Accept=" + EDOJ_Offer_Accept + ", POFU_Purview=" + POFU_Purview + ", Modified_By="
				+ Modified_By + ", Modified_On=" + Modified_On + ", Active_Flag=" + Active_Flag + ", ID=" + ID
				+ ", bgv_Status=" + bgv_Status + ", bgv_colour=" + bgv_colour + ", bgv_Triggered_Date="
				+ bgv_Triggered_Date + ", bgv_Initiated_On=" + bgv_Initiated_On + "]";
	}
	
	
}

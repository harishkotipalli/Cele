package com.hcl.pmoautomation.bgv.model;

import java.sql.Timestamp;
import java.util.Date;

public class BgvVO {
	private int SAP_ID;
	private String EMP_FIRST_NAME;
	private String EMP_LAST_NAME;
	private String PREFERRED_BUSINESS_NAME;
	private String GENDER;
	private Date DATE_OF_BIRTH;
	private String NATIONALITY;
	private String CORRESPONDENCE_LANGUAGE;
	private String PREVIOUSLY_WORKED_WITH_CLIENT;
	private String OFFER_ACCEPTED_STATUS;
	private Date OFFER_ACCEPTED_DATE;
	private String PROJECT_CODE;
	private String PROJECT_NAME;
	private String SECTOR;
	private String REQUEST_TYPE;
	private Date ASSIGNMENT_FROM;
	private Date ASSIGNMENT_TO;
	private String ONSHORE_OFFSHORE;
	private String TP_APPROVAL;
	private String TP_RESOURCE;
	private String EMP_OFFICIAL_MAIL_ID;
	private String EMP_PERSONAL_MAIL_ID;
	private String EMP_CLIENT_MAIL_ID;
	private Long EMP_CONTACT_NUMBER;
	private String LOCATION;
	private String new_LOCATION;
	private String OU_CODE;
	private int GPN;
	private String CLIENT_HIRING_MANAGER_MAIL_ID;
	private int CLIENT_HIRING_MANAGER_GPN_NO;
	private String REGION;
	private String COUNTRY;
	private String LEGAL_FIRST_NAME;
	private String LEGAL_SECOND_NAME;
	private String BGV_TYPE;
	private String REQUESTED_BY;
	private Timestamp REQUESTED_DATE;
	
	public String getNew_LOCATION() {
		return new_LOCATION;
	}
	public void setNew_LOCATION(String new_LOCATION) {
		this.new_LOCATION = new_LOCATION;
	}
	public int getSAP_ID() {
		return SAP_ID;
	}
	public void setSAP_ID(int sAP_ID) {
		SAP_ID = sAP_ID;
	}
	public String getEMP_FIRST_NAME() {
		return EMP_FIRST_NAME;
	}
	public void setEMP_FIRST_NAME(String eMP_FIRST_NAME) {
		EMP_FIRST_NAME = eMP_FIRST_NAME;
	}
	public String getEMP_LAST_NAME() {
		return EMP_LAST_NAME;
	}
	public void setEMP_LAST_NAME(String eMP_LAST_NAME) {
		EMP_LAST_NAME = eMP_LAST_NAME;
	}
	public String getPREFERRED_BUSINESS_NAME() {
		return PREFERRED_BUSINESS_NAME;
	}
	public void setPREFERRED_BUSINESS_NAME(String pREFERRED_BUSINESS_NAME) {
		PREFERRED_BUSINESS_NAME = pREFERRED_BUSINESS_NAME;
	}
	public String getGENDER() {
		return GENDER;
	}
	public void setGENDER(String gENDER) {
		GENDER = gENDER;
	}
	public Date getDATE_OF_BIRTH() {
		return DATE_OF_BIRTH;
	}
	public void setDATE_OF_BIRTH(Date dATE_OF_BIRTH) {
		DATE_OF_BIRTH = dATE_OF_BIRTH;
	}
	public String getNATIONALITY() {
		return NATIONALITY;
	}
	public void setNATIONALITY(String nATIONALITY) {
		NATIONALITY = nATIONALITY;
	}
	public String getCORRESPONDENCE_LANGUAGE() {
		return CORRESPONDENCE_LANGUAGE;
	}
	public void setCORRESPONDENCE_LANGUAGE(String cORRESPONDENCE_LANGUAGE) {
		CORRESPONDENCE_LANGUAGE = cORRESPONDENCE_LANGUAGE;
	}
	public String getPREVIOUSLY_WORKED_WITH_CLIENT() {
		return PREVIOUSLY_WORKED_WITH_CLIENT;
	}
	public void setPREVIOUSLY_WORKED_WITH_CLIENT(
			String pREVIOUSLY_WORKED_WITH_CLIENT) {
		PREVIOUSLY_WORKED_WITH_CLIENT = pREVIOUSLY_WORKED_WITH_CLIENT;
	}
	public String getOFFER_ACCEPTED_STATUS() {
		return OFFER_ACCEPTED_STATUS;
	}
	public void setOFFER_ACCEPTED_STATUS(String oFFER_ACCEPTED_STATUS) {
		OFFER_ACCEPTED_STATUS = oFFER_ACCEPTED_STATUS;
	}
	public Date getOFFER_ACCEPTED_DATE() {
		return OFFER_ACCEPTED_DATE;
	}
	public void setOFFER_ACCEPTED_DATE(Date oFFER_ACCEPTED_DATE) {
		OFFER_ACCEPTED_DATE = oFFER_ACCEPTED_DATE;
	}
	public String getPROJECT_CODE() {
		return PROJECT_CODE;
	}
	public void setPROJECT_CODE(String pROJECT_CODE) {
		PROJECT_CODE = pROJECT_CODE;
	}
	public String getPROJECT_NAME() {
		return PROJECT_NAME;
	}
	public void setPROJECT_NAME(String pROJECT_NAME) {
		PROJECT_NAME = pROJECT_NAME;
	}
	public String getSECTOR() {
		return SECTOR;
	}
	public void setSECTOR(String sECTOR) {
		SECTOR = sECTOR;
	}
	public String getREQUEST_TYPE() {
		return REQUEST_TYPE;
	}
	public void setREQUEST_TYPE(String rEQUEST_TYPE) {
		REQUEST_TYPE = rEQUEST_TYPE;
	}
	public Date getASSIGNMENT_FROM() {
		return ASSIGNMENT_FROM;
	}
	public void setASSIGNMENT_FROM(Date aSSIGNMENT_FROM) {
		ASSIGNMENT_FROM = aSSIGNMENT_FROM;
	}
	public Date getASSIGNMENT_TO() {
		return ASSIGNMENT_TO;
	}
	public void setASSIGNMENT_TO(Date aSSIGNMENT_TO) {
		ASSIGNMENT_TO = aSSIGNMENT_TO;
	}
	public String getONSHORE_OFFSHORE() {
		return ONSHORE_OFFSHORE;
	}
	public void setONSHORE_OFFSHORE(String oNSHORE_OFFSHORE) {
		ONSHORE_OFFSHORE = oNSHORE_OFFSHORE;
	}
	public String getTP_APPROVAL() {
		return TP_APPROVAL;
	}
	public void setTP_APPROVAL(String tP_APPROVAL) {
		TP_APPROVAL = tP_APPROVAL;
	}
	public String getTP_RESOURCE() {
		return TP_RESOURCE;
	}
	public void setTP_RESOURCE(String tP_RESOURCE) {
		TP_RESOURCE = tP_RESOURCE;
	}
	public String getEMP_OFFICIAL_MAIL_ID() {
		return EMP_OFFICIAL_MAIL_ID;
	}
	public void setEMP_OFFICIAL_MAIL_ID(String eMP_OFFICIAL_MAIL_ID) {
		EMP_OFFICIAL_MAIL_ID = eMP_OFFICIAL_MAIL_ID;
	}
	public String getEMP_PERSONAL_MAIL_ID() {
		return EMP_PERSONAL_MAIL_ID;
	}
	public void setEMP_PERSONAL_MAIL_ID(String eMP_PERSONAL_MAIL_ID) {
		EMP_PERSONAL_MAIL_ID = eMP_PERSONAL_MAIL_ID;
	}
	public String getEMP_CLIENT_MAIL_ID() {
		return EMP_CLIENT_MAIL_ID;
	}
	public void setEMP_CLIENT_MAIL_ID(String eMP_CLIENT_MAIL_ID) {
		EMP_CLIENT_MAIL_ID = eMP_CLIENT_MAIL_ID;
	}
	public Long getEMP_CONTACT_NUMBER() {
		return EMP_CONTACT_NUMBER;
	}
	public void setEMP_CONTACT_NUMBER(Long eMP_CONTACT_NUMBER) {
		EMP_CONTACT_NUMBER = eMP_CONTACT_NUMBER;
	}
	public String getLOCATION() {
		return LOCATION;
	}
	public void setLOCATION(String lOCATION) {
		LOCATION = lOCATION;
	}
	public String getOU_CODE() {
		return OU_CODE;
	}
	public void setOU_CODE(String oU_CODE) {
		OU_CODE = oU_CODE;
	}
	public int getGPN() {
		return GPN;
	}
	public void setGPN(int gPN) {
		GPN = gPN;
	}
	public String getCLIENT_HIRING_MANAGER_MAIL_ID() {
		return CLIENT_HIRING_MANAGER_MAIL_ID;
	}
	public void setCLIENT_HIRING_MANAGER_MAIL_ID(
			String cLIENT_HIRING_MANAGER_MAIL_ID) {
		CLIENT_HIRING_MANAGER_MAIL_ID = cLIENT_HIRING_MANAGER_MAIL_ID;
	}
	public int getCLIENT_HIRING_MANAGER_GPN_NO() {
		return CLIENT_HIRING_MANAGER_GPN_NO;
	}
	public void setCLIENT_HIRING_MANAGER_GPN_NO(int cLIENT_HIRING_MANAGER_GPN_NO) {
		CLIENT_HIRING_MANAGER_GPN_NO = cLIENT_HIRING_MANAGER_GPN_NO;
	}
	public String getREGION() {
		return REGION;
	}
	public void setREGION(String rEGION) {
		REGION = rEGION;
	}
	public String getCOUNTRY() {
		return COUNTRY;
	}
	public void setCOUNTRY(String cOUNTRY) {
		COUNTRY = cOUNTRY;
	}
	
	public String getLEGAL_FIRST_NAME() {
		return LEGAL_FIRST_NAME;
	}
	public void setLEGAL_FIRST_NAME(String lEGAL_FIRST_NAME) {
		LEGAL_FIRST_NAME = lEGAL_FIRST_NAME;
	}
	public String getLEGAL_SECOND_NAME() {
		return LEGAL_SECOND_NAME;
	}
	public void setLEGAL_SECOND_NAME(String lEGAL_SECOND_NAME) {
		LEGAL_SECOND_NAME = lEGAL_SECOND_NAME;
	}
	public String getBGV_TYPE() {
		return BGV_TYPE;
	}
	public void setBGV_TYPE(String bGV_TYPE) {
		BGV_TYPE = bGV_TYPE;
	}
	
	public String getREQUESTED_BY() {
		return REQUESTED_BY;
	}
	public void setREQUESTED_BY(String rEQUESTED_BY) {
		REQUESTED_BY = rEQUESTED_BY;
	}
	
	public Timestamp getREQUESTED_DATE() {
		return REQUESTED_DATE;
	}
	public void setREQUESTED_DATE(Timestamp rEQUESTED_DATE) {
		REQUESTED_DATE = rEQUESTED_DATE;
	}
	@Override
	public String toString() {
		return "BgvVO [SAP_ID=" + SAP_ID + ", EMP_FIRST_NAME=" + EMP_FIRST_NAME + ", EMP_LAST_NAME=" + EMP_LAST_NAME
				+ ", PREFERRED_BUSINESS_NAME=" + PREFERRED_BUSINESS_NAME + ", GENDER=" + GENDER + ", DATE_OF_BIRTH="
				+ DATE_OF_BIRTH + ", NATIONALITY=" + NATIONALITY + ", CORRESPONDENCE_LANGUAGE="
				+ CORRESPONDENCE_LANGUAGE + ", PREVIOUSLY_WORKED_WITH_CLIENT=" + PREVIOUSLY_WORKED_WITH_CLIENT
				+ ", OFFER_ACCEPTED_STATUS=" + OFFER_ACCEPTED_STATUS + ", OFFER_ACCEPTED_DATE=" + OFFER_ACCEPTED_DATE
				+ ", PROJECT_CODE=" + PROJECT_CODE + ", PROJECT_NAME=" + PROJECT_NAME + ", SECTOR=" + SECTOR
				+ ", REQUEST_TYPE=" + REQUEST_TYPE + ", ASSIGNMENT_FROM=" + ASSIGNMENT_FROM + ", ASSIGNMENT_TO="
				+ ASSIGNMENT_TO + ", ONSHORE_OFFSHORE=" + ONSHORE_OFFSHORE + ", TP_APPROVAL=" + TP_APPROVAL
				+ ", TP_RESOURCE=" + TP_RESOURCE + ", EMP_OFFICIAL_MAIL_ID=" + EMP_OFFICIAL_MAIL_ID
				+ ", EMP_PERSONAL_MAIL_ID=" + EMP_PERSONAL_MAIL_ID + ", EMP_CLIENT_MAIL_ID=" + EMP_CLIENT_MAIL_ID
				+ ", EMP_CONTACT_NUMBER=" + EMP_CONTACT_NUMBER + ", LOCATION=" + LOCATION + ", new_LOCATION="
				+ new_LOCATION + ", OU_CODE=" + OU_CODE + ", GPN=" + GPN + ", CLIENT_HIRING_MANAGER_MAIL_ID="
				+ CLIENT_HIRING_MANAGER_MAIL_ID + ", CLIENT_HIRING_MANAGER_GPN_NO=" + CLIENT_HIRING_MANAGER_GPN_NO
				+ ", REGION=" + REGION + ", COUNTRY=" + COUNTRY + ", LEGAL_FIRST_NAME=" + LEGAL_FIRST_NAME
				+ ", LEGAL_SECOND_NAME=" + LEGAL_SECOND_NAME + ", BGV_TYPE=" + BGV_TYPE + ", REQUESTED_BY="
				+ REQUESTED_BY + ", REQUESTED_DATE=" + REQUESTED_DATE + "]";
	}
	

	
}

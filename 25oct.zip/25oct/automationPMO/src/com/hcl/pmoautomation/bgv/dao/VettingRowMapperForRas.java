package com.hcl.pmoautomation.bgv.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.hcl.pmoautomation.bgv.model.VettingSheet;

public class VettingRowMapperForRas implements RowMapper<VettingSheet> {

	@Override
	public VettingSheet mapRow(ResultSet vettingResultSet, int arg1) throws SQLException {
		VettingSheet sheet=new VettingSheet();
		sheet.setproject_Name(vettingResultSet.getString("Project_Name"));
		sheet.setproject_Code(vettingResultSet.getString("Project_Code"));
        sheet.setRas_id(vettingResultSet.getInt("id"));
		//ssheet.setJoining_Location(vettingResultSet.getString("LOCATION"));
		sheet.setFirst_Name(vettingResultSet.getString("EMPNAME"));
		sheet.setcountry(vettingResultSet.getString("LOCATION"));
		sheet.setAssignment_Details_Start_Date(vettingResultSet.getDate("RAS_START_DATE"));
		sheet.setAssignment_Details_End_Date(vettingResultSet.getDate("RAS_END_DATE"));
		sheet.setSap_id(vettingResultSet.getInt("SAPCODE"));
		sheet.setWork_Location(vettingResultSet.getString("LOCATION"));
		sheet.setDuPath(vettingResultSet.getString("Upload_Path_BGV_DU"));
		
return sheet;
	}

}

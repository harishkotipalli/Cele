package com.hcl.pmoautomation.bgv.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.hcl.pmoautomation.bgv.model.BgvStatus;
import com.hcl.pmoautomation.bgv.model.EmployeeBgvStatus;

public interface BgvStatusDaoI {
	
	public BgvStatus getAllBgvStatus(int managerId,JdbcTemplate jdbcTemplet);
	public List<EmployeeBgvStatus> getAllNewBgvStatus(int managerId,JdbcTemplate jdbcTemplate);
	public BgvStatus getAllBgvPrecheckStatus(int managerId,JdbcTemplate jdbcTemplet);
	public List<EmployeeBgvStatus> getAllNewBgvPrecheckStatus(int managerId,JdbcTemplate jdbcTemplate);
	public BgvStatus getAllBgvcompletedStatus(int managerId,JdbcTemplate jdbcTemplet);
	public List<EmployeeBgvStatus> getAllNewBgvcompletedStatus(int managerId,JdbcTemplate jdbcTemplet);
	public BgvStatus getAllBgvReferredStatus(int managerId, JdbcTemplate jdbcTemplet);
	public List<EmployeeBgvStatus> getAllNewBgvrefferedStatus(int managerId,JdbcTemplate jdbcTemplet);
}

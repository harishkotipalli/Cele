package com.hcl.pmoautomation.bgv.controller;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

@WebServlet("*.postvettingupload")
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
        maxFileSize = 1024 * 1024 * 10, // 10MB
        maxRequestSize = 1024 * 1024 * 50)   // 50MB

public class uploadSerPostVetting extends HttpServlet {
	private static final String SAVE_DIR = "uploadFiles";
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  String result = null;
			 
		//  String appPath = request.getServletContext().getRealPath("");
			        String appPath="C:/";	   
			        String savePath = appPath + SAVE_DIR+"/";
			       
			        File fileSaveDir = new File(savePath);
			        if (!fileSaveDir.exists()) {
			            fileSaveDir.mkdir();
			        }
			     
			        System.out.println("hiiiiiii "+savePath);
			        String fileName=null,tempString = null;
					Scanner scanner = null;String postcheckvettingfinal=null;
				
			        for (Part part : request.getParts()) {
			        	fileName = extractFileName(part);
			        	 fileName = new File(fileName).getName();
						if (fileName.equals("")) {
							break;
						}
						System.out.println(fileName);
						fileName = fileName.replace("\\", "/");
						scanner = new Scanner(fileName);
						System.out.println("fiele   "+fileName);
						scanner.useDelimiter("/");
						while (scanner.hasNext()) {
							tempString = scanner.next();
							if (tempString.contains(".txt")) {
								break;
							}
						}
			            System.out.println(("111111111   "+savePath + fileName));
			            part.write(savePath +  fileName);
			            
			 	  postcheckvettingfinal=savePath + fileName;
			 	 
			 	 HttpSession session = request.getSession(false);
			        session.setAttribute("finalpostcheckvetting", postcheckvettingfinal);
			 	
			        }
					
			        System.out.println("finally   "+postcheckvettingfinal);
			        request.setAttribute("message", "File successfully uploaded ");
			   
			       
			        if(((String)request.getAttribute("vettingpostcheck")).equalsIgnoreCase("postcheckvetting")){
						request.getRequestDispatcher("pmoAutomation/Bgv/uploadpagepostfinal.php").forward(request, response);
			        }
	}
	  private String extractFileName(Part part) {
	        String contentDisp = part.getHeader("content-disposition");
	        String[] items = contentDisp.split(";");
	        for (String s : items) {
	            if (s.trim().startsWith("filename")) {
	                return s.substring(s.indexOf("=") + 2, s.length() - 1);
	            }
	        }
	        return "";
	    }
}

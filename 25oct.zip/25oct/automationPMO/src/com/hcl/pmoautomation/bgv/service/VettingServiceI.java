package com.hcl.pmoautomation.bgv.service;

import org.springframework.jdbc.core.JdbcTemplate;

import com.hcl.pmoautomation.bgv.model.Bgv1;
import com.hcl.pmoautomation.bgv.model.EditVettingSheet;
import com.hcl.pmoautomation.bgv.model.VettingSheet;


public interface VettingServiceI {
	
public VettingSheet getVetting(int id,int sap_id,JdbcTemplate jdbcTemplet);
public Bgv1 getVettingSheet(int sap_id,JdbcTemplate jdbcTemplet);
public EditVettingSheet getEditVettingSheet(int sap_id,JdbcTemplate jdbcTemplet);



//public Object getVetting(int id);

Object getVetting(int id, JdbcTemplate jdbcTemplet);
}

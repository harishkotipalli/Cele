package com.hcl.pmoautomation.bgv.dao;

import org.springframework.jdbc.core.JdbcTemplate;

public interface ReferBackDaoI {
	public boolean referBackPmo(JdbcTemplate jdbcTemplate,String remarks,int SapId);

}

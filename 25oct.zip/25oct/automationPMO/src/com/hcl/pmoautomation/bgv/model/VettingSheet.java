package com.hcl.pmoautomation.bgv.model;


import java.util.Date;

public class VettingSheet {
	private ResourcePersonalDetails resourcePersonalDetails;

	private int ubs_Hiring_Manager_Gpn;
	private String ubs_Hiring_Manager_email_Id;

	private String department_Ou_Code;
	private String regulatory_Region_country;
	private Date assignment_Details_Start_Date;

	private Date assignment_Details_End_Date;
	private int ras_id;
	
	private String project_Name;
	private String project_Code;
	private String email;
	private String contact_Number;
	private String type_Of_Hires;
	private String first_Name;
	private String last_Name;
	private String country;
	private String gender;
	private Date date_of_Birth;
	private String Joining_Location;
	private String work_Location;
	private String sector;
	private String tp_Resource;
	private String tp_Approved_Mail;
	private String bgv_type;
	private String requested_by;
	private Date requested_date;
	private int sap_id;
	private String duPath;
	

	public int getRas_id() {
		return ras_id;
	}

	public void setRas_id(int ras_id) {
		this.ras_id = ras_id;
	}

	public String getProject_Name() {
		return project_Name;
	}

	public void setProject_Name(String project_Name) {
		this.project_Name = project_Name;
	}

	public String getProject_Code() {
		return project_Code;
	}

	public void setProject_Code(String project_Code) {
		this.project_Code = project_Code;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	

	public String getContact_Number() {
		return contact_Number;
	}

	public void setContact_Number(String contact_Number) {
		this.contact_Number = contact_Number;
	}

	public String getType_Of_Hires() {
		return type_Of_Hires;
	}

	public void setType_Of_Hires(String type_Of_Hires) {
		this.type_Of_Hires = type_Of_Hires;
	}

	public String getLast_Name() {
		return last_Name;
	}

	public void setLast_Name(String last_Name) {
		this.last_Name = last_Name;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Date getDate_of_Birth() {
		return date_of_Birth;
	}

	public void setDate_of_Birth(Date date_of_Birth) {
		this.date_of_Birth = date_of_Birth;
	}

	public String getproject_Name() {
		return project_Name;
	}

	public void setproject_Name(String project_Name) {
		this.project_Name = project_Name;
	}

	public String getproject_Code() {
		return project_Code;
	}

	public void setproject_Code(String project_Code) {
		this.project_Code = project_Code;
	}

	public String getemail() {
		return email;
	}

	public void setemail(String email) {
		this.email = email;
	}



	public String gettype_Of_Hires() {
		return type_Of_Hires;
	}

	public void settype_Of_Hires(String type_Of_Hires) {
		this.type_Of_Hires = type_Of_Hires;
	}

	

	public String getFirst_Name() {
		return first_Name;
	}

	public void setFirst_Name(String first_Name) {
		this.first_Name = first_Name;
	}

	public String getlast_Name() {
		return last_Name;
	}

	public void setlast_Name(String last_Name) {
		this.last_Name = last_Name;
	}

	public String getcountry() {
		return country;
	}

	public void setcountry(String country) {
		this.country = country;
	}

	public String getgender() {
		return gender;
	}

	public void setgender(String gender) {
		this.gender = gender;
	}

	public Date getdate_of_Birth() {
		return date_of_Birth;
	}

	public void setdate_of_Birth(Date date_of_Birth) {
		this.date_of_Birth = date_of_Birth;
	}

	public String getJoining_Location() {
		return Joining_Location;
	}

	public void setJoining_Location(String joining_Location) {
		Joining_Location = joining_Location;
	}

	

	public ResourcePersonalDetails getResourcePersonalDetails() {
		return resourcePersonalDetails;
	}

	public void setResourcePersonalDetails(
			ResourcePersonalDetails resourcePersonalDetails) {
		this.resourcePersonalDetails = resourcePersonalDetails;
	}

	public int getUbs_Hiring_Manager_Gpn() {
		return ubs_Hiring_Manager_Gpn;
	}

	public void setUbs_Hiring_Manager_Gpn(int ubs_Hiring_Manager_Gpn) {
		this.ubs_Hiring_Manager_Gpn = ubs_Hiring_Manager_Gpn;
	}

	public String getUbs_Hiring_Manager_email_Id() {
		return ubs_Hiring_Manager_email_Id;
	}

	public void setUbs_Hiring_Manager_email_Id(
			String ubs_Hiring_Manager_email_Id) {
		this.ubs_Hiring_Manager_email_Id = ubs_Hiring_Manager_email_Id;
	}

	public String getDepartment_Ou_Code() {
		return department_Ou_Code;
	}

	public void setDepartment_Ou_Code(String department_Ou_Code) {
		this.department_Ou_Code = department_Ou_Code;
	}

	public String getRegulatory_Region_country() {
		return regulatory_Region_country;
	}

	public void setRegulatory_Region_country(String regulatory_Region_country) {
		this.regulatory_Region_country = regulatory_Region_country;
	}

	public Date getAssignment_Details_Start_Date() {
		return assignment_Details_Start_Date;
	}

	public void setAssignment_Details_Start_Date(
			Date assignment_Details_Start_Date) {
		this.assignment_Details_Start_Date = assignment_Details_Start_Date;
	}

	public Date getAssignment_Details_End_Date() {
		return assignment_Details_End_Date;
	}

	public void setAssignment_Details_End_Date(Date assignment_Details_End_Date) {
		this.assignment_Details_End_Date = assignment_Details_End_Date;
	}

	

	public String getWork_Location() {
		return work_Location;
	}

	public void setWork_Location(String work_Location) {
		this.work_Location = work_Location;
	}

	public String getSector() {
		return sector;
	}

	public void setSector(String sector) {
		this.sector = sector;
	}

	public String getTp_Resource() {
		return tp_Resource;
	}

	public void setTp_Resource(String tp_Resource) {
		this.tp_Resource = tp_Resource;
	}

	public String getTp_Approved_Mail() {
		return tp_Approved_Mail;
	}

	public void setTp_Approved_Mail(String tp_Approved_Mail) {
		this.tp_Approved_Mail = tp_Approved_Mail;
	}
	

	public String getBgv_type() {
		return bgv_type;
	}

	public void setBgv_type(String bgv_type) {
		this.bgv_type = bgv_type;
	}
	

	public String getRequested_by() {
		return requested_by;
	}

	public void setRequested_by(String requested_by) {
		this.requested_by = requested_by;
	}

	public Date getRequested_date() {
		return requested_date;
	}

	public void setRequested_date(Date requested_date) {
		this.requested_date = requested_date;
	}

	
	public int getSap_id() {
		return sap_id;
	}

	public void setSap_id(int sap_id) {
		this.sap_id = sap_id;
	}

	

	public String getDuPath() {
		return duPath;
	}

	public void setDuPath(String duPath) {
		this.duPath = duPath;
	}

	@Override
	public String toString() {
		return "VettingSheet [resourcePersonalDetails=" + resourcePersonalDetails + ", ubs_Hiring_Manager_Gpn="
				+ ubs_Hiring_Manager_Gpn + ", ubs_Hiring_Manager_email_Id=" + ubs_Hiring_Manager_email_Id
				+ ", department_Ou_Code=" + department_Ou_Code + ", regulatory_Region_country="
				+ regulatory_Region_country + ", assignment_Details_Start_Date=" + assignment_Details_Start_Date
				+ ", assignment_Details_End_Date=" + assignment_Details_End_Date + ", ras_id=" + ras_id
				+ ", project_Name=" + project_Name + ", project_Code=" + project_Code + ", email=" + email
				+ ", contact_Number=" + contact_Number + ", type_Of_Hires=" + type_Of_Hires + ", first_Name="
				+ first_Name + ", last_Name=" + last_Name + ", country=" + country + ", gender=" + gender
				+ ", date_of_Birth=" + date_of_Birth + ", Joining_Location=" + Joining_Location + ", work_Location="
				+ work_Location + ", sector=" + sector + ", tp_Resource=" + tp_Resource + ", tp_Approved_Mail="
				+ tp_Approved_Mail + ", bgv_type=" + bgv_type + ", requested_by=" + requested_by + ", requested_date="
				+ requested_date + ", sap_id=" + sap_id + ", duPath=" + duPath + "]";
	}

	





	
	

}

package com.hcl.pmoautomation.bgv.utilities;

public  interface BgvSql {
public final String updateBgvSatusintotscsql="update tsc set BGV_Status=? where cv_id=?";
public final String updateBgvSatusintorassql="update ras set BGV_Status=? where id=?";
public final String updateBgvSatusintorassql2="update mydb.ras set BGV_Status= ";
public final String updateBgvSatusintorassql3="  where SAPCODE=";
public  final String getVettingShetfromrassql="select SAPCODE,PROJECT_CODE,PROJECT_NAME,EMPNAME,RAS_START_DATE,RAS_END_DATE,LOCATION ,BGV_Status,id,Upload_Path_BGV_DU from ras where id=?";
public  final String getVettingShetfromtscsql="select Project_Name ,Project_Code ,Email,Contact_Number,First_Name ,Last_Name ,Country ,Gender,Joining_Location from tsc where CV_ID=?";


public  final String getnewResourcesql="select SAPCODE,EMPNAME,PROJECT_NAME,RAS_START_DATE,RAS_END_DATE,CV_ID,id,ras_status,gpn_status from ras where REP_MGR_CODE=? and BGV_Status=?";

//public  final String getnewResourcesql="select SAPCODE,EMPNAME,PROJECT_NAME,RES_STSRT_DATE,RES_END_DATE,CV_ID,ras_id from ras4 where REP_MGR_CODE=? and BGV_Status=?";




public final String getyetTOJoinResourcesql="select CV_ID,Project_Code,Expected_Joining_Date,Offer_Sent_Date from tsc where RM_SAP_Code=? and BGV_Status=?";
//public final String update_Tracker_Sql="insert bgv SAP_ID, EMP_FIRST_NAME, EMP_MIDDLE_NAME,EMP_LAST_NAME,PREFERRED_BUSINESS_NAME,GENDER,DATE_OF_BIRTH, NATIONALITY, CORRESPONDENCE_LANGAUGE,PROJECT_CODE,PROJECT_NAME, SECTOR,REQUEST_TYPE,RAS_START_DATE,RAS_END_DATE,REMARKS,TP_RESOURCE,TP_APPROVAL,EMP_OFFICIAL_MAIL_ID, EMP_PERSONAL_MAIL_ID, EMP_CLIENT_MAIL_ID,EMP_CONTACT_NUMBER,LOCATION, REGION, COUNTRY, ASSIGNMENT_FROM,ASSIGNMENT_TO,RAS_ID values(SAP_ID=?, EMP_FIRST_NAME=?, EMP_MIDDLE_NAME=?,EMP_LAST_NAME=?,PREFERRED_BUSINESS_NAME=?,GENDER,DATE_OF_BIRTH=?, NATIONALITY=?, CORRESPONDENCE_LANGAUGE=?,PROJECT_CODE=?,PROJECT_NAME=?, SECTOR=?,REQUEST_TYPE=?,RAS_START_DATE=?,RAS_END_DATE=?,REMARKS=?,TP_RESOURCE=?,TP_APPROVAL=?,EMP_OFFICIAL_MAIL_ID=?, EMP_PERSONAL_MAIL_ID=?, EMP_CLIENT_MAIL_ID=?,EMP_CONTACT_NUMBER=?,LOCATION=?, REGION=?, COUNTRY=?, ASSIGNMENT_FROM=?,ASSIGNMENT_TO=?,RAS_ID=?)";

public final String update_tsc_Tracker_Sql="insert into tsc_bgv(EMP_FIRST_NAME,EMP_LAST_NAME,GENDER,NATIONALITY,PROJECT_CODE,PROJECT_NAME,EMP_CONTACT_NUMBER,REQUEST_TYPE,EMP_PERSONAL_MAIL_ID) values(?,?,?,?,?,?,?,?,?)";
//public final String update_ras_Tracker_Sql="insert into bgv(sap_id,ras_id,PROJECT_CODE,PROJECT_NAME,EMP_FIRST_NAME,RAS_START_DATE,RAS_END_DATE,DATE_OF_BIRTH) values(?,?,?,?,?,?,?,'2016-03-23')";
public final String update_ras_Tracker_Sql="insert into bgv (SAP_ID,RAS_ID,EMP_FIRST_NAME,PROJECT_CODE,PROJECT_NAME,SECTOR,TP_RESOURCE,EMP_PERSONAL_MAIL_ID,EMP_OFFICIAL_MAIL_ID,EMP_CONTACT_NUMBER,EMP_CLIENT_MAIL_ID,GPN,ASSIGNMENT_FROM,ASSIGNMENT_TO,REQUEST_TYPE,REGION,COUNTRY,BGV_TYPE,CLIENT_HIRING_MANAGER_MAIL_ID,CLIENT_HIRING_MANAGER_GPN_NO,PREVIOUSLY_WORKED_WITH_CLIENT,EMP_LAST_NAME,NATIONALITY,PREFERRED_BUSINESS_NAME,GENDER,DATE_OF_BIRTH,OU_CODE,LOCATION,New_Location,REQUESTED_BY,REQUESTED_DATE) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,current_timestamp())";

public final String getvendor_initiate_Sql = "select sap_id,emp_first_name,ou_code from mydb.bgv where pending_vendor='y'";
public final String getbgv_viewBGV="SELECT * FROM mydb.bgv where SAP_ID='";
public final String getyettojoinee_details_Sql = "select emp_first_name,project_code,project_name,ou_code,location,country from tsc_bgv where active_flag='y'";
public final String getfinalbgv_details_Sql = "select sap_id,emp_first_name,request_type,project_code,project_name,"
		+ "ou_code,location,country,BGV_PRESTART_COLOR,BGV_FINAL_REPORT_COLOUR "
		+ " from mydb.bgv  where PRE_START_CHECK_WITH_PMO='initiated'"
		+ " and PRE_START_CHECK_WITH_CENTRAL_BGV='initiated'"			
		+ " and PRE_START_CHECK_WITH_RESOURCE='Y'"
		+ " and PRE_START_CHECK_STATUS='completed'"
		+ " and ACTIVEFLAG_PRECHECK='N'"
		+ " and BGV_Status='INITIATED'";
	/*	+ "from bgv where initiate_gpn='y'";*/
public final String getHCLMAIL_details_Sql = "SELECT Hcl_Mail_Id FROM mydb.login where ROLE='pmoBgvAccess' or login.SAPCODE=";
public final String getHCLMAIL_details_Sql_INITIATEBGV= "select login.Hcl_Mail_Id from mydb.login where login.SAPCODE=(select bgv.REQUESTED_BY from mydb.bgv where bgv.SAP_ID=";
public final String getHCLMAIL_details_Sql_INITIATEBGV_cntd= " )or login.ROLE='pmoBgvAccess'";
public final String getHCLMAIL_details_namesapcode = "select ras.SAPCODE,ras.EMPNAME from mydb.ras where ras.ID=";
public final String getHCLMAIL_details_namesapcode_referbackupdate = "select bgv.SAP_ID,bgv.EMP_FIRST_NAME,bgv.PROJECT_NAME from mydb.bgv where bgv.SAP_ID=";
public final String getbgvinitiatetemplate_details = "select SAP_ID,EMP_FIRST_NAME,EMP_OFFICIAL_MAIL_ID from mydb.bgv where SAP_ID=";
public final String getBgvStatus = "SELECT SAP_ID,EMP_FIRST_NAME,PROJECT_CODE,PROJECT_NAME FROM bgv where REQUESTED_BY=? and ACTIVE_FLAG=?";
public final String getBgvPrecheckStatus = "SELECT SAP_ID,EMP_FIRST_NAME,PROJECT_CODE,PROJECT_NAME FROM bgv where REQUESTED_BY=? and ACTIVE_FLAG=?";
public final String getBgvPrecompletedStatus = "SELECT SAP_ID,EMP_FIRST_NAME,PROJECT_CODE,PROJECT_NAME FROM mydb.bgv where  REQUESTED_BY=? and BGV_FINAL_REPORT_COLOUR=?";
public final String getBgvReferStatus = "SELECT SAP_ID,ID,EMP_FIRST_NAME,PROJECT_CODE,PROJECT_NAME,REFER_BACK_REMARKS FROM mydb.bgv where REQUESTED_BY=? and  REFER_BACK=?";;
public final String getEditVettingSheet ="select * from bgv where SAP_ID=?";
public final String updatereferback="UPDATE bgv SET EMP_FIRST_NAME = ?,PROJECT_NAME = ?,PROJECT_CODE = ?,SECTOR =?,TP_RESOURCE = ?,REQUEST_TYPE = ?,"
		+ "EMP_PERSONAL_MAIL_ID = ?,EMP_OFFICIAL_MAIL_ID = ?,EMP_CONTACT_NUMBER = ?,EMP_CLIENT_MAIL_ID = ?,"
		+ "GPN = ?,ASSIGNMENT_FROM = ?,ASSIGNMENT_TO = ?,REGION = ?,COUNTRY = ?, BGV_TYPE = ?,CLIENT_HIRING_MANAGER_MAIL_ID = ?,"
		+ "CLIENT_HIRING_MANAGER_GPN_NO = ?,NATIONALITY = ?,PREFERRED_BUSINESS_NAME =?,GENDER = ?,"
		+ "DATE_OF_BIRTH = ?,OU_CODE = ?,LOCATION = ?,New_Location=?,REQUESTED_BY = ?,REQUESTED_DATE = current_timestamp(),REFER_BACK = 'NO', ACTIVEFLAG_PRECHECK = 'Y',ACTIVEFLAG_PRECHECK_REFERBACK= 'N' "
		+ "WHERE SAP_ID = ?";
public final String getExcelDownload = "select SAP_ID,EMP_FIRST_NAME,EMP_LAST_NAME,PREFERRED_BUSINESS_NAME,"
		+ "date_format(Bgv.DATE_OF_BIRTH,'%m/%d/%Y') DATE_OF_BIRTH,GENDER,"
		+ "NATIONALITY,PROJECT_CODE,PROJECT_NAME,SECTOR,REQUEST_TYPE,"
		+ "TP_RESOURCE,EMP_OFFICIAL_MAIL_ID,EMP_PERSONAL_MAIL_ID,EMP_CLIENT_MAIL_ID,"
		+ "EMP_CONTACT_NUMBER,LOCATION,New_Location,OU_CODE,GPN,CLIENT_HIRING_MANAGER_MAIL_ID,"
		+ "CLIENT_HIRING_MANAGER_GPN_NO,REGION,COUNTRY,"
		+ "date_format(Bgv.ASSIGNMENT_FROM,'%m/%d/%Y %H:%i:%s') ASSIGNMENT_FROM,"
		+ "date_format(Bgv.ASSIGNMENT_TO,'%m/%d/%Y %H:%i:%s') ASSIGNMENT_TO,"
		+ "BGV_TYPE,REQUESTED_BY,date_format(Bgv.REQUESTED_DATE,'%m/%d/%Y %H:%i:%s') REQUESTED_DATE,"
		+ "PRE_START_CHECK_WITH_PMO,"
		+ "date_format(Bgv.PRE_START_CHECK_WITH_PMO_DATE,'%m/%d/%Y %H:%i:%s') PRE_START_CHECK_WITH_PMO_DATE,"
		+ "PRE_START_CHECK_WITH_CENTRAL_BGV,"
		+ "date_format(Bgv.PRE_START_CHECK_WITH_CENTRAL_BGV_DATE,'%m/%d/%Y %H:%i:%s') PRE_START_CHECK_WITH_CENTRAL_BGV_DATE,"
		+ "PRE_START_CHECK_WITH_RESOURCE,"
		+ "date_format(Bgv.PRE_START_CHECK_WITH_RESOURCE_DATE,'%m/%d/%Y %H:%i:%s') PRE_START_CHECK_WITH_RESOURCE_DATE,"
		+ "VENDOR_INITIATED_PRECHECK,"
		+ "date_format(Bgv.VENDOR_INITIATED_DATE_PRECHECK,'%m/%d/%Y %H:%i:%s') VENDOR_INITIATED_DATE_PRECHECK,"
		+ "PRE_START_CHECK_STATUS,"
		+ "date_format(Bgv.PRE_START_CHECK_COMP_DATE,'%m/%d/%Y %H:%i:%s') PRE_START_CHECK_COMP_DATE,"
		+ "BGV_PRESTART_COLOR,"
		+ "date_format(Bgv.BGV_POST_CHECK_COMPLETED_DATE,'%m/%d/%Y') BGV_POST_CHECK_COMPLETED_DATE,"
		+ "BGV_FINAL_REPORT_COLOUR"
		+ " from mydb.bgv where BGV_Status='initiated'";

public final String getbgv_details_Sql="select sap_id,emp_first_name,project_name,ou_code,date_format(Bgv.REQUESTED_DATE,'%m/%d/%Y %H:%i:%s') requested_date,pre_start_check_with_pmo,datediff(current_date(),Bgv.REQUESTED_DATE) no_of_days_pending from mydb.bgv where PRE_START_CHECK_WITH_PMO='NOTINITIATED' and ACTIVEFLAG_PRECHECK='y' order by bgv.REQUESTED_DATE ";
public final String getPreCheckCentralBGV = "select sap_id,emp_first_name,project_name,ou_code,PRE_START_CHECK_WITH_PMO,date_format(Bgv.PRE_START_CHECK_WITH_PMO_DATE,'%m/%d/%Y %H:%i:%s') PRE_START_CHECK_WITH_PMO_DATE,PRE_START_CHECK_WITH_CENTRAL_BGV,datediff(curdate(),Bgv.PRE_START_CHECK_WITH_PMO_DATE) no_of_days_pending from mydb.bgv where PRE_START_CHECK_WITH_PMO='initiated' and PRE_START_CHECK_WITH_CENTRAL_BGV='notinitiated' order by bgv.PRE_START_CHECK_WITH_PMO_DATE";


public final String preCheckResourceBGV = "select sap_id,emp_first_name,project_name,"
		+ "ou_code,PRE_START_CHECK_WITH_CENTRAL_BGV,"
		+ "date_format(Bgv.PRE_START_CHECK_WITH_CENTRAL_BGV_DATE,'%m/%d/%Y %H:%i:%s')PRE_START_CHECK_WITH_CENTRAL_BGV_DATE,"
		+ "PRE_START_CHECK_WITH_RESOURCE,"
		+ "datediff(curdate(),Bgv.PRE_START_CHECK_WITH_CENTRAL_BGV_DATE) no_of_days_pending"
		+ " from mydb.bgv where PRE_START_CHECK_WITH_PMO='initiated'"
		+ " and PRE_START_CHECK_WITH_CENTRAL_BGV='initiated'"
		+ " and PRE_START_CHECK_WITH_RESOURCE='N'"
		+ " order by Bgv.PRE_START_CHECK_WITH_CENTRAL_BGV_DATE ";
public final String preCheckVendorBGV = "select sap_id,emp_first_name,"
		+ "project_name,ou_code,PRE_START_CHECK_WITH_RESOURCE,"
		+ "date_format(Bgv.PRE_START_CHECK_WITH_RESOURCE_DATE,'%m/%d/%Y %H:%i:%s')PRE_START_CHECK_WITH_RESOURCE_DATE,"
		+ " VENDOR_INITIATED_PRECHECK,"
		+ "datediff(curdate(),Bgv.PRE_START_CHECK_WITH_RESOURCE_DATE) no_of_days_pending "
		+ "from mydb.bgv where PRE_START_CHECK_WITH_PMO='initiated'"
		+ " and PRE_START_CHECK_WITH_CENTRAL_BGV='initiated'"
		+ " and PRE_START_CHECK_WITH_RESOURCE='Y'"
		+ " and PRE_START_CHECK_STATUS='notcompleted'"
		+ " order by Bgv.PRE_START_CHECK_WITH_RESOURCE_DATE";
/*public final String preCheckPmoPending = "select sap_id,emp_first_name,project_name,ou_code,"
		+ "VENDOR_INITIATED_PRECHECK,"
		+ "date_format(Bgv.VENDOR_INITIATED_DATE_PRECHECK,'%m/%d/%Y %H:%i:%s')VENDOR_INITIATED_DATE_PRECHECK,"
		+ "PRE_START_CHECK_STATUS ,"
		+ " datediff(curdate(),Bgv.VENDOR_INITIATED_DATE_PRECHECK) no_of_days_pending"
		+ " from mydb.bgv where PRE_START_CHECK_WITH_PMO='initiated'"
		+ " and PRE_START_CHECK_WITH_CENTRAL_BGV='initiated'"
		+ " and PRE_START_CHECK_WITH_RESOURCE='uploaded'"
		+ " and VENDOR_INITIATED_PRECHECK='initiated'"
		+ " and PRE_START_CHECK_STATUS='notcompleted'"
		+ " order by Bgv.VENDOR_INITIATED_DATE_PRECHECK";*/
public final String preCheckPmoCompleted = "select sap_id,emp_first_name,project_name,ou_code, "
		+ "PRE_START_CHECK_WITH_RESOURCE, "
		+ "date_format(Bgv.PRE_START_CHECK_WITH_RESOURCE_DATE,'%m/%d/%Y %H:%i:%s')PRE_START_CHECK_WITH_RESOURCE_DATE, "
		+ "PRE_START_CHECK_STATUS,BGV_PRESTART_COLOR "		
		+ "from mydb.bgv where PRE_START_CHECK_WITH_PMO='initiated' "
		+ "and PRE_START_CHECK_WITH_CENTRAL_BGV='initiated' "		
		+ "and PRE_START_CHECK_WITH_RESOURCE='Y' "		
		+ "and PRE_START_CHECK_STATUS='completed' and ACTIVEFLAG_PRECHECK='Y' and BGV_FINAL_REPORT_COLOUR='NA' "
		+ "order by Bgv.PRE_START_CHECK_WITH_RESOURCE_DATE";
public final String preCheckPmo = "select sap_id,emp_first_name,project_name,ou_code,"
		+ "PRE_START_CHECK_WITH_RESOURCE,"
		+ "date_format(Bgv.PRE_START_CHECK_WITH_RESOURCE_DATE,'%m/%d/%Y %H:%i:%s')PRE_START_CHECK_WITH_RESOURCE_DATE,"
		+ "PRE_START_CHECK_STATUS,BGV_PRESTART_COLOR , "
		+ "datediff(curdate(),Bgv.PRE_START_CHECK_WITH_RESOURCE_DATE) no_of_days_pending "
		+ "from mydb.bgv where PRE_START_CHECK_WITH_PMO='initiated' "
		+ "and PRE_START_CHECK_WITH_CENTRAL_BGV='initiated' "		
		+ "and PRE_START_CHECK_WITH_RESOURCE='Y' "
		
		+ "and PRE_START_CHECK_STATUS='notcompleted' and bgv.Yet_to_joinee='N' "
		
		+ "order by Bgv.PRE_START_CHECK_WITH_RESOURCE_DATE";
public final String YTJpreCheckPmo = "select sap_id,emp_first_name,project_name,ou_code,"
		+ "PRE_START_CHECK_WITH_CENTRAL_BGV,"
		+ "date_format(Bgv.PRE_START_CHECK_WITH_CENTRAL_BGV_DATE,'%m/%d/%Y %H:%i:%s')PRE_START_CHECK_WITH_CENTRAL_BGV_DATE,"
		+ "PRE_START_CHECK_STATUS,BGV_PRESTART_COLOR , "
		+ "datediff(curdate(),Bgv.PRE_START_CHECK_WITH_CENTRAL_BGV_DATE) no_of_days_pending "
		+ "from mydb.bgv where PRE_START_CHECK_WITH_PMO='initiated' "
		+ "and PRE_START_CHECK_WITH_CENTRAL_BGV='initiated' "		
		+ "and PRE_START_CHECK_WITH_RESOURCE='Y' "
		
		+ "and PRE_START_CHECK_STATUS='notcompleted' and bgv.Yet_to_joinee='Y'";
		
public final String YTJGpnInitiate = "select * from mydb.bgv where bgv.BGV_PRESTART_COLOR='Green' and bgv.PRE_START_CHECK_STATUS='Completed' and bgv.INITIATE_GPN='N' and bgv.Yet_to_joinee='Y'";	

public final String postCheckPending = "select sap_id,emp_first_name,project_name,ou_code,"
	
		+ "date_format(Bgv.PRE_START_CHECK_COMP_DATE,'%m/%d/%Y %H:%i:%s')PRE_START_CHECK_COMP_DATE,"
		+ "PRE_START_CHECK_STATUS,BGV_PRESTART_COLOR , "
		+ "datediff(curdate(),Bgv.PRE_START_CHECK_COMP_DATE) no_of_days_pending "
		+ " from mydb.bgv  where PRE_START_CHECK_WITH_PMO='initiated'"
		+ " and PRE_START_CHECK_WITH_CENTRAL_BGV='initiated'"			
		+ " and PRE_START_CHECK_WITH_RESOURCE='Y'"
	
		+ " and PRE_START_CHECK_STATUS='completed'"
		+ " and ACTIVEFLAG_PRECHECK='N'"
		+ " and BGV_Status='INITIATED'"
		+ "order by Bgv.PRE_START_CHECK_COMP_DATE";

public final String postCheckcompleted = "select sap_id,emp_first_name,project_name,ou_code,"

		+ "date_format(Bgv.BGV_POST_CHECK_COMPLETED_DATE,'%m/%d/%Y %H:%i:%s')BGV_POST_CHECK_COMPLETED_DATE,"
		
		+ "BGV_FINAL_REPORT_COLOUR "
		+ " from mydb.bgv  where PRE_START_CHECK_WITH_PMO='initiated'"
		+ " and PRE_START_CHECK_WITH_CENTRAL_BGV='initiated'"			
		+ " and PRE_START_CHECK_WITH_RESOURCE='Y'"
	
		+ " and PRE_START_CHECK_STATUS='completed'"
		+ " and BGV_FINAL_REPORT_COLOUR='GREEN'"
		+ " and BGV_Status='COMPLETED'";
		


public final String preCheckPmoDetails ="select sap_id,emp_first_name,project_name,ou_code,date_format(Bgv.REQUESTED_DATE,'%m/%d/%Y %H:%i:%s') requested_date,datediff(curdate(),Bgv.REQUESTED_DATE) no_of_days_pending from mydb.bgv where PRE_START_CHECK_WITH_PMO='NOTINITIATED' and ACTIVEFLAG_PRECHECK='y' and ACTIVEFLAG_PRECHECK_REFERBACK='N' order by Bgv.REQUESTED_DATE";

public final String preCheckPmoReport = "select sap_id,emp_first_name,project_name "
		+ "from mydb.bgv where PRE_START_CHECK_WITH_PMO='initiated' and bgv.ACTIVEFLAG_PRECHECK='Y'";
		/*+ "and PRE_START_CHECK_WITH_CENTRAL_BGV='initiated' "
		+ "and VENDOR_INITIATED_PRECHECK='initiated' "
		+ "and PRE_START_CHECK_WITH_RESOURCE='uploaded' "
		+ "and PRE_START_CHECK_STATUS='completed' "
		+ "and  ACTIVEFLAG_PRECHECK='N' "
		+ "and BGV_PRESTART_COLOR='green' "
		+ "and bgv.GPN_STATUS='NA' order by Bgv.PRE_START_CHECK_WITH_RESOURCE_DATE";*/


public final String getbgv_details_Sql_Manager="select sap_id,emp_first_name,project_name,ou_code,date_format(Bgv.REQUESTED_DATE,'%m/%d/%Y %H:%i:%s') requested_date,pre_start_check_with_pmo,datediff(current_date(),Bgv.REQUESTED_DATE) no_of_days_pending from mydb.bgv where PRE_START_CHECK_WITH_PMO='NOTINITIATED' and ACTIVEFLAG_PRECHECK='y' and REQUESTED_BY=";
public final String getbgv_details_Sql_Manager_cntd=" order by bgv.REQUESTED_DATE ";

public final String getPreCheckCentralBGVManager = "select sap_id,emp_first_name,project_name,ou_code,PRE_START_CHECK_WITH_PMO,date_format(Bgv.PRE_START_CHECK_WITH_PMO_DATE,'%m/%d/%Y %H:%i:%s') PRE_START_CHECK_WITH_PMO_DATE,PRE_START_CHECK_WITH_CENTRAL_BGV,datediff(curdate(),Bgv.PRE_START_CHECK_WITH_PMO_DATE) no_of_days_pending from mydb.bgv where PRE_START_CHECK_WITH_PMO='initiated' and PRE_START_CHECK_WITH_CENTRAL_BGV='notinitiated' and REQUESTED_BY=";
public final String getPreCheckCentralBGVManager_cntd = " order by bgv.PRE_START_CHECK_WITH_PMO_DATE";

public final String preCheckResourceBGVManager = "select sap_id,emp_first_name,project_name,ou_code,"
		+ "PRE_START_CHECK_WITH_CENTRAL_BGV,"
		+ "date_format(Bgv.PRE_START_CHECK_WITH_CENTRAL_BGV_DATE,'%m/%d/%Y %H:%i:%s')PRE_START_CHECK_WITH_CENTRAL_BGV_DATE,"
		+ "PRE_START_CHECK_WITH_RESOURCE,"
		+ "datediff(curdate(),Bgv.PRE_START_CHECK_WITH_CENTRAL_BGV_DATE) no_of_days_pending "
		+ "from mydb.bgv where PRE_START_CHECK_WITH_PMO='initiated' "
		+ "and PRE_START_CHECK_WITH_CENTRAL_BGV='initiated' "
		+ "and PRE_START_CHECK_WITH_RESOURCE='N' "
		+ "and REQUESTED_BY=";
public final String preCheckResourceBGVManager_cntd = " order by Bgv.PRE_START_CHECK_WITH_CENTRAL_BGV_DATE ";

public final String preCheckVendorBGVManager = "select sap_id,emp_first_name,project_name,ou_code,"
		+ "PRE_START_CHECK_WITH_RESOURCE,"
		+ "date_format(Bgv.PRE_START_CHECK_WITH_RESOURCE_DATE,'%m/%d/%Y %H:%i:%s')PRE_START_CHECK_WITH_RESOURCE_DATE,"
		+ " VENDOR_INITIATED_PRECHECK,"
		+ "datediff(curdate(),Bgv.PRE_START_CHECK_WITH_RESOURCE_DATE) no_of_days_pending "
		+ "from mydb.bgv where PRE_START_CHECK_WITH_PMO='initiated'"
		+ " and PRE_START_CHECK_WITH_CENTRAL_BGV='initiated'"
		+ " and PRE_START_CHECK_WITH_RESOURCE='Y'"
		+ " and PRE_START_CHECK_STATUS='notcompleted'"
		+ " and REQUESTED_BY=";
public final String preCheckVendorBGVManager_cntd = " order by Bgv.PRE_START_CHECK_WITH_RESOURCE_DATE";




public final String preCheckPmoPendingManager = "select sap_id,emp_first_name,project_name,ou_code,"
		+ "VENDOR_INITIATED_PRECHECK,"
		+ "date_format(Bgv.VENDOR_INITIATED_DATE_PRECHECK,'%m/%d/%Y %H:%i:%s')VENDOR_INITIATED_DATE_PRECHECK,"
		+ "PRE_START_CHECK_STATUS , "
		+ "datediff(curdate(),Bgv.VENDOR_INITIATED_DATE_PRECHECK) no_of_days_pending "
		+ "from mydb.bgv where PRE_START_CHECK_WITH_PMO='initiated'"
		+ " and PRE_START_CHECK_WITH_CENTRAL_BGV='initiated'"
		+ " and VENDOR_INITIATED_PRECHECK='initiated'"
		+ " and PRE_START_CHECK_WITH_RESOURCE='Y'"
		+ " and PRE_START_CHECK_STATUS='notcompleted'"
		+ " and REQUESTED_BY=";


public final String preCheckPmoPendingManager_cntd = " order by Bgv.VENDOR_INITIATED_DATE_PRECHECK";

public final String preCheckPmoManager = "select sap_id,emp_first_name,project_name,ou_code,"
		+ "PRE_START_CHECK_WITH_RESOURCE,"
		+ "date_format(Bgv.PRE_START_CHECK_WITH_RESOURCE_DATE,'%m/%d/%Y %H:%i:%s')PRE_START_CHECK_WITH_RESOURCE_DATE,"
		+ "PRE_START_CHECK_STATUS,BGV_PRESTART_COLOR , "
		+ "datediff(curdate(),Bgv.PRE_START_CHECK_WITH_RESOURCE_DATE) no_of_days_pending"
		+ " from mydb.bgv where PRE_START_CHECK_WITH_PMO='initiated'"
		+ " and PRE_START_CHECK_WITH_CENTRAL_BGV='initiated'"
		+ " and PRE_START_CHECK_WITH_RESOURCE='Y'"
			
		+ " and PRE_START_CHECK_STATUS='completed'"
		+ " and  ACTIVEFLAG_PRECHECK='y' and bgv.GPN_STATUS='NA' and REQUESTED_BY=";
public final String preCheckPmoManager_cntd = " order by Bgv.PRE_START_CHECK_WITH_RESOURCE_DATE";

public final String postCheckPending_manager = "select sap_id,emp_first_name,project_name,ou_code,"

		+ "date_format(Bgv.PRE_START_CHECK_COMP_DATE,'%m/%d/%Y %H:%i:%s')PRE_START_CHECK_COMP_DATE,"
		+ "PRE_START_CHECK_STATUS,BGV_PRESTART_COLOR , "
		+ "datediff(curdate(),Bgv.PRE_START_CHECK_COMP_DATE) no_of_days_pending "
		+ " from mydb.bgv  where PRE_START_CHECK_WITH_PMO='initiated'"
		+ " and PRE_START_CHECK_WITH_CENTRAL_BGV='initiated'"			
		+ " and PRE_START_CHECK_WITH_RESOURCE='Y'"
		
		+ " and PRE_START_CHECK_STATUS='completed'"
		+ " and ACTIVEFLAG_PRECHECK='N'"
		+ " and BGV_Status='INITIATED' and REQUESTED_BY=";
public final String postCheckPending_manager_cntd = " order by Bgv.PRE_START_CHECK_COMP_DATE";

public final String postCheckcompleted_manager = "select sap_id,emp_first_name,project_name,ou_code,"

		+ "date_format(Bgv.BGV_POST_CHECK_COMPLETED_DATE,'%m/%d/%Y %H:%i:%s')BGV_POST_CHECK_COMPLETED_DATE,"
		
		+ "BGV_FINAL_REPORT_COLOUR "
		+ " from mydb.bgv  where PRE_START_CHECK_WITH_PMO='initiated'"
		+ " and PRE_START_CHECK_WITH_CENTRAL_BGV='initiated'"			
		+ " and PRE_START_CHECK_WITH_RESOURCE='Y'"
	
		+ " and PRE_START_CHECK_STATUS='completed'"
		+ " and BGV_FINAL_REPORT_COLOUR='GREEN'"
		+ " and BGV_Status='COMPLETED' and REQUESTED_BY=";


public final String bgvcompleteddetailsfordownload = "SELECT SAP_ID,EMP_FIRST_NAME,PROJECT_CODE,PROJECT_NAME,"
		+ " ONSHORE_OFFSHORE,LOCATION,REGION,COUNTRY,BGV_TYPE,"
		+ " date_format(Bgv.PRE_START_CHECK_WITH_PMO_DATE,'%m/%d/%Y %H:%i:%s')PRE_START_CHECK_WITH_PMO_DATE,"
        + " date_format(Bgv.PRE_START_CHECK_COMP_DATE,'%m/%d/%Y %H:%i:%s')PRE_START_CHECK_COMP_DATE,"
        + " BGV_PRESTART_COLOR,"
        + " date_format(Bgv.BGV_POST_CHECK_COMPLETED_DATE,'%m/%d/%Y %H:%i:%s')BGV_POST_CHECK_COMPLETED_DATE,"
        + " BGV_FINAL_REPORT_COLOUR,BGV_Status FROM mydb.bgv where bgv.BGV_Status='completed';";

}
  



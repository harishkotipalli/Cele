package com.hcl.pmoautomation.bgv.model;

public class PmoDashBoard {
	private String pendingWithPmo;
	private String pendingWithCentralBgv;
	private String pendingWithVendor;
	private String pendingWithResource;
	private String resourcePreCheckPending;
	private String precheckCompleted;
	private String postcheckCompleted;
	private String postcheckpending;
	private String count;
	public String getPendingWithPmo() {
		return pendingWithPmo;
	}
	public void setPendingWithPmo(String pendingWithPmo) {
		this.pendingWithPmo = pendingWithPmo;
	}
	public String getPendingWithCentralBgv() {
		return pendingWithCentralBgv;
	}
	public void setPendingWithCentralBgv(String pendingWithCentralBgv) {
		this.pendingWithCentralBgv = pendingWithCentralBgv;
	}
	public String getPendingWithVendor() {
		return pendingWithVendor;
	}
	public void setPendingWithVendor(String pendingWithVendor) {
		this.pendingWithVendor = pendingWithVendor;
	}
	public String getPendingWithResource() {
		return pendingWithResource;
	}
	public void setPendingWithResource(String pendingWithResource) {
		this.pendingWithResource = pendingWithResource;
	}
	public String getResourcePreCheckPending() {
		return resourcePreCheckPending;
	}
	public void setResourcePreCheckPending(String resourcePreCheckPending) {
		this.resourcePreCheckPending = resourcePreCheckPending;
	}
	public String getPrecheckCompleted() {
		return precheckCompleted;
	}
	public void setPrecheckCompleted(String precheckCompleted) {
		this.precheckCompleted = precheckCompleted;
	}
	public String getCount() {
		return count;
	}
	public void setCount(String count) {
		this.count = count;
	}
	
	public String getPostcheckCompleted() {
		return postcheckCompleted;
	}
	public void setPostcheckCompleted(String postcheckCompleted) {
		this.postcheckCompleted = postcheckCompleted;
	}
	
	public String getPostcheckpending() {
		return postcheckpending;
	}
	public void setPostcheckpending(String postcheckpending) {
		this.postcheckpending = postcheckpending;
	}
	@Override
	public String toString() {
		return "PmoDashBoard [pendingWithPmo=" + pendingWithPmo + ", pendingWithCentralBgv=" + pendingWithCentralBgv
				+ ", pendingWithVendor=" + pendingWithVendor + ", pendingWithResource=" + pendingWithResource
				+ ", resourcePreCheckPending=" + resourcePreCheckPending + ", precheckCompleted=" + precheckCompleted
				+ ", postcheckCompleted=" + postcheckCompleted + ", postcheckpending=" + postcheckpending + ", count="
				+ count + "]";
	}
	
	

}

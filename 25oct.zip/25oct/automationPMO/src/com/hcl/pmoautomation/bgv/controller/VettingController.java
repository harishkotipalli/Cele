package com.hcl.pmoautomation.bgv.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.hcl.pmoautomation.bgv.dao.DownloadPathDao;
import com.hcl.pmoautomation.bgv.model.Bgv;
import com.hcl.pmoautomation.bgv.model.DownloadPathvo;
import com.hcl.pmoautomation.bgv.model.EditVettingSheet;
import com.hcl.pmoautomation.bgv.model.ResourcePersonalDetails;
import com.hcl.pmoautomation.bgv.model.VettingSheet;
import com.hcl.pmoautomation.bgv.service.VettingServiceImpl;


@Controller
@RequestMapping(value = "pmoAutomation/VettingCont")
public class VettingController {
	/*@ExceptionHandler(Exception.class)
	public ModelAndView handleException(Exception ex, HttpServletRequest request, HttpServletResponse response) {
	    ModelAndView modelAndView = new ModelAndView();
	    modelAndView.addObject("errorMessage", ex.getMessage());
	    modelAndView.addObject("errorDetails", ExceptionUtils.getStackTrace(ex));
	    modelAndView.setViewName("Login/Error");

	    return modelAndView;
	}*/
	@Autowired
	JdbcTemplate jdbcTemplate;

	// VettingServiceI vettingService;

	@RequestMapping(value ="/getVettingSheet.php", method = {RequestMethod.GET,RequestMethod.POST }) 
	
	public ModelAndView getVetttingSheet(@RequestParam("id") int ras_id,
			@RequestParam("sap_id") int sap_id, HttpServletRequest req) throws Exception  {

		VettingSheet vettingSheet = (new VettingServiceImpl()).getVetting(
				ras_id, sap_id, jdbcTemplate);
		String Dupath=vettingSheet.getDuPath();
		System.out.println("dupath----"+ras_id);
		HttpSession session = req.getSession();
        session.setAttribute("rasIDforreloadgetvetting", ras_id);
        session.setAttribute("sapIDforreloadgetvetting", sap_id);
		req.setAttribute("DUPATH", Dupath);
		System.out.println(vettingSheet.getFirst_Name());
		System.out.println(vettingSheet.getRas_id());
        req.getSession().setAttribute("sap_id",sap_id);
        req.getSession().setAttribute("ras_id",ras_id);
        ModelAndView modelAndView = new ModelAndView("Bgv/ras_vettingsheet");
		// modelAndView.
		Bgv bgv = new Bgv();
		bgv.setVettingSheet(vettingSheet);
			System.out.println(bgv);
		modelAndView.addObject("vettingSheet1", bgv);

		return modelAndView;

	}
	@RequestMapping(value ="/againgetVetttingSheet.php", method = {RequestMethod.GET,RequestMethod.POST }) 
	public ModelAndView againgetVetttingSheet( HttpServletRequest req) throws Exception  {
		 int reloadpagerasid=(int) req.getSession().getAttribute("rasIDforreloadgetvetting");
		 int reloadpagesapid=(int) req.getSession().getAttribute("sapIDforreloadgetvetting");
		 VettingSheet vettingSheet = (new VettingServiceImpl()).getVetting(
				reloadpagerasid, reloadpagesapid, jdbcTemplate);
		String Dupath=vettingSheet.getDuPath();
		System.out.println("dupath----"+reloadpagerasid);
		
		req.setAttribute("DUPATH", Dupath);
		System.out.println(vettingSheet.getFirst_Name());
		System.out.println(vettingSheet.getRas_id());
        req.getSession().setAttribute("sap_id",reloadpagesapid);
        req.getSession().setAttribute("ras_id",reloadpagerasid);
        ModelAndView modelAndView = new ModelAndView("Bgv/ras_vettingsheet");
		// modelAndView.
		Bgv bgv = new Bgv();
		bgv.setVettingSheet(vettingSheet);
			System.out.println(bgv);
		modelAndView.addObject("vettingSheet1", bgv);

		return modelAndView;

	}
	
	@RequestMapping(value = "/deleteDUmailPath.php")
	public String deleteDUmailPath(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String sapID=request.getParameter("deletesapforuploadDU");
		int deletepathusingsap=Integer.parseInt(sapID);
		System.out.println("dellllllllll "+deletepathusingsap);
		jdbcTemplate.update("update mydb.ras set ras.Upload_Path_BGV_DU= NULL where ras.SAPCODE="+deletepathusingsap);
		
		return "redirect:../../pmoAutomation/VettingCont/againgetVetttingSheet.php";
		
	}
	
	@RequestMapping(value = "/deleteDUmailPathInternal.php")
	public String deleteDUmailPathInternal(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String sapID=request.getParameter("deletesapforuploadDU");
	
		System.out.println("dellllllllll "+sapID);
		jdbcTemplate.update("update mydb.uniqueid_internal_resouces set uniqueid_internal_resouces.Du_path= NULL where uniqueid_internal_resouces.Unique_Id='"+sapID+"'");
		
		return "redirect:../../pmoAutomation/Bgv/internalResourceVettingreload.php";
		
	}
	
	@RequestMapping(value="/getEditVettingSheet.php",method = {RequestMethod.GET,RequestMethod.POST })
	public ModelAndView getEditVettingSheet(@RequestParam("bgvId") int bgv_id,
			@RequestParam("sapId") int sap_id, HttpServletRequest req,HttpServletResponse rep)  {
		EditVettingSheet editVettingSheet =(new VettingServiceImpl().getEditVettingSheet(sap_id, jdbcTemplate));
		System.out.println(sap_id+"this is our resource     ssssaaaaappppppiiiiiiidddddddddddddddddddddddddd"+sap_id);
		req.getSession().setAttribute("sap_id", sap_id);
		
		//req.getSession().setAttribute("bgv_id", bgv_id);
		ModelAndView modelAndView = new ModelAndView("Bgv/EditVettingSheet"); 
		Bgv bgv = new Bgv();
		bgv.setEditVettingSheet(editVettingSheet);
		System.out.println(bgv);
		modelAndView.addObject("EditVettingSheet1",bgv);
	return modelAndView;
		
	}
/*	@RequestMapping(value="getEditVettingSheet.php", method=RequestMethod.POST)
	public ModelAndView getEditVettingSheet(@RequestParam("bgvId") int bgv_id,
			@RequestParam("sapId") int sap_id, HttpServletRequest req,HttpServletResponse rep)  {
		EditVettingSheet editVettingSheet =(new VettingServiceImpl().getEditVettingSheet(sap_id, jdbcTemplate));
		req.getSession().setAttribute("sap_id", sap_id);
		ModelAndView modelAndView = new ModelAndView("Bgv/EditVettingSheet"); 
		Bgv bgv = new Bgv();
		bgv.setEditVettingSheet(editVettingSheet);
		System.out.println(bgv);
		modelAndView.addObject("EditVettingSheet",bgv);
		
		
		
		
		return modelAndView;
	}
	*/

	@RequestMapping("/getAllYetToJoinVettingSheet.php")
	public ModelAndView getVettingSheetForYetTojoin(@RequestParam("id") int id) {
		
		VettingSheet vettingSheet = (new VettingServiceImpl()).getVetting(
				id, jdbcTemplate);
		
		ModelAndView modelAndView = new ModelAndView("Bgv/Yet_To_Joinee");
		
		/*System.out.println("yet to join controller is working fine!!!!!!!!!!!"
				+ id);
		System.out.println(id);*/
		Bgv bgv = new Bgv();
		bgv.setVettingSheet(vettingSheet);
			System.out.println(bgv);
		modelAndView.addObject("vettingSheet1", bgv);

		return modelAndView;

	}
	
	@RequestMapping(value = "/uploadBgvYTJ.php")
	public String uploadBgvYTJ(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String uniqueID=request.getParameter("searchDUuniqueYTJ");
		String uniqueID1=request.getParameter("quantita");
		String uniqueID2=request.getParameter("projectname");
		String uniqueID3=request.getParameter("projectcode");
		String uniqueID4=request.getParameter("sapid");
		
		System.out.println(" hhh "+uniqueID3 +"rrrrrrrrr" +uniqueID4);
				//int sapIDfrmVettingSheet=Integer.parseInt(sapID);
				HttpSession session = request.getSession();
		        session.setAttribute("uniqueYTJId", uniqueID);
		        session.setAttribute("uniquename", uniqueID1);
		        session.setAttribute("projectName", uniqueID2);
		        session.setAttribute("projectCode", uniqueID3);
		        session.setAttribute("SAPid", uniqueID4);
		        
		return "Bgv/DUuploadYTJ";
		
	}
	@RequestMapping(value = "TPuploadBgvYTJ.php")
	public String uploadtpBgvYTJ(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String uniqueID=request.getParameter("searchTPuniqueYTJ");
				//int sapIDfrmVettingSheet=Integer.parseInt(sapID);
				HttpSession session = request.getSession();
		        session.setAttribute("TPuniqueYTJId", uniqueID);
		return "Bgv/TPuploadYTJ";
		
	}
	@RequestMapping(value = "/bgvDUconYTJ.php", method = {RequestMethod.POST,RequestMethod.GET})
	public void DUUpload(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		System.out.println("hi iam in controller DU");

		request.setAttribute("fileTypepdfDUYTJ", "pdfuploadDUYTJ");
		request.getRequestDispatcher("/fileUploadbgv.bgvuploadDUYTJ").forward(request,
				response);
	}
	@RequestMapping(value = "/bgvTPconYTJ.php", method = {RequestMethod.POST,RequestMethod.GET})
	public void TpUploadytj(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		System.out.println("hi iam in controller DU");

		request.setAttribute("fileTypepdfTPYTJ", "pdfuploadTPYTJ");
		request.getRequestDispatcher("/fileUploadbgv.bgvuploadTPYTJ").forward(request,
				response);
	}
	@RequestMapping(value = "/uploadpageDUYTJ.php")
	public void uploadpageDU(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter out = response.getWriter();
		String sapid= (String) request.getSession().getAttribute("uniqueYTJId");

		 String finaluploadPathbgv=(String) request.getSession().getAttribute("finaluploadPathbgvDUYTJ");
		 if(finaluploadPathbgv!=null){
			 
		 
		    System.out.println("servlet sapbgv du"+sapid);
		    System.out.println("final path in controller bgv  du "+finaluploadPathbgv);
		    jdbcTemplate.update("update mydb.uniqueid_internal_resouces set uniqueid_internal_resouces.Du_path='"+finaluploadPathbgv+"' where uniqueid_internal_resouces.Unique_Id='"+sapid+"'");

		    request.setAttribute("message", "File successfully uploaded!!!");

		 out.println("<html><body><script>window.alert('File successfully uploaded!!!');window.location='../../pmoAutomation/Bgv/internalResourceVettingreload.php';</script></body></html>");
		}
		else{
		out.println("<html><body><script>alert('Error in uploading File!!!');window.location= '../../pmoAutomation/VettingCont/uploadBgvYTJ.php';</script></body></html>");
		}

		//return " out.println("<html><body><script>alert('No Existing Document found');window.location= '../../pmoAutomation/Bgv/newBgvApproval.php';</script></body></html>");";
		}
	@RequestMapping(value = "/uploadpageTPYTJ.php")
	public void uploadpagetp(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException 
	{
	 	
	 
	 
	 PrintWriter out = response.getWriter();
	String sapid= (String) request.getSession().getAttribute("TPuniqueYTJId");

	 String finaluploadPathbgv=(String) request.getSession().getAttribute("finaluploadPathbgvTPYTJ");
	 if(finaluploadPathbgv!=null){
		 
	 
	    System.out.println("servlet sapbgv du"+sapid);
	    System.out.println("final path in controller bgv  du "+finaluploadPathbgv);
	    jdbcTemplate.update("update mydb.uniqueid_internal_resouces set uniqueid_internal_resouces.Tp_path='"+finaluploadPathbgv+"' where uniqueid_internal_resouces.Unique_Id='"+sapid+"'");

	    request.setAttribute("message", "File successfully uploaded!!!");

	 out.println("<html><body><script>window.alert('File successfully uploaded!!!');window.close();</script></body></html>");
	}
	else{
	out.println("<html><body><script>alert('Error in uploading File!!!');window.location= '../../pmoAutomation/VettingCont/TPuploadBgvYTJ.php';</script></body></html>");
	}
			
		//return " out.println("<html><body><script>alert('No Existing Document found');window.location= '../../pmoAutomation/Bgv/newBgvApproval.php';</script></body></html>");";
		}
	@RequestMapping(value = "/pdf.php")
	public void pdfdownloadDU(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		

		String sapid=request.getParameter("sear");

		System.out.println("controller sap from jsp  du  "+sapid);
		DownloadPathDao path=new DownloadPathDao();
		List<DownloadPathvo> downloadPathlink=path.DownloadPathDUYTJ(sapid, jdbcTemplate);
		System.out.println("pathhhhhhhh "+downloadPathlink);
		String[] array = new String[downloadPathlink.size()];
		int index = 0;
		for (Object value : downloadPathlink) {
			array[index] = String.valueOf( value );
		}
		
		HttpSession session = request.getSession();
	    session.setAttribute("downloadpathsessionDUYTJ", array[index]);
		// TODO:Spring Multipart enable it,Servlet disable it
		request.setAttribute("fileTypepdfdown", "pdfdownload");
		
		request.getRequestDispatcher("/fileUpload.downloadDUYTJ").forward(request,
				response);
		
	}
	@RequestMapping(value = "/pd.php")
	public void pdfdownloadTP(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		

		String sapid=request.getParameter("searc");
		
		System.out.println("controller sap from jsp  du  "+sapid);
		DownloadPathDao path=new DownloadPathDao();
		List<DownloadPathvo> downloadPathlink=path.DownloadPathTPYTJ(sapid, jdbcTemplate);
		
		String[] array = new String[downloadPathlink.size()];
		int index = 0;
		for (Object value : downloadPathlink) {
			array[index] = String.valueOf( value );
		}
		
		HttpSession session = request.getSession();
	    session.setAttribute("downloadpathsessionTPYTJ", array[index]);
		// TODO:Spring Multipart enable it,Servlet disable it
		request.setAttribute("fileTypepdfdown", "pdfdownload");
		
		request.getRequestDispatcher("/fileUpload.downloadTPytj").forward(request,
				response);
		
	}
	

}

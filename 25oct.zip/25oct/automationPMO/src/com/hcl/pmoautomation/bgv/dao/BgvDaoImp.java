package com.hcl.pmoautomation.bgv.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;

import com.hcl.pmoautomation.ot.dao.DatabaseQuery;

public class BgvDaoImp implements BgvDaoUp{

	
	
	@Override
	public boolean saveBGVDumpData(
			List<ArrayList<String>> readExcelAllDynamically,
			String BGVTABLENAME, JdbcTemplate jdbcTemplate) {

		// JdbcTemplate jdbcTemplate = new JdbcTemplate();
		int count = 0;
		boolean resultFlag = false;
		String[] returnData = null;
		List<Map<String, Object>> columnNames = getAllColumnNamesDynamically1(
				BGVTABLENAME, jdbcTemplate);

		StringBuilder sqlQuery = new StringBuilder();
		sqlQuery = sqlQuery.append("call BGV"  + "(");
System.out.println("Dao layr   "+sqlQuery);
		/*for (Map columnMapRowData : columnNames) {
			String tempData = (String) columnMapRowData.get("column_name");

			if (count == columnNames.size() - 1) {
				sqlQuery.append("`" + tempData.trim() + "`) values (");//`,`MODIFIED_DATE`
				break;
			}
			sqlQuery.append("`" + tempData.trim() + "`,");

			count++;
		}*/

		// For Adding the Values
		count = 0;
		for (Map columnMapRowData : columnNames) {

			if (count == columnNames.size() - 1) {
				sqlQuery.append("?" + ");");
				break;
			}
			sqlQuery.append("?" + ",");

			count++;
		}
		//
	
		// final Object[] objects =
		// setAllDataDynamically(readExcelAllDynamically,
		// columnNames);
		final List<Object[]> objects2 = setAllDataDynamically1(
				readExcelAllDynamically, columnNames);
		/*for (ArrayList<String> ps : readExcelAllDynamically) {
		
		}
		for (Object[] objects : objects2) {
			System.out.println(Arrays.toString(objects));
		}*/
		
		final List<String> columnDataTypes = new ArrayList<String>();
		// System.out.println(objects2.size() + "SOMETHING");

		for (Map map : columnNames) {
			columnDataTypes.add((String) map.get("COLUMN_DATATYPE"));
		}
		try {
			// resultFlag= jdbcTemplate.update(
			// sqlQuery.toString(),
			// setAllDataDynamically(readExcelAllDynamically,
			// columnNames))>0?true:false;

			resultFlag = (jdbcTemplate.batchUpdate(sqlQuery.toString(),
					new BatchPreparedStatementSetter() {

						@Override
						public void setValues(java.sql.PreparedStatement ps,
								int j) throws SQLException {

							Object[] objects = objects2.get(j);

							
							ps.setInt(1, (int) objects[0]);
							ps.setString(2, (String) objects[1]);
							ps.setString(3, (String) objects[2]);
							ps.setString(4, (String) objects[3]);
							
							if (!(objects[4] == null)) {
								ps.setDate(5, new java.sql.Date(
										((Date) objects[4]).getTime()));
							}
							if ((objects[4] == null)) {
								ps.setDate(5, null);
							}
							ps.setString(6, (String) objects[5]);
							ps.setString(7, (String) objects[6]);
							ps.setString(8, (String) objects[7]);
							ps.setString(9, (String) objects[8]);
							ps.setString(10, (String) objects[9]);
							ps.setString(11, (String) objects[10]);
							ps.setString(12, (String) objects[11]);
							ps.setString(13, (String) objects[12]);
							ps.setString(14, (String) objects[13]);
							ps.setString(15, (String) objects[14]);
							ps.setString(16, (String) objects[15]);
							ps.setString(17, (String) objects[16]);
							ps.setString(18, (String) objects[17]);
							ps.setString(19, (String) objects[18]);
							ps.setInt(20, (int) objects[19]);
							ps.setString(21, (String) objects[20]);
							ps.setInt(22, (int) objects[21]);
							ps.setString(23, (String) objects[22]);
							ps.setString(24, (String) objects[23]);
							if (!(objects[24] == null)) {
								ps.setDate(25, new java.sql.Date(
										((Date) objects[24]).getTime()));
							}
							if ((objects[24] == null)) {
								ps.setDate(25, null);
							}
							if (!(objects[25] == null)) {
								ps.setDate(26, new java.sql.Date(
										((Date) objects[25]).getTime()));
							}
							if ((objects[25] == null)) {
								ps.setDate(26, null);
							}
							ps.setString(27, (String) objects[26]);
							ps.setString(28, (String) objects[27]);
							if (!(objects[28] == null)) {
								ps.setDate(29, new java.sql.Date(
										((Date) objects[28]).getTime()));
							}
							if ((objects[28] == null)) {
								ps.setDate(29, null);
							}
							ps.setString(30, (String) objects[29]);
							if (!(objects[30] == null)) {
								ps.setDate(31, new java.sql.Date(
										((Date) objects[30]).getTime()));
							}
							if ((objects[30] == null)) {
								ps.setDate(31, null);
							}
							ps.setString(32, (String) objects[31]);
							
							
							if (!(objects[32] == null)) {
								ps.setDate(33, new java.sql.Date(
										((Date) objects[32]).getTime()));
							}
							if ((objects[32] == null)) {
								ps.setDate(33, null);
							}
							ps.setString(34, (String) objects[33]);
							
							if (!(objects[34] == null)) {
								ps.setDate(35, new java.sql.Date(
										((Date) objects[34]).getTime()));
							}
							if ((objects[34] == null)) {
								ps.setDate(35, null);
							}
							
						}

						@Override
						public int getBatchSize() {

							return objects2.size();
						}
					})).length >0? true : false;

		} catch (Exception e) {
			
			e.printStackTrace();
		}

		// TODO:LOGIC TO SENT MAIL

		return resultFlag;

	}
	public List<Map<String, Object>> getAllColumnNamesDynamically1(
			String tableName, JdbcTemplate jdbcTemplate) {

		String queryToFetchColumns = DatabaseQuery.QUERY_FETCH_COLUMNS1
				+ tableName + DatabaseQuery.QUERY_FETCH_COLUMNS2;

		System.out.println(queryToFetchColumns);
		// jdbcTemplate=new JdbcTemplate();
		// System.out.println(getJdbcTemplate());
		return jdbcTemplate.queryForList(queryToFetchColumns);
	}
	
	@SuppressWarnings("deprecation")
	private List<Object[]> setAllDataDynamically1(
			
			List<ArrayList<String>> arrayLists,
			List<Map<String, Object>> columnNames) {
		List<Object[]> objects = new ArrayList<Object[]>();
		Object[] objectData = null;
		// ArrayList<String> excaliburData = arrayLists.get(0);
		// System.out.println(excaliburData);
		// System.out.println(arrayLists.size());
		int tempCount = 0;
		for (ArrayList<String> excaliburData : arrayLists) {
			objectData = new Object[columnNames.size()];
			for (Map columnMapRowData : columnNames) {
//				 System.out.println(columnMapRowData);
				 System.out.println(excaliburData);
				if (((String) columnMapRowData.get("column_datatype"))
						.equalsIgnoreCase("STRING")) {
					objectData[tempCount] = excaliburData.get(tempCount);
				}
				if (((String) columnMapRowData.get("column_datatype"))
						.equalsIgnoreCase("INT")) {
					if (!(excaliburData.get(tempCount) ==null)) {
						objectData[tempCount] = Integer.parseInt(excaliburData
								.get(tempCount));

					}
					if (excaliburData.get(tempCount) == null) {
						objectData[tempCount] = 0;
					}
				}
				if (((String) columnMapRowData.get("column_datatype"))
						.equalsIgnoreCase("Date")) {

					if (!(excaliburData.get(tempCount) == null)) {
						objectData[tempCount] = new Date(new java.util.Date(
								excaliburData.get(tempCount)).getTime());

					}

					if (excaliburData.get(tempCount) == null) {
						objectData[tempCount] = null;
					}
				}

				// System.out.println(objectData[tempCount]);
				tempCount++;

			}

			tempCount = 0;
			objects.add(objectData);

		}
		// System.out.println("Ending Setter");

		return objects;
	}
	

public List<Map<String, Object>> getAllColumnNamesDynamically(
		String tableName, JdbcTemplate jdbcTemplate) {

	String queryToFetchColumns = DatabaseQuery.QUERY_FETCH_COLUMNS1
			+ tableName + DatabaseQuery.QUERY_FETCH_COLUMNS2;

	System.out.println(queryToFetchColumns);
	// jdbcTemplate=new JdbcTemplate();
	// System.out.println(getJdbcTemplate());
	return jdbcTemplate.queryForList(queryToFetchColumns);
}

@SuppressWarnings("deprecation")
private List<Object[]> setAllDataDynamically(
		
		List<ArrayList<String>> arrayLists,
		List<Map<String, Object>> columnNames) {
	List<Object[]> objects = new ArrayList<Object[]>();
	Object[] objectData = null;
	// ArrayList<String> excaliburData = arrayLists.get(0);
	// System.out.println(excaliburData);
	// System.out.println(arrayLists.size());
	int tempCount = 0;
	for (ArrayList<String> excaliburData : arrayLists) {
		objectData = new Object[columnNames.size()];
		for (Map columnMapRowData : columnNames) {
//			 System.out.println(columnMapRowData);
			 System.out.println(excaliburData);
			if (((String) columnMapRowData.get("column_datatype"))
					.equalsIgnoreCase("STRING")) {
				objectData[tempCount] = excaliburData.get(tempCount);
			}
			if (((String) columnMapRowData.get("column_datatype"))
					.equalsIgnoreCase("INT")) {
				if (!(excaliburData.get(tempCount) == null)) {
					objectData[tempCount] = Integer.parseInt(excaliburData
							.get(tempCount));

				}
				if (excaliburData.get(tempCount) == null) {
					objectData[tempCount] = 0;
				}
			}
			if (((String) columnMapRowData.get("column_datatype"))
					.equalsIgnoreCase("Date")) {

				if (!(excaliburData.get(tempCount) == null)) {
					objectData[tempCount] = new Date(new java.util.Date(
							excaliburData.get(tempCount)).getTime());

				}

				if (excaliburData.get(tempCount) == null) {
					objectData[tempCount] = null;
				}
			}

			// System.out.println(objectData[tempCount]);
			tempCount++;

		}

		tempCount = 0;
		objects.add(objectData);

	}
	// System.out.println("Ending Setter");

	return objects;
}

@Override
public List<Object[]> getRASDataWithNOSRMapped(JdbcTemplate jdbcTemplate, String pmCode) {
	List<Object[]> rasActualDataForPMName=new ArrayList<Object[]>();
	List<Map<String, Object>> rasDataForPMName=jdbcTemplate.queryForList(DatabaseQuery.QUERY_TO_FETCH_RAS_HAVING_PM,new Object[]{Integer.parseInt(pmCode),Integer.parseInt(pmCode)});
	Object[] objects=null;
	
	for(Map<String,Object> ras:rasDataForPMName){
		
		objects=new Object[12];
		
		objects[0]=(int)ras.get("name");
		objects[1]=(String)ras.get("branch");
		/*objects[2]=(String)ras.get("BAND");
		objects[3]=(String)ras.get("FRESHER_LATERAL_TP");
		objects[4]=(String)ras.get("DESIG");
		objects[5]=(int)ras.get("REP_MGR_CODE");
		objects[6]=(String)ras.get("REP_MGR_NAME");
		objects[7]=(int)ras.get("TOTAL_EXPERIENCE");
		objects[8]=(String)ras.get("LOB_DESC");
		objects[9]=(String)ras.get("LOCATION");
		objects[10]=(String)ras.get("PROJECT_CODE");
		objects[11]=(String)ras.get("PROJECT_NAME");*/
		
		
		

		rasActualDataForPMName.add(objects);

		//RAS according to RAS Sheet
		//SRID -> ajax Primary Skill Secondary Skill
		
	}

			return rasActualDataForPMName;
	
	
}
@Override
public boolean saveSRRASMapping(JdbcTemplate jdbcTemplate, int sapCode, String srID) {
	// TODO Auto-generated method stub
	return false;
}

}

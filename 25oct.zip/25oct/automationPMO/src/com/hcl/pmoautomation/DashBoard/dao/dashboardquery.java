package com.hcl.pmoautomation.DashBoard.dao;

public interface dashboardquery {
	/*public String QUERY_TO_FETCH_dashboardquerygetdatacollection="select TASK_ID,TASK_NAME,TOTAL_HOURS,OWNER_NAME,REVIEWER_NAME,STATUS from mydb.kanban_dashboard where STATUS='DATA COLLECTION' and (REVIEWER_NAME='";
	public String QUERY_TO_FETCH_dashboardquerygetdatacollection_cntd=" or OWNER_NAME='";
	public String QUERY_TO_FETCH_dashboardquerygetdatacollectionview="select TASK_ID,TASK_NAME,TOTAL_HOURS,OWNER_NAME,REVIEWER_NAME,STATUS from mydb.kanban_dashboard where STATUS='DATA COLLECTION'";
	
	public String QUERY_TO_FETCH_dashboardquery_update="update mydb.kanban_dashboard  set kanban_dashboard.status='WORK IN PROGRESS' where kanban_dashboard.TASK_ID=";
	public String QUERY_TO_ActionID="select coalesce(max(kanban_dashboard.TASK_ID),0)+1 as task_id from mydb.kanban_dashboard;" ;
	public String QUERY_TO_FETCH_dashboardquery_delete= " update mydb.kanban_dashboard  set kanban_dashboard.status='DELETE' where kanban_dashboard.TASK_ID=";
	
	public String QUERY_TO_FETCH_dashboardquerygetworkinprogress="select TASK_ID,TASK_NAME,TOTAL_HOURS,OWNER_NAME,REVIEWER_NAME,STATUS from mydb.kanban_dashboard where STATUS='WORK IN PROGRESS'  and (REVIEWER_NAME='";
	public String QUERY_TO_FETCH_dashboardquerygetworkinprogressview="select TASK_ID,TASK_NAME,TOTAL_HOURS,OWNER_NAME,REVIEWER_NAME,STATUS from mydb.kanban_dashboard where STATUS='WORK IN PROGRESS'";
	
	public String QUERY_TO_FETCH_dashboardquery_updateworkinprogress="update mydb.kanban_dashboard  set kanban_dashboard.status='REVIEW' where kanban_dashboard.TASK_ID=";
	
	public String QUERY_TO_FETCH_dashboardquerygetreview="select TASK_ID,TASK_NAME,TOTAL_HOURS,OWNER_NAME,REVIEWER_NAME,STATUS from mydb.kanban_dashboard where STATUS='REVIEW' and (REVIEWER_NAME='";
	public String QUERY_TO_FETCH_dashboardquerygetreviewview="select TASK_ID,TASK_NAME,TOTAL_HOURS,OWNER_NAME,REVIEWER_NAME,STATUS from mydb.kanban_dashboard where STATUS='REVIEW'";
	
	public String QUERY_TO_FETCH_dashboardquery_deleteworkinprogress="update mydb.kanban_dashboard  set kanban_dashboard.status='DATA COLLECTION' where kanban_dashboard.TASK_ID=";

	public String 	QUERY_TO_FETCH_dashboardquery_updatereview="update mydb.kanban_dashboard  set kanban_dashboard.status='COMPLETE' where kanban_dashboard.TASK_ID=";

	public String 	QUERY_TO_FETCH_dashboardquerygetcomplete="select TASK_ID,TASK_NAME,TOTAL_HOURS,OWNER_NAME,REVIEWER_NAME,STATUS from mydb.kanban_dashboard where STATUS='COMPLETE' and (REVIEWER_NAME='";
	public String 	QUERY_TO_FETCH_dashboardquerygetcompleteview="select TASK_ID,TASK_NAME,TOTAL_HOURS,OWNER_NAME,REVIEWER_NAME,STATUS from mydb.kanban_dashboard where STATUS='COMPLETE'";

	public String 	QUERY_TO_FETCH_dashboardquery_deletereview="update mydb.kanban_dashboard  set kanban_dashboard.status='WORK IN PROGRESS' where kanban_dashboard.TASK_ID=";
	
	public String 	QUERY_TO_FETCH_dashboardquery_deletecomplete="update mydb.kanban_dashboard  set kanban_dashboard.status='REVIEW' where kanban_dashboard.TASK_ID=";
	
	public String QUERY_TO_FETCH_dashboardquery_updatecomplete= " update mydb.kanban_dashboard  set kanban_dashboard.status='CLOSED' where kanban_dashboard.TASK_ID= ";

	public String 	QUERY_TO_FETCH_myactivitycount= "select count(*) from mydb.kanban_dashboard where status NOT IN ('CLOSED','DELETE')" ;
	public String QUERY_TO_FETCH_LOGINNAMES_FOR_ADDACTIVITY="SELECT NAME FROM mydb.login where ROLE='emoaccess' or ROLE='admin' or ROLE='emoupdate'";
	public String QUERY_TO_FETCH_LOGINNAMES_FOR_Mail_trig_for_datacollection_righttick="select Hcl_Mail_Id from mydb.login where Name in('";
	public String QUERY_TO_FETCH_LOGINNAMES_FOR_Mail_trig_for_datacollection_righttick_cntd="' ,'";
	public String QUERY_TO_FETCH_getMailDetails="select * from mydb.kanban_dashboard where TASK_ID= ";
	*/
	
	public String QUERY_TO_FETCH_dashboardquerygetdatacollection="select Activity_Start_Date,TASK_ID,TASK_NAME,TOTAL_HOURS,OWNER_NAME,REVIEWER_NAME,STATUS,DataCollection_Comments from mydb.kanban_dashboard where STATUS='DATA COLLECTION' and (REVIEWER_NAME='";
	public String QUERY_TO_FETCH_dashboardquerygetdatacollection_cntd=" or OWNER_NAME='";
	public String QUERY_TO_FETCH_dashboardquerygetdatacollectionview="select Activity_Start_Date,TASK_ID,TASK_NAME,TOTAL_HOURS,OWNER_NAME,REVIEWER_NAME,STATUS from mydb.kanban_dashboard where STATUS='DATA COLLECTION'";
	
	public String QUERY_TO_FETCH_dashboardquery_update="update mydb.kanban_dashboard  set kanban_dashboard.status='WORK IN PROGRESS',kanban_dashboard.WorkinProgress_Comments='";
    public String QUERY_TO_FETCH_dashboardquery_update_cntd="', kanban_dashboard.Data_Collection_Tick_Date=current_timestamp() where kanban_dashboard.TASK_ID=";
	
	public String QUERY_TO_ActionID="select coalesce(max(kanban_dashboard.TASK_ID),0)+1 as task_id from mydb.kanban_dashboard;" ;
	public String QUERY_TO_FETCH_dashboardquery_delete= " update mydb.kanban_dashboard  set kanban_dashboard.status='DELETE',kanban_dashboard.Deleted_Comments='";
	public String QUERY_TO_FETCH_dashboardquery_delete_cntd= "', kanban_dashboard.Data_Collection_Wrong_Date=current_timestamp() where kanban_dashboard.TASK_ID=";
	
	public String QUERY_TO_FETCH_dashboardquerygetworkinprogress="select Activity_Start_Date,TASK_ID,TASK_NAME,TOTAL_HOURS,OWNER_NAME,REVIEWER_NAME,STATUS,WorkinProgress_Comments from mydb.kanban_dashboard where STATUS='WORK IN PROGRESS'  and (REVIEWER_NAME='";
	public String QUERY_TO_FETCH_dashboardquerygetworkinprogressview="select Activity_Start_Date,TASK_ID,TASK_NAME,TOTAL_HOURS,OWNER_NAME,REVIEWER_NAME,STATUS from mydb.kanban_dashboard where STATUS='WORK IN PROGRESS'";
	
	public String QUERY_TO_FETCH_dashboardquery_updateworkinprogress="update mydb.kanban_dashboard  set kanban_dashboard.status='REVIEW',kanban_dashboard.Review_Comments='";
	public String QUERY_TO_FETCH_dashboardquery_updateworkinprogress_cntd="', kanban_dashboard.Work_In_Progress_Tick_Date=current_timestamp() where kanban_dashboard.TASK_ID=";
	
	public String QUERY_TO_FETCH_dashboardquerygetreview=" select Activity_Start_Date,TASK_ID,TASK_NAME,TOTAL_HOURS,OWNER_NAME,REVIEWER_NAME,STATUS,Review_Comments from mydb.kanban_dashboard where STATUS='REVIEW' and (REVIEWER_NAME='";
	public String QUERY_TO_FETCH_dashboardquerygetreviewview="select Activity_Start_Date,TASK_ID,TASK_NAME,TOTAL_HOURS,OWNER_NAME,REVIEWER_NAME,STATUS from mydb.kanban_dashboard where STATUS='REVIEW'";
	
	public String QUERY_TO_FETCH_dashboardquery_deleteworkinprogress="update mydb.kanban_dashboard  set kanban_dashboard.status='DATA COLLECTION',kanban_dashboard.DataCollection_Comments='";
	public String QUERY_TO_FETCH_dashboardquery_deleteworkinprogress_cntd="', kanban_dashboard.Work_In_Progress_Wrong_Date=current_timestamp() where kanban_dashboard.TASK_ID=";

	public String 	QUERY_TO_FETCH_dashboardquery_updatereview="update mydb.kanban_dashboard  set kanban_dashboard.status='COMPLETE',kanban_dashboard.Complete_Comments='";
	public String 	QUERY_TO_FETCH_dashboardquery_updatereview_cntd="', kanban_dashboard.Review_Tick_Date=current_timestamp() where kanban_dashboard.TASK_ID=";

	public String 	QUERY_TO_FETCH_dashboardquerygetcomplete=" select Activity_Start_Date,TASK_ID,TASK_NAME,TOTAL_HOURS,OWNER_NAME,REVIEWER_NAME,STATUS,Complete_Comments from mydb.kanban_dashboard where STATUS='COMPLETE' and (REVIEWER_NAME='";
	public String 	QUERY_TO_FETCH_dashboardquerygetcompleteview="select Activity_Start_Date,TASK_ID,TASK_NAME,TOTAL_HOURS,OWNER_NAME,REVIEWER_NAME,STATUS from mydb.kanban_dashboard where STATUS='COMPLETE'";

	public String 	QUERY_TO_FETCH_dashboardquery_deletereview="update mydb.kanban_dashboard  set kanban_dashboard.status='WORK IN PROGRESS',kanban_dashboard.WorkinProgress_Comments='";
	public String 	QUERY_TO_FETCH_dashboardquery_deletereview_cntd="', kanban_dashboard.Review_Wrong_Date=current_timestamp() where kanban_dashboard.TASK_ID=";
	
	public String 	QUERY_TO_FETCH_dashboardquery_deletecomplete="update mydb.kanban_dashboard  set kanban_dashboard.status='REVIEW' ,kanban_dashboard.Review_Comments='"; 
	public String 	QUERY_TO_FETCH_dashboardquery_deletecomplete_cntd="', kanban_dashboard.Complete_Wrong_Date=current_timestamp() where kanban_dashboard.TASK_ID=";
	
	public String QUERY_TO_FETCH_dashboardquery_updatecomplete= " update mydb.kanban_dashboard  set kanban_dashboard.status='CLOSED',kanban_dashboard.Closed_Comments='";
	public String QUERY_TO_FETCH_dashboardquery_updatecomplete_cntd= "', kanban_dashboard.Complete_Tick_Date=current_timestamp() where kanban_dashboard.TASK_ID= ";

	public String 	QUERY_TO_FETCH_myactivitycount= "select count(*) from mydb.kanban_dashboard where status NOT IN ('CLOSED','DELETE')" ;
	public String QUERY_TO_FETCH_LOGINNAMES_FOR_ADDACTIVITY="SELECT NAME FROM mydb.login where ROLE='emoaccess' or ROLE='admin'";
	public String QUERY_TO_FETCH_LOGINNAMES_FOR_Mail_trig_for_datacollection_righttick="select Hcl_Mail_Id from mydb.login where Name in('";
	public String QUERY_TO_FETCH_LOGINNAMES_FOR_Mail_trig_for_datacollection_righttick_cntd="' ,'";
	public String QUERY_TO_FETCH_getMailDetails="select * from mydb.kanban_dashboard where TASK_ID= ";
	
	public String QUERY_TO_FETCH_dashboardqueryget_top_three_resources="select count(status),kanban_dashboard.OWNER_NAME from mydb.kanban_dashboard where kanban_dashboard.STATUS='CLOSED' group by kanban_dashboard.OWNER_NAME order by count(status) desc limit 3";
	
	
}

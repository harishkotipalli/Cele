package com.hcl.pmoautomation.DashBoard.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.hcl.pmoautomation.DashBoard.VO.KanBanDashboardvo;
import com.hcl.pmoautomation.DashBoard.VO.mailIdVO;




public class Dashboarddao {
	public List<KanBanDashboardvo> getdatacollection(String loginname, JdbcTemplate jdbcTemplate )
	{
		

		String sql=dashboardquery.QUERY_TO_FETCH_dashboardquerygetdatacollection+loginname+"'"+dashboardquery.QUERY_TO_FETCH_dashboardquerygetdatacollection_cntd+loginname+"')";
	//System.out.println("----------------"+sql);

		 List<KanBanDashboardvo> dashboardvo = jdbcTemplate.query(sql, new RowMapper<KanBanDashboardvo>() 

				 {
	@Override
	public KanBanDashboardvo mapRow(ResultSet rs, int rowNum) throws SQLException 
	{
		
				KanBanDashboardvo dab=new KanBanDashboardvo();
				
			
		    dab.setActionID(rs.getInt("TASK_ID"));
			dab.setTaskname(rs.getString("TASK_NAME"));
			dab.setTotalhours(rs.getString("TOTAL_HOURS"));
			
			
			dab.setOwnername(rs.getString("OWNER_NAME"));
			dab.setReviewername(rs.getString("REVIEWER_NAME"));
			dab.setStatus(rs.getString("STATUS"));
			dab.setComments(rs.getString("DataCollection_Comments"));
			dab.setActivity_start_date(rs.getTimestamp("activity_start_date"));
		
			
		
			
			return dab;
	
		
		
	}	 
	
});	
		 
return dashboardvo;

}
	public List<KanBanDashboardvo> topthreeresources( JdbcTemplate jdbcTemplate )
	{
		

		String sql=dashboardquery.QUERY_TO_FETCH_dashboardqueryget_top_three_resources;
	//System.out.println("----------------"+sql);

		 List<KanBanDashboardvo> dashboardvo = jdbcTemplate.query(sql, new RowMapper<KanBanDashboardvo>() 

				 {
	@Override
	public KanBanDashboardvo mapRow(ResultSet rs, int rowNum) throws SQLException 
	{
		
		KanBanDashboardvo dab=new KanBanDashboardvo();
			dab.setOwnername(rs.getString("OWNER_NAME"));
			dab.setCount(rs.getString("count(status)"));
		return dab;
	
		
		
	}	 
	
});	
		 
return dashboardvo;

}
	public List<KanBanDashboardvo> actid(JdbcTemplate jdbcTemplate) 
	{
		
	 	String sql = dashboardquery.QUERY_TO_ActionID;
		List<KanBanDashboardvo> listaa = jdbcTemplate.query(sql, new RowMapper<KanBanDashboardvo>() 
			 {
			@Override
			public KanBanDashboardvo mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				KanBanDashboardvo add= new KanBanDashboardvo();
				add.setActionID(rs.getInt("task_id"));
			return add;
			}
	  });
	    		 return listaa;
	    
	}
	public List<KanBanDashboardvo> loginnamedetails(JdbcTemplate jdbcTemplate) 
	{
		
	 	String sql = dashboardquery.QUERY_TO_FETCH_LOGINNAMES_FOR_ADDACTIVITY;
		List<KanBanDashboardvo> listaa = jdbcTemplate.query(sql, new RowMapper<KanBanDashboardvo>() 
			 {
			@Override
			public KanBanDashboardvo mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				KanBanDashboardvo add= new KanBanDashboardvo();
				add.setOwnername(rs.getString("NAME"));
			return add;
			}
	  });
	    		 return listaa;
	    
	}
	public List<KanBanDashboardvo> updatestatus(int taskid,JdbcTemplate jdbcTemplate )
	{
		

		String sql=dashboardquery.QUERY_TO_FETCH_dashboardquery_update+taskid;
	//System.out.println("----------------"+sql);

		 List<KanBanDashboardvo> dashboardvo = jdbcTemplate.query(sql, new RowMapper<KanBanDashboardvo>() 

				 {
	@Override
	public KanBanDashboardvo mapRow(ResultSet rs, int rowNum) throws SQLException 
	{
		
				KanBanDashboardvo dab=new KanBanDashboardvo();
				
			
		    dab.setActionID(rs.getInt("TASK_ID"));
			dab.setTaskname(rs.getString("TASK_NAME"));
			dab.setTotalhours(rs.getString("TOTAL_HOURS"));
			dab.setOwnername(rs.getString("OWNER_NAME"));
			dab.setReviewername(rs.getString("REVIEWER_NAME"));
			dab.setStatus(rs.getString("STATUS"));
			
		
			
		
			
			return dab;
	
		
		
	}	 
	
});	
		 
return dashboardvo;

}
	public List<KanBanDashboardvo> getworkinprogress(String loginname,JdbcTemplate jdbcTemplate )
	{
		

		String sql=dashboardquery.QUERY_TO_FETCH_dashboardquerygetworkinprogress+loginname+"'"+dashboardquery.QUERY_TO_FETCH_dashboardquerygetdatacollection_cntd+loginname+"')";
	//System.out.println("----------------"+sql);

		 List<KanBanDashboardvo> dashboardvo = jdbcTemplate.query(sql, new RowMapper<KanBanDashboardvo>() 

				 {
	@Override
	public KanBanDashboardvo mapRow(ResultSet rs, int rowNum) throws SQLException 
	{
		
				KanBanDashboardvo dabwork=new KanBanDashboardvo();
				
			
		    dabwork.setActionID(rs.getInt("TASK_ID"));
			dabwork.setTaskname(rs.getString("TASK_NAME"));
			dabwork.setTotalhours(rs.getString("TOTAL_HOURS"));
			
			//System.out.println("TASK_NAME");
			
			dabwork.setOwnername(rs.getString("OWNER_NAME"));
			dabwork.setReviewername(rs.getString("REVIEWER_NAME"));
			dabwork.setStatus(rs.getString("STATUS"));
			dabwork.setComments(rs.getString("WorkinProgress_Comments"));
			dabwork.setActivity_start_date(rs.getTimestamp("activity_start_date"));
		
			
			//System.out.println("STATUS");
			
			return dabwork;
	
		
		
	}	 
	
});	
		 
return dashboardvo;

}
	public List<KanBanDashboardvo> getreview(String loginname,JdbcTemplate jdbcTemplate )
	{
		

		String sql=dashboardquery.QUERY_TO_FETCH_dashboardquerygetreview+loginname+"'"+dashboardquery.QUERY_TO_FETCH_dashboardquerygetdatacollection_cntd+loginname+"')";
	//System.out.println("----------------"+sql);

		 List<KanBanDashboardvo> dashboardvo = jdbcTemplate.query(sql, new RowMapper<KanBanDashboardvo>() 

				 {
	@Override
	public KanBanDashboardvo mapRow(ResultSet rs, int rowNum) throws SQLException 
	{
		
				KanBanDashboardvo dabwork=new KanBanDashboardvo();
				
			
		    dabwork.setActionID(rs.getInt("TASK_ID"));
			dabwork.setTaskname(rs.getString("TASK_NAME"));
			dabwork.setTotalhours(rs.getString("TOTAL_HOURS"));
			
			//System.out.println("TASK_NAME");
			
			dabwork.setOwnername(rs.getString("OWNER_NAME"));
			dabwork.setReviewername(rs.getString("REVIEWER_NAME"));
			dabwork.setStatus(rs.getString("STATUS"));
			dabwork.setComments(rs.getString("Review_Comments"));
			dabwork.setActivity_start_date(rs.getTimestamp("activity_start_date"));
		
			
			//System.out.println("STATUS");
			
			return dabwork;
	
		
		
	}	 
	
});	
		 
return dashboardvo;

}
	public List<KanBanDashboardvo> getcomplete(String loginname,JdbcTemplate jdbcTemplate )
	{
		

		String sql=dashboardquery.QUERY_TO_FETCH_dashboardquerygetcomplete+loginname+"'"+dashboardquery.QUERY_TO_FETCH_dashboardquerygetdatacollection_cntd+loginname+"')";
	//System.out.println("----------------"+sql);

		 List<KanBanDashboardvo> dashboardvo = jdbcTemplate.query(sql, new RowMapper<KanBanDashboardvo>() 

				 {
	@Override
	public KanBanDashboardvo mapRow(ResultSet rs, int rowNum) throws SQLException 
	{
		
				KanBanDashboardvo dabwork=new KanBanDashboardvo();
				
			
		    dabwork.setActionID(rs.getInt("TASK_ID"));
			dabwork.setTaskname(rs.getString("TASK_NAME"));
			dabwork.setTotalhours(rs.getString("TOTAL_HOURS"));
			
			//System.out.println("TASK_NAME");
			
			dabwork.setOwnername(rs.getString("OWNER_NAME"));
			dabwork.setReviewername(rs.getString("REVIEWER_NAME"));
			dabwork.setStatus(rs.getString("STATUS"));
			dabwork.setComments(rs.getString("Complete_Comments"));
			dabwork.setActivity_start_date(rs.getTimestamp("activity_start_date"));
		
			
			//System.out.println("STATUS");
			
			return dabwork;
	
		
		
	}	 
	
});	
		 
return dashboardvo;

}
	public List<KanBanDashboardvo> getdatacollectionview( JdbcTemplate jdbcTemplate )
	{
		

		String sql=dashboardquery.QUERY_TO_FETCH_dashboardquerygetdatacollectionview;
	//System.out.println("----------------"+sql);

		 List<KanBanDashboardvo> dashboardvo = jdbcTemplate.query(sql, new RowMapper<KanBanDashboardvo>() 

				 {
	@Override
	public KanBanDashboardvo mapRow(ResultSet rs, int rowNum) throws SQLException 
	{
		
				KanBanDashboardvo dab=new KanBanDashboardvo();
				
			
		    dab.setActionID(rs.getInt("TASK_ID"));
			dab.setTaskname(rs.getString("TASK_NAME"));
			dab.setTotalhours(rs.getString("TOTAL_HOURS"));
			
			//System.out.println("TASK_NAME");
			
			dab.setOwnername(rs.getString("OWNER_NAME"));
			dab.setReviewername(rs.getString("REVIEWER_NAME"));
			dab.setStatus(rs.getString("STATUS"));
			dab.setActivity_start_date(rs.getTimestamp("activity_start_date"));
		
			
			//System.out.println("STATUS");
			
			return dab;
	
		
		
	}	 
	
});	
		 
return dashboardvo;

}
	public List<KanBanDashboardvo> getworkinprogressview( JdbcTemplate jdbcTemplate )
	{
		

		String sql=dashboardquery.QUERY_TO_FETCH_dashboardquerygetworkinprogressview;
	//System.out.println("----------------"+sql);

		 List<KanBanDashboardvo> dashboardvo = jdbcTemplate.query(sql, new RowMapper<KanBanDashboardvo>() 

				 {
	@Override
	public KanBanDashboardvo mapRow(ResultSet rs, int rowNum) throws SQLException 
	{
		
				KanBanDashboardvo dab=new KanBanDashboardvo();
				
			
		    dab.setActionID(rs.getInt("TASK_ID"));
			dab.setTaskname(rs.getString("TASK_NAME"));
			dab.setTotalhours(rs.getString("TOTAL_HOURS"));
			
			//System.out.println("TASK_NAME");
			
			dab.setOwnername(rs.getString("OWNER_NAME"));
			dab.setReviewername(rs.getString("REVIEWER_NAME"));
			dab.setStatus(rs.getString("STATUS"));
			dab.setActivity_start_date(rs.getTimestamp("activity_start_date"));
		
			
			//System.out.println("STATUS");
			
			return dab;
	
		
		
	}	 
	
});	
		 
return dashboardvo;

}
	public List<KanBanDashboardvo> getreviewview( JdbcTemplate jdbcTemplate )
	{
		

		String sql=dashboardquery.QUERY_TO_FETCH_dashboardquerygetreviewview;
	//System.out.println("----------------"+sql);

		 List<KanBanDashboardvo> dashboardvo = jdbcTemplate.query(sql, new RowMapper<KanBanDashboardvo>() 

				 {
	@Override
	public KanBanDashboardvo mapRow(ResultSet rs, int rowNum) throws SQLException 
	{
		
				KanBanDashboardvo dab=new KanBanDashboardvo();
				
			
		    dab.setActionID(rs.getInt("TASK_ID"));
			dab.setTaskname(rs.getString("TASK_NAME"));
			dab.setTotalhours(rs.getString("TOTAL_HOURS"));
			
			//System.out.println("TASK_NAME");
			
			dab.setOwnername(rs.getString("OWNER_NAME"));
			dab.setReviewername(rs.getString("REVIEWER_NAME"));
			dab.setStatus(rs.getString("STATUS"));
			dab.setActivity_start_date(rs.getTimestamp("activity_start_date"));
		
			
			//System.out.println("STATUS");
			
			return dab;
	
		
		
	}	 
	
});	
		 
return dashboardvo;

}
	public List<KanBanDashboardvo> getcompleteview( JdbcTemplate jdbcTemplate )
	{
		

		String sql=dashboardquery.QUERY_TO_FETCH_dashboardquerygetcompleteview;
	//System.out.println("----------------"+sql);

		 List<KanBanDashboardvo> dashboardvo = jdbcTemplate.query(sql, new RowMapper<KanBanDashboardvo>() 

				 {
	@Override
	public KanBanDashboardvo mapRow(ResultSet rs, int rowNum) throws SQLException 
	{
		
				KanBanDashboardvo dab=new KanBanDashboardvo();
				
			
		    dab.setActionID(rs.getInt("TASK_ID"));
			dab.setTaskname(rs.getString("TASK_NAME"));
			dab.setTotalhours(rs.getString("TOTAL_HOURS"));
			
			//System.out.println("TASK_NAME");
			
			dab.setOwnername(rs.getString("OWNER_NAME"));
			dab.setReviewername(rs.getString("REVIEWER_NAME"));
			dab.setStatus(rs.getString("STATUS"));
			dab.setActivity_start_date(rs.getTimestamp("activity_start_date"));
		
			
			//System.out.println("STATUS");
			
			return dab;
	
		
		
	}	 
	
});	
		 
return dashboardvo;

}
	public List<KanBanDashboardvo> getmyactivitycount( JdbcTemplate jdbcTemplate )
	{
		String sql = dashboardquery.QUERY_TO_FETCH_myactivitycount;
	
	 List<KanBanDashboardvo> myactivitycount = jdbcTemplate.query(sql, new RowMapper<KanBanDashboardvo>() 
				 {
			@Override
			public KanBanDashboardvo mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				KanBanDashboardvo count = new KanBanDashboardvo();
			
				count.setCount(rs.getString("count(*)"));
				//System.out.println("count(*)");
			
				return count;
			}
	 			  	
	    });//---------------new Object[]{year, month});
	   
		 return myactivitycount;
	}
	public List<KanBanDashboardvo> listoftemplatedatafordatacollection(String taskid, JdbcTemplate jdbcTemplate) {
		
		String sql =dashboardquery.QUERY_TO_FETCH_getMailDetails+taskid;
		

		 List<KanBanDashboardvo> maildetails = jdbcTemplate.query(sql, new RowMapper<KanBanDashboardvo>() 

				 {
	@Override
	public KanBanDashboardvo mapRow(ResultSet rs, int rowNum) throws SQLException 
	{
		KanBanDashboardvo mail = new KanBanDashboardvo();
			
	mail.setActionID(rs.getInt("TASK_ID"));
	mail.setTaskname(rs.getString("TASK_NAME"));
	mail.setOwnername(rs.getString("OWNER_NAME"));
	mail.setReviewername(rs.getString("REVIEWER_NAME"));
	mail.setTotalhours(rs.getString("TOTAL_HOURS"));
         
	    return mail;
	}

});
		
		
return maildetails;



}
	public List<mailIdVO> listofmailidsfordatacollection(String ownername,String reviwername, JdbcTemplate jdbcTemplate) {
		
		String sql =dashboardquery.QUERY_TO_FETCH_LOGINNAMES_FOR_Mail_trig_for_datacollection_righttick+ownername+dashboardquery.QUERY_TO_FETCH_LOGINNAMES_FOR_Mail_trig_for_datacollection_righttick_cntd+reviwername+"')";
		
System.out.println("mail data   "+sql);
		 List<mailIdVO> maildetails = jdbcTemplate.query(sql, new RowMapper<mailIdVO>() 

				 {
	@Override
	public mailIdVO mapRow(ResultSet rs, int rowNum) throws SQLException 
	{
		mailIdVO mailId = new mailIdVO();
			
	mailId.setHclmailId(rs.getString("Hcl_Mail_Id"));
	
         
	    return mailId;
	}

});
		
		
return maildetails;



}
	
		
	}
	


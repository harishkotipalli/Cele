package com.hcl.pmoautomation.DashBoard.VO;

import java.sql.Timestamp;

public class KanBanDashboardvo {
	private String taskid;
	private String taskname;
	private String totalhours;
	private String ownername;
	private String reviewername;
	private String comments;
	private String status;
	private int actionID;
	private String count;
	private Timestamp activity_start_date;
	private Timestamp data_collection_tick_date;
	
	private Timestamp data_collection_wrong_date;
	private Timestamp  work_in_progress_tick_date;
	private Timestamp  work_in_progress_wrong_date;
	private Timestamp review_tick_date;
	private Timestamp  review_wrong_date;
	private Timestamp  complete_tick_date;
	private Timestamp  complete_wrong_date;
	public String getTaskid() {
		return taskid;
	}
	public void setTaskid(String taskid) {
		this.taskid = taskid;
	}
	public String getTaskname() {
		return taskname;
	}
	public void setTaskname(String taskname) {
		this.taskname = taskname;
	}
	public String getTotalhours() {
		return totalhours;
	}
	public void setTotalhours(String totalhours) {
		this.totalhours = totalhours;
	}
	public String getOwnername() {
		return ownername;
	}
	public void setOwnername(String ownername) {
		this.ownername = ownername;
	}
	public String getReviewername() {
		return reviewername;
	}
	public void setReviewername(String reviewername) {
		this.reviewername = reviewername;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getActionID() {
		return actionID;
	}
	public void setActionID(int actionID) {
		this.actionID = actionID;
	}
	
	public String getCount() {
		return count;
	}
	public void setCount(String count) {
		this.count = count;
	}
	
	public Timestamp getActivity_start_date() {
		return activity_start_date;
	}
	public void setActivity_start_date(Timestamp activity_start_date) {
		this.activity_start_date = activity_start_date;
	}
	public Timestamp getData_collection_tick_date() {
		return data_collection_tick_date;
	}
	public void setData_collection_tick_date(Timestamp data_collection_tick_date) {
		this.data_collection_tick_date = data_collection_tick_date;
	}
	public Timestamp getData_collection_wrong_date() {
		return data_collection_wrong_date;
	}
	public void setData_collection_wrong_date(Timestamp data_collection_wrong_date) {
		this.data_collection_wrong_date = data_collection_wrong_date;
	}
	public Timestamp getWork_in_progress_tick_date() {
		return work_in_progress_tick_date;
	}
	public void setWork_in_progress_tick_date(Timestamp work_in_progress_tick_date) {
		this.work_in_progress_tick_date = work_in_progress_tick_date;
	}
	public Timestamp getWork_in_progress_wrong_date() {
		return work_in_progress_wrong_date;
	}
	public void setWork_in_progress_wrong_date(Timestamp work_in_progress_wrong_date) {
		this.work_in_progress_wrong_date = work_in_progress_wrong_date;
	}
	public Timestamp getReview_tick_date() {
		return review_tick_date;
	}
	public void setReview_tick_date(Timestamp review_tick_date) {
		this.review_tick_date = review_tick_date;
	}
	public Timestamp getReview_wrong_date() {
		return review_wrong_date;
	}
	public void setReview_wrong_date(Timestamp review_wrong_date) {
		this.review_wrong_date = review_wrong_date;
	}
	public Timestamp getComplete_tick_date() {
		return complete_tick_date;
	}
	public void setComplete_tick_date(Timestamp complete_tick_date) {
		this.complete_tick_date = complete_tick_date;
	}
	public Timestamp getComplete_wrong_date() {
		return complete_wrong_date;
	}
	public void setComplete_wrong_date(Timestamp complete_wrong_date) {
		this.complete_wrong_date = complete_wrong_date;
	}
	
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	@Override
	public String toString() {
		return "KanBanDashboardvo [taskid=" + taskid + ", taskname=" + taskname + ", totalhours=" + totalhours
				+ ", ownername=" + ownername + ", reviewername=" + reviewername + ", comments=" + comments + ", status="
				+ status + ", actionID=" + actionID + ", count=" + count + ", activity_start_date="
				+ activity_start_date + ", data_collection_tick_date=" + data_collection_tick_date
				+ ", data_collection_wrong_date=" + data_collection_wrong_date + ", work_in_progress_tick_date="
				+ work_in_progress_tick_date + ", work_in_progress_wrong_date=" + work_in_progress_wrong_date
				+ ", review_tick_date=" + review_tick_date + ", review_wrong_date=" + review_wrong_date
				+ ", complete_tick_date=" + complete_tick_date + ", complete_wrong_date=" + complete_wrong_date + "]";
	}
	
	
	
}
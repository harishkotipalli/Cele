package com.hcl.pmoautomation.DashBoard.VO;



public class mailIdVO {

	
	
private String hclmailId;

public String getHclmailId() {
	return hclmailId;
}

public void setHclmailId(String hclmailId) {
	this.hclmailId = hclmailId;
}

@Override
public String toString() {
	return hclmailId ;
}


}

package com.hcl.pmoautomation.DashBoard.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hcl.pmoautomation.DashBoard.VO.KanBanDashboardvo;
import com.hcl.pmoautomation.DashBoard.VO.mailIdVO;
import com.hcl.pmoautomation.DashBoard.dao.Dashboarddao;
import com.hcl.pmoautomation.DashBoard.dao.dashboardquery;
import com.hcl.pmoautomation.email.App;





@Controller
@RequestMapping(value =  "pmoAutomation/AdminRoleAccess")

public class KanbanDashboardController {
	@Autowired(required = true)
	JdbcTemplate jdbcTemplate;
	
	
	
	
	@RequestMapping(value="/dashBoardView1.php")
	public  String ViewDahboard1(HttpServletRequest request,HttpServletResponse response) {
try{
		Dashboarddao dao=new Dashboarddao();
	List<KanBanDashboardvo> actid=dao.actid(jdbcTemplate);
	List<KanBanDashboardvo> loginnamedropdown=dao.loginnamedetails(jdbcTemplate);
	String loginname=(String) request.getSession().getAttribute("LOGINNAME");
	request.setAttribute("actid",actid);
	request.setAttribute("loginname",loginname);
	request.setAttribute("loginnamedropdowndetails",loginnamedropdown);
}
catch(Exception e){
	return "forward:../../pmoAutomation/Login/errorPage.php";
}
		  return "KanBanDashBoard/AddKanBanActivity";
	}
		
	
	@RequestMapping(value="/Task.php",method = RequestMethod.POST )
	public  String Task(HttpServletRequest request,HttpServletResponse response) {
		
	
		try{
		String taskid=request.getParameter("taskid");
	 	String 	task=request.getParameter("taskname");
	 	String thours=request.getParameter("totalhours");
		
			String 	owner=request.getParameter("ownername");
			String 	reviewer=request.getParameter("Reviewername");
			
			String addQuery = "insert into mydb.kanban_dashboard(TASK_ID,TASK_NAME,TOTAL_HOURS,OWNER_NAME ,REVIEWER_NAME,ACTIVITY_START_DATE) values(?,?,?,?,?,current_timestamp())";
			this.jdbcTemplate.update(addQuery,  new Object[] {taskid,task,thours,owner,reviewer,});
	
		
			Dashboarddao dao=new Dashboarddao();
			App mailtrigger = new App();
			List<mailIdVO> mailIdformailtrig=dao.listofmailidsfordatacollection(owner, reviewer, jdbcTemplate);
			String[] array = new String[mailIdformailtrig.size()];
			System.out.println("two mails "+mailIdformailtrig);
			int index = 0;
			for (Object value : mailIdformailtrig) {
				array[index] = String.valueOf( value );
					 
		
				List<KanBanDashboardvo> initiatedatacollectiondetails=dao.listoftemplatedatafordatacollection(taskid, jdbcTemplate);
				
			
				mailtrigger.Mailtrigger("pmoappadmin_ou@hcl.com", array[index],  "Activity Added to your Bucket", "harish", "/mailtrigforaddingactivity.jsp", initiatedatacollectiondetails, null);

			
			}	
		
		}
		catch(Exception e){
			return "forward:../../pmoAutomation/Login/errorPage.php";
		}
		  return "redirect:../../pmoAutomation/AdminRoleAccess/getdatacollection.php";
		  
		
	}
	@RequestMapping(value="/getdatacollection.php")
	public String getdatacollection(HttpServletRequest request,HttpServletResponse response){
	 	
    	try{
    		
    		String loginname=(String) request.getSession().getAttribute("LOGINNAME");
    
    	
    	
    		Dashboarddao db=new Dashboarddao();
    		
    			List<KanBanDashboardvo> count=db.getmyactivitycount(jdbcTemplate);
    			
    			request.setAttribute("getmyactivitycount",count);
    
    			List<KanBanDashboardvo> topthreeclosed=db.topthreeresources(jdbcTemplate);
    			request.setAttribute("listoftopthreeresources",topthreeclosed);
              	boolean resultflagleaderboard=topthreeclosed.isEmpty();
        		if (resultflagleaderboard) {
        			request.setAttribute("recordsinleadershipboard", "No Records Found");

        		}
    			
    			
              	List<KanBanDashboardvo > data=db.getdatacollection(loginname, jdbcTemplate);
              	request.setAttribute("getdatacollection",data);
              	boolean resultflag=data.isEmpty();
        		if (resultflag) {
        			request.setAttribute("recordsindatacollection", "No Records Found in Data Collection");

        		}
              	
  	           List<KanBanDashboardvo > work=db.getworkinprogress(loginname, jdbcTemplate);
              	
             
              	
              	request.setAttribute("getdataworkinprogress",work);
            	boolean resultflagwork=work.isEmpty();
        		if (resultflagwork) {
        			request.setAttribute("recordsindataworkinprogress", "No Records Found in Work in Progress");

        		}
              	
              	List<KanBanDashboardvo > review=db.getreview(loginname,jdbcTemplate);
              	
              
              	
              	request.setAttribute("getreview",review);
              	boolean resultflagreview=review.isEmpty();
        		if (resultflagreview) {
        			request.setAttribute("recordsindatareview", "No Records Found in Review");

        		}
              	List<KanBanDashboardvo > complete=db.getcomplete(loginname, jdbcTemplate);
              	
             
              	
              	request.setAttribute("getcomplete",complete);
              	boolean resultflagcomplete=complete.isEmpty();
        		if (resultflagcomplete) {
        			request.setAttribute("recordsindatacomplete", "No Records Found in Complete");

        		}
    	}
    	catch (Exception e) 
    	{
    		return "forward:../../pmoAutomation/Login/errorPage.php";
    	}
    	
    	return "KanBanDashBoard/DashBoard";
    	
    	
    	}		
	@RequestMapping(value="/getActivityView.php")
	public String getActivityView(HttpServletRequest request,HttpServletResponse response){
	 	
    	try{
    		
    		
    
    	
    	
    		Dashboarddao db=new Dashboarddao();
    		
          
              	List<KanBanDashboardvo > dataview=db.getdatacollectionview(jdbcTemplate);
              	
             
              	
              	request.setAttribute("getdatacollectionview",dataview);
              	boolean resultflag=dataview.isEmpty();
        		if (resultflag) {
        			request.setAttribute("recordsindatacollectionview", "No Records Found in Data Collection");

        		}
              	
  	           List<KanBanDashboardvo > workview=db.getworkinprogressview(jdbcTemplate);
              	
              
              	
              	request.setAttribute("getdataworkinprogressview",workview);
              	boolean resultflagwork=workview.isEmpty();
        		if (resultflagwork) {
        			request.setAttribute("recordsindataworkinprogressview", "No Records Found in Work in Progress");

        		}
              	
              	List<KanBanDashboardvo > reviewview=db.getreviewview(jdbcTemplate);
              	
              	
              	
              	request.setAttribute("getreviewview",reviewview);
            	boolean resultflagreview=reviewview.isEmpty();
        		if (resultflagreview) {
        			request.setAttribute("recordsindatareviewview", "No Records Found in Review");

        		}
              	List<KanBanDashboardvo > completeview=db.getcompleteview( jdbcTemplate);
              	
           
              	
              	request.setAttribute("getcompleteview",completeview);
            	boolean resultflagcomplete=completeview.isEmpty();
        		if (resultflagcomplete) {
        			request.setAttribute("recordsindatacompleteview", "No Records Found in Complete");

        		}
    	}
    	catch (Exception e) 
    	{
    		return "forward:../../pmoAutomation/Login/errorPage.php";
    	}
    	
    	return "KanBanDashBoard/EMODashboardview";
    	
    	
    	}		
	@RequestMapping(value="/datacollection.php" ,params="datacollectiontick")
	public String updatestatus(HttpServletRequest request,HttpServletResponse response){
	 	
    	try{
    	
  	    	
  	    	String taskid =  request.getParameter("taskid");
  	    	String taskowner =  request.getParameter("taskownername");
  	    	String taskreviwer =  request.getParameter("taskreviwername");
  	    	String taskdatacollectioncomments =  request.getParameter("datacollectioncomments");
  	    	int tid = Integer.parseInt(taskid);
  	    	
  				jdbcTemplate.update(dashboardquery.QUERY_TO_FETCH_dashboardquery_update+taskdatacollectioncomments+dashboardquery.QUERY_TO_FETCH_dashboardquery_update_cntd+tid);
    	
  				
  				Dashboarddao dao=new Dashboarddao();
					App mailtrigger = new App();
					List<mailIdVO> mailIdformailtrig=dao.listofmailidsfordatacollection(taskowner, taskreviwer, jdbcTemplate);
					String[] array = new String[mailIdformailtrig.size()];
					System.out.println("two mails "+mailIdformailtrig);
					int index = 0;
					for (Object value : mailIdformailtrig) {
						array[index] = String.valueOf( value );
							 
				
						List<KanBanDashboardvo> initiatedatacollectiondetails=dao.listoftemplatedatafordatacollection(taskid, jdbcTemplate);
						
					
						mailtrigger.Mailtrigger("pmoappadmin_ou@hcl.com", array[index],  "Activity Moved to Work In Progress from Data Collection", "harish", "/mailtrigfordatacollectionrightclick.jsp", initiatedatacollectiondetails, null);

					
					}	
    	}
    	catch (Exception e) 
    	{
    		return "forward:../../pmoAutomation/Login/errorPage.php";
    	}
    	
    	return "forward:../../pmoAutomation/AdminRoleAccess/getdatacollection.php";
    	
    	
    	}
	@RequestMapping(value="/workinprogress.php",params="workinprogresstick")
	public String updateworkinprogress(HttpServletRequest request,HttpServletResponse response){
	 	
    	try{
    		
   
  	    	String taskid =  request.getParameter("taskid");
  	    	String taskowner =  request.getParameter("taskownername");
  	    	String taskreviwer =  request.getParameter("taskreviwername");
  	    	String taskworkinprogresscomments =  request.getParameter("workinprogresscomments");
  	    	int tid = Integer.parseInt(taskid);
  	    	
  				jdbcTemplate.update(dashboardquery.QUERY_TO_FETCH_dashboardquery_updateworkinprogress+taskworkinprogresscomments+dashboardquery.QUERY_TO_FETCH_dashboardquery_updateworkinprogress_cntd+tid);
    	Dashboarddao dao=new Dashboarddao();
  						App mailtrigger = new App();
  						List<mailIdVO> mailIdformailtrig=dao.listofmailidsfordatacollection(taskowner, taskreviwer, jdbcTemplate);
  						
  						String[] array = new String[mailIdformailtrig.size()];
  						int index = 0;
  						for (Object value : mailIdformailtrig) {
  							array[index] = String.valueOf( value );
  								 
  					
  							List<KanBanDashboardvo> initiatedatacollectiondetails=dao.listoftemplatedatafordatacollection(taskid, jdbcTemplate);
  							
  						
  							mailtrigger.Mailtrigger("pmoappadmin_ou@hcl.com", array[index],  "Activity Moved to Review from Work In Progress", "harish", "/mailtrigforworkinprogressrightclick.jsp", initiatedatacollectiondetails, null);

  						
  						}
  	    	
    	}
    	catch (Exception e) 
    	{
    		return "forward:../../pmoAutomation/Login/errorPage.php";
    	}
    	
    	return "forward:../../pmoAutomation/AdminRoleAccess/getdatacollection.php";
    	
    	
    	}
	@RequestMapping(value="/workinprogress.php",params="workinprogresswrong")
	public String deleteworkinprogress(HttpServletRequest request,HttpServletResponse response){
	 	
    	try{
    		
  
  	    	String taskid =  request.getParameter("taskid");
  	    	String taskowner =  request.getParameter("taskownername");
  	    	String taskreviwer =  request.getParameter("taskreviwername");
  	    	String taskworkinprogresscomments =  request.getParameter("workinprogresscomments");
  	    	int tid = Integer.parseInt(taskid);
  	    	
  				jdbcTemplate.update(dashboardquery.QUERY_TO_FETCH_dashboardquery_deleteworkinprogress+taskworkinprogresscomments+dashboardquery.QUERY_TO_FETCH_dashboardquery_deleteworkinprogress_cntd+tid);
    	Dashboarddao dao=new Dashboarddao();
  						App mailtrigger = new App();
  						List<mailIdVO> mailIdformailtrig=dao.listofmailidsfordatacollection(taskowner, taskreviwer, jdbcTemplate);
  						
  						String[] array = new String[mailIdformailtrig.size()];
  						int index = 0;
  						for (Object value : mailIdformailtrig) {
  							array[index] = String.valueOf( value );
  								 
  					
  							List<KanBanDashboardvo> initiatedatacollectiondetails=dao.listoftemplatedatafordatacollection(taskid, jdbcTemplate);
  							
  						
  							mailtrigger.Mailtrigger("pmoappadmin_ou@hcl.com", array[index],  "Activity Deleted from Work In Progress and moved to Data Collection", "harish", "/mailtrigforworkinprogresswrongclick.jsp", initiatedatacollectiondetails, null);

  						
  						}
    	}
    	catch (Exception e) 
    	{
    		return "forward:../../pmoAutomation/Login/errorPage.php";
    	}
    	
    	return "forward:../../pmoAutomation/AdminRoleAccess/getdatacollection.php";
    	
    	
    	}
	@RequestMapping(value="/review.php",params="reviewwrong")
	public String deleteReview(HttpServletRequest request,HttpServletResponse response){
	 	
    	try{
 
  	    	String taskid =  request.getParameter("taskid");
  	    	String taskowner =  request.getParameter("taskownername");
  	    	String taskreviwer =  request.getParameter("taskreviwername");
  	    	String taskreviewcomments =  request.getParameter("reviewcomments");
  	    	int tid = Integer.parseInt(taskid);
  	  
  				jdbcTemplate.update(dashboardquery.QUERY_TO_FETCH_dashboardquery_deletereview+taskreviewcomments+dashboardquery.QUERY_TO_FETCH_dashboardquery_deletereview_cntd+tid);
    	Dashboarddao dao=new Dashboarddao();
  						App mailtrigger = new App();
  						List<mailIdVO> mailIdformailtrig=dao.listofmailidsfordatacollection(taskowner, taskreviwer, jdbcTemplate);
  						
  						String[] array = new String[mailIdformailtrig.size()];
  						int index = 0;
  						for (Object value : mailIdformailtrig) {
  							array[index] = String.valueOf( value );
  								 
  					
  							List<KanBanDashboardvo> initiatedatacollectiondetails=dao.listoftemplatedatafordatacollection(taskid, jdbcTemplate);
  							
  						
  							mailtrigger.Mailtrigger("pmoappadmin_ou@hcl.com", array[index],  "Activity Deleted from Review and moved to Work In Progress", "harish", "/mailtrigforReviewwrongclick.jsp", initiatedatacollectiondetails, null);

  						
  						}
    	}
    	catch (Exception e) 
    	{
    		return "forward:../../pmoAutomation/Login/errorPage.php";
    	}
    	
    	return "forward:../../pmoAutomation/AdminRoleAccess/getdatacollection.php";
    	
    	
    	}
	@RequestMapping(value="/complete.php",params="completewrong")
	public String deleteComplete(HttpServletRequest request,HttpServletResponse response){
	 	
    	try{
    		

  	    	String taskid =  request.getParameter("taskid");
  	    	String taskowner =  request.getParameter("taskownername");
  	    	String taskreviwer =  request.getParameter("taskreviwername");
	    	String taskcompletecomments =  request.getParameter("completecomments");
  	    	int tid = Integer.parseInt(taskid);
  	    
  				jdbcTemplate.update(dashboardquery.QUERY_TO_FETCH_dashboardquery_deletecomplete+taskcompletecomments+dashboardquery.QUERY_TO_FETCH_dashboardquery_deletecomplete_cntd+tid);
    	Dashboarddao dao=new Dashboarddao();
  					App mailtrigger = new App();
  						List<mailIdVO> mailIdformailtrig=dao.listofmailidsfordatacollection(taskowner, taskreviwer, jdbcTemplate);
  						
  						String[] array = new String[mailIdformailtrig.size()];
  						int index = 0;
  						for (Object value : mailIdformailtrig) {
  							array[index] = String.valueOf( value );
  								 
  					
  							List<KanBanDashboardvo> initiatedatacollectiondetails=dao.listoftemplatedatafordatacollection(taskid, jdbcTemplate);
  							
  						
  							mailtrigger.Mailtrigger("pmoappadmin_ou@hcl.com", array[index],  "Activity Deleted from Complete and moved to Review", "harish", "/mailtrigforcompletewrongclick.jsp", initiatedatacollectiondetails, null);

  						
  						}
    	}
    	catch (Exception e) 
    	{
    		return "forward:../../pmoAutomation/Login/errorPage.php";
    	}
    	
    	return "forward:../../pmoAutomation/AdminRoleAccess/getdatacollection.php";
    	
    	
    	}
	@RequestMapping(value="/review.php",params="reviewtick")
	public String updateReview(HttpServletRequest request,HttpServletResponse response){
	 	
    	try{
    		
    
  	    	String taskid =  request.getParameter("taskid");
  	    	String taskowner =  request.getParameter("taskownername");
  	    	String taskreviwer =  request.getParameter("taskreviwername");
  	    	String taskreviewcomments =  request.getParameter("reviewcomments");
  	    	int tid = Integer.parseInt(taskid);
  	    
  				jdbcTemplate.update(dashboardquery.QUERY_TO_FETCH_dashboardquery_updatereview+taskreviewcomments+dashboardquery.QUERY_TO_FETCH_dashboardquery_updatereview_cntd+tid);
    	Dashboarddao dao=new Dashboarddao();
  					App mailtrigger = new App();
  					List<mailIdVO> mailIdformailtrig=dao.listofmailidsfordatacollection(taskowner, taskreviwer, jdbcTemplate);
  					
  					String[] array = new String[mailIdformailtrig.size()];
  					int index = 0;
  					for (Object value : mailIdformailtrig) {
  						array[index] = String.valueOf( value );
  							 
  				
  						List<KanBanDashboardvo> initiatedatacollectiondetails=dao.listoftemplatedatafordatacollection(taskid, jdbcTemplate);
  						
  					
  						mailtrigger.Mailtrigger("pmoappadmin_ou@hcl.com", array[index],  "Activity Moved to Complete from Review", "harish", "/mailtrigforReviewrightclick.jsp", initiatedatacollectiondetails, null);

  					
  					}
  	    	
    	}
    	catch (Exception e) 
    	{
    		return "forward:../../pmoAutomation/Login/errorPage.php";
    	}
    	
    	return "forward:../../pmoAutomation/AdminRoleAccess/getdatacollection.php";
    	
    	
    	}
	@RequestMapping(value="/datacollection.php",params="datacollectionwrong")
	public String deletestatus(HttpServletRequest request,HttpServletResponse response){
	 	
    	try{
    	   	String taskid =  request.getParameter("taskid");
    	   	String taskowner =  request.getParameter("taskownername");
  	    	String taskreviwer =  request.getParameter("taskreviwername");
  	   	String taskdatacollectioncomments =  request.getParameter("datacollectioncomments");
	    	int tid = Integer.parseInt(taskid);
	 
		
          	jdbcTemplate.update(dashboardquery.QUERY_TO_FETCH_dashboardquery_delete+taskdatacollectioncomments+dashboardquery.QUERY_TO_FETCH_dashboardquery_delete_cntd+tid);
          	
        
              	Dashboarddao dao=new Dashboarddao();
            			App mailtrigger = new App();
            				List<mailIdVO> mailIdformailtrig=dao.listofmailidsfordatacollection(taskowner, taskreviwer, jdbcTemplate);
            				
            				String[] array = new String[mailIdformailtrig.size()];
            				int index = 0;
            				for (Object value : mailIdformailtrig) {
            					array[index] = String.valueOf( value );
            						 
            			
            					List<KanBanDashboardvo> initiatedatacollectiondetails=dao.listoftemplatedatafordatacollection(taskid, jdbcTemplate);
            					
            				
            					mailtrigger.Mailtrigger("pmoappadmin_ou@hcl.com", array[index],  "Activity Removed from Data Collection", "harish", "/mailtrigforcompleterightclick.jsp", initiatedatacollectiondetails, null);

            				
            				}
    	
    	}
    	catch (Exception e) 
    	{
    		return "forward:../../pmoAutomation/Login/errorPage.php";
    	}
    	
    	return "forward:../../pmoAutomation/AdminRoleAccess/getdatacollection.php";
    	
    	
    	}
	@RequestMapping(value="/complete.php",params="completetick")
	public String updatecomplete(HttpServletRequest request,HttpServletResponse response){
	 	
    	try{
    	   	String taskid =  request.getParameter("taskid");
    	   	String taskowner =  request.getParameter("taskownername");
  	    	String taskreviwer =  request.getParameter("taskreviwername");
  	  	String taskcompletecomments =  request.getParameter("completecomments");
	    	int tid = Integer.parseInt(taskid);
	    
		
          	jdbcTemplate.update(dashboardquery.QUERY_TO_FETCH_dashboardquery_updatecomplete+taskcompletecomments+dashboardquery.QUERY_TO_FETCH_dashboardquery_updatecomplete_cntd+tid);
          	
            
              	Dashboarddao dao=new Dashboarddao();
        		App mailtrigger = new App();
        				List<mailIdVO> mailIdformailtrig=dao.listofmailidsfordatacollection(taskowner, taskreviwer, jdbcTemplate);
        		
        				String[] array = new String[mailIdformailtrig.size()];
        				int index = 0;
        				for (Object value : mailIdformailtrig) {
        					array[index] = String.valueOf( value );
        						 
        			
        					List<KanBanDashboardvo> initiatedatacollectiondetails=dao.listoftemplatedatafordatacollection(taskid, jdbcTemplate);
        					
        				
        					mailtrigger.Mailtrigger("pmoappadmin_ou@hcl.com", array[index],  "Activity Deleted from Complete stage", "harish", "/mailtrigforCompleterightclick.jsp", initiatedatacollectiondetails, null);

        				
        				}
    	}
    	catch (Exception e) 
    	{
    		return "forward:../../pmoAutomation/Login/errorPage.php";
    	}
    	
    	return "forward:../../pmoAutomation/AdminRoleAccess/getdatacollection.php";
    	
    	
    	}
}

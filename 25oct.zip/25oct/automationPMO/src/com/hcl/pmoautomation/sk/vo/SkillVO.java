package com.hcl.pmoautomation.sk.vo;

public class SkillVO {
 String activeflag;

public String getActiveflag() {
	return activeflag;
}

public void setActiveflag(String activeflag) {
	this.activeflag = activeflag;
}

@Override
public String toString() {
	return activeflag ;
}
 
}

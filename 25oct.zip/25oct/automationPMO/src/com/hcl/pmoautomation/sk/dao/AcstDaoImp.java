package com.hcl.pmoautomation.sk.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;



public class AcstDaoImp implements AcstDao{

	
	
		@Override
		public boolean saveRASDumpData(
				List<ArrayList<String>> readExcelAllDynamically,
				String ACSTTABLENAME, JdbcTemplate jdbcTemplate) {

			// JdbcTemplate jdbcTemplate = new JdbcTemplate();
			int count = 0;
			boolean resultFlag = false;
			String[] returnData = null;
			List<Map<String, Object>> columnNames = getAllColumnNamesDynamically1(
					ACSTTABLENAME, jdbcTemplate);

			StringBuilder sqlQuery = new StringBuilder();
			sqlQuery = sqlQuery.append("call skill"  + "(");

			/*for (Map columnMapRowData : columnNames) {
				String tempData = (String) columnMapRowData.get("column_name");

				if (count == columnNames.size() - 1) {
					sqlQuery.append("`" + tempData.trim() + "`) values (");//`,`MODIFIED_DATE`
					break;
				}
				sqlQuery.append("`" + tempData.trim() + "`,");

				count++;
			}*/

			// For Adding the Values
			count = 0;
			for (Map columnMapRowData : columnNames) {

				if (count == columnNames.size() - 1) {
					sqlQuery.append("?" + ");");
					break;
				}
				sqlQuery.append("?" + ",");

				count++;
			}
			//
		
			// final Object[] objects =
			// setAllDataDynamically(readExcelAllDynamically,
			// columnNames);
			final List<Object[]> objects2 = setAllDataDynamically1(
					readExcelAllDynamically, columnNames);
			/*for (ArrayList<String> ps : readExcelAllDynamically) {
			
			}
			for (Object[] objects : objects2) {
				System.out.println(Arrays.toString(objects));
			}*/
			
			final List<String> columnDataTypes = new ArrayList<String>();
			// System.out.println(objects2.size() + "SOMETHING");

			for (Map map : columnNames) {
				columnDataTypes.add((String) map.get("COLUMN_DATATYPE"));
			}
			try {
				// resultFlag= jdbcTemplate.update(
				// sqlQuery.toString(),
				// setAllDataDynamically(readExcelAllDynamically,
				// columnNames))>0?true:false;

				resultFlag = (jdbcTemplate.batchUpdate(sqlQuery.toString(),
						new BatchPreparedStatementSetter() {

							@Override
							public void setValues(java.sql.PreparedStatement ps,
									int j) throws SQLException {

								Object[] objects = objects2.get(j);

								
								ps.setString(1, (String) objects[0]);
								ps.setString(2, (String) objects[1]);
								ps.setString(3, (String) objects[2]);
								ps.setString(4, (String) objects[3]);
								ps.setString(5, (String) objects[4]);
								ps.setInt(6, (int) objects[5]);
								ps.setString(7, (String) objects[6]);
								ps.setString(8, (String) objects[7]);
								ps.setString(9, (String) objects[8]);
								ps.setString(10, (String) objects[9]);
								ps.setInt(11, (int) objects[10]);
								ps.setInt(12, (int) objects[11]);
								ps.setInt(13, (int) objects[12]);
								ps.setInt(14, (int) objects[13]);
								/*ps.setString(13, (String) objects[12]);
								ps.setString(14, (String) objects[13]);
								ps.setString(15, (String) objects[14]);
								ps.setString(16, (String) objects[15]);
								ps.setString(17, (String) objects[16]);
								ps.setString(18, (String) objects[17]);
								ps.setString(19, (String) objects[18]);
								ps.setString(20, (String) objects[19]);
								ps.setString(21, (String) objects[20]);
								ps.setString(22, (String) objects[21]);
								
 								ps.setString(23, (String) objects[22]);
								
								ps.setString(24, (String) objects[23]);
								ps.setString(25, (String) objects[24]);
								ps.setString(26, (String) objects[25]);
								ps.setString(27, (String) objects[26]);
								ps.setString(28, (String) objects[27]);
								ps.setString(29, (String) objects[28]);
								ps.setString(30, (String) objects[29]);
								ps.setString(31, (String) objects[30]);
								ps.setString(32, (String) objects[31]);
								ps.setString(33, (String) objects[32]);
								ps.setString(34, (String) objects[33]);
								ps.setString(35, (String) objects[34]);
								ps.setString(36, (String) objects[35]);

								ps.setString(37, (String) objects[36]);
								ps.setString(38, (String) objects[37]);
								ps.setString(39, (String) objects[38]);
								ps.setString(40, (String) objects[39]);

								
								ps.setString(41, (String) objects[40]);
								ps.setString(42, (String) objects[41]);
								ps.setString(43, (String) objects[42]);
								ps.setString(44, (String) objects[43]);
								ps.setString(45, (String) objects[44]);
								ps.setString(46, (String) objects[45]);
								ps.setString(47, (String) objects[46]);
								ps.setString(48, (String) objects[47]);
								ps.setString(49, (String) objects[48]);
								ps.setString(50, (String) objects[49]);
								ps.setString(51, (String) objects[50]);
								ps.setString(52, (String) objects[51]);
								ps.setString(53, (String) objects[52]);
								ps.setString(54, (String) objects[53]);
								ps.setString(55, (String) objects[54]);
								ps.setString(56, (String) objects[55]);
								ps.setString(57, (String) objects[56]);
								ps.setString(58, (String) objects[57]);
								ps.setString(59, (String) objects[58]);
								ps.setString(60, (String) objects[59]);
								ps.setString(61, (String) objects[60]);
								ps.setString(62, (String) objects[61]);
								ps.setString(63, (String) objects[62]);
								*/
								
							}

							@Override
							public int getBatchSize() {

								return objects2.size();
							}
						})).length >0? true : false;

			} catch (Exception e) {
				
				e.printStackTrace();
			}

			// TODO:LOGIC TO SENT MAIL

			return resultFlag;

		}
		public List<Map<String, Object>> getAllColumnNamesDynamically1(
				String tableName, JdbcTemplate jdbcTemplate) {

			String queryToFetchColumns = DatabaseQuery.QUERY_FETCH_COLUMNS1
					+ tableName + DatabaseQuery.QUERY_FETCH_COLUMNS2;

			System.out.println(queryToFetchColumns);
			// jdbcTemplate=new JdbcTemplate();
			// System.out.println(getJdbcTemplate());
			return jdbcTemplate.queryForList(queryToFetchColumns);
		}
		
		@SuppressWarnings("deprecation")
		private List<Object[]> setAllDataDynamically1(
				
				List<ArrayList<String>> arrayLists,
				List<Map<String, Object>> columnNames) {
			List<Object[]> objects = new ArrayList<Object[]>();
			Object[] objectData = null;
			// ArrayList<String> excaliburData = arrayLists.get(0);
			// System.out.println(excaliburData);
			// System.out.println(arrayLists.size());
			int tempCount = 0;
			for (ArrayList<String> excaliburData : arrayLists) {
				objectData = new Object[columnNames.size()];
				for (Map columnMapRowData : columnNames) {
//					 System.out.println(columnMapRowData);
					 System.out.println(excaliburData);
					if (((String) columnMapRowData.get("column_datatype"))
							.equalsIgnoreCase("STRING")) {
						objectData[tempCount] = excaliburData.get(tempCount);
					}
					if (((String) columnMapRowData.get("column_datatype"))
							.equalsIgnoreCase("INT")) {
						if (!(excaliburData.get(tempCount) ==null)) {
							objectData[tempCount] = Integer.parseInt(excaliburData
									.get(tempCount));

						}
						if (excaliburData.get(tempCount) == null) {
							objectData[tempCount] = 0;
						}
					}
					if (((String) columnMapRowData.get("column_datatype"))
							.equalsIgnoreCase("Date")) {

						if (!(excaliburData.get(tempCount) == null)) {
							objectData[tempCount] = new Date(new java.util.Date(
									excaliburData.get(tempCount)).getTime());

						}

						if (excaliburData.get(tempCount) == null) {
							objectData[tempCount] = null;
						}
					}

					// System.out.println(objectData[tempCount]);
					tempCount++;

				}

				tempCount = 0;
				objects.add(objectData);

			}
			// System.out.println("Ending Setter");

			return objects;
		}
		
	
	public List<Map<String, Object>> getAllColumnNamesDynamically(
			String tableName, JdbcTemplate jdbcTemplate) {

		String queryToFetchColumns = DatabaseQuery.QUERY_FETCH_COLUMNS1
				+ tableName + DatabaseQuery.QUERY_FETCH_COLUMNS2;

		System.out.println(queryToFetchColumns);
		// jdbcTemplate=new JdbcTemplate();
		// System.out.println(getJdbcTemplate());
		return jdbcTemplate.queryForList(queryToFetchColumns);
	}
	
	@SuppressWarnings("deprecation")
	private List<Object[]> setAllDataDynamically(
			
			List<ArrayList<String>> arrayLists,
			List<Map<String, Object>> columnNames) {
		List<Object[]> objects = new ArrayList<Object[]>();
		Object[] objectData = null;
		// ArrayList<String> excaliburData = arrayLists.get(0);
		// System.out.println(excaliburData);
		// System.out.println(arrayLists.size());
		int tempCount = 0;
		for (ArrayList<String> excaliburData : arrayLists) {
			objectData = new Object[columnNames.size()];
			for (Map columnMapRowData : columnNames) {
//				 System.out.println(columnMapRowData);
				 System.out.println(excaliburData);
				if (((String) columnMapRowData.get("column_datatype"))
						.equalsIgnoreCase("STRING")) {
					objectData[tempCount] = excaliburData.get(tempCount);
				}
				if (((String) columnMapRowData.get("column_datatype"))
						.equalsIgnoreCase("INT")) {
					if (!(excaliburData.get(tempCount) == null)) {
						objectData[tempCount] = Integer.parseInt(excaliburData
								.get(tempCount));

					}
					if (excaliburData.get(tempCount) == null) {
						objectData[tempCount] = 0;
					}
				}
				if (((String) columnMapRowData.get("column_datatype"))
						.equalsIgnoreCase("Date")) {

					if (!(excaliburData.get(tempCount) == null)) {
						objectData[tempCount] = new Date(new java.util.Date(
								excaliburData.get(tempCount)).getTime());

					}

					if (excaliburData.get(tempCount) == null) {
						objectData[tempCount] = null;
					}
				}

				// System.out.println(objectData[tempCount]);
				tempCount++;

			}

			tempCount = 0;
			objects.add(objectData);

		}
		// System.out.println("Ending Setter");

		return objects;
	}

	@Override
	public List<Object[]> getRASDataWithNOSRMapped(JdbcTemplate jdbcTemplate, String pmCode) {
		List<Object[]> rasActualDataForPMName=new ArrayList<Object[]>();
		List<Map<String, Object>> rasDataForPMName=jdbcTemplate.queryForList(DatabaseQuery.QUERY_TO_FETCH_RAS_HAVING_PM,new Object[]{Integer.parseInt(pmCode),Integer.parseInt(pmCode)});
		Object[] objects=null;
		
		for(Map<String,Object> ras:rasDataForPMName){
			
			objects=new Object[12];
			
			objects[0]=(int)ras.get("name");
			objects[1]=(String)ras.get("branch");
			/*objects[2]=(String)ras.get("BAND");
			objects[3]=(String)ras.get("FRESHER_LATERAL_TP");
			objects[4]=(String)ras.get("DESIG");
			objects[5]=(int)ras.get("REP_MGR_CODE");
			objects[6]=(String)ras.get("REP_MGR_NAME");
			objects[7]=(int)ras.get("TOTAL_EXPERIENCE");
			objects[8]=(String)ras.get("LOB_DESC");
			objects[9]=(String)ras.get("LOCATION");
			objects[10]=(String)ras.get("PROJECT_CODE");
			objects[11]=(String)ras.get("PROJECT_NAME");*/
			
			
			
	
			rasActualDataForPMName.add(objects);

			//RAS according to RAS Sheet
			//SRID -> ajax Primary Skill Secondary Skill
			
		}

				return rasActualDataForPMName;
		
		
	}

	@Override
	public boolean saveSRRASMapping(JdbcTemplate jdbcTemplate, int sapCode, String srID) {
		boolean flag=jdbcTemplate.update(DatabaseQuery.QUERY_TO_UPDATE_RAS_FOR_SAPID_WITH_SRID, new Object[]{srID,sapCode})>0?true:false;
		return flag;
	}

}

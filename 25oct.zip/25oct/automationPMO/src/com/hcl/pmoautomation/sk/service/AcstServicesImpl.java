package com.hcl.pmoautomation.sk.service;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;


import com.hcl.pmoautomation.sk.dao.AcstDao;
import com.hcl.pmoautomation.sk.dao.AcstDaoImp;
import com.hcl.pmoautomation.sk.utility.ExcelGenericReader;



public class AcstServicesImpl implements acstservice {

	@Override
	public boolean saveRASDump(String rasFilePath, String ACSTSHEETNAME, String ACSTTABLENAME,
			JdbcTemplate jdbcTemplate) {
		AcstDao rasDao = new AcstDaoImp();
		boolean resultFlag = false;
		try {
			resultFlag = rasDao.saveRASDumpData(ExcelGenericReader
					.readExcelAllDynamically(rasFilePath, ACSTSHEETNAME,
							ACSTTABLENAME, jdbcTemplate), ACSTTABLENAME,
					jdbcTemplate);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return resultFlag;
	}

	@Override
	public List<Object[]> getRASDataWithNOSRMapped(JdbcTemplate jdbcTemplate, String pmCode) {
		AcstDao rasDao = new AcstDaoImp();
		
		return rasDao.getRASDataWithNOSRMapped(jdbcTemplate,pmCode);

	}

	@Override
	public boolean saveSRRASMapping(JdbcTemplate jdbcTemplate, int sapCode, String srID) {
		AcstDao rasDao = new AcstDaoImp();
		return rasDao.saveSRRASMapping(jdbcTemplate,sapCode,srID);
	}

	
}

package com.hcl.pmoautomation.sk.vo;

import java.util.Date;

public class skillSearch {

	
	private String cluster;
	private String rag;
	private String month;
	private String type;
	private float percentage;
	private int sapId;
	private String name;
	private String role;
	private String module;
	private String skill;
	private int weightage;
	private int need;
	private  int actual;
	private String year;
	private float avgPercentage;
	private String projectname;
	private String projectcode;
	
	public String getRag() {
		return rag;
	}
	public void setRag(String rag) {
		this.rag = rag;
	}
	public float getAvgPercentage() {
		return avgPercentage;
	}
	public void setAvgPercentage(float avgPercentage) {
		this.avgPercentage = avgPercentage;
	}
	public String getCluster() {
		return cluster;
	}
	public void setCluster(String cluster) {
		this.cluster = cluster;
	}
	public String getrAG() {
		return rag;
	}
	public void setrAG(String rAG) {
		this.rag = rAG;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public float getPercentage() {
		return percentage;
	}
	public void setPercentage(float percentage) {
		this.percentage = percentage;
	}
	public int getSapId() {
		return sapId;
	}
	public void setSapId(int sapId) {
		this.sapId = sapId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	public String getSkill() {
		return skill;
	}
	public void setSkill(String skill) {
		this.skill = skill;
	}
	public int getWeightage() {
		return weightage;
	}
	public void setWeightage(int weightage) {
		this.weightage = weightage;
	}
	public int getNeed() {
		return need;
	}
	public void setNeed(int need) {
		this.need = need;
	}
	public int getActual() {
		return actual;
	}
	public void setActual(int actual) {
		this.actual = actual;
	}
	
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	
	public String getProjectcode() {
		return projectcode;
	}
	public void setProjectcode(String projectcode) {
		this.projectcode = projectcode;
	}
	public String getProjectname() {
		return projectname;
	}
	public void setProjectname(String projectname) {
		this.projectname = projectname;
	}
	@Override
	public String toString() {
		return "skillSearch [cluster=" + cluster + ", rag=" + rag + ", month=" + month + ", type=" + type
				+ ", percentage=" + percentage + ", sapId=" + sapId + ", name=" + name + ", role=" + role + ", module="
				+ module + ", skill=" + skill + ", weightage=" + weightage + ", need=" + need + ", actual=" + actual
				+ ", year=" + year + ", avgPercentage=" + avgPercentage + ", projectname=" + projectname
				+ ", projectcode=" + projectcode + "]";
	}
	
	
	
	

	
	
	
	
	
	
}

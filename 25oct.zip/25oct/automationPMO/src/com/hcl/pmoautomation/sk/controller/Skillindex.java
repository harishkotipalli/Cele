package com.hcl.pmoautomation.sk.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hcl.pmoautomation.sk.dao.SkillsDAO;
import com.hcl.pmoautomation.sk.vo.SkillVO;

@Controller
@RequestMapping(value="SkillIndex/formation")
public class Skillindex {
	@Autowired
	 JdbcTemplate jdbcTemplate;
	
	
	@RequestMapping(value = "/skillForm.php")
	public String home(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String sapid=request.getParameter("SapIdforSkills");
		int sapId=Integer.parseInt(sapid);
		
		SkillsDAO sap=new SkillsDAO ();
		List<SkillVO> skill =sap.linkactive(sapId, jdbcTemplate);
	
		String[] array = new String[skill.size()];
		int index = 0;
		for (Object value : skill) {
			array[index] = String.valueOf( value );
		}
		if(array[index].equalsIgnoreCase("Y")){
			request.setAttribute("sapID", sapId);
			HttpSession session = request.getSession();
		    session.setAttribute("sapidforskillupdate", sapId);
		}
		else{
			return"GPN/NDABlockPage";
		}
		
		return "skill/SkillForm";

	}
	
	@RequestMapping(value = "/skillFormSubmit.php")
	public void submit(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String sapid=request.getParameter("sapidsubmit");
		String primary=request.getParameter("primary");
		String secondary=request.getParameter("secondary");
		String domain=request.getParameter("domain");
		String softskills=request.getParameter("softskills");
		
		String addQuery = "insert into mydb.resource_skills_table (SapId,Primary_Skill,Secondary_Skill ,Domain ,Soft_Skills) values(?,?,?,?,?)";
		this.jdbcTemplate.update(addQuery,  new Object[] {sapid,primary,secondary,domain,softskills});

		

		 PrintWriter out = response.getWriter();
		 out.println("<html><body><script>window.alert('Submitted successfully!!!');window.close();</script></body></html>");
	}

}

package com.hcl.pmoautomation.sk.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;


import com.hcl.pmoautomation.sk.vo.skillSearch;

public interface skillsearchinterface {
	
	// List<skillSearch> list(String year, String month,String type, String  cluster, String rag, JdbcTemplate jdbcTemplate) ;
	// List<skillSearch> list(String date, String CLUSTER, String RAG, JdbcTemplate jdbcTemplate);
	
	skillSearch mapRow(ResultSet rs, int rowNum) throws SQLException;
	
	
}


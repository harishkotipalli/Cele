package com.hcl.pmoautomation.sk.utility;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.jdbc.core.JdbcTemplate;


import com.hcl.pmoautomation.sk.dao.AcstDaoImp;



public class ExcelGenericReader {

	// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	public static List<ArrayList<String>> readExcelAllDynamically(String file,
			String sheetName, String tableName, JdbcTemplate jdbcTemplate) throws FileNotFoundException, IOException, Exception
			{
		Workbook myExcelBook = new WorkbookFactory().create(new FileInputStream(file));
		Sheet myExcelSheet = myExcelBook.getSheet(sheetName);
		String tempData = null;

		int tempReadCount = 0;
		List<String> tempStrings = new ArrayList<String>();
		List<ArrayList<String>> tempStringList = new ArrayList<ArrayList<String>>();
		AcstDaoImp oppTrcakerImpl = new AcstDaoImp();
		List<Map<String, Object>> colNames = oppTrcakerImpl
				.getAllColumnNamesDynamically(tableName, jdbcTemplate);
		List<Integer> rowCount = new ArrayList<Integer>();
		System.out.println("Size : " + colNames.size());
		for (Map columnMapRowData : colNames) {
//			System.out.println((Integer) columnMapRowData.get("column_id"));
			rowCount.add((Integer) columnMapRowData.get("column_id"));
		}
//		System.out.println("Name : " + myExcelBook.getSheetName(0));
//		System.out.println(myExcelSheet.getPhysicalNumberOfRows());
		Row row=null;
		for (int j = 1; j < myExcelSheet.getPhysicalNumberOfRows(); j++) {

			row = myExcelSheet.getRow(j);
System.out.println();
			for (int i = 0; i < rowCount.size(); i++) {
				
				tempReadCount = rowCount.get(i) - 1;
//				System.out.print(row);
//				System.out.print(row.getCell(tempReadCount));
				// System.out.println(row.getCell(tempReadCount).getStringCellValue());
//				 System.out.print(row.getCell(tempReadCount).getCellType());
				if (row.getCell(tempReadCount).getCellType() == Cell.CELL_TYPE_STRING) {
					System.out.print(row.getCell(tempReadCount).getCellType());
					tempData = row.getCell(tempReadCount).getStringCellValue();

					if (row.getCell(tempReadCount).getStringCellValue()
							.equals("")) {
						tempData = null;
					}

				}
                
				if (row.getCell(tempReadCount).getCellType() == Cell.CELL_TYPE_BLANK) {
					System.out.print(row.getCell(tempReadCount).getCellType());
					
					

					tempData = null;
				}
				if (row.getCell(tempReadCount).getCellType() == Cell.CELL_TYPE_NUMERIC) {

					if (HSSFDateUtil.isCellDateFormatted(row
							.getCell(tempReadCount))) {
						System.out.print(row.getCell(tempReadCount).getCellType());
						tempData = new SimpleDateFormat("dd-MMM-yyyy")
								.format(row.getCell(tempReadCount)
										.getDateCellValue())
								+ "";
						
					} else {
						System.out.print(row.getCell(tempReadCount).getCellType());
//						System.out.println(tempData);
						tempData =  new Double(row.getCell(tempReadCount)
								.getNumericCellValue()).longValue() + "";
						
					}
				}
				if (row.getCell(tempReadCount).getCellType() == Cell.CELL_TYPE_FORMULA) {
					
					if (row.getCell(tempReadCount).getCachedFormulaResultType() == Cell.CELL_TYPE_NUMERIC) {
						System.out.print(row.getCell(tempReadCount).getCellType());
						if (!HSSFDateUtil.isCellDateFormatted(row
								.getCell(tempReadCount)))
							tempData = (int) row.getCell(tempReadCount)
									.getNumericCellValue() + "";
						
					}
					if (row.getCell(tempReadCount).getCellType() == Cell.CELL_TYPE_STRING) {
						System.out.print(row.getCell(tempReadCount).getCellType());
						if (!HSSFDateUtil.isCellDateFormatted(row
								.getCell(tempReadCount)))
							tempData = row.getCell(tempReadCount)
									.getStringCellValue();
						
					}
				}
				if(tempReadCount==0 && (tempData==null|| tempData.equalsIgnoreCase((0+"")))){
					break;
				}
				// System.out.println(tempData);
				tempStrings.add(tempData);
//				tempData = null;
				
			}
//			System.out.println(tempStrings);
			if (!(tempStrings.size() == 0)) {
				tempStringList.add(new ArrayList<String>(tempStrings));
			}
			tempStrings.clear();
			

		}

		
//		System.out.println(tempStringList.size());
		return tempStringList;

	}

	/*
	 * public static Map<String, Boolean> checkForExcaliburMandatoryFields(
	 * String file, String sheetName, String tableName) throws Exception {
	 * Workbook myExcelBook = WorkbookFactory .create(new
	 * FileInputStream(file)); Sheet myExcelSheet =
	 * myExcelBook.getSheet(sheetName); String tempData = null;
	 * 
	 * int tempReadCount = 0; Map<String, Boolean> mandatoryExcaliburFields =
	 * new HashMap<String, Boolean>();
	 * 
	 * ExcaliburDaoImpl oppTrcakerImpl = new ExcaliburDaoImpl();
	 * List<ArrayList<String>> colNames = oppTrcakerImpl
	 * .getAllColumnNamesDynamically(tableName, DatabaseUtil.getConnection());
	 * List<Integer> rowCount = new ArrayList<Integer>();
	 * 
	 * // System.out.println(colNames.size()); for (int i = 0; i <
	 * colNames.size(); i++) { ArrayList<String> temp = colNames.get(i); //
	 * System.out.println(temp); rowCount.add(new Integer(temp.get(0)));
	 * 
	 * }
	 * 
	 * // System.out.println(myExcelSheet.getSheetName()+"ASASA"); //
	 * System.out.println(myExcelSheet.getLastRowNum()); for (int j = 1; j <=
	 * myExcelSheet.getLastRowNum(); j++) { // System.out.println("QWQWW"); Row
	 * row = myExcelSheet.getRow(j);
	 * 
	 * for (int i = 0; i < rowCount.size(); i++) {
	 * 
	 * tempReadCount = rowCount.get(i) - 1; //
	 * System.out.println(row.getCell(tempReadCount).getStringCellValue());
	 * 
	 * if (row.getCell(tempReadCount).getCellType() ==
	 * XSSFCell.CELL_TYPE_STRING) {
	 * 
	 * tempData = row.getCell(tempReadCount).getStringCellValue();
	 * 
	 * // System.out.println("ASASAS");
	 * 
	 * if (row.getCell(tempReadCount).getStringCellValue() .equals("")) {
	 * tempData = "BLANK"; }
	 * 
	 * }
	 * 
	 * if (row.getCell(tempReadCount).getCellType() == XSSFCell.CELL_TYPE_BLANK)
	 * { if (tempReadCount == 0) { break; }
	 * 
	 * tempData = "BLANK"; } if (row.getCell(tempReadCount).getCellType() ==
	 * Cell.CELL_TYPE_NUMERIC) {
	 * 
	 * if (HSSFDateUtil.isCellDateFormatted(row .getCell(tempReadCount))) {
	 * 
	 * tempData = new SimpleDateFormat("dd-MMM-yyyy")
	 * .format(row.getCell(tempReadCount) .getDateCellValue()) + "";
	 * 
	 * } else {
	 * 
	 * tempData = (int) row.getCell(tempReadCount) .getNumericCellValue() + "";
	 * 
	 * } } if (row.getCell(tempReadCount).getCellType() ==
	 * Cell.CELL_TYPE_FORMULA) { if
	 * (row.getCell(tempReadCount).getCachedFormulaResultType() ==
	 * Cell.CELL_TYPE_NUMERIC) { if (!HSSFDateUtil.isCellDateFormatted(row
	 * .getCell(tempReadCount))) tempData = (int) row.getCell(tempReadCount)
	 * .getNumericCellValue() + ""; } if
	 * (row.getCell(tempReadCount).getCellType() == XSSFCell.CELL_TYPE_STRING) {
	 * if (!HSSFDateUtil.isCellDateFormatted(row .getCell(tempReadCount)))
	 * tempData = row.getCell(tempReadCount) .getStringCellValue(); } }
	 * System.out.println(tempData);
	 * 
	 * for (int index : ExcelSheetConstants.EXCALIBUR_MANDATORY_FIELDS_INDEXS) {
	 * if (tempReadCount == index) { //
	 * System.out.println(tempReadCount+" +++ "+ index); if
	 * (tempData.equalsIgnoreCase("BLANK")) { //
	 * System.out.println(row.getCell(tempReadCount).getStringCellValue());
	 * mandatoryExcaliburFields.put( myExcelSheet.getRow(j - 1)
	 * .getCell(tempReadCount) .getStringCellValue(), false);
	 * 
	 * } } } }
	 * 
	 * }
	 * 
	 * return mandatoryExcaliburFields;
	 * 
	 * }
	 * 
	 * public static Map<String, Boolean> checkForSRMandatoryFields(String file,
	 * String sheetName, String tableName) throws Exception { Workbook
	 * myExcelBook = WorkbookFactory .create(new FileInputStream(file)); Sheet
	 * myExcelSheet = myExcelBook.getSheet(sheetName); String tempData = null;
	 * 
	 * int tempReadCount = 0; Map<String, Boolean> mandatorySRFields = new
	 * HashMap<String, Boolean>();
	 * 
	 * ExcaliburDaoImpl oppTrcakerImpl = new ExcaliburDaoImpl();
	 * List<ArrayList<String>> colNames = oppTrcakerImpl
	 * .getAllColumnNamesDynamically(tableName, DatabaseUtil.getConnection());
	 * List<Integer> rowCount = new ArrayList<Integer>();
	 * 
	 * System.out.println(colNames.size()); for (int i = 0; i < colNames.size();
	 * i++) { ArrayList<String> temp = colNames.get(i);
	 * 
	 * rowCount.add(new Integer(temp.get(0)));
	 * 
	 * }
	 * 
	 * for (int j = 1; j < myExcelSheet.getLastRowNum(); j++) {
	 * 
	 * Row row = myExcelSheet.getRow(j);
	 * 
	 * for (int i = 0; i < rowCount.size(); i++) {
	 * 
	 * tempReadCount = rowCount.get(i) - 1;
	 * 
	 * if (row.getCell(tempReadCount).getCellType() ==
	 * XSSFCell.CELL_TYPE_STRING) {
	 * 
	 * tempData = row.getCell(tempReadCount).getStringCellValue();
	 * 
	 * if (row.getCell(tempReadCount).getStringCellValue() .equals("")) {
	 * tempData = "BLANK"; }
	 * 
	 * }
	 * 
	 * if (row.getCell(tempReadCount).getCellType() == XSSFCell.CELL_TYPE_BLANK)
	 * { if (tempReadCount == 0) { break; }
	 * 
	 * tempData = "BLANK"; } if (row.getCell(tempReadCount).getCellType() ==
	 * Cell.CELL_TYPE_NUMERIC) {
	 * 
	 * if (HSSFDateUtil.isCellDateFormatted(row .getCell(tempReadCount))) {
	 * 
	 * tempData = new SimpleDateFormat("dd-MMM-yyyy")
	 * .format(row.getCell(tempReadCount) .getDateCellValue()) + "";
	 * 
	 * } else {
	 * 
	 * tempData = (int) row.getCell(tempReadCount) .getNumericCellValue() + "";
	 * 
	 * } } if (row.getCell(tempReadCount).getCellType() ==
	 * Cell.CELL_TYPE_FORMULA) { if
	 * (row.getCell(tempReadCount).getCachedFormulaResultType() ==
	 * Cell.CELL_TYPE_NUMERIC) { if (!HSSFDateUtil.isCellDateFormatted(row
	 * .getCell(tempReadCount))) tempData = (int) row.getCell(tempReadCount)
	 * .getNumericCellValue() + ""; } if
	 * (row.getCell(tempReadCount).getCellType() == XSSFCell.CELL_TYPE_STRING) {
	 * if (!HSSFDateUtil.isCellDateFormatted(row .getCell(tempReadCount)))
	 * tempData = row.getCell(tempReadCount) .getStringCellValue(); } }
	 * 
	 * for (int index : ExcelSheetConstants.SR_MANDATORY_FIELDS_INDEXS) { if
	 * (tempReadCount == index) { if (tempData.equalsIgnoreCase("BLANK")) {
	 * mandatorySRFields.put(myExcelSheet.getRow(j - 1) .getCell(tempReadCount)
	 * .getStringCellValue(), false);
	 * 
	 * } } } }
	 * 
	 * }
	 * 
	 * return mandatorySRFields;
	 * 
	 * }*/
}

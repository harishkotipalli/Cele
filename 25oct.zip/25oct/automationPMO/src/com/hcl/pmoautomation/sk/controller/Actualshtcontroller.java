package com.hcl.pmoautomation.sk.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.xml.bind.ParseConversionEvent;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


import com.hcl.pmoautomation.sk.dao.skillSearchDAO;
import com.hcl.pmoautomation.sk.service.AcstServicesImpl;
import com.hcl.pmoautomation.sk.service.acstservice;
import com.hcl.pmoautomation.sk.utility.ExcelSheetConstant;
import com.hcl.pmoautomation.sk.utility.excelDwnd;
import com.hcl.pmoautomation.sk.vo.skillSearch;

@Controller
@RequestMapping(value="SkillIndex/ad")

public class Actualshtcontroller 
{
	@ExceptionHandler(Exception.class)
	public ModelAndView handleException(Exception ex, HttpServletRequest request, HttpServletResponse response) {
	    ModelAndView modelAndView = new ModelAndView();
	    modelAndView.addObject("errorMessage", ex.getMessage());
	    modelAndView.addObject("errorDetails", ExceptionUtils.getStackTrace(ex));
	    modelAndView.setViewName("Login/Error");

	    return modelAndView;
	}
List ed=null;

	@Autowired
	private JdbcTemplate jdbcTemplate;
		
	@RequestMapping(value = "/actualUpload.php", method = RequestMethod.GET)
	public String RASUpload(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException,Exception 
	{

			return "skill/skUpload";

		}

		@RequestMapping(value = "/ActualExcelUpload.php", method = RequestMethod.POST )
		public void uplaodRASFile(Model model,HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {

			try{

				request.setAttribute("fileType", "ActualSheet");
				request.getRequestDispatcher("/fileUpload.aspx").forward(request,
						response);
			}
			catch(Exception e){
				response.sendRedirect("forward:../../pmoAutomation/Login/errorPage.php");
			}
		
			
			

		
		
	}
	  
	@RequestMapping(value = "/actualExcelReadSave.php", method = RequestMethod.POST)
	public String rasExcelRedingAndSaving(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		acstservice rasService = new AcstServicesImpl();
		boolean resultFlag = rasService.saveRASDump(
				(String) request.getAttribute("filePath"),
				ExcelSheetConstant.ACSTSHEETNAME,
				ExcelSheetConstant.ACSTTABLENAME, jdbcTemplate);
		String excaliburSaveResult = resultFlag == true ? "Successfully Uploaded!!!"
				: "Error!!!Uploading the File";
		request.setAttribute("uploadDataSaveResult", excaliburSaveResult);
		return "skill/skUpload";

	}
	
	

	
	
	@RequestMapping(value = "/actualsearch.php")
	public String SearchSkill(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		skillSearchDAO ssdao=new skillSearchDAO();
		List<skillSearch> se =ssdao.autopopulatecl(jdbcTemplate);
		List<skillSearch> se1=ssdao.autopopulatepn(jdbcTemplate);
		List<skillSearch> se2=ssdao.autopopulatepc(jdbcTemplate);
		request.setAttribute("clusters", se);
		request.setAttribute("pname", se1);
		request.setAttribute("pcode", se2);
	
		return "skill/searchSK";

	}
	
	@RequestMapping(value = "/SubmitSearch.php", method = RequestMethod.POST)
		
	
	public String SubmitSearchs(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException 
	{
		try{
			
		
		String year=request.getParameter("year");
		
		String month=request.getParameter("month");
		String type=request.getParameter("type");
		String cluster=request.getParameter("cluster");
		String rag=request.getParameter("rag");
		String pname=request.getParameter("projectName");
		String pcode=request.getParameter("projectCode");
System.out.println(pname+""+pcode);
		
	
		 skillSearchDAO ss=new skillSearchDAO();
		
		List<skillSearch> se = ss.list(year, month, type, cluster,rag,pname,pcode, jdbcTemplate);
		
		ed=se;
		boolean resultflag=ed.isEmpty();
		System.out.println("recordssssssssssss "+ed);
		request.setAttribute("skill123",se);
		if (resultflag) {
			request.setAttribute("searchrecordsfound", "No Records Found");

		} else {
			request.setAttribute("searchrecordsfound", "Records found");
		}

		}
		catch(Exception e){
			return "../../pmoAutomation/Login/errorPage.php";
		}
		return "forward:../../SkillIndex/ad/actualsearch.php";
	}
	

@RequestMapping(value = "/SubmitSearch12345.php", method = RequestMethod.POST)
		
	
	public String SubmitSearchs123(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException 
	{
	
		//TODO: Pass summary skillset object to new page with index.
	String lp=request.getParameter("loop");
	int i=Integer.parseInt(lp);
	
	String[] id=request.getParameterValues("id");
	//int[] idd = Arrays.stream(id).mapToInt(Integer::parseInt).toArray();
	String[] sub=request.getParameterValues("sub");
	//int[] subb = Arrays.stream(id).mapToInt(Integer::parseInt).toArray();
	
	String[] cluster=request.getParameterValues("cluster");
	String[] type=request.getParameterValues("type");
	String[] role=request.getParameterValues("role");
	String[] module=request.getParameterValues("module");
	String[] month=request.getParameterValues("month");
	String[] year=request.getParameterValues("year");
	String[] rag=request.getParameterValues("rag");
	String submit=(sub[0]);
	
	
	for(int z=0;z<=i-1;z++){
		
		if(id[z].equalsIgnoreCase(submit)){
			skillSearchDAO ss=new skillSearchDAO();
			
			List<skillSearch> se1=ss.foraHref(year[z], month[z], type[z], cluster[z], module[z], rag[z], role[z], jdbcTemplate);
			
		
			
			request.setAttribute("skill12345",se1);
			return "skill/DetailsPage";
		}
		/*else{
			
		}
		PrintWriter out = response.getWriter();
		out.println("<html>");
	       out.println("<head>");
	       out.println("<title> A very simple servlet example</title>");
	       out.println("</head>");
	       out.println("<body>");
	       out.println("<h1>NO RECORDS FOUND</h1>");
	       out.println("</body>");
	       out.println("</html>");
	       out.close();*/

		}
				
		
	 
	return "skill/DetailsPage";
		
		
		
	}




@RequestMapping(value = "/reports.php", method = RequestMethod.GET)
public String reports(HttpServletRequest request,
		HttpServletResponse response) throws ServletException, IOException 
{

		return "skill/reports";

	}

@RequestMapping(value = "/reportssearch.php", method = RequestMethod.POST)


public String ReportsSearch(HttpServletRequest request,
		HttpServletResponse response) throws ServletException, IOException 
{
	try{
		
	
	String cluster=request.getParameter("cluster");
	String year=request.getParameter("year");
	String month=request.getParameter("month");
	String type=request.getParameter("type");
	
	
	



	 skillSearchDAO ss=new skillSearchDAO();
	
	List<skillSearch> se1 = ss.reports(year, month, type, cluster, jdbcTemplate);
	
		boolean resultflag=se1.isEmpty();
	request.setAttribute("reports",se1);
	
	if (resultflag) {
		request.setAttribute("searchrecordsfound", "No Records Found");

	} else {
		request.setAttribute("searchrecordsfound", "Records found");
	}
	
	
	
	}
	catch(Exception e){
		 return "forward:../../pmoAutomation/Login/errorPage.php";
	}

	
	return "skill/reports";
}

@RequestMapping(value = "/cluster5.php", method=RequestMethod.GET)
public String clusterMonthly(HttpServletRequest request,
		HttpServletResponse response) throws ServletException, IOException 
{
	 skillSearchDAO ss=new skillSearchDAO();
	 List<skillSearch> cluster = ss.Cluster5(jdbcTemplate);
	 boolean resultflag=cluster.isEmpty();
	 request.setAttribute("cluster",cluster);
	 if (resultflag) {
			request.setAttribute("searchrecordsfound", "No Records Found");

		} else {
			request.setAttribute("searchrecordsfound", "Records found");
		}
		
		return "skill/cluster5";

	}
}





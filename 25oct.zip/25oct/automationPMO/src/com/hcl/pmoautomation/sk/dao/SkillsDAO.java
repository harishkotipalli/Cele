package com.hcl.pmoautomation.sk.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.hcl.pmoautomation.rnc.dao.DataBaseRNCQuery;
import com.hcl.pmoautomation.rnc.model.NDAActivFlagCheck;
import com.hcl.pmoautomation.sk.vo.SkillVO;

public class SkillsDAO {

	public List<SkillVO> linkactive(int sap,JdbcTemplate jdbcTemplate) 
	{
		String sql = DatabaseQuery.QUERY_TO_FETCH_Skill_ActiveFlagCheck+sap;
		    		 List<SkillVO> listaa = jdbcTemplate.query(sql, new RowMapper<SkillVO>() 
	
	    				 {
			@Override
			public SkillVO mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				SkillVO path = new SkillVO();
				
				path.setActiveflag(rs.getString("Active_Flag"));
			return path;
			}
	   });
	    return listaa;
	    
	   }
}

package com.hcl.pmoautomation.sk.dao;

import org.springframework.jdbc.core.PreparedStatementCreator;

public interface DatabaseQuery {

	public String QUERY_FETCH_COLUMNS1 = "select column_id ,column_name ,column_datatype from  mydb.type_configuration where table_name='";
	public String QUERY_FETCH_COLUMNS2 = "' and active_flag='Y' order by column_id";
	
	public String QUERY_TO_FETCH_EXCALIBUR = "select * FROM excalibur where PM_CM is null";
	public String QUERY_TO_UPDATE_EXCALIBUR1="update excalibur set STATUS_DM_PM ='Y', PM_CM='";
	public String QUERY_TO_UPDATE_EXCALIBUR2="' where excalibur_id='";
	public String QUERY_TO_UPDATE_PM_DM_STATUS_NO = "update excalibur set STATUS_DM_PM='N',STATUS_EMAIL='N' where EXCALIBUR_ID='";
	public String QUERY_TO_UPDATE_PM_DM_STATUS_YES = "update excalibur set STATUS_DM_PM='Y',STATUS_EMAIL='N' where EXCALIBUR_ID='";
	public String QUERY_TO_FETCH_PM_NAMES = "select PM_NAME FROM dm_pm_mapping where DM_NAME like '%";
	public String QUERY_TO_UPDATE_EXCALIBUR_PM1 ="update excalibur set PM_CM='";
	public String QUERY_TO_UPDATE_EXCALIBUR_PM2 ="',STATUS_DM_PM='Y' where EXCALIBUR_ID='";
	public String QUERY_TO_FETCH_SR_DATA = "select SR_ID,PRIMARY_SKILLS,PROJECT,PROJECT_CODE from sr where INITIATOR like '";
	public String QUERY_TO_FETCH_EXCALIBUR_PMNAME = "select EXCALIBUR_ID from excalibur where PM_CM='";
	public String QUERY_TO_FETCH_AM_DM_NAME = "select ACCOUNT_MANAGER,DM from excalibur where PM_CM like '";
	public String QUERY_TO_FETCH_OPPORTUNITY_NAME = "select OPPORTUNITY_NAME from excalibur where EXCALIBUR_ID='";
	public String QUERY_TO_INSERT_SR_EXCALIBUR = "insert into excalibur_sr_mapping (EXCALIBUR_ID,SR_ID,ACCOUNT_MANAGER,PM_MAP_ID) values(?,?,?,?)";
	public String QUERY_TO_FETCH_SR_FROM_SREXCALIBUR = "select SR_ID from excalibur_sr_mapping";
	public String QUERY_TO_FETCH_RAS_HAVING_PM = "select * from ras where PM_CODE=? AND SR_ID IS NULL AND  NOT(SAPCODE=?)";
	public String QUERY_TO_FETCH_SR_HAVING_PMNAME = "select SR_ID from excalibur_sr_mapping where PM_MAP_ID=";
	public String QUERY_TO_FETCH_SRDETAIL_FOR_SRID = "select PRIMARY_SKILLS from sr where sr_id=?";
	public String QUERY_TO_UPDATE_RAS_FOR_SAPID_WITH_SRID = "update info set name=? where SAPCODE=?";
	public String QUERY_TO_FETCH_TSC = "select * from tsc";
	public String QUERY_TO_FETCH_EXCALIBURVIEW = "select * from excalibur where STATUS_DM_PM='Y' AND MODIFIED_DATE between ";
	public String QUERY_TO_FETCH_SMARTRECRUIT_DATA = "select * from sr where INITIATOR like '%";
	public String QUERY_TO_FETCH_SkillSearch_GETRECORD="select * from mydb.skillindex where upload_date=? and Cluster=? and RAG=?";
	public String QUERY_TO_FETCH_SkillSearch_GETRECORD1 = "select * from mydb.skillindex where upload_date=? and cluster=? and rag=?";
	
	public String QUERY_TO_FETCH_SkillSearch_SUMMARY1 =" SELECT Month,Type,Cluster,SapId,project_name,project_code,Name,Role,Module,Skill,Weightage,Need,Actual,PERCENTAGE,Year,rag,avg(percentage) FROM mydb.skillindex Where year = ";
	public String QUERY_TO_FETCH_SkillSearch_SUMMARY12 =" and month = "; 
	public String QUERY_TO_FETCH_SkillSearch_SUMMARY2=" And  TYPE= ";														
	public String QUERY_TO_FETCH_SkillSearch_SUMMARY3=" And Cluster = ";
	public String QUERY_TO_FETCH_SkillSearch_SUMMARY4=" And RAG = ";
	public String QUERY_TO_FETCH_SkillSearch_SUMMARY6=" And module = ";
	public String QUERY_TO_FETCH_SkillSearch_SUMMARY7=" And role = ";
	public String QUERY_TO_FETCH_SkillSearch_SUMMARY8=" And project_name = ";
	public String QUERY_TO_FETCH_SkillSearch_SUMMARY9=" And project_code = ";
	public String QUERY_TO_FETCH_SkillSearch_SUMMARY5=" Group By Cluster, ROLE, Module, Month, Year, Type, rag";
	/*SELECT * FROM mydb.skillindex 
	Where Cluster ='ibd it' 
	And type = 'ad'	
	And Year = 2016 
	And month = 'aug' 
	And RAG = 'R'
	And Module = 'Process Knowledge'
	And ROLE = 'BusinessAnalyst';*/
	public String QUERY_TO_FETCH_SkillSearch_reports1="SELECT Cluster,Month,Year,type,avg(percentage) FROM mydb.skillindex Where year = ";
	public String QUERY_TO_FETCH_SkillSearch_reports2=" and month = ";
	public String QUERY_TO_FETCH_SkillSearch_reports3=" And  TYPE= ";
	public String QUERY_TO_FETCH_SkillSearch_reports4=" And ";
	public String QUERY_TO_FETCH_SkillSearch_reports5="= ";
	public String QUERY_TO_FETCH_SkillSearch_reports6="Group By Cluster,Month, Year,SAPID,name ";
	
	
	/*SELECT Cluster,Month,SAPID,name,round(avg(percentage))
	FROM mydb.skillindex
	Where month = 'August'
	And Year = 2016
	Group By Cluster,Month, Year,SAPID,name;
	*/

	public String QUERY_TO_FETCH_SkillSearch_totalPercentageCluster=" SELECT Cluster,Month,Year,type,avg(percentage),rag FROM mydb.skillindex Where `upload_date` >= last_day(now()) + interval 1 day - interval 5 month  Group By Cluster,Month, Year";
	public String QUERY_TO_FETCH_SkillSearch_autopopulate="SELECT distinct Cluster FROM mydb.skillindex";
	public String QUERY_TO_FETCH_SkillSearch_autopopulate1="SELECT distinct project_name FROM mydb.skillindex";
	public String QUERY_TO_FETCH_SkillSearch_autopopulate2="SELECT distinct project_code FROM mydb.skillindex";
	/*SELECT Cluster,Month,SAPID,name,round(avg(percentage))
	 
	FROM mydb.skillindex
	 
	Where month = 'August'
	 
	And Year = 2016
	 
	Group By Cluster,Month, Year,SAPID,name;*/
	public String QUERY_TO_FETCH_SkillSearch_ResourceWise="SELECT Cluster,Month,SAPID,name,year,type ,avg(percentage) FROM mydb.skillindex Where month =";
	 
	public String QUERY_TO_FETCH_SkillSearch_ResourceWise1="And Year=";
	public String QUERY_TO_FETCH_SkillSearch_ResourceWise2="And type=";
	public String QUERY_TO_FETCH_SkillSearch_ResourceWise3="And cluster=";
	public String QUERY_TO_FETCH_SkillSearch_ResourceWise4="Group By Cluster,Month, Year,SAPID,name;";
	public String QUERY_TO_FETCH_Skill_ActiveFlagCheck="SELECT Active_Flag FROM mydb.resource_skills_table where SapId=";
	
	
	

}

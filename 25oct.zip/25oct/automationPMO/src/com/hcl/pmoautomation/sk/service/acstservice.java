package com.hcl.pmoautomation.sk.service;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

public interface acstservice {

	public boolean saveRASDump(String rasFilePath, String ACSTSHEETNAME,
			String ACSTTABLENAME, JdbcTemplate jdbcTemplate);

	public List<Object[]> getRASDataWithNOSRMapped(JdbcTemplate jdbcTemplate,
			String pmCode);

	public boolean saveSRRASMapping(JdbcTemplate jdbcTemplate, int sapCode, String srID);

}

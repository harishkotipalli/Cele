package com.hcl.pmoautomation.sk.dao;

import java.io.IOException;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.hcl.pmoautomation.AddAction.dao.DataBaseQueryForAddAction;

import com.hcl.pmoautomation.sk.vo.skillSearch;



public class skillSearchDAO implements skillsearchinterface{
	
	
	
	
	
	
	
	
	
	
	public List<skillSearch> list(String year, String month,String type, String  cluster, String rag,  String  pname, String pcode,JdbcTemplate jdbcTemplate) 
	{
		
	 	String sql = DatabaseQuery.QUERY_TO_FETCH_SkillSearch_SUMMARY1+"'"+year+"'"+DatabaseQuery.QUERY_TO_FETCH_SkillSearch_SUMMARY12+"'"+month+"'";
		
		if (!type.equalsIgnoreCase("-select-"))
		{
			sql +=DatabaseQuery.QUERY_TO_FETCH_SkillSearch_SUMMARY2+"'"+type+"'";
		}
		if (!cluster.equalsIgnoreCase("-select-"))
		{
			sql +=DatabaseQuery.QUERY_TO_FETCH_SkillSearch_SUMMARY3+"'"+cluster+"'";
		}
		if (!rag.equalsIgnoreCase("-select-"))
		{
			sql +=DatabaseQuery.QUERY_TO_FETCH_SkillSearch_SUMMARY4+"'"+rag+"'";
		}
		if (!pname.equalsIgnoreCase("-select-"))
		{
			sql +=DatabaseQuery.QUERY_TO_FETCH_SkillSearch_SUMMARY8+"'"+pname+"'";
		}
		if (!pcode.equalsIgnoreCase("-select-"))
		{
			sql +=DatabaseQuery.QUERY_TO_FETCH_SkillSearch_SUMMARY9+"'"+pcode+"'";
		}
		
		sql += DatabaseQuery.QUERY_TO_FETCH_SkillSearch_SUMMARY5;
		
		System.out.println(sql);
	   
	    		 List<skillSearch> listaa = jdbcTemplate.query(sql, new RowMapper<skillSearch>() 
	
	    				 {
			@Override
			public skillSearch mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
					skillSearch sskk1 = new skillSearch();
					
				/*sskk1.setMonth(rs.getString("month"));
            	sskk1.setType(rs.getString("type"));
            	sskk1.setCluster(rs.getString("cluster"));
            	//sskk1.setSapId(rs.getInt("sapId"));
            	//sskk1.setName(rs.getString("name"));
            	sskk1.setRole(rs.getString("role"));
            	sskk1.setModule(rs.getString("module"));
            	//sskk1.setSkill(rs.getString("skill"));
            	//sskk1.setWeightage(rs.getInt("weightage"));
            	//sskk1.setNeed(rs.getInt("need"));
            	//sskk1.setActual(rs.getInt("actual"));
            	//sskk1.setPercentage(rs.getFloat("percentage"));
            	sskk1.setrAG(rs.getString("rag"));
            	sskk1.setYear(rs.getString("year"));*/
					sskk1.setMonth(rs.getString("month"));
	            	sskk1.setType(rs.getString("type"));
	            	sskk1.setCluster(rs.getString("cluster"));
	            	sskk1.setProjectname(rs.getString("project_name"));
	            	sskk1.setProjectcode(rs.getString("project_code"));
	            	sskk1.setSapId(rs.getInt("sapId"));
	            	sskk1.setName(rs.getString("name"));
	            	sskk1.setRole(rs.getString("role"));
	            	sskk1.setModule(rs.getString("module"));
	            	sskk1.setSkill(rs.getString("skill"));
	            	sskk1.setWeightage(rs.getInt("weightage"));
	            	sskk1.setNeed(rs.getInt("need"));
	            	sskk1.setActual(rs.getInt("actual"));
	            	
	            	sskk1.setrAG(rs.getString("rag"));
	            	sskk1.setYear(rs.getString("year"));
					
				
				return sskk1;
			}
	 
			
			
			
			
			
			
	    });//---------------new Object[]{year, month});
	    		
	    		
	    return listaa;
	    
	  
	    
	    }

	@Override
	public skillSearch mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	public List<skillSearch> foraHref(String year, String month, String type, String cluster, String module,String rag,String role, JdbcTemplate jdbcTemplate) 
	{
		  
		  
		String sql = DatabaseQuery.QUERY_TO_FETCH_SkillSearch_SUMMARY1+"'"+year+"'"+DatabaseQuery.QUERY_TO_FETCH_SkillSearch_SUMMARY12+"'"+month+"'";
		
		if (!type.equalsIgnoreCase("-select-"))
		{
			sql +=DatabaseQuery.QUERY_TO_FETCH_SkillSearch_SUMMARY2+"'"+type+"'";
		}
		if (!cluster.equalsIgnoreCase("-select-"))
		{
			sql +=DatabaseQuery.QUERY_TO_FETCH_SkillSearch_SUMMARY3+"'"+cluster+"'";
		}
		if (!rag.equalsIgnoreCase("-select-"))
		{
			sql +=DatabaseQuery.QUERY_TO_FETCH_SkillSearch_SUMMARY4+"'"+rag+"'";
		}
		
		if (!rag.equalsIgnoreCase("-select-"))
		{
			sql +=DatabaseQuery.QUERY_TO_FETCH_SkillSearch_SUMMARY7+"'"+role+"'";
		}
		
		
		
		
	   
	    		 List<skillSearch> listaa = jdbcTemplate.query(sql, new RowMapper<skillSearch>() 
	
	    				 {
			@Override
			public skillSearch mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				skillSearch sskk1 = new skillSearch();
				
				
				
				//TODO: Have another column in POJO called ID and set the ID here with rowNum or rs.getRow()
				//sskk1.setId(rowNum);
				sskk1.setMonth(rs.getString("month"));
            	sskk1.setType(rs.getString("type"));
            	sskk1.setCluster(rs.getString("cluster"));
            	sskk1.setSapId(rs.getInt("sapId"));
            	sskk1.setName(rs.getString("name"));
            	sskk1.setRole(rs.getString("role"));
            	sskk1.setModule(rs.getString("module"));
            	sskk1.setSkill(rs.getString("skill"));
            	sskk1.setWeightage(rs.getInt("weightage"));
            	sskk1.setNeed(rs.getInt("need"));
            	sskk1.setActual(rs.getInt("actual"));
            	
            	sskk1.setrAG(rs.getString("rag"));
            	sskk1.setYear(rs.getString("year"));
            	sskk1.setPercentage(rs.getFloat("percentage"));
				return sskk1;
			}
	 
			
			
			
			
			
			
	    });//---------------new Object[]{year, month});
	    	
	    		
	    return listaa;
		
	}

	public List<skillSearch> reports(String year,String month, String type, String cluster,JdbcTemplate jdbcTemplate ){
	String sql = DatabaseQuery.QUERY_TO_FETCH_SkillSearch_ResourceWise+"'"+month+"'"+DatabaseQuery.QUERY_TO_FETCH_SkillSearch_ResourceWise1+"'"+year+"'";
		
		if (!type.equalsIgnoreCase("-select-"))
		{
			sql +=DatabaseQuery.QUERY_TO_FETCH_SkillSearch_ResourceWise2+"'"+type+"'";
		}
		if (!cluster.equalsIgnoreCase("-select-"))
		{
			sql +=DatabaseQuery.QUERY_TO_FETCH_SkillSearch_ResourceWise3+"'"+cluster+"'";
		}
		
		
		sql += DatabaseQuery.QUERY_TO_FETCH_SkillSearch_ResourceWise4;
		
		
		    		 List<skillSearch> listaa = jdbcTemplate.query(sql, new RowMapper<skillSearch>() 
		
		    				 {
				@Override
				public skillSearch mapRow(ResultSet rs, int rowNum) throws SQLException 
				{
					
						skillSearch sskk1 = new skillSearch();
						sskk1.setName(rs.getString("name"));
						sskk1.setCluster(rs.getString("cluster"));
						sskk1.setMonth(rs.getString("month"));
						sskk1.setSapId(rs.getInt("sapId"));
						
						sskk1.setYear(rs.getString("year"));
						sskk1.setType(rs.getString("type"));
						sskk1.setAvgPercentage(rs.getFloat("avg(percentage)"));
						
		            	
		            	
		            	
		            	
		            	
		              
					
					return sskk1;
				}	 
				
		    });//---------------new Object[]{year, month});	
		    return listaa;
		
	}
	public List<skillSearch> Cluster5(JdbcTemplate jdbcTemplate ){
	 	String sql = DatabaseQuery.QUERY_TO_FETCH_SkillSearch_totalPercentageCluster;
		
			
			
		
		    		 List<skillSearch> listaa = jdbcTemplate.query(sql, new RowMapper<skillSearch>() 
		
		    				 {
				@Override
				public skillSearch mapRow(ResultSet rs, int rowNum) throws SQLException 
				{
					
						skillSearch sskk1 = new skillSearch();
						sskk1.setYear(rs.getString("year"));
						sskk1.setMonth(rs.getString("month"));
						sskk1.setType(rs.getString("type"));
		            	sskk1.setCluster(rs.getString("cluster"));
		            	
		            	sskk1.setAvgPercentage(rs.getFloat("avg(percentage)"));
		            	
		            	sskk1.setRag(rs.getString("rag"));
					
					return sskk1;
				}	 
				
		    });//---------------new Object[]{year, month});	
		    return listaa;
		
	}
	public List<skillSearch> autopopulatecl(JdbcTemplate jdbcTemplate)
	{
		String sql = DatabaseQuery.QUERY_TO_FETCH_SkillSearch_autopopulate;
		
		 List<skillSearch> listpopulate = jdbcTemplate.query(sql, new RowMapper<skillSearch>() 
			
		 {
				@Override
				public skillSearch mapRow(ResultSet rs, int rowNum) throws SQLException 
		{
		

		skillSearch ob = new skillSearch();
       
           
               
                ob.setCluster(rs.getString("Cluster"));
             
            
			return ob;

    }
});
		 
		return listpopulate;
	}
	
	
	public List<skillSearch> autopopulatepn(JdbcTemplate jdbcTemplate)
	{
		String sql = DatabaseQuery.QUERY_TO_FETCH_SkillSearch_autopopulate1;
		
		 List<skillSearch> listpopulate = jdbcTemplate.query(sql, new RowMapper<skillSearch>() 
			
		 {
				@Override
				public skillSearch mapRow(ResultSet rs, int rowNum) throws SQLException 
		{
		

		skillSearch ob = new skillSearch();
       
           
             
                ob.setProjectname(rs.getString("project_name"));
               
             
            
			return ob;

    }
});
		 
		return listpopulate;
	}
	
	public List<skillSearch> autopopulatepc(JdbcTemplate jdbcTemplate)
	{
		String sql = DatabaseQuery.QUERY_TO_FETCH_SkillSearch_autopopulate2;
		
		 List<skillSearch> listpopulate = jdbcTemplate.query(sql, new RowMapper<skillSearch>() 
			
		 {
				@Override
				public skillSearch mapRow(ResultSet rs, int rowNum) throws SQLException 
		{
		

		skillSearch ob = new skillSearch();
       
           
                ob.setProjectcode(rs.getString("project_code"));
             
             
            
			return ob;

    }
});
		 
		return listpopulate;
	}

	
}





package com.hcl.pmoautomation.workstatus.service;

import org.springframework.jdbc.core.PreparedStatementCreator;

public interface emodatabase {

	public String emodata = "select pmo_details.SAPCODE,pmo_details.NAME,pmo_work_area.MONDAY,pmo_work_area.TUESDAY,pmo_work_area.WEDNESDAY,"
+" pmo_work_area.THURSDAY,pmo_work_area.FRIDAY "
+" from mydb.pmo_work_area, mydb.pmo_details"
+" where pmo_work_area.SAPCODE in"
+" (select pmo_details.SAPCODE from mydb.pmo_details where pmo_details.RM_SAPCODE=";
public String emodata1 =")and pmo_work_area.SAPCODE= pmo_details.SAPCODE and pmo_work_area.WEEK_START_DATE='";
	
	
	

}

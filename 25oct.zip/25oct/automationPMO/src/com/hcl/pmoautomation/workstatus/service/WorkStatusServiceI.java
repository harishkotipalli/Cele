package com.hcl.pmoautomation.workstatus.service;



import org.springframework.jdbc.core.JdbcTemplate;
import com.hcl.pmoautomation.workstatus.vo.EmployeeStatus;

public interface WorkStatusServiceI {

	public EmployeeStatus getAllEmployeeStatus(int managerId, JdbcTemplate jdbcTemplet);
	public EmployeeStatus getAllNextWeekEmployeeStatus(int managerId,  JdbcTemplate jdbcTemplet);
	public EmployeeStatus getEmployeeView(JdbcTemplate jdbcTemplet);
}

package com.hcl.pmoautomation.workstatus.dao;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.jdbc.core.JdbcTemplate;


import com.hcl.pmoautomation.workstatus.vo.EmployeeOfficeStatus;
import com.hcl.pmoautomation.workstatus.vo.EmployeeStatus;

public class WorkStatusDaoImpl implements WorkStatusDaoI {

	@Override
	public EmployeeStatus getAllEmployeeStatus(int managerId, JdbcTemplate jdbcTemplet) {
		
		EmployeeStatus employeeStatus = new EmployeeStatus();
		System.out.println(employeeStatus);
	/*	Calendar cal = Calendar.getInstance();
		System.out.println(cal);	for(int i = Calendar.SUNDAY; i <= Calendar.SATURDAY; i++) {
		    cal.set(Calendar.DAY_OF_WEEK, i);
		  System.out.println(cal.getTime());*/
		
		try{
			
		
		
			  System.out.println("here");
			employeeStatus.setEmployeOfficeStatus(getAllNewEmployeeStatus(managerId, jdbcTemplet));
		  
		    System.out.println(getAllNewEmployeeStatus(managerId, jdbcTemplet));
		    System.out.println("Notworking");
			
			
			
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return employeeStatus;
	}

	@Override
	public List<EmployeeOfficeStatus> getAllNewEmployeeStatus(int managerId, JdbcTemplate jdbcTemplet) {
		WorkStatusDaoImpl impl = new WorkStatusDaoImpl();
		
		
		ArrayList al= new ArrayList();
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 1);
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
		System.out.println(cal);
	
		for(int i = Calendar.MONDAY; i <= Calendar.FRIDAY; i++) {
		    cal.set(Calendar.DAY_OF_WEEK, i);
		    System.out.println(cal.getTime());
		  //  System.out.println(cal.getTime());
		    al.add(format1.format(cal.getTime()));
		}
		System.out.println(al);
		
		
		
		 System.out.println("Checking "+al);
		
		Object[] param = { managerId,al.get(0) };
		//System.out.println(param);
		 //System.out.println(jdbcTemplet); 
	       //System.out.println(managerId);
	       //System.out.println(EmployeeStatussql.getEmployeedetails);
	       //System.out.println("checking");
	       
	     
		//return jdbcTemplet.query(new EmployeeStatusRowMapper());
		return jdbcTemplet.query(EmployeeStatussql.getEmployeedetails,param,new EmployeeStatusRowMapper());
	}
	
	public ArrayList DateRange(){
		ArrayList al= new ArrayList();
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 1);
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
		System.out.println(cal);
	
		for(int i = Calendar.MONDAY; i <= Calendar.FRIDAY; i++) {
		    cal.set(Calendar.DAY_OF_WEEK, i);
		    System.out.println(cal.getTime());
		  //  System.out.println(cal.getTime());
		    al.add(format1.format(cal.getTime()));
		}
		System.out.println(al);
		return al;
		
		
	}

	@Override
	public EmployeeStatus getAllEmployeeNextWeekStatus(int managerId,  JdbcTemplate jdbcTemplet) {
		EmployeeStatus employeenextweekstatus = new EmployeeStatus();
		
			
			try{
				
				employeenextweekstatus.setEmployeeNextOfficeStatus(getAllNewEmployeeNextWeekStatus(managerId, jdbcTemplet));
				
				
				
			}catch(Exception e){
				e.printStackTrace();
			}
			
			return employeenextweekstatus;
	}

	@Override
	public List<EmployeeOfficeStatus> getAllNewEmployeeNextWeekStatus(int managerId, JdbcTemplate jdbcTemplet) {
		
		ArrayList al= new ArrayList();
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 7);
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
		System.out.println(cal);
	
		for(int i = Calendar.MONDAY; i <= Calendar.FRIDAY; i++) {
		    cal.set(Calendar.DAY_OF_WEEK, i);
		    System.out.println(cal.getTime());
		  //  System.out.println(cal.getTime());
		    al.add(format1.format(cal.getTime()));
		}
		System.out.println(al);
		
		Object[] param = { managerId,al.get(0)};
		 System.out.println(jdbcTemplet); 
	       System.out.println(managerId);

		return jdbcTemplet.query(EmployeeStatussql.getEmployeedetails,param,new EmployeeStatusRowMapper());
	}
	
	public ArrayList DateRangeNextWeek(){
		ArrayList al= new ArrayList();
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 7);
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
		System.out.println(cal);
	
		for(int i = Calendar.MONDAY; i <= Calendar.FRIDAY; i++) {
		    cal.set(Calendar.DAY_OF_WEEK, i);
		    System.out.println(cal.getTime());
		  //  System.out.println(cal.getTime());
		    al.add(format1.format(cal.getTime()));
		}
		System.out.println(al);
		return al;
		
		
	}

	@Override
	public EmployeeStatus getAllEmployeeViewMon(JdbcTemplate jdbcTemplet) {
		
		EmployeeStatus employeestatusview = new EmployeeStatus();
		
		
		try{
			
		    System.out.println(getAllNewEmployeeViewTue(jdbcTemplet));
		    employeestatusview.setEmployeeViewMon(getAllNewEmployeeViewMon(jdbcTemplet));
		    employeestatusview.setEmployeeViewTue(getAllNewEmployeeViewTue(jdbcTemplet));
		    employeestatusview.setEmployeeViewWed(getAllNewEmployeeViewWed(jdbcTemplet));
		    employeestatusview.setEmployeeViewTh(getAllNewEmployeeViewTh(jdbcTemplet));
		    employeestatusview.setEmployeeViewFri(getAllNewEmployeeViewFri(jdbcTemplet));
		 
			
			System.out.println(getAllNewEmployeeViewMon(jdbcTemplet));
			/*System.out.println(getAllNewEmployeeViewTue(jdbcTemplet));
			System.out.println(getAllNewEmployeeViewWed(jdbcTemplet));
			System.out.println(getAllNewEmployeeViewTh(jdbcTemplet));
			System.out.println(getAllNewEmployeeViewFri(jdbcTemplet));*/
			
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return employeestatusview;
	}
	
	@Override
	public EmployeeStatus getAllEmployeeViewTue(JdbcTemplate jdbcTemplet) {
		
   EmployeeStatus employeestatusview = new EmployeeStatus();
		
		
		try{
			
		    
		    employeestatusview.setEmployeeViewTue(getAllNewEmployeeViewTue(jdbcTemplet));
		  
			
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return employeestatusview;
	}
	

	@Override
	public EmployeeStatus getAllEmployeeViewWed(JdbcTemplate jdbcTemplet) {
		
		  EmployeeStatus employeestatusview = new EmployeeStatus();
			
			
			try{
				
			  
			    employeestatusview.setEmployeeViewWed(getAllNewEmployeeViewWed(jdbcTemplet));
			  
				
				
			}catch(Exception e){
				e.printStackTrace();
			}
			
			return employeestatusview;
		}
	

	@Override
	public EmployeeStatus getAllEmployeeViewTh(JdbcTemplate jdbcTemplet) {
		  EmployeeStatus employeestatusview = new EmployeeStatus();
			
			
			try{
				
			
			    employeestatusview.setEmployeeViewTh(getAllNewEmployeeViewTh(jdbcTemplet));
			  
				
				
			}catch(Exception e){
				e.printStackTrace();
			}
			
			return employeestatusview;
		}

	@Override
	public EmployeeStatus getAllEmployeeViewFr(JdbcTemplate jdbcTemplet) {
		EmployeeStatus employeestatusview = new EmployeeStatus();
		
		
		try{
			
		
		    employeestatusview.setEmployeeViewFri(getAllNewEmployeeViewFri(jdbcTemplet));
		  
			
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return employeestatusview;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	@Override
	public List<EmployeeOfficeStatus> getAllNewEmployeeViewMon(JdbcTemplate jdbcTemplet) {
		
    WorkStatusDaoImpl impl = new WorkStatusDaoImpl();
		
		
		ArrayList al= new ArrayList();
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 1);
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
		System.out.println(cal);
	
		for(int i = Calendar.MONDAY; i <= Calendar.FRIDAY; i++) {
		    cal.set(Calendar.DAY_OF_WEEK, i);
		    System.out.println(cal.getTime());
		  //  System.out.println(cal.getTime());
		    al.add(format1.format(cal.getTime()));
		}
		System.out.println(al);
		
		
		
		 System.out.println("Checking "+al);
		
		Object[] param = {al.get(0) };
		
		return jdbcTemplet.query(EmployeeStatussql.getEmployeedetailsview,param,new EmployeeStatusViewRowMapper());
	}

	@Override
	public List<EmployeeOfficeStatus> getAllNewEmployeeViewTue(JdbcTemplate jdbcTemplet) {
WorkStatusDaoImpl impl = new WorkStatusDaoImpl();
		
		
		ArrayList al= new ArrayList();
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 1);
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
		System.out.println(cal);
	
		for(int i = Calendar.MONDAY; i <= Calendar.FRIDAY; i++) {
		    cal.set(Calendar.DAY_OF_WEEK, i);
		    System.out.println(cal.getTime());
		  //  System.out.println(cal.getTime());
		    al.add(format1.format(cal.getTime()));
		}
		System.out.println(al);
		
		
		
		 System.out.println("Checking "+al);
		
		Object[] param = {al.get(0) };
		
		return jdbcTemplet.query(EmployeeStatussql.getEmployeedetailsviewTu,param,new EmployeeStatusViewRowMapper());
	}

	@Override
	public List<EmployeeOfficeStatus> getAllNewEmployeeViewWed(JdbcTemplate jdbcTemplet) {
WorkStatusDaoImpl impl = new WorkStatusDaoImpl();
		
		
		ArrayList al= new ArrayList();
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 1);
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
		System.out.println(cal);
	
		for(int i = Calendar.MONDAY; i <= Calendar.FRIDAY; i++) {
		    cal.set(Calendar.DAY_OF_WEEK, i);
		    System.out.println(cal.getTime());
		  //  System.out.println(cal.getTime());
		    al.add(format1.format(cal.getTime()));
		}
		System.out.println(al);
		
		
		
		 System.out.println("Checking "+al);
		
		Object[] param = {al.get(0) };
		
		return jdbcTemplet.query(EmployeeStatussql.getEmployeedetailsviewWed,param,new EmployeeStatusViewRowMapper());
	}

	@Override
	public List<EmployeeOfficeStatus> getAllNewEmployeeViewTh(JdbcTemplate jdbcTemplet) {
WorkStatusDaoImpl impl = new WorkStatusDaoImpl();
		
		
		ArrayList al= new ArrayList();
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 1);
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
		System.out.println(cal);
	
		for(int i = Calendar.MONDAY; i <= Calendar.FRIDAY; i++) {
		    cal.set(Calendar.DAY_OF_WEEK, i);
		    System.out.println(cal.getTime());
		  //  System.out.println(cal.getTime());
		    al.add(format1.format(cal.getTime()));
		}
		System.out.println(al);
		
		
		
		 System.out.println("Checking "+al);
		
		Object[] param = {al.get(0) };
		
		return jdbcTemplet.query(EmployeeStatussql.getEmployeedetailsviewTh,param,new EmployeeStatusViewRowMapper());
	}

	@Override
	public List<EmployeeOfficeStatus> getAllNewEmployeeViewFri(JdbcTemplate jdbcTemplet) {
		
     WorkStatusDaoImpl impl = new WorkStatusDaoImpl();
		
		
		ArrayList al= new ArrayList();
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 1);
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
		System.out.println(cal);
	
		for(int i = Calendar.MONDAY; i <= Calendar.FRIDAY; i++) {
		    cal.set(Calendar.DAY_OF_WEEK, i);
		    System.out.println(cal.getTime());
		  //  System.out.println(cal.getTime());
		    al.add(format1.format(cal.getTime()));
		}
		System.out.println(al);
		
		
		
		 System.out.println("Checking "+al);
		
		Object[] param = {al.get(0) };
		
		return jdbcTemplet.query(EmployeeStatussql.getEmployeedetailsviewFr,param,new EmployeeStatusViewRowMapper());
	}

	



	

	
	}



package com.hcl.pmoautomation.workstatus.vo;



public class EmployeeOfficeStatus {
	
	public int sapId;
	public String employeeName;
	public String mday;
	public String tuday;
	public String wday;
	public String thday;
	public String fday;
	public String avaialbleStatus;
	
	public int getSapId() {
		return sapId;
	}
	public void setSapId(int sapId) {
		this.sapId = sapId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	

	public String getAvaialbleStatus() {
		return avaialbleStatus;
	}
	
	public String getMday() {
		return mday;
	}
	public void setMday(String mday) {
		this.mday = mday;
	}
	public String getTuday() {
		return tuday;
	}
	public void setTuday(String tuday) {
		this.tuday = tuday;
	}
	public String getWday() {
		return wday;
	}
	public void setWday(String wday) {
		this.wday = wday;
	}
	public String getThday() {
		return thday;
	}
	public void setThday(String thday) {
		this.thday = thday;
	}
	public String getFday() {
		return fday;
	}
	public void setFday(String fday) {
		this.fday = fday;
	}
	public void setAvaialbleStatus(String avaialbleStatus) {
		this.avaialbleStatus = avaialbleStatus;
	}
	@Override
	public String toString() {
		return "EmployeeOfficeStatus [sapId=" + sapId + ", employeeName=" + employeeName + ", mday=" + mday + ", tuday="
				+ tuday + ", wday=" + wday + ", thday=" + thday + ", fday=" + fday + ", avaialbleStatus="
				+ avaialbleStatus + "]";
	}
	
	
	
	
	
	

}

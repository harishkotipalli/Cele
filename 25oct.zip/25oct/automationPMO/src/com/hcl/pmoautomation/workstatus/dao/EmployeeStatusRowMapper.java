package com.hcl.pmoautomation.workstatus.dao;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;


import com.hcl.pmoautomation.workstatus.vo.EmployeeOfficeStatus;

public class EmployeeStatusRowMapper implements RowMapper<EmployeeOfficeStatus>, Serializable{ /**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	@Override
	public EmployeeOfficeStatus mapRow(ResultSet neJoingResultSet, int arg1) throws SQLException {
		EmployeeOfficeStatus employeeStatus = new EmployeeOfficeStatus();
		employeeStatus.setSapId((neJoingResultSet.getInt("SAPCODE")));
		employeeStatus.setEmployeeName((neJoingResultSet.getString("NAME")));
		employeeStatus.setMday(neJoingResultSet.getString("MONDAY"));
		employeeStatus.setTuday(neJoingResultSet.getString("TUESDAY"));
		employeeStatus.setWday(neJoingResultSet.getString("WEDNESDAY"));
		employeeStatus.setThday(neJoingResultSet.getString("THURSDAY"));
		employeeStatus.setFday(neJoingResultSet.getString("FRIDAY"));
		return employeeStatus;

}
	
}

package com.hcl.pmoautomation.workstatus.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.hcl.pmoautomation.workstatus.dao.WorkStatusDaoImpl;

import com.hcl.pmoautomation.workstatus.service.WorkStatusServiceImpl;
import com.hcl.pmoautomation.workstatus.vo.EmployeeOfficeStatus;
import com.hcl.pmoautomation.workstatus.vo.EmployeeStatus;

@Controller
@RequestMapping(value =  "pmoAutomation/Employee")
public class workStatusController {
	
	@ExceptionHandler(NullPointerException.class)
    public ModelAndView myError(Exception exception) {
    ModelAndView e = new ModelAndView();
    e.addObject("exception", exception);
    e.setViewName("Login/Error");
    return e;
}
	@Autowired(required = true)
	JdbcTemplate jdbcTemplate;
	
	@RequestMapping(value =  "/workStatus.php")
	public ModelAndView getEmployeeStatusDetails(HttpServletRequest request)throws NullPointerException{
		
		System.out.println(request.getSession().getAttribute("managerId"));
		
		WorkStatusDaoImpl dao = new WorkStatusDaoImpl();
		List<String> date= dao.DateRange();
		System.out.println(date);
		request.setAttribute("date",date);
		
		
		
		
		
		return new ModelAndView("WorkStatus/EmployeeStatus","listOfEmployeeStatus",(new WorkStatusServiceImpl().getAllEmployeeStatus((int) request
				.getSession().getAttribute("managerId"), jdbcTemplate)));
		
	}
	@RequestMapping(value =  "/workNextWeekStatus.php")
	public ModelAndView getNextWeekEmployeeStatus(HttpServletRequest request) throws NullPointerException{
		
		WorkStatusDaoImpl dao = new WorkStatusDaoImpl();
		List<String> date= dao.DateRangeNextWeek();
		System.out.println(date);
		//System.out.println(date);
		request.setAttribute("date",date);
		
		
		return new ModelAndView("WorkStatus/EmployeeNextWeekStatus","listOfNextWeekEmployeeStatus",(new WorkStatusServiceImpl().getAllNextWeekEmployeeStatus((int) request
				.getSession().getAttribute("managerId"),jdbcTemplate)));
		
	}
	@RequestMapping(value="/employeeView.php")
	public ModelAndView getEmployeeView(HttpServletRequest request) throws NullPointerException{
		
		WorkStatusDaoImpl dao = new WorkStatusDaoImpl();
		List<String> date= dao.DateRange();
		System.out.println(date);
		request.setAttribute("date",date);
		

		return new ModelAndView("WorkStatus/EmployeeWeekStatusView","listOfWeekEmployeeStatusView",(new WorkStatusServiceImpl().getEmployeeView(jdbcTemplate)));
		
	}
	
	
	
		
	
	@RequestMapping(value =  "/submitStatus.php",method=RequestMethod.POST)

    public String SubmitStatus(HttpServletRequest request,
    		HttpServletResponse response) throws ServletException, IOException 
    {
		try{
		String sapid=request.getParameter("sapAdmin"+request.getParameter("sapHid"));
		System.out.println(sapid);
		String monDATE=	request.getParameter("mon");
		System.out.println(monDATE);
		String mon=	request.getParameter("workfrommon");
		System.out.println(mon);
			String tue=	request.getParameter("workfromtu");
			System.out.println(tue);
			String wed=	request.getParameter("workfromw");
			String thu=	request.getParameter("workfromth");
			String fri=	request.getParameter("workfromf");
			
			String updQuery = "call mydb.pmo_work_area_proc(?,?,?,?,?,?,?);";
			this.jdbcTemplate.update(updQuery,  new Object[] {sapid,mon,tue,wed,thu,fri,monDATE});
	System.out.println("updateactintrack------------"+updQuery);
    }
	catch (Exception e) 
	{
		return "forward:../../pmoAutomation/Login/errorPage.php";
	}
			return "forward:../../pmoAutomation/Employee/workStatus.php";

    	}
	
	@RequestMapping(value =  "/submitNextWeekStatus.php",method=RequestMethod.POST)
    public String SubmitNextWeekStatus(HttpServletRequest request,
    		HttpServletResponse response) throws ServletException, IOException 
    {
		try{
		String sapid=request.getParameter("sapAdmin"+request.getParameter("sapHid"));
		System.out.println(sapid);
		String monDATE=	request.getParameter("mon");
		System.out.println(monDATE);
		String mon=	request.getParameter("workfrommon");
		System.out.println(mon);
			String tue=	request.getParameter("workfromtu");
			System.out.println(tue);
			String wed=	request.getParameter("workfromw");
			String thu=	request.getParameter("workfromth");
			String fri=	request.getParameter("workfromf");
			
			String updQuery = "call mydb.pmo_work_area_proc(?,?,?,?,?,?,?);";
			this.jdbcTemplate.update(updQuery,  new Object[] {sapid,mon,tue,wed,thu,fri,monDATE});
	System.out.println("updateactintrack------------"+updQuery);
    }
	catch (Exception e) 
	{
		return "forward:../../pmoAutomation/Login/errorPage.php";
	}
			return "forward:../../pmoAutomation/Employee/workNextWeekStatus.php";

    	}
	
	
}

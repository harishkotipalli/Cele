package com.hcl.pmoautomation.workstatus.dao;

public interface EmployeeStatussql {
	public final String getEmployeedetails ="select pmo_details.SAPCODE,pmo_details.NAME,pmo_work_area.MONDAY,"
			+"pmo_work_area.TUESDAY,pmo_work_area.WEDNESDAY,pmo_work_area.THURSDAY,pmo_work_area.FRIDAY "
			+"from mydb.pmo_work_area, mydb.pmo_details "
			 +"where pmo_work_area.SAPCODE in(select pmo_details.SAPCODE from mydb.pmo_details where pmo_details.RM_SAPCODE=? )"
			+"and pmo_work_area.SAPCODE= pmo_details.SAPCODE and pmo_work_area.WEEK_START_DATE=?";	
	
	

	/*public final String getEmployeedetailsview = "select pmo_details.SAPCODE,pmo_details.NAME,pmo_work_area.MONDAY,"
			+"pmo_work_area.TUESDAY,pmo_work_area.WEDNESDAY,pmo_work_area.THURSDAY,pmo_work_area.FRIDAY"
			+ " from mydb.pmo_work_area, mydb.pmo_details "
			+ "where pmo_work_area.WEEK_START_DATE=? "
			+ "and pmo_work_area.SAPCODE= pmo_details.SAPCODE";*/ 
	
	public final String getEmployeedetailsview ="select pmo_details.NAME from mydb.pmo_details, mydb.pmo_work_area"
			+ " where pmo_details.SAPCODE= pmo_work_area.SAPCODE and pmo_work_area.MONDAY='ODC' and pmo_work_area.WEEK_START_DATE=?";
	public final String getEmployeedetailsviewTu ="select pmo_details.NAME from mydb.pmo_details, mydb.pmo_work_area"
			+ " where pmo_details.SAPCODE= pmo_work_area.SAPCODE and pmo_work_area.TUESDAY='ODC' and pmo_work_area.WEEK_START_DATE=?";
	public final String getEmployeedetailsviewWed ="select pmo_details.NAME from mydb.pmo_details, mydb.pmo_work_area"
			+ " where pmo_details.SAPCODE= pmo_work_area.SAPCODE and pmo_work_area.WEDNESDAY='ODC' and pmo_work_area.WEEK_START_DATE=?";
	public final String getEmployeedetailsviewTh ="select pmo_details.NAME from mydb.pmo_details, mydb.pmo_work_area"
			+ " where pmo_details.SAPCODE= pmo_work_area.SAPCODE and pmo_work_area.THURSDAY='ODC' and pmo_work_area.WEEK_START_DATE=?";
	public final String getEmployeedetailsviewFr ="select pmo_details.NAME from mydb.pmo_details, mydb.pmo_work_area"
			+ " where pmo_details.SAPCODE= pmo_work_area.SAPCODE and pmo_work_area.FRIDAY='ODC' and pmo_work_area.WEEK_START_DATE=?";
}



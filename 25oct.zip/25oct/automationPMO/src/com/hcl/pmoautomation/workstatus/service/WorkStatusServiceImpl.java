package com.hcl.pmoautomation.workstatus.service;

import org.springframework.jdbc.core.JdbcTemplate;

import com.hcl.pmoautomation.workstatus.dao.WorkStatusDaoI;
import com.hcl.pmoautomation.workstatus.dao.WorkStatusDaoImpl;
import com.hcl.pmoautomation.workstatus.vo.EmployeeStatus;

public class WorkStatusServiceImpl implements WorkStatusServiceI {

	@Override
	public EmployeeStatus getAllEmployeeStatus(int managerId, JdbcTemplate jdbcTemplet) {
		WorkStatusDaoI workStatusDaoI = new WorkStatusDaoImpl ();
		return workStatusDaoI.getAllEmployeeStatus(managerId, jdbcTemplet);
	}

	@Override
	public EmployeeStatus getAllNextWeekEmployeeStatus(int managerId, JdbcTemplate jdbcTemplet) {
		WorkStatusDaoI workStatusDaoI = new WorkStatusDaoImpl ();
		return workStatusDaoI.getAllEmployeeNextWeekStatus(managerId, jdbcTemplet);
	}

	@Override
	public EmployeeStatus getEmployeeView(JdbcTemplate jdbcTemplet) {
		WorkStatusDaoI workStatusDaoI = new WorkStatusDaoImpl ();
		return workStatusDaoI.getAllEmployeeViewMon(jdbcTemplet) ;
	}

}

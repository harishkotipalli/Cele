package com.hcl.pmoautomation.workstatus.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;



import com.hcl.pmoautomation.workstatus.vo.EmployeeOfficeStatus;
import com.hcl.pmoautomation.workstatus.vo.EmployeeStatus;


public interface WorkStatusDaoI {
	
	public EmployeeStatus getAllEmployeeStatus(int managerId,JdbcTemplate jdbcTemplet);
	public List<EmployeeOfficeStatus> getAllNewEmployeeStatus(int managerId,JdbcTemplate jdbcTemplet);
	public EmployeeStatus getAllEmployeeNextWeekStatus(int managerId, JdbcTemplate jdbcTemplet);
	public List<EmployeeOfficeStatus> getAllNewEmployeeNextWeekStatus(int managerId,JdbcTemplate jdbcTemplet);
	public EmployeeStatus getAllEmployeeViewMon(JdbcTemplate jdbcTemplet);
	public List<EmployeeOfficeStatus> getAllNewEmployeeViewMon(JdbcTemplate jdbcTemplet);
	public EmployeeStatus getAllEmployeeViewTue(JdbcTemplate jdbcTemplet);
	public List<EmployeeOfficeStatus> getAllNewEmployeeViewTue(JdbcTemplate jdbcTemplet);
	public EmployeeStatus getAllEmployeeViewWed(JdbcTemplate jdbcTemplet);
	public List<EmployeeOfficeStatus> getAllNewEmployeeViewWed(JdbcTemplate jdbcTemplet);
	public EmployeeStatus getAllEmployeeViewTh(JdbcTemplate jdbcTemplet);
	public List<EmployeeOfficeStatus> getAllNewEmployeeViewTh(JdbcTemplate jdbcTemplet);
	public EmployeeStatus getAllEmployeeViewFr(JdbcTemplate jdbcTemplet);
	public List<EmployeeOfficeStatus> getAllNewEmployeeViewFri(JdbcTemplate jdbcTemplet);

}

package com.hcl.pmoautomation.workstatus.vo;

import java.util.List;



public class EmployeeStatus {
	
	
	List<EmployeeOfficeStatus> employeOfficeStatus;
	List<EmployeeOfficeStatus> employeeNextOfficeStatus;
	List<EmployeeOfficeStatus> employeeViewMon;
	List<EmployeeOfficeStatus> employeeViewTue;
	List<EmployeeOfficeStatus> employeeViewWed;
	List<EmployeeOfficeStatus> employeeViewTh;
	List<EmployeeOfficeStatus> employeeViewFri;
	

	public List<EmployeeOfficeStatus> getEmployeOfficeStatus() {
		return employeOfficeStatus;
	}

	public void setEmployeOfficeStatus(List<EmployeeOfficeStatus> employeOfficeStatus) {
		this.employeOfficeStatus = employeOfficeStatus;
	}
     
	public List<EmployeeOfficeStatus> getEmployeeNextOfficeStatus() {
		return employeeNextOfficeStatus;
	}

	public void setEmployeeNextOfficeStatus(List<EmployeeOfficeStatus> employeeNextOfficeStatus) {
		this.employeeNextOfficeStatus = employeeNextOfficeStatus;
	}
	

	

	public List<EmployeeOfficeStatus> getEmployeeViewMon() {
		return employeeViewMon;
	}

	public void setEmployeeViewMon(List<EmployeeOfficeStatus> employeeViewMon) {
		this.employeeViewMon = employeeViewMon;
	}

	public List<EmployeeOfficeStatus> getEmployeeViewTue() {
		return employeeViewTue;
	}

	public void setEmployeeViewTue(List<EmployeeOfficeStatus> employeeViewTue) {
		this.employeeViewTue = employeeViewTue;
	}

	public List<EmployeeOfficeStatus> getEmployeeViewWed() {
		return employeeViewWed;
	}

	public void setEmployeeViewWed(List<EmployeeOfficeStatus> employeeViewWed) {
		this.employeeViewWed = employeeViewWed;
	}

	public List<EmployeeOfficeStatus> getEmployeeViewTh() {
		return employeeViewTh;
	}

	public void setEmployeeViewTh(List<EmployeeOfficeStatus> employeeViewTh) {
		this.employeeViewTh = employeeViewTh;
	}

	public List<EmployeeOfficeStatus> getEmployeeViewFri() {
		return employeeViewFri;
	}

	public void setEmployeeViewFri(List<EmployeeOfficeStatus> employeeViewFri) {
		this.employeeViewFri = employeeViewFri;
	}

	@Override
	public String toString() {
		return "EmployeeStatus [employeOfficeStatus=" + employeOfficeStatus + ", employeeNextOfficeStatus="
				+ employeeNextOfficeStatus + ", employeeViewMon=" + employeeViewMon + ", employeeViewTue="
				+ employeeViewTue + ", employeeViewWed=" + employeeViewWed + ", employeeViewTh=" + employeeViewTh
				+ ", employeeViewFri=" + employeeViewFri + "]";
	}

	
	}

	

	
	



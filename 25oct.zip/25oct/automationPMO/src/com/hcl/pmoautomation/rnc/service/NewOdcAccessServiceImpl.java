package com.hcl.pmoautomation.rnc.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.hcl.pmoautomation.rnc.dao.OdcAccessDaoI;
import com.hcl.pmoautomation.rnc.vo.NewJoineeOdcAccess;

public class NewOdcAccessServiceImpl implements OdcAccessServiceI {
  @Autowired
  OdcAccessDaoI odcAccessDaoI;
  
  @Override
	public List<Map<String, Object>> getEmployee(int sapcode,
			JdbcTemplate jdbcTemplate) {
	
		return odcAccessDaoI.getEmployee(sapcode,jdbcTemplate);
	}

	@Override
	public int addNewJoineeOdcdetails(NewJoineeOdcAccess odc,String gpn,JdbcTemplate jdbcTemplate) {
		
		return odcAccessDaoI.addNewJoineeOdcdetails(odc,gpn,jdbcTemplate);
	}

	
	

}

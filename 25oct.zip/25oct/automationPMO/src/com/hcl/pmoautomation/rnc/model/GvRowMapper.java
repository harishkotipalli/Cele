package com.hcl.pmoautomation.rnc.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.hcl.pmoautomation.rnc.vo.Bgv;

public class GvRowMapper implements RowMapper<Bgv>{
	//bgv.EMP_FIRST_NAME,bgv.EMP_LAST_NAME,gpn_initiation.GPN,bgv.SAP_ID,bgv.COUNTRY
	
	@Override
	 public Bgv mapRow(ResultSet resultSet, int line) throws SQLException {
	  GvExtractor gvExtractor = new GvExtractor();
	  return  gvExtractor.extractData(resultSet);
	}

}

package com.hcl.pmoautomation.rnc.model;

public class NDAActivFlagCheck {
	String activeflag;

	public String getActiveflag() {
		return activeflag;
	}

	public void setActiveflag(String activeflag) {
		this.activeflag = activeflag;
	}

	@Override
	public String toString() {
		return activeflag ;
	}
	

}

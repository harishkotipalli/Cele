package com.hcl.pmoautomation.rnc.vo;
import java.sql.Timestamp;

public class Resource_amendments {
	
	private static final String Requested_type = null;
	private String Request_type;
	private String Requestor_Name_from_delivery;
	private Timestamp Requested_date;
	private String Reason_for_Leaving;
	private Boolean Snow_Ticket_Creation_Flag;
	private Timestamp Snow_Ticket_Submitted_Date;
	private String Ticket_No;
	private String Ticket_Status;
	private Timestamp Follow_up_Mail_Date_Day1;
	private Timestamp Follow_up_Mail_Date_Day2;
	private Timestamp Follow_up_Mail_Date_Day3;
	private Timestamp Escalation_Mail_Date_Day1;
	private Timestamp Escalation_Mail_Date_Day2;
	private Timestamp Snow_Ticket_Completed_Date;
	private Timestamp GPN_Termonation_Date;
	private String Remarks;
	private String RSA_Submitted;
	private String VDI_Status;
	private Timestamp VDI_Revoked_Date;
	private String Current_OU_Code;
	private String Current_OU_Description;
	private String NEW_OU_Code;
	private String NEW_OU_Description;
	private String Reason_For_OUchange;
	private String LM_Approval;
	private String Reportong_Date;
	private String Type_Of_Transfer;
	private String Access_Revoke_From_RNC;
	private String Admin_ARC;
	private String IT_ARC;
	private String Physical_ARC_Date;
	private String Logical_ARC_Date;
	
	public void setRequested_Type(String Requested_type)
	{
		this.Request_type=Requested_type;
		
	}
	public String getRequested_type() {
		return Requested_type;
	}
	public void setRequestor_Name_from_delivery(String Requestor_Name_from_delivery)
	{
		this.Requestor_Name_from_delivery=Requestor_Name_from_delivery;
		
	}
	public String getRequest_type() {
		return Request_type;
	}
	public void setRequest_type(String request_type) {
		Request_type = request_type;
	}
	public String getCurrent_OU_Code() {
		return Current_OU_Code;
	}
	public void setCurrent_OU_Code(String current_OU_Code) {
		Current_OU_Code = current_OU_Code;
	}
	public String getCurrent_OU_Description() {
		return Current_OU_Description;
	}
	public void setCurrent_OU_Description(String current_OU_Description) {
		Current_OU_Description = current_OU_Description;
	}
	public String getNEW_OU_Code() {
		return NEW_OU_Code;
	}
	public void setNEW_OU_Code(String nEW_OU_Code) {
		NEW_OU_Code = nEW_OU_Code;
	}
	public String getNEW_OU_Description() {
		return NEW_OU_Description;
	}
	public void setNEW_OU_Description(String nEW_OU_Description) {
		NEW_OU_Description = nEW_OU_Description;
	}
	public String getReason_For_OUchange() {
		return Reason_For_OUchange;
	}
	public void setReason_For_OUchange(String reason_For_OUchange) {
		Reason_For_OUchange = reason_For_OUchange;
	}
	public String getLM_Approval() {
		return LM_Approval;
	}
	public void setLM_Approval(String lM_Approval) {
		LM_Approval = lM_Approval;
	}
	public String getReportong_Date() {
		return Reportong_Date;
	}
	public void setReportong_Date(String reportong_Date) {
		Reportong_Date = reportong_Date;
	}
	public String getType_Of_Transfer() {
		return Type_Of_Transfer;
	}
	public void setType_Of_Transfer(String type_Of_Transfer) {
		Type_Of_Transfer = type_Of_Transfer;
	}
	public String getAccess_Revoke_From_RNC() {
		return Access_Revoke_From_RNC;
	}
	public void setAccess_Revoke_From_RNC(String access_Revoke_From_RNC) {
		Access_Revoke_From_RNC = access_Revoke_From_RNC;
	}
	public String getAdmin_ARC() {
		return Admin_ARC;
	}
	public void setAdmin_ARC(String admin_ARC) {
		Admin_ARC = admin_ARC;
	}
	public String getIT_ARC() {
		return IT_ARC;
	}
	public void setIT_ARC(String iT_ARC) {
		IT_ARC = iT_ARC;
	}
	public String getPhysical_ARC_Date() {
		return Physical_ARC_Date;
	}
	public void setPhysical_ARC_Date(String physical_ARC_Date) {
		Physical_ARC_Date = physical_ARC_Date;
	}
	public String getLogical_ARC_Date() {
		return Logical_ARC_Date;
	}
	public void setLogical_ARC_Date(String logical_ARC_Date) {
		Logical_ARC_Date = logical_ARC_Date;
	}
	public static String getRequestedType() {
		return Requested_type;
	}
	public String getRequestor_Name_from_delivery() {
		return Requestor_Name_from_delivery;
	}
	
	public void setRequested_date(Timestamp Requested_date)
	{
		this.Requested_date=Requested_date;
		
	}
	public Timestamp getRequested_date() {
		return Requested_date;
	}
	public void setReason_for_Leaving(String Reason_for_Leaving)
	{
		this.Reason_for_Leaving=Reason_for_Leaving;
		
	}
	public String getReason_for_Leaving() {
		return Reason_for_Leaving;
	}
	public void setSnow_Ticket_Creation_Flag(Boolean Snow_Ticket_Creation_Flag)
	{
		this.Snow_Ticket_Creation_Flag=Snow_Ticket_Creation_Flag;
		
	}
	public Boolean getSnow_Ticket_Creation_Flag() {
		return Snow_Ticket_Creation_Flag;
	}
	
	public void setSnow_Ticket_Submitted_Date(Timestamp Snow_Ticket_Submitted_Date)
	{
		this.Snow_Ticket_Submitted_Date=Snow_Ticket_Submitted_Date;
		
	}
	public Timestamp getSnow_Ticket_Submitted_Date() {
		return Snow_Ticket_Submitted_Date;
	}
	public void setTicket_No(String Ticket_No)
	{
		this.Ticket_No=Ticket_No;
		
	}
	public String getTicket_No() {
		return Ticket_No;
	}
	public void setTicket_Status(String  Ticket_Status)
	{
		this.Ticket_Status=Ticket_Status;
		
	}
	public String getTicket_Status() {
		return Ticket_Status;
	}
	public void setFollow_up_Mail_Date_Day1(Timestamp  Follow_up_Mail_Date_Day1)
	{
		this. Follow_up_Mail_Date_Day1= Follow_up_Mail_Date_Day1;
		
	}
	public Timestamp getFollow_up_Mail_Date_Day1() {
		return  Follow_up_Mail_Date_Day1;
	}
	public void setFollow_up_Mail_Date_Day2(Timestamp  Follow_up_Mail_Date_Day2)
	{
		this. Follow_up_Mail_Date_Day2= Follow_up_Mail_Date_Day2;
		
	}
	public Timestamp getFollow_up_Mail_Date_Day2() {
		return  Follow_up_Mail_Date_Day2;
	}
	public void setFollow_up_Mail_Date_Day3(Timestamp Follow_up_Mail_Date_Day3)
	{
		this.Follow_up_Mail_Date_Day3= Follow_up_Mail_Date_Day3;
		
	}
	public Timestamp getFollow_up_Mail_Date_Day3() {
		return  Follow_up_Mail_Date_Day3;
	}
	public void setEscalation_Mail_Date_Day1(Timestamp  Escalation_Mail_Date_Day1)
	{
		this.Escalation_Mail_Date_Day1= Escalation_Mail_Date_Day1;
		
	}
	public Timestamp getEscalation_Mail_Date_Day1() {
		return  Escalation_Mail_Date_Day1;
	}
	public void setEscalation_Mail_Date_Day2(Timestamp  Escalation_Mail_Date_Day2)
	{
		this.Escalation_Mail_Date_Day1= Escalation_Mail_Date_Day2;
		
	}
	public Timestamp getEscalation_Mail_Date_Day2() {
		return  Escalation_Mail_Date_Day2;
	}
	public void setSnow_Ticket_Completed_Date(Timestamp   Snow_Ticket_Completed_Date)
	{
		this.Snow_Ticket_Completed_Date= Snow_Ticket_Completed_Date;
		
	}
	public Timestamp getSnow_Ticket_Completed_Date() {
		return Snow_Ticket_Completed_Date;
	}
	public void setGPN_Termonation_Date(Timestamp GPN_Termonation_Date)
	{
		this.GPN_Termonation_Date= GPN_Termonation_Date;
		
	}
	public Timestamp getGPN_Termonation_Date() {
		return GPN_Termonation_Date;
	}
	public void setRemarks(String Remarks)
	{
		this.Remarks=Remarks;
		
	}
	public String  getRemarks() {
		return Remarks;
	}
	public void setRSA_Submitted(String RSA_Submitted)
	{
		this.RSA_Submitted=RSA_Submitted;
		
	}
	public String getRSA_Submitted() {
		return RSA_Submitted;
	}
	public void setVDI_Status(String VDI_Status)
	{
		this.VDI_Status=VDI_Status;
		
	}
	public String getVDI_Status() {
		return VDI_Status;
	}
	public void setVDI_Revoked_Date(Timestamp VDI_Revoked_Date)
	{
		this.VDI_Revoked_Date=VDI_Revoked_Date;
		
	}
	public Timestamp getVDI_Revoked_Date() {
		return VDI_Revoked_Date;
	}
	
}

package com.hcl.pmoautomation.rnc.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.hcl.pmoautomation.ot.vo.*;

public class RasExtractor implements ResultSetExtractor<RAS>{

	 public RAS extractData(ResultSet rs) throws SQLException,
	   DataAccessException {
	  
	  RAS ras = new RAS();
	  
	  ras.getRepMgrName();
	  
	 	return ras;
		
	 }
}

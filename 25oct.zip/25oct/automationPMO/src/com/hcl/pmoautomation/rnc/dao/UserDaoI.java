package com.hcl.pmoautomation.rnc.dao;

public interface UserDaoI {
	
	public boolean isValidUser(String userName,String password,String role);

}

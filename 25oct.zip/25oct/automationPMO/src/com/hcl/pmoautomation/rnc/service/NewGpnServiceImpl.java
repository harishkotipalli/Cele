package com.hcl.pmoautomation.rnc.service;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.hcl.pmoautomation.rnc.dao.NewGpnDaoImpl;

public class NewGpnServiceImpl {

	public List<Object[]> getGpnDetails(JdbcTemplate jdbcTemplate) {
		NewGpnDaoImpl impl=new NewGpnDaoImpl();
		return impl.getGpnDetails(jdbcTemplate);
	}
	public List<Object[]> getNDADetails(JdbcTemplate jdbcTemplate) {
		NewGpnDaoImpl impl=new NewGpnDaoImpl();
		return impl.getNDADetails(jdbcTemplate);
	}
	public boolean saveSnowTicketDetails(JdbcTemplate jdbcTemplate, int parseInt2, int parseInt) {
		NewGpnDaoImpl impl=new NewGpnDaoImpl();
		return impl.saveSnowTicketDetails(jdbcTemplate,parseInt2,parseInt);
		
		
	}

	
	public boolean savegpnbgv(JdbcTemplate jdbcTemplate, String gpnNumber, String gpnCreationDate, String gpnStartDate,
			String gpnendDate, int parseInt) {
		NewGpnDaoImpl impl=new NewGpnDaoImpl();
		return impl.saveGpnBgv(jdbcTemplate,gpnNumber,gpnCreationDate,gpnStartDate,gpnendDate,parseInt);
		
	}
	public boolean savegpnnumber(JdbcTemplate jdbcTemplate, int parseInt, String gpnCreationDate, String gpnStartDate,
			String gpnendDate, int parseInt2) {
		NewGpnDaoImpl impl=new NewGpnDaoImpl();
		
		return impl.saveGpnDetails(jdbcTemplate,parseInt,gpnCreationDate,gpnStartDate,gpnendDate,parseInt2);
		
		
	}


	public boolean savegpnras(JdbcTemplate jdbcTemplate, int parseInt) {
		NewGpnDaoImpl impl=new NewGpnDaoImpl();
		return impl.saveGpnStatusRas(jdbcTemplate,parseInt);
	}

	public List<Object[]> getGpnPmo(JdbcTemplate jdbcTemplate) {
		NewGpnDaoImpl getGpnPmo = new NewGpnDaoImpl();
		return getGpnPmo.getGpnPmo(jdbcTemplate);
	}

	

	

	

}

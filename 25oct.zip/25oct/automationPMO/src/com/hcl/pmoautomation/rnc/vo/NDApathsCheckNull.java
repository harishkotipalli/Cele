package com.hcl.pmoautomation.rnc.vo;

public class NDApathsCheckNull {

	
	String uploadone;
	String uploadtwo;
	String uploadthree;
	String uploadfour;
	String uploadfive;
	String linkflagcheck;
	public String getUploadone() {
		return uploadone;
	}
	public void setUploadone(String uploadone) {
		this.uploadone = uploadone;
	}
	public String getUploadtwo() {
		return uploadtwo;
	}
	public void setUploadtwo(String uploadtwo) {
		this.uploadtwo = uploadtwo;
	}
	public String getUploadthree() {
		return uploadthree;
	}
	public void setUploadthree(String uploadthree) {
		this.uploadthree = uploadthree;
	}
	public String getUploadfour() {
		return uploadfour;
	}
	public void setUploadfour(String uploadfour) {
		this.uploadfour = uploadfour;
	}
	public String getUploadfive() {
		return uploadfive;
	}
	public void setUploadfive(String uploadfive) {
		this.uploadfive = uploadfive;
	}
	
	public String getLinkflagcheck() {
		return linkflagcheck;
	}
	public void setLinkflagcheck(String linkflagcheck) {
		this.linkflagcheck = linkflagcheck;
	}
	@Override
	public String toString() {
		return "NDApathsCheckNull [uploadone=" + uploadone + ", uploadtwo=" + uploadtwo + ", uploadthree=" + uploadthree
				+ ", uploadfour=" + uploadfour + ", uploadfive=" + uploadfive + ", linkflagcheck=" + linkflagcheck
				+ "]";
	}
	
	
}

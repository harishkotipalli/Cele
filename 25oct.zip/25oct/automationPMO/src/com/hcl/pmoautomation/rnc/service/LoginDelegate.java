package com.hcl.pmoautomation.rnc.service;

import java.sql.SQLException;

public class LoginDelegate {
	
	private UserServiceI userServicei;

	public UserServiceI getUserservicei() {
		return userServicei;
	}

	public void setUserservicei(UserServiceI userservicei) {
		this.userServicei = userservicei;
	}
	 public boolean isValidUser(String userName,String password,String role) throws SQLException {
		return userServicei.isValidUser(userName, password, role);
	}

}

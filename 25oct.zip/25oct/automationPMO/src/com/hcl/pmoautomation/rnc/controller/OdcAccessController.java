package com.hcl.pmoautomation.rnc.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindException;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleFormController;

import com.hcl.pmoautomation.ot.dao.ExcaliburDaoImpl;
import com.hcl.pmoautomation.rnc.dao.NewOdcAccessImpl;
import com.hcl.pmoautomation.rnc.dao.OdcAccessDaoI;
import com.hcl.pmoautomation.rnc.service.RncNewOdcServiceImpl;
import com.hcl.pmoautomation.rnc.vo.NewJoineeOdcAccess;

@Controller
@RequestMapping("pmoautomation/NewOdcAccessController")
public class OdcAccessController {
	@Autowired
	private OdcAccessDaoI odcdao;
	
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@RequestMapping(value = "/newodcaccess.php", method = RequestMethod.GET)
	public ModelAndView newContact(ModelAndView model) {
		NewJoineeOdcAccess newAccess = new NewJoineeOdcAccess();
		 model.addObject("odc", newAccess);
		 model.setViewName("Access/NewOdcAccess");
		return model;
		
	}
	

	@RequestMapping(value = "/save.php", method = RequestMethod.POST)
	public String addContact(@ModelAttribute(value="odc") NewJoineeOdcAccess newJoineeOdcAccess,HttpServletRequest request,HttpServletResponse response) {
		NewOdcAccessImpl	daoImpl = new NewOdcAccessImpl();
		String gpnnum=daoImpl.getgpn(jdbcTemplate,
				(String) request.getParameter("sapcode"));
		System.out.println("gpnfromjsp to controller "+gpnnum);
		boolean result=odcdao.addNewJoineeOdcdetails(newJoineeOdcAccess,gpnnum, jdbcTemplate)>0?true:false;
		/*System.out.println(newJoineeOdcAccess);*/
		
	
		if (result){
			request.setAttribute("resultSaveNewJoineeOdcdetails", "Saved Successfully!!!");
		}else{
			request.setAttribute("resultSaveNewJoineeOdcdetails", "Problem in Saving the data!!!");
		}
		
		return "Access/Home";
		
	}
	
	@RequestMapping(value = "/getEmpName.php", method = RequestMethod.POST)
	public void getEmpName(HttpServletRequest req,HttpServletResponse response) throws IOException {
		
		String sapCode=req.getParameter("sapCode");
		String empName=new NewOdcAccessImpl().getEmp(jdbcTemplate, sapCode);
		response.getWriter().print("<form:input path='empName' value="+empName+" />");
	
		
		
	}
	@RequestMapping(value = "/getemployeeName.php", method = RequestMethod.GET)
	public void getemployeeName(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

	  NewOdcAccessImpl	daoImpl = new NewOdcAccessImpl();
System.out.println("controller sapcode"+(String) request.getParameter("sapCode"));
		response.getWriter().print(
				daoImpl.getemployeename(jdbcTemplate,
						(String) request.getParameter("sapCode")));
		
	}
	@RequestMapping(value = "/getprojectName.php", method = RequestMethod.GET)
	public void getprojectName(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

	  NewOdcAccessImpl	daoImpl = new NewOdcAccessImpl();
System.out.println("controller sapcode1"+(String) request.getParameter("sapCode"));
		response.getWriter().print(
				daoImpl.getprojectname(jdbcTemplate,
						(String) request.getParameter("sapCode")));
		
	}

	@RequestMapping(value = "/getgpnnumber.php", method = RequestMethod.GET)
	public void getgpn(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

	  NewOdcAccessImpl	daoImpl = new NewOdcAccessImpl();
System.out.println("controller sapcode"+(String) request.getParameter("sapCode"));
		response.getWriter().print(
				daoImpl.getgpn(jdbcTemplate,
						(String) request.getParameter("sapCode")));
		
	}
	@RequestMapping(value = "/getlocation.php", method = RequestMethod.GET)
	public void getlocation(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

	  NewOdcAccessImpl	daoImpl = new NewOdcAccessImpl();
System.out.println("controller sapcode"+(String) request.getParameter("sapCode"));
		response.getWriter().print(
				daoImpl.getlocation(jdbcTemplate,
						(String) request.getParameter("sapCode")));
		
	}
	/*public Map referenceData(HttpServletRequest request) throws Exception{
		
		Map referenceData = new HashMap();
		
		List<String> type = new ArrayList<String>();
		type.add("PHYSICAL ACCESS");
		type.add("LOGICAL ACCESS");
		type.add("BOTH PHYSICAL/LOGICAL");
		referenceData.put("odcaccesstype", type);
		
		Map<String,String>  reasonForAccess = new LinkedHashMap<String,String>();
		reasonForAccess.put("NEW ODC ACCESS REQUEST", "new odc access request");
		reasonForAccess.put("FORGOT ID ", "forgot id");
		reasonForAccess.put("LOST ID","lost id");
		referenceData.put("reasonforaccess",reasonForAccess);
		
		 Map<String,String> buildingName = new LinkedHashMap<String,String>();
		 buildingName.put("BANGALORE SEZ", "bangalore sez");
		 buildingName.put("CHENNAI,NAVALLUR", "chennai navallur");
		 buildingName.put("PUNE", "pune");
		 referenceData.put("buildingname", buildingName);
		 
		 Map<String,String> towerNumber = new LinkedHashMap<String,String>();
		 towerNumber.put("TOWER-3", "tower-3");
		 towerNumber.put("ETA-3", "eta-3");
		 towerNumber.put("PUNE", "pune");
		 referenceData.put("towernumber", towerNumber);
		 
		 Map<String,String> floorNumber = new LinkedHashMap<String,String>();
		 floorNumber.put("GROUND FLOOR", "ground floor");
		 floorNumber.put("FIRST FLOOR", "first floor");
		 floorNumber.put("SECOND FLOOR", "second floor");
		 floorNumber.put("THIRD FLOOR", "third floor");
		 referenceData.put("floornumber", floorNumber);
		 
		 
		 Map<String,String> odcNumber = new LinkedHashMap<String,String>();
		 odcNumber.put("1", "1");
		 odcNumber.put("1A", "1a");
		 odcNumber.put("1B", "1b");
		 odcNumber.put("2", "2");
		 odcNumber.put("4", "4");
		 referenceData.put("odcnumber", odcNumber);
		
		
		return referenceData;
		
	}*/
	
	@RequestMapping(value = "/newOdcAccessApproval.php", method = RequestMethod.GET)
	public String newODCAccessApproval(HttpServletRequest request) {
		
		RncNewOdcServiceImpl impl=new RncNewOdcServiceImpl();
/*		request.setAttribute("getODCDetails",impl.getODC_Details(jdbcTemplate));
		request.setAttribute("bgvIdDetails", impl.getBgvId_Details(jdbcTemplate));
		request.setAttribute("empClientDetails", impl.getEmpClient_Details(jdbcTemplate) );*/
		request.setAttribute("getDataForRNCApproval",impl.getDataForRNCApproval(jdbcTemplate) );
		
		return "Access/RncNewOdc";
		
	}
	
	@RequestMapping(value = "/saveEmpClient.php", method = RequestMethod.GET)
	public String saveEmpClient(HttpServletRequest request) {
		
		Object[] odcDetail=(Object[]) request.getSession().getAttribute("odcDetail");
		
		RncNewOdcServiceImpl impl=new RncNewOdcServiceImpl();
		impl.saveEmpClient(jdbcTemplate,odcDetail);
//		return "redirect:../../../../pmoautomation/NewOdcAccessController/newOdcAccessApproval.php";
		return "forward:../../pmoAutomation/Login/generalHomePage.php";
		//request.setAttribute("getDataForRNCApproval",impl.getDataForRNCApproval(jdbcTemplate) );
		
		//return "Access/RncNewOdc";
		
	}

	

	

}

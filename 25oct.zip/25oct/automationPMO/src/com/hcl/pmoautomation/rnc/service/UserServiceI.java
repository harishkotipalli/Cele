package com.hcl.pmoautomation.rnc.service;

public interface UserServiceI {
	
		
		public boolean isValidUser(String userName,String password,String role);

	}



package com.hcl.pmoautomation.rnc.model;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;
import com.hcl.pmoautomation.rnc.vo.*;

public class BgvExtractor implements ResultSetExtractor<Bgv>{

 public Bgv extractData(ResultSet rs) throws SQLException,
   DataAccessException {
  
  Bgv bgv = new Bgv();
  bgv.setId(rs.getInt("id"));
  bgv.setRequest_Type(rs.getString("request_Type"));
	bgv.setRegion(rs.getString("region"));
	bgv.setClient_Hiring_Manager_Gpn_No(rs.getInt("client_Hiring_Manager_Gpn_No"));
	bgv.setClient_Hiring_Manager_Mail_Id(rs.getString("client_Hiring_Manager_Mail_Id"));
	bgv.setPreviously_Worked_With_Client(rs.getString("previously_Worked_With_Client"));
	bgv.setEmp_First_Name(rs.getString("emp_First_Name"));
	bgv.setEmp_Last_Name(rs.getString("emp_Last_Name"));
	bgv.setDate_Of_Birth(rs.getTimestamp("date_Of_Birth"));
	bgv.setCorrespondence_Language(rs.getString("correspondence_Language"));
	bgv.setNationality(rs.getString("nationality"));
	bgv.setGender(rs.getString("gender"));
	bgv.setAssignment_From(rs.getTimestamp("assignment_From"));
	bgv.setAssignment_To(rs.getTimestamp("assignment_To"));
	bgv.setOu_Code(rs.getString("ou_Code"));
	bgv.setProject_Name(rs.getString("project_Name"));
  return bgv;
 }
 
  

}

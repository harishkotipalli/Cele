package com.hcl.pmoautomation.rnc.model;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.hcl.pmoautomation.rnc.vo.*;


public class GvExtractor implements ResultSetExtractor<Bgv> {
	//bgv.EMP_FIRST_NAME,bgv.EMP_LAST_NAME,gpn_initiation.GPN,bgv.SAP_ID,bgv.COUNTRY
	
	 public Bgv extractData(ResultSet rs) throws SQLException,
	   DataAccessException {
	  Bgv bgv = new Bgv();
	bgv.setEmp_First_Name(rs.getString("emp_First_Name"));
	bgv.setEmp_Last_Name(rs.getString("emp_Last_Name"));
	bgv.setSap_Id(rs.getInt("sap_Id"));
	bgv.setCountry(rs.getString("country"));
	bgv.setGpn(rs.getInt("GPN"));
	
	//gpn.setSnow_Ticket_Init_Date(rs.getTimestamp("snow_Ticket_Init_Date"));	
	//gpn.setPlaced_In_Sharepoint_For_WMA(rs.getString("placed_In_Sharepoint_For_WMA"));
	//gpn.setContract_End_Date(rs.getDate("contract_end_date"));

	  
	  return bgv;
}
}
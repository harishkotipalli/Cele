package com.hcl.pmoautomation.rnc.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.hcl.pmoautomation.rnc.vo.Bgv;
import com.hcl.pmoautomation.rnc.vo.Gpn;

public class GpnRowMapper implements RowMapper<Gpn>{

	@Override
	 public Gpn mapRow(ResultSet resultSet, int line) throws SQLException {
	  GpnExtractor gpnExtractor = new GpnExtractor();
	  return  gpnExtractor.extractData(resultSet);
	}

}

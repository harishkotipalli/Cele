package com.hcl.pmoautomation.rnc.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.hcl.pmoautomation.ot.vo.RAS;

public class RasRowMapper implements RowMapper<RAS> {

	 @Override
	 public RAS mapRow(ResultSet resultSet, int line) throws SQLException {
	  RasExtractor rasExtractor = new RasExtractor();
	  return  rasExtractor.extractData(resultSet);
	 }
	 
}

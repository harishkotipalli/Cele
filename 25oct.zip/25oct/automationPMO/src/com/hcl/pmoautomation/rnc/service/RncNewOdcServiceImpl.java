package com.hcl.pmoautomation.rnc.service;

import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;

import com.hcl.pmoautomation.rnc.dao.RncNewAccessDaoImpl;

public class RncNewOdcServiceImpl {

	public List<Map<String, Object>> getODC_Details(JdbcTemplate jdbcTemplate) {

		RncNewAccessDaoImpl accessDaoImpl = new RncNewAccessDaoImpl();

		return accessDaoImpl.getODC_Details(
				accessDaoImpl.getListOfGpn(jdbcTemplate), jdbcTemplate);

	}
	public List<Map<String, Object>> getBgvId_Details(JdbcTemplate jdbcTemplate) {

		RncNewAccessDaoImpl accessDaoImpl = new RncNewAccessDaoImpl();

		return accessDaoImpl.getBgvId_Details(
				accessDaoImpl.getListOfBGV_ID(jdbcTemplate), jdbcTemplate);
	}
	public List<Map<String, Object>> getEmpClient_Details(JdbcTemplate jdbcTemplate){
		RncNewAccessDaoImpl accessDaoImpl = new RncNewAccessDaoImpl();
		return  accessDaoImpl.getEmpClient_Details(accessDaoImpl.getListOfEMP_CLIENT_ID(jdbcTemplate), jdbcTemplate);
	}
    public List<Object[]> getDataForRNCApproval(JdbcTemplate jdbcTemplate){
		RncNewAccessDaoImpl accessDaoImpl = new RncNewAccessDaoImpl();
		return accessDaoImpl.getDataForRNCApproval( jdbcTemplate );
    	
    }
	public boolean saveEmpClient(JdbcTemplate jdbcTemplate, Object[] odcDetail) {
		RncNewAccessDaoImpl accessDaoImpl = new RncNewAccessDaoImpl();
		return accessDaoImpl.saveEmpClient(jdbcTemplate,odcDetail);
		
	}
}

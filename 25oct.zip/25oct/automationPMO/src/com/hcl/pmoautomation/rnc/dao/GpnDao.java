package com.hcl.pmoautomation.rnc.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;

import com.hcl.pmoautomation.rnc.vo.Bgv;
import com.hcl.pmoautomation.rnc.vo.Gpn;

public interface GpnDao {
	
	  
	  public boolean updateData(String[] gpn, String[] id, String[] gpnCreationDate, String[] startDateList, String[] endDateList,  boolean flagToDecide);
	  //gpn,bgvID, gpnCreationDate, gpnStartDate, contractEndDate,flagToDecide
	  public List<Object[]> getReactList();
	public List<Object[]> getGpnList();
	public void insertGPN(List<Object[]> list);
	public boolean saveSnowTicketNumber(String[] bgvid, String[] snowTicketNumberList);
	boolean updateReactGpn(String[] bgvid, String[] gpnStartDate,
			String[] contractEndDate, boolean flagToDecide);
	boolean updateReactSnowTicketNumber(String[] placedinSharePoint,
			String[] snowTicketNumberList, String[] gpn, String[] bgvid,
			String[] empclientid);
	public List<Object[]> getTermiList();
	public List<Object[]> getTermiDetails(String choose, boolean select , int sap);
	public List<Object[]> getVdiDetails();
	public boolean saveGrsNumber(String[] grsNumber, String[] sapId, boolean flagtodecide);
	boolean saveVdiNumber(String[] vdiNumber, String[] vdi, String[] sapID, boolean flagtodecide );
	public boolean saveTermiInfo(String gpn, String reason, String termiDate);
	public boolean updateTermiData(String[] gpn, String[] physicalAccessRevokeDate, String[] logicalAccessRevokeDate, String[] vdiRevokeDate, String[] rsaSubmitted, String[] notepadSurrender);
	public boolean updateDataBGVTable(String[] gpn, String[] id,
			String[] startDateList, String[] endDateList, boolean flagToDecide);
	public boolean updateTermiSnowTicketNumber(String[] snowTicketNumberList, String[] gpn);
	boolean updateTermiData();
	public boolean saveAllDataDynamically(
			List<ArrayList<String>> readExcelAllDynamically,
			String initiationTableName);
	public List<Map<String, Object>> getAllColumnNamesDynamically(
			String tableName);
	}



package com.hcl.pmoautomation.rnc.dao;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindException;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleFormController;

import com.hcl.pmoautomation.rnc.dao.OdcAccessDaoI;
import com.hcl.pmoautomation.rnc.vo.NewJoineeOdcAccess;
@Controller
@RequestMapping("pmoautomation/NewOdcController")
public class OdcController extends SimpleFormController {

    @Autowired
	private OdcAccessDaoI odcdao;
	
	@RequestMapping(value ="/newodcaccess.php", method = RequestMethod.GET)
	public ModelAndView newContact(ModelAndView model) {
		NewJoineeOdcAccess newAccess = new NewJoineeOdcAccess();
		 model.addObject("odc", newAccess);
		 model.setViewName("NewOdcAccess");
		return model;
		
	}
	
	
	@RequestMapping(value="/save.php")
	@Override
	protected ModelAndView onSubmit(HttpServletRequest request,
			HttpServletResponse response, Object command, BindException errors)
			throws Exception {

//		   int result=odcdao.addNewJoineeOdcdetails((NewJoineeOdcAccess)command);
		System.out.println((NewJoineeOdcAccess)command);
		   return new ModelAndView(getSuccessView(),"result","");
		
	}

}

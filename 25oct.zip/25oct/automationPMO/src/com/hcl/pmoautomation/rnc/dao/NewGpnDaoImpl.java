package com.hcl.pmoautomation.rnc.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.hcl.pmoautomation.bgv.dao.DataBaseQueryBGVdashboard;
import com.hcl.pmoautomation.bgv.model.DownloadPathvo;
import com.hcl.pmoautomation.bgv.model.bgvinitiatetempvo;
import com.hcl.pmoautomation.bgv.utilities.BgvSql;
import com.hcl.pmoautomation.rnc.model.DownloadspathVO;
import com.hcl.pmoautomation.rnc.model.NDAActivFlagCheck;
import com.hcl.pmoautomation.rnc.model.NDAformpath;
import com.hcl.pmoautomation.rnc.vo.Bgv;
import com.hcl.pmoautomation.rnc.vo.NDAdownloadPath;
import com.hcl.pmoautomation.rnc.vo.NDApathsCheckNull;



public class NewGpnDaoImpl {

	public List<Object[]> getGpnDetails(JdbcTemplate jdbcTemplate) {
String sqlquery = DataBaseRNCQuery.QUERY_TO_GET_GPNCREATELIST;
		
		List<Map<String, Object>> maps = jdbcTemplate.queryForList(sqlquery);
		List<Object[]> list = new ArrayList<Object[]>();
		Object[] objects=null;
		for (Map tempMap : maps) {
			objects = new Object[tempMap.size()];
			
			objects[0] = ((int) tempMap.get("sap_Id"));
			objects[1] = ((String) tempMap.get("emp_first_name"));
			objects[2] = ((String) tempMap.get("project_name"));
			objects[3] = ((String) tempMap.get("location"));
			objects[4] = ((String) tempMap.get("country"));
			objects[5] = ((String) tempMap.get("SNOW_TICKET_NO"));
			objects[6] = ((int) tempMap.get("id"));
			
		
			
			list.add(objects);
			System.out.println(tempMap);
			}
		System.out.println(sqlquery);
		System.out.println(list);
		return list;
	}
	public List<Object[]> getNDADetails(JdbcTemplate jdbcTemplate) {
		String sqlquery = DataBaseRNCQuery.QUERY_TO_GET_NDA;
				
				List<Map<String, Object>> maps = jdbcTemplate.queryForList(sqlquery);
				List<Object[]> list = new ArrayList<Object[]>();
				Object[] objects=null;
				for (Map tempMap : maps) {
					objects = new Object[tempMap.size()];
					
					objects[0] = ((int) tempMap.get("sap_Id"));
					objects[1] = ((String) tempMap.get("emp_first_name"));
					objects[2] = ((String) tempMap.get("project_name"));
					objects[3] = ((String) tempMap.get("location"));
					objects[4] = ((String) tempMap.get("country"));
					objects[5] = ((String) tempMap.get("INITIATE_NDA"));
					
					
				
					
					list.add(objects);
				
					}
				
				return list;
			}
	public boolean saveSnowTicketDetails(JdbcTemplate jdbcTemplate,int parseInt2, int parseInt) {
		boolean flag = false;
		flag=jdbcTemplate.update("update gpn_initiation set snow_ticket_creation_date=sysdate(), snow_ticket_no=? where bgv_id=?",
				new Object[]{parseInt2,parseInt})>0?true:false;
				System.out.println(flag);
		return flag;
	}

	public boolean saveGpnDetails(JdbcTemplate jdbcTemplate, int parseInt, String gpnCreationDate, String gpnStartDate,
			String gpnendDate, int parseInt2) {
		boolean flag = false;
		flag=jdbcTemplate.update("Update gpn_initiation set gpn=?,gpn_creation_date=?,gpn_start_date=?,contract_end_date=? ,gpn_status='ACTIVE' where bgv_id=?",
				new Object[]{parseInt,gpnCreationDate,gpnStartDate,gpnendDate,parseInt2})>0?true:false;
				
		return flag;
	}

	public boolean saveGpnBgv(JdbcTemplate jdbcTemplate, String gpnNumber, String gpnCreationDate, String gpnStartDate,
			String gpnendDate, int parseInt) {
		boolean flag = false;
		flag=jdbcTemplate.update("Update bgv set gpn=?,gpn_creation_date=?,gpn_start_date=?,gpn_end_date=? ,gpn_status='ACTIVE' where id=?",
				new Object[]{gpnNumber,gpnCreationDate,gpnStartDate,gpnendDate,parseInt})>0?true:false;
		return flag;
	}

	public boolean saveGpnStatusRas(JdbcTemplate jdbcTemplate, int parseInt) {
		boolean flag = false;
		flag=jdbcTemplate.update("update mydb.ras set ras.GPN_Status='ACTIVE' where ras.SAPCODE=(select bgv.SAP_ID from mydb.bgv where bgv.id= ?)",
				new Object[]{parseInt})>0?true:false;
		return flag;
	}

	public List<Object[]> getGpnPmo(JdbcTemplate jdbcTemplate) {
String sqlquery = DataBaseRNCQuery.QUERY_TO_GET_GPNCOMPLETESTSTUS;
		
		List<Map<String, Object>> maps = jdbcTemplate.queryForList(sqlquery);
		List<Object[]> list = new ArrayList<Object[]>();
		Object[] objects=null;
		for (Map tempMap : maps) {
			objects = new Object[tempMap.size()];
			
			objects[0] = ((int) tempMap.get("sap_Id"));
			objects[1] = ((String) tempMap.get("emp_first_name"));
			objects[2] = ((String) tempMap.get("project_name"));
			objects[3] = ((int) tempMap.get("gpn"));
			objects[4] = ((Date) tempMap.get("gpn_start_date"));
			objects[5] = ((Date) tempMap.get("GPN_END_DATE"));
			
		
			
			list.add(objects);
			System.out.println(tempMap);
			}
		System.out.println(sqlquery);
		System.out.println(list);
		return list;
	
	}


	public List<DownloadspathVO> NDADownloadPath(String country,JdbcTemplate jdbcTemplate) 
	{
		
	 	String sql = DataBaseRNCQuery.QUERY_TO_GET_NDA_path+country+"'";
		
		
		System.out.println(sql);
	   
	    		 List<DownloadspathVO> listaa = jdbcTemplate.query(sql, new RowMapper<DownloadspathVO>() 
		 {
			@Override
			public DownloadspathVO mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				DownloadspathVO dp = new DownloadspathVO();
				dp.setNdaformpath(rs.getString("NDA_FORM_PATH"));
				
				return dp;
			}
	 	
	    });		
	    return listaa;
	    
	    }
	public List<NDAformpath> pathforNDAform(String country,JdbcTemplate jdbcTemplate) 
	{
		String sql = DataBaseRNCQuery.QUERY_TO_GET_NDA_path+country+"'";
		    		 List<NDAformpath> listaa = jdbcTemplate.query(sql, new RowMapper<NDAformpath>() 
	
	    				 {
			@Override
			public NDAformpath mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				NDAformpath path = new NDAformpath();
				path.setPath(rs.getString("NDA_FORM_PATH"));
			return path;
			}
	   });
	    return listaa;
	    
	   }
	public List<Bgv> sapname(String sap,JdbcTemplate jdbcTemplate) 
	{
		String sql = DataBaseRNCQuery.QUERY_TO_GET_sapid_name+sap+"'";
		    		 List<Bgv> listaa = jdbcTemplate.query(sql, new RowMapper<Bgv>() 
	
	    				 {
			@Override
			public Bgv mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				Bgv path = new Bgv();
				path.setSap_Id(rs.getInt("SAP_ID"));
				path.setEmp_First_Name(rs.getString("EMP_FIRST_NAME"));
			return path;
			}
	   });
	    return listaa;
	    
	   }
	
	public List<NDAActivFlagCheck> linkactive(String sap,JdbcTemplate jdbcTemplate) 
	{
		String sql = DataBaseRNCQuery.QUERY_TO_GET_sapid_for_linkchecking+sap+"')";
		    		 List<NDAActivFlagCheck> listaa = jdbcTemplate.query(sql, new RowMapper<NDAActivFlagCheck>() 
	
	    				 {
			@Override
			public NDAActivFlagCheck mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				NDAActivFlagCheck path = new NDAActivFlagCheck();
				
				path.setActiveflag(rs.getString("ACTIVEFLAG_LINK"));
			return path;
			}
	   });
	    return listaa;
	    
	   }
	
	
	public List<NDAdownloadPath> NDAdownload1(int sapid,JdbcTemplate jdbcTemplate) 
	{
		
	 	String sql = DataBaseRNCQuery.QUERY_TO_GET_NDA_Download_link1+sapid+")";
		
		
		System.out.println(sql);
	   
	    		 List<NDAdownloadPath> listaa = jdbcTemplate.query(sql, new RowMapper<NDAdownloadPath>() 
		 {
			@Override
			public NDAdownloadPath mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				NDAdownloadPath dp = new NDAdownloadPath();
				dp.setPath(rs.getString("NDA_UPLOAD_PATH_1"));
				
				return dp;
			}
	 	
	    });		
	    return listaa;
	    
	    }
	
	public List<NDAdownloadPath> NDAdownload2(int sapid,JdbcTemplate jdbcTemplate) 
	{
		
	 	String sql = DataBaseRNCQuery.QUERY_TO_GET_NDA_Download_link2+sapid+")";
		
		
		System.out.println(sql);
	   
	    		 List<NDAdownloadPath> listaa = jdbcTemplate.query(sql, new RowMapper<NDAdownloadPath>() 
		 {
			@Override
			public NDAdownloadPath mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				NDAdownloadPath dp = new NDAdownloadPath();
				dp.setPath(rs.getString("NDA_UPLOAD_PATH_2"));
				
				return dp;
			}
	 	
	    });		
	    return listaa;
	    
	    }

	public List<NDAdownloadPath> NDAdownload3(int sapid,JdbcTemplate jdbcTemplate) 
	{
		
	 	String sql = DataBaseRNCQuery.QUERY_TO_GET_NDA_Download_link3+sapid+")";
		
		
		System.out.println(sql);
	   
	    		 List<NDAdownloadPath> listaa = jdbcTemplate.query(sql, new RowMapper<NDAdownloadPath>() 
		 {
			@Override
			public NDAdownloadPath mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				NDAdownloadPath dp = new NDAdownloadPath();
				dp.setPath(rs.getString("NDA_UPLOAD_PATH_3"));
				
				return dp;
			}
	 	
	    });		
	    return listaa;
	    
	    }

	public List<NDAdownloadPath> NDAdownload4(int sapid,JdbcTemplate jdbcTemplate) 
	{
		
	 	String sql = DataBaseRNCQuery.QUERY_TO_GET_NDA_Download_link4+sapid+")";
		
		
		System.out.println(sql);
	   
	    		 List<NDAdownloadPath> listaa = jdbcTemplate.query(sql, new RowMapper<NDAdownloadPath>() 
		 {
			@Override
			public NDAdownloadPath mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				NDAdownloadPath dp = new NDAdownloadPath();
				dp.setPath(rs.getString("NDA_UPLOAD_PATH_4"));
				
				return dp;
			}
	 	
	    });		
	    return listaa;
	    
	    }
	public List<NDAdownloadPath> NDAdownload5(int sapid,JdbcTemplate jdbcTemplate) 
	{
		
	 	String sql = DataBaseRNCQuery.QUERY_TO_GET_NDA_Download_link5+sapid+")";
		
		
		System.out.println(sql);
	   
	    		 List<NDAdownloadPath> listaa = jdbcTemplate.query(sql, new RowMapper<NDAdownloadPath>() 
		 {
			@Override
			public NDAdownloadPath mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				NDAdownloadPath dp = new NDAdownloadPath();
				dp.setPath(rs.getString("NDA_UPLOAD_PATH_5"));
				
				return dp;
			}
	 	
	    });		
	    return listaa;
	    
	    }
	public List<NDApathsCheckNull> NDApathcheks(int sapid,JdbcTemplate jdbcTemplate) 
	{
		
	 	String sql = DataBaseRNCQuery.QUERY_TO_GET_NDA_paths_null_check+sapid+")";
		
		
		System.out.println(sql);
	   
	    		 List<NDApathsCheckNull> listaa = jdbcTemplate.query(sql, new RowMapper<NDApathsCheckNull>() 
		 {
			@Override
			public NDApathsCheckNull mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				NDApathsCheckNull dp = new NDApathsCheckNull();
				dp.setUploadone(rs.getString("NDA_UPLOAD_PATH_1"));
				dp.setUploadtwo(rs.getString("NDA_UPLOAD_PATH_2"));
				dp.setUploadthree(rs.getString("NDA_UPLOAD_PATH_3"));
				dp.setUploadfour(rs.getString("NDA_UPLOAD_PATH_4"));
				dp.setUploadfive(rs.getString("NDA_UPLOAD_PATH_5"));
				dp.setLinkflagcheck(rs.getString("ACTIVEFLAG_LINK"));
				return dp;
			}
	 	
	    });		
	    return listaa;
	    
	    }
	
}

package com.hcl.pmoautomation.rnc.service;

import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;

import com.hcl.pmoautomation.rnc.vo.NewJoineeOdcAccess;

public interface OdcAccessServiceI {
	
	public List<Map<String,Object>> getEmployee(int sapcode,JdbcTemplate jdbcTemplate);
	public int addNewJoineeOdcdetails(NewJoineeOdcAccess odc,String gpn,JdbcTemplate jdbcTemplate);

}

package com.hcl.pmoautomation.rnc.vo;

import java.sql.Timestamp;



public class Bgv {
	
	private int sap_Id;
	private int id;
	private String emp_First_Name;
	private String emp_Last_Name;
	private String gender;
	private Timestamp date_Of_Birth;
	private String nationality;
	private String correspondence_Language;
	private String previously_Worked_With_Client;
	private String offer_Accepted_Status;
	private Timestamp offer_Accepted_Date;
	private String project_Code;
	private String project_Name;
	private String sector;
	private String request_Type;
	private Timestamp ras_Start_Date;
	private Timestamp ras_End_Date;
	private String onshore_Offshore;
	private Timestamp expected_Joining_Date;
	private String remarks;
	private String tp_Resource;
	private String tp_Approval;
	private String emp_Official_Mail_Id;
	private String emp_Personal_Mail_Id;
	private String emp_Client_Mail_Id;
	private int emp_Contact_Number;
	private String location;
	private String ou_Code;
	//private int gpn;Correspondence_Language
	private int gpn;
	private String client_Hiring_Manager_Mail_Id;
	private int client_Hiring_Manager_Gpn_No;
	private String region;
	private String country;
	private Timestamp assignment_From;
	private Timestamp assignment_To;
	private String bgv_Type;
	private Timestamp gpn_Start_Date;
	private String gpn_Status;
	private String initiate_Gpn;
	private int ras_Id;
	private String bgv_Final_Report_Colour;
	private String bgv_Council_Approval_Received_Status;
	private Timestamp bgv_Council_Approval_Received_Date;
	private String resource_Justification_Received__Status;
	private Timestamp resource_Justification_Received__Date;
	private String active_Flag;
	private String modified_By;
	private Timestamp modified_Date;
	
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCorrespondence_Language() {
		return correspondence_Language;
	}
	public void setCorrespondence_Language(String correspondence_Language) {
		this.correspondence_Language = correspondence_Language;
	}
	public int getSap_Id() {
		return sap_Id;
		
	}
	public void setSap_Id(int sap_Id) {
		this.sap_Id = sap_Id;
	}
	public String getEmp_First_Name() {
		return emp_First_Name;
	}
	public void setEmp_First_Name(String emp_First_Name) {
		this.emp_First_Name = emp_First_Name;
	}
	public String getEmp_Last_Name() {
		return emp_Last_Name;
	}
	public void setEmp_Last_Name(String emp_Last_Name) {
		this.emp_Last_Name = emp_Last_Name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Timestamp getDate_Of_Birth() {
		return date_Of_Birth;
	}
	public void setDate_Of_Birth(Timestamp date_Of_Birth) {
		this.date_Of_Birth = date_Of_Birth;
	}
	public String getNationality() {
		return nationality;
	}
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	
	public String getPreviously_Worked_With_Client() {
		return previously_Worked_With_Client;
	}
	public void setPreviously_Worked_With_Client(String previosly_Worked_With_Client) {
		this.previously_Worked_With_Client = previosly_Worked_With_Client;
	}
	public String getOffer_Accepted_Status() {
		return offer_Accepted_Status;
	}
	public void setOffer_Accepted_Status(String offer_Accepted_Status) {
		this.offer_Accepted_Status = offer_Accepted_Status;
	}
	public Timestamp getOffer_Accepted_Date() {
		return offer_Accepted_Date;
	}
	public void setOffer_Accepted_Date(Timestamp offer_Accepted_Date) {
		this.offer_Accepted_Date = offer_Accepted_Date;
	}
	public String getProject_Code() {
		return project_Code;
	}
	public void setProject_Code(String project_Code) {
		this.project_Code = project_Code;
	}
	public String getProject_Name() {
		return project_Name;
	}
	public void setProject_Name(String project_Name) {
		this.project_Name = project_Name;
	}
	public String getSector() {
		return sector;
	}
	public void setSector(String sector) {
		this.sector = sector;
	}
	public String getRequest_Type() {
		return request_Type;
	}
	public void setRequest_Type(String request_Type) {
		this.request_Type = request_Type;
	}
	public Timestamp getRas_Start_Date() {
		return ras_Start_Date;
	}
	public void setRas_Start_Date(Timestamp ras_Start_Date) {
		this.ras_Start_Date = ras_Start_Date;
	}
	public Timestamp getRas_End_Date() {
		return ras_End_Date;
	}
	public void setRas_End_Date(Timestamp ras_End_Date) {
		this.ras_End_Date = ras_End_Date;
	}
	public String getOnshore_Offshore() {
		return onshore_Offshore;
	}
	public void setOnshore_Offshore(String onshore_Offshore) {
		this.onshore_Offshore = onshore_Offshore;
	}
	public Timestamp getExpected_Joining_Date() {
		return expected_Joining_Date;
	}
	public void setExpected_Joining_Date(Timestamp expected_Joining_Date) {
		this.expected_Joining_Date = expected_Joining_Date;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getTp_Resource() {
		return tp_Resource;
	}
	public void setTp_Resource(String tp_Resource) {
		this.tp_Resource = tp_Resource;
	}
	public String getTp_Approval() {
		return tp_Approval;
	}
	public void setTp_Approval(String tp_Approval) {
		this.tp_Approval = tp_Approval;
	}
	public String getEmp_Official_Mail_Id() {
		return emp_Official_Mail_Id;
	}
	public void setEmp_Official_Mail_Id(String emp_Official_Mail_Id) {
		this.emp_Official_Mail_Id = emp_Official_Mail_Id;
	}
	public String getEmp_Personal_Mail_Id() {
		return emp_Personal_Mail_Id;
	}
	public void setEmp_Personal_Mail_Id(String emp_Personal_Mail_Id) {
		this.emp_Personal_Mail_Id = emp_Personal_Mail_Id;
	}
	public String getEmp_Client_Mail_Id() {
		return emp_Client_Mail_Id;
	}
	public void setEmp_Client_Mail_Id(String emp_Client_Mail_Id) {
		this.emp_Client_Mail_Id = emp_Client_Mail_Id;
	}
	public int getEmp_Contact_Number() {
		return emp_Contact_Number;
	}
	public void setEmp_Contact_Number(int emp_Contact_Number) {
		this.emp_Contact_Number = emp_Contact_Number;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getOu_Code() {
		return ou_Code;
	}
	public void setOu_Code(String ou_Code) {
		this.ou_Code = ou_Code;
	}
	public int getGpn() {
		return gpn;
	}
	public void setGpn(int i) {
		this.gpn = i;
	}
	public String getClient_Hiring_Manager_Mail_Id() {
		return client_Hiring_Manager_Mail_Id;
	}
	public void setClient_Hiring_Manager_Mail_Id(
			String client_Hiring_Manager_Mail_Id) {
		this.client_Hiring_Manager_Mail_Id = client_Hiring_Manager_Mail_Id;
	}
	public int getClient_Hiring_Manager_Gpn_No() {
		return client_Hiring_Manager_Gpn_No;
	}
	public void setClient_Hiring_Manager_Gpn_No(int client_Hiring_Manager_Gpn_No) {
		this.client_Hiring_Manager_Gpn_No = client_Hiring_Manager_Gpn_No;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public Timestamp getAssignment_From() {
		return assignment_From;
	}
	public void setAssignment_From(Timestamp assignment_From) {
		this.assignment_From = assignment_From;
	}
	public Timestamp getAssignment_To() {
		return assignment_To;
	}
	public void setAssignment_To(Timestamp assignment_To) {
		this.assignment_To = assignment_To;
	}
	public String getBgv_Type() {
		return bgv_Type;
	}
	public void setBgv_Type(String bgv_Type) {
		this.bgv_Type = bgv_Type;
	}
	public Timestamp getGpn_Start_Date() {
		return gpn_Start_Date;
	}
	public void setGpn_Start_Date(Timestamp gpn_Start_Date) {
		this.gpn_Start_Date = gpn_Start_Date;
	}
	public String getGpn_Status() {
		return gpn_Status;
	}
	public void setGpn_Status(String gpn_Status) {
		this.gpn_Status = gpn_Status;
	}
	public String getInitiate_Gpn() {
		return initiate_Gpn;
	}
	public void setInitiate_Gpn(String initiate_Gpn) {
		this.initiate_Gpn = initiate_Gpn;
	}
	public int getRas_Id() {
		return ras_Id;
	}
	public void setRas_Id(int ras_Id) {
		this.ras_Id = ras_Id;
	}
	public String getBgv_Final_Report_Colour() {
		return bgv_Final_Report_Colour;
	}
	public void setBgv_Final_Report_Colour(String bgv_Final_Report_Colour) {
		this.bgv_Final_Report_Colour = bgv_Final_Report_Colour;
	}
	public String getBgv_Council_Approval_Received_Status() {
		return bgv_Council_Approval_Received_Status;
	}
	public void setBgv_Council_Approval_Received_Status(
			String bgv_Council_Approval_Received_Status) {
		this.bgv_Council_Approval_Received_Status = bgv_Council_Approval_Received_Status;
	}
	public Timestamp getBgv_Council_Approval_Received_Date() {
		return bgv_Council_Approval_Received_Date;
	}
	public void setBgv_Council_Approval_Received_Date(
			Timestamp bgv_Council_Approval_Received_Date) {
		this.bgv_Council_Approval_Received_Date = bgv_Council_Approval_Received_Date;
	}
	public String getResource_Justification_Received__Status() {
		return resource_Justification_Received__Status;
	}
	public void setResource_Justification_Received__Status(
			String resource_Justification_Received__Status) {
		this.resource_Justification_Received__Status = resource_Justification_Received__Status;
	}
	public Timestamp getResource_Justification_Received__Date() {
		return resource_Justification_Received__Date;
	}
	public void setResource_Justification_Received__Date(
			Timestamp resource_Justification_Received__Date) {
		this.resource_Justification_Received__Date = resource_Justification_Received__Date;
	}
	public String getActive_Flag() {
		return active_Flag;
	}
	public void setActive_Flag(String active_Flag) {
		this.active_Flag = active_Flag;
	}
	public String getModified_By() {
		return modified_By;
	}
	public void setModified_By(String modified_By) {
		this.modified_By = modified_By;
	}
	public Timestamp getModified_Date() {
		return modified_Date;
	}
	public void setModified_Date(Timestamp modified_Date) {
		this.modified_Date = modified_Date;
	}
	@Override
	public String toString() {
		return "Bgv [sap_Id=" + sap_Id + ", emp_First_Name=" + emp_First_Name
				+ ", emp_Last_Name=" + emp_Last_Name + ", gender=" + gender
				+ ", date_Of_Birth=" + date_Of_Birth + ", nationality="
				+ nationality + ", Correspondence_Language="
				+ correspondence_Language + ", previously_Worked_With_Client="
				+ previously_Worked_With_Client + ", offer_Accepted_Status="
				+ offer_Accepted_Status + ", offer_Accepted_Date="
				+ offer_Accepted_Date + ", project_Code=" + project_Code
				+ ", project_Name=" + project_Name + ", sector=" + sector
				+ ", request_Type=" + request_Type + ", ras_Start_Date="
				+ ras_Start_Date + ", ras_End_Date=" + ras_End_Date
				+ ", onshore_Offshore=" + onshore_Offshore
				+ ", expected_Joining_Date=" + expected_Joining_Date
				+ ", remarks=" + remarks + ", tp_Resource=" + tp_Resource
				+ ", tp_Approval=" + tp_Approval + ", emp_Official_Mail_Id="
				+ emp_Official_Mail_Id + ", emp_Personal_Mail_Id="
				+ emp_Personal_Mail_Id + ", emp_Client_Mail_Id="
				+ emp_Client_Mail_Id + ", emp_Contact_Number="
				+ emp_Contact_Number + ", location=" + location + ", ou_Code="
				+ ou_Code + ", gpn=" + gpn + ", client_Hiring_Manager_Mail_Id="
				+ client_Hiring_Manager_Mail_Id
				+ ", client_Hiring_Manager_Gpn_No="
				+ client_Hiring_Manager_Gpn_No + ", region=" + region
				+ ", country=" + country + ", assignment_From="
				+ assignment_From + ", assignment_To=" + assignment_To
				+ ", bgv_Type=" + bgv_Type + ", gpn_Start_Date="
				+ gpn_Start_Date + ", gpn_Status=" + gpn_Status
				+ ", initiate_Gpn=" + initiate_Gpn + ", ras_Id=" + ras_Id
				+ ", bgv_Final_Report_Colour=" + bgv_Final_Report_Colour
				+ ", bgv_Council_Approval_Received_Status="
				+ bgv_Council_Approval_Received_Status
				+ ", bgv_Council_Approval_Received_Date="
				+ bgv_Council_Approval_Received_Date
				+ ", resource_Justification_Received__Status="
				+ resource_Justification_Received__Status
				+ ", resource_Justification_Received__Date="
				+ resource_Justification_Received__Date + ", active_Flag="
				+ active_Flag + ", modified_By=" + modified_By
				+ ", modified_Date=" + modified_Date + "]";
	}
	
	
	
	
}

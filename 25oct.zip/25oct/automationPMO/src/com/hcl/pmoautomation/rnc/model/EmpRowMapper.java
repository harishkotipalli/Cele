package com.hcl.pmoautomation.rnc.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.hcl.pmoautomation.rnc.vo.Bgv;
import com.hcl.pmoautomation.rnc.vo.Emp_Client;;

public class EmpRowMapper implements RowMapper<Emp_Client>{

	@Override
	 public Emp_Client mapRow(ResultSet resultSet, int line) throws SQLException {
	  EmpRowExtractor gpnExtractor = new EmpRowExtractor();
	  return  gpnExtractor.extractData(resultSet);
	}

}

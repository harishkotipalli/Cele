package com.hcl.pmoautomation.rnc.dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;

import javax.sql.DataSource;

public class UserDaoImpl implements UserDaoI {
	
	DataSource dataSource;
	

	public DataSource getDataSource() {
		return dataSource;
	}


	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}


	@Override
	public boolean isValidUser(String userName, String password, String role) {
		String query = "Select username,password,role from user where username = ? and password = ? role=?";
		PreparedStatement stmt;
		try {
			stmt = dataSource.getConnection().prepareStatement(query);
			stmt.setString(1, userName);
			 stmt.setString(1, password);
			 stmt.setString(1, role);
			 ResultSet resultSet = stmt.executeQuery();
			 if(resultSet.next())
				 return (resultSet.getInt(1) > 0);
				 
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
       	 return false;
	}

}

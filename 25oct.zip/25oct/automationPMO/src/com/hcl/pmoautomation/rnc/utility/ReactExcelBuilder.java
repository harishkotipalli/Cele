package com.hcl.pmoautomation.rnc.utility;

	import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

	import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.view.document.AbstractExcelView;

	import com.hcl.pmoautomation.rnc.dao.GpnDao;
import com.hcl.pmoautomation.rnc.service.GpnService;
import com.hcl.pmoautomation.rnc.service.GpnServiceImpl;
import com.hcl.pmoautomation.rnc.vo.Bgv;
import com.hcl.pmoautomation.rnc.vo.Gpn;
	 
	/**
	 * This class builds an Excel spreadsheet document using Apache POI library.
	 * @author 
	 *
	 */
	public class ReactExcelBuilder extends AbstractExcelView {
		
		@Override
	    protected void buildExcelDocument(Map<String, Object> model,
	            HSSFWorkbook workbook, HttpServletRequest request, HttpServletResponse response) {
	        @SuppressWarnings("unchecked")
			List<Object[]>userList = (List<Object[]>) model.get("userList");
			
			//setExcelRows(excelSheet,animalList);
	 
	        // create a new Excel sheet
	        HSSFSheet sheet = workbook.createSheet("Gpn Initiation");
	        sheet.setDefaultColumnWidth(30);
	         
	        // create style for header cells
	        CellStyle style = workbook.createCellStyle();
	        Font font = workbook.createFont();
	        font.setFontName("Arial");
	        style.setFillForegroundColor(HSSFColor.BLUE.index);
	        style.setFillPattern(CellStyle.SOLID_FOREGROUND);
	        font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
	        font.setColor(HSSFColor.WHITE.index);
	        style.setFont(font);
	         
	        // create header row
	        HSSFRow header = sheet.createRow(0);
	         
	        header.createCell(0).setCellValue("Name");
	        header.getCell(0).setCellStyle(style);
	        
	        header.createCell(1).setCellValue("SAP ID");
	        header.getCell(1).setCellStyle(style);
	         
	        header.createCell(2).setCellValue("GPN");
	        header.getCell(2).setCellStyle(style);
	        
	        header.createCell(3).setCellValue("Project Name");
	        header.getCell(3).setCellStyle(style);
	         
	        header.createCell(4).setCellValue("Region");
	        header.getCell(4).setCellStyle(style);
	         
	        header.createCell(5).setCellValue("Contract End Date");
	        header.getCell(5).setCellStyle(style);
	         
	        header.createCell(6).setCellValue("Snow Ticket No");
	        header.getCell(6).setCellStyle(style);
	         
	        header.createCell(7).setCellValue("New Contrat End Date");
	        header.getCell(7).setCellStyle(style);
	        
	        
	        
	        
	        
	        // create data rows
	        int rowCount = 1;
	        
	        /*objects=new Object[10];
			objects[0]=bgv.getSap_Id();
			objects[1]=bgv.getEmp_First_Name()+" "+bgv.getEmp_Last_Name();
			objects[2]=bgv.getGpn();
			objects[3]=bgv.getProject_Name();
			objects[4]=bgv.getRegion();
			for(Gpn gpn:gpnLst){
				{
					if(bgv.getId()==gpn.getBgvid()){
						objects[5]=gpn.getContract_End_Date();
						objects[6]=gpn.getSnow_Ticket_Number();
						objects[7]=gpn.getBgvid();
						objects[8]=gpn.getEmp_Client_Id();

*/	        
	        for (Object[] aBook : userList) {
	            HSSFRow aRow = sheet.createRow(rowCount++);
	            aRow.createCell(0).setCellValue((int)aBook[0]);
	            String name = (String) (aBook[1]) ;
	            aRow.createCell(1).setCellValue(name);//name
	            aRow.createCell(2).setCellValue((Date)aBook[0]);//SAP
	            aRow.createCell(3).setCellValue((String)aBook[2]);//gpn
	            aRow.createCell(4).setCellValue((String)aBook[3]);//project name
	            aRow.createCell(5).setCellValue((String) aBook[4]); //region
	            aRow.createCell(6).setCellValue((String)aBook[5]);//contract_end_date
	            aRow.createCell(7).setCellValue((String)aBook[9]);//snow_ticket_no
	               
	        }
	    }
	 
	}
	


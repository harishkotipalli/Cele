package com.hcl.pmoautomation.rnc.dao;

import java.io.Serializable;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.activation.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.CallableStatementCallback;
import org.springframework.jdbc.core.CallableStatementCreator;
import org.springframework.jdbc.core.ConnectionCallback;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.StatementCallback;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Component;

import com.hcl.pmoautomation.rnc.vo.*;
import com.hcl.pmoautomation.ot.dao.DatabaseQuery;
import com.hcl.pmoautomation.ot.vo.*;
import com.hcl.pmoautomation.rnc.model.BgvReactRowMapper;
import com.hcl.pmoautomation.rnc.model.EmpRowMapper;
import com.hcl.pmoautomation.rnc.model.GpnReactRowMapper;
import com.hcl.pmoautomation.rnc.model.GpnRowMapper;
import com.hcl.pmoautomation.rnc.model.BgvRowMapper;
import com.hcl.pmoautomation.rnc.model.GvRowMapper;
import com.hcl.pmoautomation.rnc.model.RasRowMapper;
//import com.hcl.pmoautomation.rnc.model.ReactRowMapper;
@Component
public  class GpnDaoImpl implements GpnDao{
	@Autowired(required=true)
	JdbcTemplate jdbcTemplate;

	@Override
	public void insertGPN(final List<Object[]> list) 
	{
		try
		{
			List data = new ArrayList<Bgv>();
			data.add(list);
			System.out.println("inserting new data set for gpn");
			/*String sql = "INSERT INTO "
					+ "gpn_initiation "
					+ "(bgv_id,emp_client_id) "
					+ "VALUES " + "(?,?)";
			 */
			String sql = "INSERT INTO "
					+ "gpn_initiation "
					+ "(bgv_id) "
					+ "VALUES " + "(?)";

			jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {


				@Override
				public int getBatchSize() {
					// TODO Auto-generated method stub
					return list.size();
				}

				@Override
				public void setValues(PreparedStatement ps, int i)
						throws SQLException {
					// TODO Auto-generated method stub
					System.out.println(" GpnDaoImpl:insertGPN :Inside prepared statement setter");
					Object[] objArr = list.get(i);
					ps.setInt(1,(int) objArr[0]);
					//ps.setInt(2,(int)objArr[1]);
					System.out.println(ps);

				}
			});			
			//getGpnList();

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}


	@Override
	public List<Object[]> getGpnList() {
		List<Object[]> list=null;
		List<Object[]> objArr=null;
		ArrayList<Object[]> objlist = new ArrayList<Object[]>();
		List<Map<String, Object>> nxtlst = new ArrayList<Map<String,Object>>();
		//List<Map<String, Object>> lst = new ArrayList<Map<String,Object>>();

		try {

			//if(idTest.isEmpty()){
			System.out.println("GpnDaoImpl: getGpnList: hello");

			Object[] objects2=null;
			//nxtlst =  jdbcTemplate.queryForList("select bgv.id as bgvid,emp.id from bgv ,emp_client emp where bgv.gpn is null and bgv.sap_id=emp.sap_id and bgv.id not in (select bgv_id from gpn_initiation);", new Object[]{});
			nxtlst =  jdbcTemplate.queryForList("select bgv.id as bgvid from bgv Where bgv.gpn is null And bgv.id not in (select bgv_id from gpn_initiation where GPN is null)", new Object[]{});			
			int size =nxtlst.size();
			System.out.println(size);
			if(size>0){
				for(Map map:nxtlst)
				{
					System.out.println(nxtlst);
					objects2=new Object[2];
					objects2[0]=map.get("bgvid");
					System.out.println("GpnDaoImpl : getGpnList: bgvid :" + objects2[0]);					
					objects2[1]=map.get("id");
					System.out.println("GpnDaoImpl : getGpnList: id :" + objects2[1]);
					objlist.add(objects2);
				}
				System.out.println(objlist.toString());
				System.out.println("fetching ");

				insertGPN(objlist);//System.out.println(Arrays.asList(objects2));


			}	

			List<Map<String, Object>> lst = new ArrayList<Map<String,Object>>();

			lst =  jdbcTemplate.queryForList(DataBaseRNCQuery.QUERY_TO_GET_GPNCREATELIST, new Objects[]{}); // jdbcTemplate.query(DataBaseRNCQuery.QUERY_TO_GET_GPNCREATELIST, new BgvRowMapper());
			/* select bgv.id,e.id,request_type, region, project_name, country ,client_hiring_manager_gpn_no , datediff(curdate(),gpn.SNOW_TICKET_CREATION_DATE) as datediff, client_hiring_manager_mail_id ,
                  previously_worked_with_client ,emp_first_name , emp_middle_name ,emp_last_name ,date_of_birth ,
                  correspondence_language ,nationality, gender ,assignment_from ,assignment_to ,ou_code
                  from bgv , emp_client e , gpn_initiation gpn where bgv.sap_id=e.sap_id and gpn.bgv_id=bgv.id and bgv.initiate_gpn='y'
                  and bgv.id in (select bgv_id from gpn_initiation where gpn is null);*/


			List<Gpn> idTest= jdbcTemplate.query("select bgv_id,snow_ticket_no from gpn_initiation;", new GpnRowMapper()) ; 
			Object[] objects=null;

			list=new ArrayList<Object[]>();
			int count=0;

			for(Map map:lst)
			{
				objects=new Object[18];
				objects[0]= map.get("id");//.getId();
				objects[1]=map.get("region");//getRegion();
				objects[2]=map.get("previously_worked_with_client");//getPreviously_Worked_With_Client();
				objects[3]=map.get("Emp_First_Name");//getEmp_First_Name()+" "+bgv.getEmp_Last_Name();
				objects[4]=map.get("Gender");//getGender();
				objects[5]=map.get("Project_name");//getProject_Name();
				objects[6]=map.get("snow_ticket_no");
				for(Gpn gpn:idTest){
					System.out.println(idTest);
					/*if(map.get("id")==map.get("bgv_id")){
						objects[6]=gpn.getSnow_Ticket_Number();
						System.out.println(objects[6]);
					*/	objects[7]=gpn.getSnow_Ticket_Init_Date();
					//}
					objects[8]=map.get("Date_Of_Birth");//getDate_Of_Birth();
					objects[9]=map.get("Correspondence_Language");//getCorrespondence_Language();
					objects[10]=map.get("Nationality");//getNationality();
					objects[11]=map.get("Assignment_From");//getAssignment_From();
					objects[12]=map.get("Assignment_To");//getAssignment_To();
					objects[13]=map.get("Ou_Code");//getOu_Code();
					objects[14]=map.get("Request_Type");//getRequest_Type();
					objects[15]=map.get("Client_Hiring_Manager_Gpn_No");//getClient_Hiring_Manager_Gpn_No();
					objects[16]=map.get("Client_Hiring_Manager_Mail_Id");//getClient_Hiring_Manager_Mail_Id();
					objects[17]=map.get("datediff");
					System.out.println(objects[17]);
				}
				//objects[8]=lst.get(19);

				count++;
				list.add(objects);


				System.out.println(Arrays.asList(objects));
			}

			//TODO: Pass the BGV, Emp Client Id as list of VO
		}catch(Exception e){
			e.printStackTrace();
		}
		return list;
}

@Override
public boolean saveSnowTicketNumber( String[] snowTicketNumberList,	String[] bgvID) {

	final String[] snowList=snowTicketNumberList;
	final String[]bgvList=bgvID;
	
	System.out.println("GpnDaoImpl saveSnowTicketNumber: snowTicket :" + snowList[0]);
	System.out.println("GpnDaoImpl saveSnowTicketNumber: bgvId :" + bgvList[0]);

	return	(jdbcTemplate.batchUpdate(DataBaseRNCQuery.QUERY_TO_SAVE_SNOWTICKETNUMBERS, new BatchPreparedStatementSetter() {

		@Override
		public void setValues(PreparedStatement ps, int i) throws SQLException {
			String snowTicket=snowList[i];
			String bgvId=bgvList[i];
			//String placed=placedinSharePoint[i];
			ps.setString(1, snowTicket);
			ps.setString(2,bgvId);
			System.out.println(ps);
		}

		@Override
		public int getBatchSize() {

			return snowList.length;
		}
	})).length==snowTicketNumberList.length;
	//		return null;
}


//method to save GPN details in the gpnInitiation
//Flag: snowTicketCreated:true saveGpn:false
@Override
public boolean updateData(String[] gpn, String[] id, String[] gpnCreationDate, String[] startDateList, String[] endDateList, boolean flagToDecide) {
	//gpn,bgvID, gpnCreationDate, gpnStartDate, contractEndDate,flagToDecide
	java.util.Date today = new java.util.Date();

	final String[]gpnList=gpn;
	final String[]bgvList=id;
	final String[]startdateList=startDateList;
	System.out.println(gpnCreationDate);
	final String[]creationdateList=gpnCreationDate;
	final String[]enddateList=endDateList;

	if(!flagToDecide){

		return	(jdbcTemplate.batchUpdate(DataBaseRNCQuery.QUERY_TO_SAVE_GPN, new BatchPreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				int gpn=Integer.parseInt(gpnList[i]);
				String bgvId=bgvList[i];
				String gpnStartDate=startdateList[i];
				String contractEndDate=enddateList[i];
				String gpnCreationDateStr=creationdateList[i];
				System.out.println(gpnCreationDateStr);
				SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd"); 
				java.util.Date date = null;
				java.util.Date endDate = null;
				java.util.Date creationDate=null;
				try {
					date = sdf1.parse(gpnStartDate);
					endDate = sdf1.parse(contractEndDate);
					creationDate = sdf1.parse(gpnCreationDateStr);
				} catch (ParseException e) {
					e.printStackTrace();
				} 
				java.sql.Date sqlStartDate = new java.sql.Date(date.getTime()); 
				java.sql.Date sqlEndDate = new java.sql.Date(endDate.getTime());
				java.sql.Date sqlCreationDate = new java.sql.Date(creationDate.getTime());

				ps.setDate(1, sqlStartDate);
				ps.setDate(2, sqlEndDate);
				ps.setDate(3, sqlCreationDate);
				ps.setInt(4, gpn);
				ps.setString(5,bgvId);
				System.out.println(ps);
			}

			@Override
			public int getBatchSize() {

				return gpnList.length;
			}
		})).length==bgvList.length;

	}
	else{
		return false;
	}
}

@Override
public boolean updateDataBGVTable(String[] gpn, String[] id, String[] startDateList, String[] endDateList, boolean flagToDecide) {

	java.util.Date today = new java.util.Date();

	final String[]gpnList=gpn;
	final String[]bgvList=id;
	final String[]startdateList=startDateList;
	final String[]enddateList=endDateList;

	if(!flagToDecide){

		return(jdbcTemplate.batchUpdate("update bgv set gpn=?,initiate_gpn='N',gpn_start_date=? where id=?;", new BatchPreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				int gpn=Integer.parseInt(gpnList[i]);
				System.out.println(gpn);
				SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd"); 
				java.util.Date date = null;
				String gpnStartDate=startdateList[i];
				try {
					date = sdf1.parse(gpnStartDate);
				} catch (ParseException e) {
					e.printStackTrace();
				} 
				java.sql.Date sqlStartDate = new java.sql.Date(date.getTime()); 
				String bgvId=bgvList[i];
				System.out.println(bgvId);

				ps.setInt(1, gpn);
				ps.setDate(2, sqlStartDate);
				ps.setString(3,bgvId);

			}

			@Override
			public int getBatchSize() {
				// TODO Auto-generated method stub
				return bgvList.length;
			}
		})).length==bgvList.length;
	}
	else{
		return false;
	}
}


@Override
public List<Object[]> getReactList() {
	ArrayList<Object[]> list=new ArrayList<Object[]>();
	List<Map<String, Object>> lstgpn = new ArrayList<Map<String,Object>>();
	
	try{
		Object[] objects=null;

		//List<Bgv> lst =  jdbcTemplate.query(DataBaseRNCQuery.QUERY_TO_GET_GPNREACTLIST, new BgvReactRowMapper());
		//select contract_end_date,snow_ticket_no,snow_ticket_creation_date,bgv_id,emp_client_id,datediff(sysdate(),SNOW_TICKET_CREATION_DATE) as dateduf from gpn_initiation;
		//List<Gpn> gpnLst = jdbcTemplate.query(, new GpnReactRowMapper());
		//select bgv.id,bgv.sap_id,bgv.emp_first_name,bgv.emp_last_name,bgv.gpn,bgv.project_name,ras.rep_mgr_name, gpn.contract_end_date, gpn.bgv_id , bgv.region from gpn_initiation gpn,bgv,emp_client emp ,ras where bgv.id=gpn.bgv_id and emp.id=gpn.emp_client_id and ras.id=bgv.ras_id and datediff(gpn.contract_end_date , curdate()) between 0 and 45;int count=0;
		//System.out.println(lst.toString());
		lstgpn =  jdbcTemplate.queryForList(DataBaseRNCQuery.QUERY_TO_GET_GPNREACTLIST, new Objects[]{});
		for(Map gpn:lstgpn){
		
			objects=new Object[10];
			objects[0]=gpn.get("sap_id");//getSap_Id();
			objects[1]=gpn.get("emp_first_name");//getEmp_First_Name();//+" "+gpn.getEmp_Last_Name();
			objects[2]=gpn.get("gpn");//getGpn();
			objects[3]=gpn.get("project_name");//getProject_Name();
			objects[4]=gpn.get("region");//getRegion();
			
			
					//if(bgv.getId()==gpn.get("id")){
					System.out.println("getting data from gpn table");
						objects[5]=gpn.get("contract_end_date");//getContract_End_Date();
						objects[6]=gpn.get("snow_ticket_no");//getSnow_Ticket_Number();
						objects[7]=gpn.get("bgv_id");//getBgvid();
						objects[8]=gpn.get("emp_client_id");//getEmp_Client_Id();
						objects[9]=gpn.get("dateduf");
						System.out.println("OBJ"+ objects[9] + " end date"+ objects[5]);
					
				
			}
			list.add(objects);	
			//count++;
			System.out.println(lstgpn.toString());
			System.out.println(Arrays.asList(objects));
		}
	catch(Exception e){
		e.printStackTrace();
	}
	return list;
}

@Override
public boolean updateReactSnowTicketNumber(String[] placedinSharePoint,
		String[] snowTicketNumberList, String[] gpn,String[] bgvid, String[] empclientid) {

	final String[] snowList=snowTicketNumberList;
	final String[] gpnList=gpn;
	final String[] sharePoint=placedinSharePoint;
	final String[] bgvIdList=bgvid;
	final String[] empIDList=empclientid;

	return	(jdbcTemplate.batchUpdate(DataBaseRNCQuery.QUERY_TO_SAVE_SNOWTICKETNUMBERS, new BatchPreparedStatementSetter() {
		//update gpn_initiation set snow_ticket_creation_date=sysdate(), snow_ticket_no=? where bgv_id=?
		@Override
		public void setValues(PreparedStatement ps, int i) throws SQLException {
			String snowTicket=snowList[i];
			String placed=sharePoint[i];
			String bgvId=bgvIdList[i];
			ps.setString(1, snowTicket);
			//ps.setString(2, placed);
			ps.setString(2, bgvId);
			System.out.println(ps);
		}

		@Override
		public int getBatchSize() {

			return snowList.length;
		}
	})).length==snowTicketNumberList.length;
	//		return null;
}

@Override
public boolean updateReactGpn(String[] bgvid, String[] startDateList, String[] endDateList, boolean flagToDecide) {

	java.util.Date today = new java.util.Date();

	final String[] bgvList=bgvid;
	final String[]startdateList=startDateList;
	final String[]enddateList=endDateList;

	if(!flagToDecide){//flag false for gpn_created

		return	(jdbcTemplate.batchUpdate(DataBaseRNCQuery.QUERY_TO_SAVE_REACT_GPN, new BatchPreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				String bgv=bgvList[i];
				String gpnStartDate=startdateList[i];
				String contractEndDate=enddateList[i];
				/*Update gpn_initiation set gpn_creation_date=sysdate(), gpn_start_date=?,contract_end_date=? where bgv_id=?;*/
				SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd"); 
				//java.util.Date date = null;
				java.util.Date endDate = null;
				try {
					//date = sdf1.parse(gpnStartDate);
					endDate = sdf1.parse(contractEndDate);
				} catch (ParseException e) {
					e.printStackTrace();
				} 
				//java.sql.Date sqlStartDate = new java.sql.Date(date.getTime()); 
				java.sql.Date sqlEndDate = new java.sql.Date(endDate.getTime()); 
				int bgvint = Integer.parseInt(bgv);
				//ps.setDate(1, sqlStartDate);
				ps.setDate(1, sqlEndDate);
				ps.setInt(2, bgvint);
				System.out.println(ps);
			}

			@Override
			public int getBatchSize() {

				return bgvList.length;
			}
		})).length==bgvid.length;

	}
	else{
		return false;
	}
}

@Override
public List<Object[]> getTermiDetails(String choose, boolean select, int sap) {
	ArrayList<Object[]> list=new ArrayList<Object[]>();
	int Sap=sap;
	List<Object[]> objects2=null;
	try{
		Object[] objects=null;

		List<Gpn> gpnLst = jdbcTemplate.query("select snow_Ticket_Creation_Date,contract_end_date,snow_ticket_no,bgv_id,emp_client_id from gpn_initiation", new GpnReactRowMapper());
		List<Map<String, Object>> lst = new ArrayList<Map<String,Object>>();
		ArrayList<Object[]> objlist = new ArrayList<Object[]>();


		int count=0;

		if(select){//select is true if it is gpn based search
			lst =  jdbcTemplate.queryForList(DataBaseRNCQuery.QUERY_TO_GET_GPNTERMINDETAILSUSINGGPN, new Object[]{sap});
		}else{
			lst =  jdbcTemplate.queryForList(DataBaseRNCQuery.QUERY_TO_GET_GPNTERMINDETAILSUSINGSAP, new Object[]{sap});
		}
		System.out.println(lst.toString());
		for(Map map:lst)
		{
			//select bgv.SAP_ID,bgv.EMP_FIRST_NAME,bgv.EMP_LAST_NAME,bgv.PROJECT_CODE,bgv.PROJECT_NAME,bgv.gpn,bgv.GPN_START_DATE,emp_client.LM_NAME,ras.PM_NAME,bgv.LOCATION,bgv.COUNTRY
			//from mydb.bgv, mydb.gpn_initiation, mydb.emp_client,mydb.ras where bgv.id=gpn_initiation.bgv_id and 
			//gpn_initiation.EMP_CLIENT_ID= emp_client.ID and bgv.RAS_ID = ras.ID and bgv.SAP_ID= emp_client.SAP_ID and bgv.SAP_ID = ?;
			// SAP_ID   | EMP_FIRST_NAME | EMP_LAST_NAME | PROJECT_CODE | PROJECT_NAME | gpn      | GPN_START_DATE      | LM_NAME | PM_NAME    | LOCATION  | COUNTRY
			objects=new Object[10];
			objects[0]=map.get("SAP_ID");
			objects[1]=map.get("Emp_First_name");
			objects[2]=map.get("Emp_Last_name");
			objects[3]=map.get("Project_Name");
			objects[4]=map.get("gpn");
			objects[5]=map.get("Gpn_Start_Date");
			objects[6]=map.get("Lm_name");
			objects[7]=map.get("Pm_Name");
			objects[8]=map.get("Location");
			objects[9]=map.get("Country");
			objlist.add(objects);
			return objlist;
		}
		System.out.println(objlist.toString());
		System.out.println(Arrays.asList(objects));
	}catch(Exception e){
		e.printStackTrace();
	}
	return objects2;
}

@Override
public boolean saveTermiInfo(String gpn, final String reason, String termiDate) {
	final int gpnint = Integer.parseInt(gpn);
	SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd"); 
	java.util.Date date = null;
	try {
		date = sdf1.parse(termiDate);
	} catch (ParseException e) {
		e.printStackTrace();
	} 
	final java.sql.Date terminationDate = new java.sql.Date(date.getTime()); 
	int result = jdbcTemplate.update(DataBaseRNCQuery.QUERY_TO_SAVE_TERMINATION_REQUEST, new Object[] {reason,terminationDate,gpnint});
	//insert into resource_amendments(REQUEST_TYPE,REQUEST_DATE,REASON_FOR_LEAVING,GPN_TERMINATION_DATE,GPN) values('gpn termination',sysdate(),?,?.?)

	return result>0?true:false;
}

@SuppressWarnings("null")
@Override
public List<Object[]> getTermiList() {
	List<Object[]> objArr= new ArrayList<Object[]>();
	ArrayList<Object[]> objlist = new ArrayList<Object[]>();
	/*select bgv.EMP_FIRST_NAME,emp_client.LM_NAME,resource_amendments.GPN_TERMINATION_DATE,resource_amendments.ticket_no,resource_amendments.FOLLOW_UP_MAIL_DATE_DAY1,resource_amendments.FOLLOW_UP_MAIL_DATE_DAY2,resource_amendments.FOLLOW_UP_MAIL_DATE_DAY3,resource_amendments.ESCALATION_MAIL_DATE_DAY1,resource_amendments.ESCALATION_MAIL_DATE_DAY2,
resource_amendments.REASON_FOR_LEAVING,resource_amendments.PHYSICAL_ARC_DATE,resource_amendments.LOGICAL_ARC_DATE,resource_amendments.gpn as resGpn,gpn_initiation.gpn,bgv.LOCATION
from mydb.resource_amendments, mydb.bgv, mydb.emp_client, mydb.ras, mydb.gpn_initiation where bgv.id=gpn_initiation.bgv_id and gpn_initiation.EMP_CLIENT_ID= emp_client.ID and bgv.RAS_ID = ras.ID and bgv.SAP_ID= emp_client.SAP_ID and resource_amendments.GPN= gpn_initiation.GPN and resource_amendments.gpn is not null;*/
	ArrayList<Object[]> list=new ArrayList<Object[]>();
	try{
		Object[] objects=null;

		List<Map<String, Object>> lst = new ArrayList<Map<String,Object>>();
		lst =  jdbcTemplate.queryForList(DataBaseRNCQuery.QUERY_TO_GET_GPNTERMINATIONLIST, new Objects[]{});
		System.out.println(lst.size());
		for(Map map:lst)
		{
			objects=new Object[16];
			objects[0]=map.get("Emp_First_name");
			objects[1]=map.get("LM_name");
			objects[2]=map.get("GPN_TERMINATION_DATE");
			objects[3]=map.get("REASON_FOR_LEAVING");
			objects[4]=map.get("LOCATION");
			objects[5]=map.get("ONSITE_OR_OFFSHORE");
			/*if(map.get("resgpn") == map.get("gpn")){*/
			objects[6]=map.get("ticket_no");
			objects[8]=map.get("FOLLOW_UP_MAIL_DATE_DAY2");
			objects[9]=map.get("FOLLOW_UP_MAIL_DATE_DAY3");
			objects[10]=map.get("ESCALATION_MAIL_DATE_DAY1");
			objects[11]=map.get("ESCALATION_MAIL_DATE_DAY2");
			objects[12]=map.get("PHYSICAL_ARC_DATE");
			objects[13]=map.get("LOGICAL_ARC_DATE");
			objects[14]=map.get("resGpn");
			objects[15]=map.get("project_name");
			objlist.add(objects);
			System.out.println(Arrays.asList(objects));
		}
		objArr.addAll(objlist);
		//objArr.addAll(objlist);
		System.out.println(objArr);
		//System.out.println(Arrays.asList(objects));
	}catch(Exception e){
		e.printStackTrace();
	}
	return objArr;

}

@Override
public boolean updateTermiSnowTicketNumber(String[] snowTicketNumberList, String[] gpn) {
	final String[] snowList=snowTicketNumberList;
	final String[] gpnList=gpn;

	return	(jdbcTemplate.batchUpdate("update mydb.resource_amendments set SNOW_TICKET_SUBMITTED_DATE=sysdate(),TICKET_NO=?,SNOW_TICKET_CREATION_FLAG='Y' WHERE gpn=? ;", new BatchPreparedStatementSetter() {

		@Override
		public void setValues(PreparedStatement ps, int i) throws SQLException {
			String snowTicket=snowList[i];
			String gpnstr=gpnList[i];
			int gpnint=Integer.parseInt(gpnstr);
			ps.setString(1, snowTicket);
			ps.setInt(2, gpnint);
			System.out.println(ps);
		}

		@Override
		public int getBatchSize() {

			return snowList.length;
		}
	})).length==snowTicketNumberList.length;

}

@Override
public boolean updateTermiData(String[] gpn,String[] physicalAccessRevokeDate,String[] logicalAccessRevokeDate,String[] vdiRevokeDate,String[] rsaSubmitted,String[] notepadSurrender) {
	final String[] gpnList=gpn;
	final String[] physical=physicalAccessRevokeDate;
	final String[] logical=logicalAccessRevokeDate;
	final String[] vdi=vdiRevokeDate;
	final String[] rsa=rsaSubmitted;
	final String[] notepad=notepadSurrender;
	return jdbcTemplate.batchUpdate("update resource_amendments set PHYSICAL_ARC_DATE=?,LOGICAL_ARC_DATE=?,VDI_REVOKE_DATE=?,RSA_STATUS=?,NOTEPAD_SURRENDER=? "
			+ "where GPN=? and REQUEST_TYPE='gpn termination';", new BatchPreparedStatementSetter() {

				@Override
				public void setValues(PreparedStatement ps, int i) throws SQLException {
					int gpn=Integer.parseInt(gpnList[i]);
					SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd"); 
					java.util.Date date = null;
					String physicalDate=physical[i];
					String logicalDate=logical[i];
					String vdiDate=vdi[i];
					String notepadSur=notepad[i];
					String rsaSur=rsa[i];
					java.util.Date physicalutilDate=null;
					java.util.Date logicaldate=null;
					java.util.Date vDiDate=null;

					try {
						physicalutilDate = sdf1.parse(physicalDate);
						logicaldate = sdf1.parse(logicalDate);
						vDiDate = sdf1.parse(vdiDate);

					} catch (ParseException e) {
						e.printStackTrace();
					} 
					//String bgvId=bgvList[i];
					final java.sql.Date sqlPhysicalDate = new java.sql.Date(physicalutilDate.getTime());
					java.sql.Date sqllogicalDate = new java.sql.Date(logicaldate.getTime());
					java.sql.Date sqlvdiDate = new java.sql.Date(vDiDate.getTime());
					ps.setDate(1, sqlPhysicalDate);
					ps.setDate(2,sqllogicalDate);
					ps.setDate(3, sqlvdiDate);
					ps.setString(4, rsaSur);
					ps.setString(5, notepadSur);
					ps.setInt(6, gpn);


				}

				@Override
				public int getBatchSize() {
					// TODO Auto-generated method stub
					return gpnList.length;
				}
			}).length==physicalAccessRevokeDate.length;

} 
/*@Override
		public int getBatchSize() {

			return gpnList.length;
		}
	})).length==bgvList.length;

}
else{
	return false;
}


}
 */

@Override
public List<Object[]> getVdiDetails() {
	List<Object[]> list=null;
	List<Object[]> objArr=null;
	try {
		List<Bgv> lst= jdbcTemplate.query(DataBaseRNCQuery.QUERY_TO_GET_GRSVDILIST, new GvRowMapper()) ;
		//select bgv.EMP_FIRST_NAME, bgv.EMP_LAST_NAME, bgv.GPN, bgv.SAP_ID, bgv.COUNTRY, emp1.GRS_REQUEST_NO, emp1.VDI_REQUEST_NO, emp1.VDI_NO 
		//from mydb.emp_client emp1,mydb.bgv where bgv.SAP_ID= emp1.SAP_ID and (emp1.GRS_REQUEST_RAISED IS  NULL or emp1.VDI_REQUEST_RAISED IS  NULL)
		//and not exists ( select emp2.SAP_ID from mydb.emp_client emp2 where emp2.GRS_REQUEST_RAISED IS  NULL and emp2.VDI_REQUEST_RAISED IS  NULL and emp1.sap_id=emp2.sap_id)
		Object[] objects=null;
		List<Emp_Client> emplst= jdbcTemplate.query("select emp1.sap_Id,emp1.GRS_REQUEST_NO,emp1.VDI_REQUEST_NO,emp1.VDI_NO from mydb.emp_client emp1 where (emp1.GRS_REQUEST_RAISED IS  NULL or emp1.VDI_REQUEST_RAISED IS  NULL) and not exists (select emp2.SAP_ID "
				+ "from mydb.emp_client emp2 where emp2.GRS_REQUEST_RAISED IS  NULL and emp2.VDI_REQUEST_RAISED IS  NULL and emp1.sap_id=emp2.sap_id)", new EmpRowMapper()) ;

		list=new ArrayList<Object[]>();
		int count=0;

		for(Bgv bgv:lst)
		{
			objects=new Object[9];
			objects[0]=bgv.getEmp_First_Name()+ " "+ bgv.getEmp_Last_Name();
			objects[1]=bgv.getGpn();
			objects[2]=bgv.getSap_Id();
			objects[3]=bgv.getCountry();
			for(Emp_Client emp:emplst){
				if( emp.getSap_Id()  == bgv.getSap_Id()){
					objects[4]=emp.getGrs_Request_No();//grsRequestNo
					objects[5]=emp.getVdi_Request_Number();//vdiRequNo
					objects[6]=emp.getVdi_No();//vdino
				}}
			count++;
			list.add(objects);
			System.out.println(Arrays.asList(objects));
		}
		//TODO: Pass the BGV, Emp Client Id as list of VO
	}catch(Exception e){
		e.printStackTrace();
	}
	return list;
}


@Override
public boolean saveGrsNumber(String[] grsNumber,String[] sapId, boolean flagtodecide) {
	final String[] grsNumberArr=grsNumber;
	final String[] sapIdArr=sapId;
	final boolean flagtoDecide=flagtodecide;

	if(flagtoDecide){

		return	(jdbcTemplate.batchUpdate(DataBaseRNCQuery.QUERY_TO_SAVE_GRSDATA, new BatchPreparedStatementSetter() {
			//update mydb.emp_client set emp_client.GRS_REQUEST_NO = ?,emp_client.GRS_REQUEST_RAISED = 'Y', emp_client.GRS_REQUEST_RAISED_DATE = curdate() where emp_client.SAP_ID=?;
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				String grs=grsNumberArr[i];
				String sapId=sapIdArr[i];
				int grsint = Integer.parseInt(grs);
				int sapid = Integer.parseInt(sapId);
				ps.setInt(1, grsint);
				ps.setInt(2, sapid);
				System.out.println(ps);
			}

			@Override
			public int getBatchSize() {

				return grsNumberArr.length;
			}
		})).length==sapIdArr.length;

	}else{
		return false;
	}

}

@Override
public boolean saveVdiNumber(String[] vdiNumber, String[] vdi, String[] sapID, boolean flagtodecide) {
	final String[] vdiNumberArr=vdiNumber;
	final String[] sapIdArr=sapID;
	final boolean flagtoDecide=flagtodecide;
	final String[] vdiNo=vdi;

	if(!flagtoDecide){

		return	(jdbcTemplate.batchUpdate(DataBaseRNCQuery.QUERY_TO_SAVE_GRSDATA, new BatchPreparedStatementSetter() {
			//update mydb.emp_client set emp_client.VDI_NO = ? ,emp_client.VDI_REQUEST_NO = ?,emp_client.VDI_REQUEST_RAISED = 'Y', emp_client.VDI_REQUESTED_DATE = curdate() where emp_client.SAP_ID=?;			
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				String vdi=vdiNumberArr[i];
				String sapId=sapIdArr[i];
				String vdiNO=vdiNo[i];
				int vdiint = Integer.parseInt(vdi);
				int sapid = Integer.parseInt(sapId);
				int vdi2=Integer.parseInt(vdiNO);
				ps.setInt(1, vdi2);
				ps.setInt(2, vdiint);
				ps.setInt(3, sapid);

				System.out.println(ps);
			}

			@Override
			public int getBatchSize() {

				return vdiNumberArr.length;
			}
		})).length==sapIdArr.length;

	}else{
		return false;
	}
}


@Override
public boolean updateTermiData() {
	// TODO Auto-generated method stub
	return false;
}

public List<Map<String, Object>> getAllColumnNamesDynamically(
		String tableName) {

	String queryToFetchColumns = DatabaseQuery.QUERY_FETCH_COLUMNS1
			+ tableName + DatabaseQuery.QUERY_FETCH_COLUMNS2;

	System.out.println(queryToFetchColumns);
//	jdbcTemplate=new JdbcTemplate();
	// System.out.println(getJdbcTemplate());
System.out.println(jdbcTemplate);
	return jdbcTemplate.queryForList(queryToFetchColumns);
}


@Override
public boolean saveAllDataDynamically(
		List<ArrayList<String>> readExcelAllDynamically,
		String initiationTableName) {
	int count = 0;boolean resultFlag=false;
	String[] returnData=null;
	final List<Map<String, Object>> columnNames = getAllColumnNamesDynamically(
			initiationTableName);

	StringBuilder sqlQuery = new StringBuilder();
	sqlQuery = sqlQuery.append("insert into " + initiationTableName + "(");

	for (Map columnMapRowData : columnNames) {
		String tempData = (String) columnMapRowData.get("column_name");

		if (count == columnNames.size() - 1) {
			sqlQuery.append("`" + tempData.trim() + "`) values (");
			break;
		}
		sqlQuery.append("`" + tempData.trim() + "`,");

		count++;
	}

	// For Adding the Values
	count = 0;
	for (Map columnMapRowData : columnNames) {

		if (count == columnNames.size() - 1) {
			sqlQuery.append("?" + ")");
			break;
		}
		sqlQuery.append("?" + ",");

		count++;
	}
	final List<ArrayList<String>> arrayLists = null;
	final int size=setAllDataDynamically(arrayLists, columnNames).size();
	boolean flagInsert=	(jdbcTemplate.batchUpdate(sqlQuery.toString(),new BatchPreparedStatementSetter() {

		@Override
		public void setValues(PreparedStatement ps, int i) throws SQLException {

			Object[] excalibur=(setAllDataDynamically(arrayLists, columnNames)).get(i);


			ps.setString(1,(String)excalibur[16]);
			ps.setString(2,(String)excalibur[17]);
			ps.setString(3,(String)excalibur[18]);
			ps.setString(4,(String)excalibur[19]);
			ps.setString(4,(String)excalibur[20]);

		}

		@Override
		public int getBatchSize() {

			return size;
		}
	}).length==size)?true:false;
	String[] strings=null;
	if(flagInsert){

		for(ArrayList<String> temp:arrayLists){
			strings=pmChecker(temp);
			//if(strings[0].equalsIgnoreCase("NO")){
			resultFlag=	jdbcTemplate.update("update gpn_initiation set snow_ticket_no=?,gpn=?,gpn_creation_date=?,gpn_srart_date=?,contract_end_date=?"+strings[1]+"'")>0?true:false;

			/*}
			if(strings[0].equalsIgnoreCase("YES")){
				resultFlag=jdbcTemplate.update(DatabaseQuery.QUERY_TO_UPDATE_PM_DM_STATUS_YES+strings[1]+"'")>0?true:false;

			}
			 */	}
	}	

	return flagInsert;

}
@SuppressWarnings({ "deprecation", "unused" })
private List<Object[]> setAllDataDynamically(List<ArrayList<String>> arrayLists,
		List<Map<String, Object>> columnNames) {

	final	List<Object[]> objectDataList = new ArrayList<Object[]>();
	Object[] objectData=null;
	//		ArrayList<String> excaliburData = arrayLists.get(0);
	//		System.out.println(excaliburData);
	int tempCount = 0;
	for(ArrayList<String> excaliburData:arrayLists){
		objectData=new Object[excaliburData.size()];
		for (Map columnMapRowData : columnNames) {
			System.out.println(columnMapRowData);


			// System.out.println(dataList.get(tempModCount));
			if (((String) columnMapRowData.get("column_datatype"))
					.equalsIgnoreCase("STRING")) {
				objectData[tempCount] = excaliburData.get(tempCount);
			}
			if (((String) columnMapRowData.get("column_datatype"))
					.equalsIgnoreCase("INT")) {
				if (!(excaliburData.get(tempCount) == null)) {
					objectData[tempCount] = Integer.parseInt(excaliburData
							.get(tempCount));

				}
				if (excaliburData.get(tempCount) == null) {
					objectData[tempCount] = 0;
				}
			}
			if (((String) columnMapRowData.get("column_datatype"))
					.equalsIgnoreCase("Date")) {

				if (!(excaliburData.get(tempCount) == null)) {
					objectData[tempCount] = new Date(new java.util.Date(
							excaliburData.get(tempCount)).getTime());

				}

				if (excaliburData.get(tempCount) == null) {
					objectData[tempCount] = null;
				}
			}

			System.out.println(objectData[tempCount]);

			tempCount++;

		}
		objectDataList.add(objectData);
	}

	return objectDataList;
}

private String[] pmChecker(ArrayList<String> arrayList) {

	if (!(arrayList.get(2) == null)) {
		return new String[] { "YES", (String) arrayList.get(4) };
	}

	return new String[] { "NO", (String) arrayList.get(4) };
}

/*	public String getOppName(JdbcTemplate jdbcTemplate, String parameter) {
		System.out.println("asasass");
		return jdbcTemplate.queryForObject(DatabaseQuery.QUERY_TO_FETCH_OPPORTUNITY_NAME+parameter+"'", String.class);

	}
 */
/*@Override
	public List<Map<String, Object>> excaliburView(JdbcTemplate jdbcTemplate) {
		List<Map<String, Object>> excaliburList= jdbcTemplate.queryForList(DatabaseQuery.QUERY_TO_FETCH_EXCALIBURVIEW);
		System.out.println(excaliburList);
		return excaliburList;
	}*/



}





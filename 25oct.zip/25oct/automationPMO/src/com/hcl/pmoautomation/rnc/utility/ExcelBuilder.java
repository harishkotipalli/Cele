package com.hcl.pmoautomation.rnc.utility;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import com.hcl.pmoautomation.rnc.dao.GpnDao;
import com.hcl.pmoautomation.rnc.service.GpnService;
import com.hcl.pmoautomation.rnc.service.GpnServiceImpl;
import com.hcl.pmoautomation.rnc.vo.Bgv;
import com.hcl.pmoautomation.rnc.vo.Gpn;
 
/**
 * This class builds an Excel spreadsheet document using Apache POI library.
 * @author 
 *
 */
public class ExcelBuilder extends AbstractExcelView {
	
	@Override
    protected void buildExcelDocument(Map<String, Object> model,
            HSSFWorkbook workbook, HttpServletRequest request, HttpServletResponse response) {
        @SuppressWarnings("unchecked")
		List<Object[]>userList = (List<Object[]>) model.get("userList");
		
		//setExcelRows(excelSheet,animalList);
 
        // create a new Excel sheet
        HSSFSheet sheet = workbook.createSheet("Gpn Initiation");
        sheet.setDefaultColumnWidth(30);
         
        // create style for header cells
        CellStyle style = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setFontName("Arial");
        style.setFillForegroundColor(HSSFColor.BLUE.index);
        style.setFillPattern(CellStyle.SOLID_FOREGROUND);
        font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
        font.setColor(HSSFColor.WHITE.index);
        style.setFont(font);
         
        // create header row
        HSSFRow header = sheet.createRow(0);
         
        header.createCell(0).setCellValue("ID");
        header.getCell(0).setCellStyle(style);
        
        header.createCell(1).setCellValue("Name");
        header.getCell(1).setCellStyle(style);
         
        header.createCell(2).setCellValue("DOB");
        header.getCell(2).setCellStyle(style);
        
        header.createCell(3).setCellValue("Gender");
        header.getCell(3).setCellStyle(style);
         
        header.createCell(4).setCellValue("Previously Worked with client");
        header.getCell(4).setCellStyle(style);
         
        header.createCell(5).setCellValue("Region");
        header.getCell(5).setCellStyle(style);
         
        header.createCell(6).setCellValue("Project Name");
        header.getCell(6).setCellStyle(style);
         
        header.createCell(7).setCellValue("Correspondence Language");
        header.getCell(7).setCellStyle(style);
        
        header.createCell(8).setCellValue("Nationality");
        header.getCell(8).setCellStyle(style);
        
        header.createCell(9).setCellValue("RAS assignation from");
        header.getCell(9).setCellStyle(style);
        
        header.createCell(10).setCellValue("RAS assignation to");
        header.getCell(10).setCellStyle(style);
        
        header.createCell(11).setCellValue("OU code");
        header.getCell(11).setCellStyle(style);
        
        header.createCell(12).setCellValue("Client Hiring Manager Code");
        header.getCell(12).setCellStyle(style);
        
        header.createCell(13).setCellValue("Client Hiring Manager Mail id");
        header.getCell(13).setCellStyle(style);
        
        header.createCell(14).setCellValue("Snow Ticket Number");
        header.getCell(14).setCellStyle(style);
        
        header.createCell(15).setCellValue("GPN");
        header.getCell(15).setCellStyle(style);
        
        header.createCell(16).setCellValue("GPN creation Date");
        header.getCell(16).setCellStyle(style);
        
        header.createCell(17).setCellValue("GPN start Date");
        header.getCell(17).setCellStyle(style);
        
        header.createCell(18).setCellValue("Contract End Date");
        header.getCell(18).setCellStyle(style);
        
        
        // create data rows
        int rowCount = 1;
        
        /*objects[0]=bgv.getId();
		objects[1]=bgv.getRegion();
		objects[2]=bgv.getPreviously_Worked_With_Client();
		objects[3]=bgv.getEmp_First_Name()+" "+bgv.getEmp_Last_Name();
		objects[4]=bgv.getGender();
		objects[5]=bgv.getProject_Name();
		for(Gpn gpn:idTest){
			System.out.println(idTest);
			if(bgv.getId()==gpn.getBgvid()){
				objects[6]=gpn.getSnow_Ticket_Number();
				System.out.println(objects[6]);
				objects[7]=gpn.getSnow_Ticket_Init_Date();
			}
		objects[8]=bgv.getDate_Of_Birth();
		objects[9]=bgv.getCorrespondence_Language();
		objects[10]=bgv.getNationality();
		objects[11]=bgv.getAssignment_From();
		objects[12]=bgv.getAssignment_To();
		objects[13]=bgv.getOu_Code();
		objects[14]=bgv.getRequest_Type();
		objects[15]=bgv.getClient_Hiring_Manager_Gpn_No();
		objects[16]=bgv.getClient_Hiring_Manager_Mail_Id();
		}
*/
        
        for (Object[] aBook : userList) {
            HSSFRow aRow = sheet.createRow(rowCount++);
            aRow.createCell(0).setCellValue((int)aBook[0]);
            String name = (String) (aBook[3]) ;
            aRow.createCell(1).setCellValue(name);//name
            aRow.createCell(2).setCellValue((Date)aBook[8]);//DOB
            aRow.createCell(3).setCellValue((String)aBook[4]);//gender
            aRow.createCell(4).setCellValue((String)aBook[2]);//previouslyworked withclient
            aRow.createCell(5).setCellValue((String) aBook[1]); //region
            aRow.createCell(6).setCellValue((String)aBook[5]);//project name
            aRow.createCell(7).setCellValue((String)aBook[9]);//correspondence Language
            aRow.createCell(8).setCellValue((String)aBook[10]);//Nationality
            Date utilFromDate = (Date)aBook[11];
            aRow.createCell(9).setCellValue(utilFromDate );//RAS assignation from
            aRow.createCell(10).setCellValue((java.sql.Timestamp)aBook[12]);//RAS assignation to
            aRow.createCell(11).setCellValue((String)aBook[13]);//OU code
            aRow.createCell(12).setCellValue((int)aBook[15]);//Client Hiring Manager Code
            aRow.createCell(13).setCellValue((String)aBook[16]);//Client hiring manager mail id
            aRow.createCell(14).setCellValue((String)aBook[6]);//Snow ticket no
        
        }
    }
 
}
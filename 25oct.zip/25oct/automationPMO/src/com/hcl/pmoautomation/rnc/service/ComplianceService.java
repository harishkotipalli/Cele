package com.hcl.pmoautomation.rnc.service;


	import java.sql.Date;
import java.util.List;

	import org.springframework.jdbc.core.JdbcTemplate;

	import com.hcl.pmoautomation.rnc.vo.Bgv;
import com.hcl.pmoautomation.rnc.vo.Gpn;

	public interface ComplianceService {

		public List<Object[]> getCitList();
		/*public List<Object[]> getReactList(); 
		public boolean saveSnowTicketNumber( String[] snowTicketNumberList, String[] bgvid);
		boolean updateData(String[] Gpn, String[] id, String[] gpnCreationDate, String[] startdate,
				String[] enddate, boolean flagToDecide);
		public boolean updateReactSnowTicketNumber(String[] placedinSharePoint,
				String[] snowTicketNumberList, String[] gpn,String[] bgvid, String[] empclientid);
		public boolean updateReactGpn(String[] bgvid, String[] gpnStartDate, String[] contractEndDate, boolean flagToDecide);
		public List<Object[]> getTermiList();
		public List<Object[]> getTermiDetails(String choose, boolean select, int sap);
		public List<Object[]> getVdiList();
		public boolean saveGrsNumber(String[] grsNumber, String[] sapId, boolean flagtodecide);
		public boolean saveVdiNumber(String[] vdiNumber, String[] vdi, String[] sapID, boolean flagtodecide);
		public boolean saveTermiInfo(String gpn, String reason,String termiDate);
		public boolean updateTermData(String[] gpn, String[] physicalAccessRevokeDate, String[] logicalAccessRevokeDate, String[] vdiRevokeDate, String[] rsaSubmitted, String[] notepadSurrender);
		public boolean updateDataBGVTable(String[] gpn, String[] id,
				String[] startDateList, String[] endDateList, boolean flagToDecide);
		public boolean updateTermiSnowTicketNumber(String[] snowTicketNumberList, String[] gpn);
		public boolean saveinitDump(String attribute, String initiationSheetName,
				String initiationTableName, JdbcTemplate jdbcTemplate);*/

		public boolean saveCitInitData(String[] trainerList,
				String[] trainingPlace, String[] sapID);

		public boolean updateCitData(String[] citIndex, String[] citDate,
				String[] sapID);

		List<Object[]> getEIBlockList();
		

	}





package com.hcl.pmoautomation.rnc.controller;

import java.io.IOException;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service; 
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.hcl.pmoautomation.rnc.utility.ExcelSheetConstants;
import com.hcl.pmoautomation.rnc.service.GpnService;
import com.hcl.pmoautomation.rnc.vo.*;
import com.hcl.pmoautomation.rnc.dao.GpnDao;
import com.hcl.pmoautomation.rnc.dao.GpnDaoImpl;
import com.hcl.pmoautomation.rnc.service.*;


@Controller
@RequestMapping("pmoautomation/GPN")
public class GPNController {

	@Autowired(required=true)
	GpnService gpnService;
	GpnDao gpnDao;
	private JdbcTemplate jdbcTemplate;

	@RequestMapping(value="/onOff.php", method = RequestMethod.GET)
	public String getOnOffPage(HttpServletRequest request) {
		List<Object[]> userList = gpnService.getGpnList();
		request.setAttribute("gpnList", userList);
		List<Object[]> userList1 = gpnService.getReactList();
		request.setAttribute("gpnreactList", userList1);
		List<Object[]> userList3 = gpnService.getVdiList();
		request.setAttribute("vdiDetails", userList3);
		List<Object[]> userList4 = gpnService.getTermiList();
		request.setAttribute("termiDetails", userList4);
		return "GPN/OnOffBoard";
	}


	@RequestMapping(value = "/homeGPN.php", method = RequestMethod.GET)
	public String getUserLIst(HttpServletRequest request) {

		request.setAttribute("checkForFirst", true);
		List<Object[]> userList = gpnService.getGpnList();
		request.setAttribute("gpnList", userList);
		return "GPN/GpnInit";
	}
	
	
	@RequestMapping(value = "/downloadExcel.php", method = RequestMethod.GET)
    public ModelAndView downloadExcel() {
        // create some sample data
		List<Object[]> userList = gpnService.getGpnList();
		// return a view which will be resolved by an excel view resolver
		
		System.out.println("helooooooo  "+userList);
        return new ModelAndView("excelView", "userList", userList);
    }
	
	@RequestMapping(value = "/initiaitonUpload.php", method = RequestMethod.POST)
	public void excaliburUpload(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		// Internally hitting another Servlet

		// TODO:Spring Multipart enable it,Servlet disable it
		request.setAttribute("fileType", "GpnInitiator");
		request.getRequestDispatcher("/fileUpload.aspxx").forward(request,
				response);
	}

	@RequestMapping(value = "/initExcelReadSave.php", method = RequestMethod.POST)
	public String initSaveData(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		// Internally hitting another Servlet

		// TODO:Spring Multipart enable it,Servlet disable it
		//SRMappingService srMappingService = new SRMappingServiceImpl();
		boolean resultFlag = gpnService.saveinitDump(
				(String) request.getAttribute("filePath"),
				ExcelSheetConstants.INITIATION_SHEET_NAME,
				ExcelSheetConstants.INITIATION_TABLE_NAME);
		if (resultFlag) {
			request.setAttribute("initDataSaveResult", "Data Save Successfully!!!");
			return "GPN/GpnInit";
		}
		return "GPN/GpnInit";
	}

	

	@RequestMapping(value = "/saveGPNData.php", method = RequestMethod.GET)
	public String saveSharePointData(HttpServletRequest request) {

		String button = request.getParameter("btn");
		boolean flagToDecide= button.equalsIgnoreCase("Snow Ticket Created")?true:button.equalsIgnoreCase("Gpn Created")?false:false;
		System.out.println("GPNController --- : " + flagToDecide);

		int countNumb=0;
		String[] chkDataList=request.getParameterValues("chkToSave");
		String[] gpnCreationDate = new String[chkDataList.length] ;
		String[] gpn = new String[chkDataList.length] ;
		String[] bgvID = new String[chkDataList.length] ;
		String[] snowTicketNumberList = new String[chkDataList.length] ;
		String[] gpnStartDate = new String[chkDataList.length] ;
		String[] contractEndDate = new String[chkDataList.length] ;
		
		for(String count:chkDataList ){

			if(flagToDecide){
				bgvID[countNumb]=request.getParameter("bgvid"+count);
				snowTicketNumberList[countNumb]=request.getParameter("snowTicketNumb"+count)!=null?request.getParameter("snowTicketNumb"+count):request.getParameter("snowTicketNumb"+count);//snowTicketNumb
				countNumb++;
				request.setAttribute("snowSaveResult",gpnService.saveSnowTicketNumber(snowTicketNumberList,bgvID)?"Successfully saved !!":"Error");
			}
			if(!flagToDecide){
				bgvID[countNumb]=request.getParameter("bgvid"+count);
				//System.out.println("bgvid  "+bgvID);
				gpn[countNumb]=request.getParameter("gpn"+count)!=null?request.getParameter("gpn"+count):null;
				gpnStartDate[countNumb]=request.getParameter("gpnStartDate"+count)!=null?request.getParameter("gpnStartDate"+count):null;//gpnStartDate
				contractEndDate[countNumb]=request.getParameter("contractEndDate"+count)!=null?request.getParameter("contractEndDate"+count):null;//contractEndDate
				gpnCreationDate[countNumb]=request.getParameter("gpnCreationDate"+count)!=null?request.getParameter("gpnCreationDate"+count):null;
				System.out.println(gpnCreationDate);
				countNumb++;
				System.out.println(gpnService.updateDataBGVTable(gpn, bgvID, gpnStartDate, contractEndDate, flagToDecide)?"inserted into bgv table":"bgv table insertion failed");
				request.setAttribute("gpnDataSaveResult",gpnService.updateData(gpn,bgvID, gpnCreationDate, gpnStartDate, contractEndDate,flagToDecide)?"GPN no. Succcessfully Saved!!!":"Error");
			}
		}

		return "forward:../../pmoautomation/GPN/homeGPN.php";		
	}


	@RequestMapping(value = "/reactGPN.php", method = RequestMethod.GET)
	public String getReactLIst(HttpServletRequest request) {

		request.setAttribute("checkForFirst", true);
		List<Object[]> userList = gpnService.getReactList();
		
		request.setAttribute("gpnreactList", userList);
		return "GPN/GpnReact";
	}

	@RequestMapping(value = "/downloadReactExcel.php", method = RequestMethod.GET)
    public ModelAndView downloadReactExcel() {
        // create some sample data
		List<Object[]> userList = gpnService.getReactList();
				// return a view which will be resolved by an excel view resolver
        return new ModelAndView("excelReactView", "userList", userList);
    }
	
	@RequestMapping(value = "/saveGPNExtensionData.php", method = RequestMethod.GET)
	public String saveExtensionData(HttpServletRequest request) {

		String button = request.getParameter("btn");
		boolean flagToDecide= button.equalsIgnoreCase("Snow Ticket Created")?true:button.equalsIgnoreCase("Reactivation Done")?false:false;
		System.out.println("flag: "+flagToDecide);

		int countNumb=0;
		String[] chkDataList=request.getParameterValues("chkToSave");
		String[] placedinSharePoint = new String[chkDataList.length] ;
		String[] gpn = new String[chkDataList.length] ;
		String[] snowTicketNumberList = new String[chkDataList.length] ;
		String[] gpnStartDate = new String[chkDataList.length] ;
		String[] contractEndDate = new String[chkDataList.length] ;
		String[] bgvid = new String[chkDataList.length];
		String[] empclientid = new String[chkDataList.length];

		for(String count:chkDataList ){

			if(flagToDecide){
				gpn[countNumb]=request.getParameter("gpn"+count)!=null?request.getParameter("gpn"+count):null;
				snowTicketNumberList[countNumb]=request.getParameter("snowTicketNumb"+count)!=null?request.getParameter("snowTicketNumb"+count):snowTicketNumberList[countNumb];
				placedinSharePoint[countNumb]=null; //request.getParameter("sharepoint"+count);
				bgvid[countNumb]=request.getParameter("bgvid"+count);
				//empclientid[countNumb]=null;//request.getParameter("emp_client_id"+count);//emp_client_id
				System.out.println(gpn+"bgv"+bgvid+"emp"+empclientid);
				countNumb++;
				request.setAttribute("snowSaveResult",gpnService.updateReactSnowTicketNumber(placedinSharePoint,snowTicketNumberList,gpn,bgvid,empclientid)?"Successfully saved !!":"Error");
			}
			if(!flagToDecide){
				bgvid[countNumb]=request.getParameter("bgvid"+count);
				gpnStartDate[countNumb]=/*request.getParameter("gpnStartDate"+count)!=null?request.getParameter("gpnStartDate"+count):*/null;//gpnStartDate
				contractEndDate[countNumb]=request.getParameter("contractEndDate"+count)!=null?request.getParameter("contractEndDate"+count):null;
				countNumb++;
				request.setAttribute("gpnDataSaveResult",gpnService.updateReactGpn(bgvid, gpnStartDate, contractEndDate,flagToDecide)?"Successfully saved !!":"Error");
			}
		}
		return "forward:../../pmoautomation/GPN/reactGPN.php";		
	}


	/*@RequestMapping(value = "/gpnTermiManager.php", method = RequestMethod.GET)
	public String getTermiForm(HttpServletRequest request) {
		return "GPN/GpnTerminateMngr";
	}*/
	@RequestMapping(value = "/gpnTermiManager.php", method = RequestMethod.GET)
	public ModelAndView newContact(ModelAndView model) {
		Resource_amendments resource = new Resource_amendments();
		NewJoineeOdcAccess newAccess = new NewJoineeOdcAccess();
		 model.addObject("country", resource);
		 model.setViewName("GPN/GpnTerminateMngr");
		return model;
		
	}



	@RequestMapping(value = "/gpnTermiManagerData.php", method = RequestMethod.GET)
	public String getTermiFormData(HttpServletRequest request) {

		String button = request.getParameter("btn");
		boolean flagToDecide= button.equalsIgnoreCase("search")?true:button.equalsIgnoreCase("Terminate GPN")?false:false;
		if(flagToDecide){
			boolean select=false;
			request.setAttribute("checkForFirst", true);
			String choose= request.getParameter("Criteria");
			if(choose.equalsIgnoreCase("gpn")){
				select=true;
			}
			int sap = Integer.parseInt(request.getParameter("SAP"));
			List<Object[]> userList = gpnService.getTermiDetails(choose,select,sap);
			request.setAttribute("termiDetails", userList);
		}
		if(!flagToDecide){
			String gpn=request.getParameter("gpn");
			String reason= request.getParameter("Reason_for_Leaving");
			String termiDate= request.getParameter("termiDate");
			request.setAttribute("termiSaveResult",gpnService.saveTermiInfo(gpn,reason,termiDate)?"Request Submitted Successfully!":"Error");
		}
		return "forward:../../pmoautomation/GPN/gpnTermiManager.php";
	}

	@RequestMapping(value = "/termi.php", method = RequestMethod.GET)
	public String getTermiList(HttpServletRequest request) {

		request.setAttribute("checkForFirst", true);
		List<Object[]> userList = gpnService.getTermiList();
		request.setAttribute("termiDetails", userList);
		return "GPN/GpnTermiRnC";
	}
	
	@RequestMapping(value="/saveTermiData.php", method= RequestMethod.GET)
	public String getTermiSaveDate(HttpServletRequest request) {
		String[] chkDataList=request.getParameterValues("chkToSave");
		String[] gpn = new String[chkDataList.length] ;
		String[] bgvID = new String[chkDataList.length] ;
		String[] snowTicketNumberList = new String[chkDataList.length] ;
		String[] logicalAccessRevokeDate = new String[chkDataList.length] ;
		String[] physicalAccessRevokeDate = new String[chkDataList.length] ;
		String[] vdiRevokeDate = new String[chkDataList.length] ;
		String[] rsaSubmitted = new String[chkDataList.length] ;
		String[] notepadSurrender = new String[chkDataList.length] ;
		
		String button = request.getParameter("btn");
		int countNumb=0;
		boolean flagToDecide= button.equalsIgnoreCase("Snow Ticket Created")?true:button.equalsIgnoreCase("Update Termination Status")?false:false;
		
		for(String count:chkDataList ){
			if(flagToDecide){
			snowTicketNumberList[countNumb]=request.getParameter("snowTicketNumb"+count)!=null?request.getParameter("snowTicketNumb"+count):snowTicketNumberList[countNumb];
			gpn[countNumb]=request.getParameter("gpn"+count);
			countNumb++;
			request.setAttribute("termisnowSaveResult",gpnService.updateTermiSnowTicketNumber(snowTicketNumberList,gpn)?"Successfully saved !!":"Error");
		}
		if(!flagToDecide){
			gpn[countNumb]=request.getParameter("gpn"+count);
			//followUpMailDate[countNumb]=request.getParameter("followupMailDate"+count)!=null?request.getParameter("followupMailDate"+count):null;//gpnStartDate
			//escalationMailDate[countNumb]=request.getParameter("escalationMailDate"+count)!=null?request.getParameter("escalationMailDate"+count):null;
			physicalAccessRevokeDate[countNumb]=request.getParameter("physicalaccessRevokeDate"+count);
			logicalAccessRevokeDate[countNumb]=request.getParameter("logicalaccessRevokeDate"+count);
			vdiRevokeDate[countNumb]=request.getParameter("vdiRevokeDate"+count);
			rsaSubmitted[countNumb] = request.getParameter("rsaSubmit"+count);
			notepadSurrender[countNumb] = request.getParameter("notepadSurrender"+count);
			countNumb++;
			request.setAttribute("gpnDataSaveResult",gpnService.updateTermData(gpn,physicalAccessRevokeDate,logicalAccessRevokeDate,vdiRevokeDate,rsaSubmitted,notepadSurrender)?"Successfully saved !!":"Error");
		}
		
		}
		return "forward:../../pmoautomation/GPN/termi.php";
	}
	
	
	@RequestMapping(value = "/grsVdi.php", method = RequestMethod.GET)
	public String getGrsVdi(HttpServletRequest request) {
		request.setAttribute("checkForFirst", true);
		List<Object[]> userList = gpnService.getVdiList();
		request.setAttribute("vdiDetails", userList);

		return "GPN/GrsVdi";
	}
	

	@RequestMapping(value = "/saveGrsData.php", method = RequestMethod.GET)
	public String getGrsVdiData(HttpServletRequest request) {
		String button = request.getParameter("btn");
		boolean flagToDecide= button.equalsIgnoreCase("GRS Created")?true:button.equalsIgnoreCase("VDI Created")?false:false;
		System.out.println("flag: "+flagToDecide);
		int countNumb=0;
		String[] chkDataList=request.getParameterValues("chkToSave");
		System.out.println(chkDataList);
		String[] grsNumber = new String[chkDataList.length] ;
		String[] vdiNumber = new String[chkDataList.length] ;
		String[] sapId = new String[chkDataList.length] ;
		String[] vdi=new String[chkDataList.length];

		for(String count:chkDataList ){

			if(flagToDecide){
				grsNumber[countNumb]=request.getParameter("grsNumb"+count)!=null?request.getParameter("grsNumb"+count):request.getParameter("grsNumb"+count);
				sapId[countNumb]=request.getParameter("sap"+count);
				countNumb++;
				request.setAttribute("snowSaveResult",gpnService.saveGrsNumber(grsNumber,sapId,flagToDecide)?"Successfully saved !!":"Error");
			}
			if(!flagToDecide){
				vdiNumber[countNumb]=request.getParameter("vdiTicketNumb"+count)!=null?request.getParameter("vdiTicketNumb"+count):null;
				sapId[countNumb]=request.getParameter("sap"+count);
				vdi[countNumb]=request.getParameter("vdiNo"+count);
				countNumb++;
				request.setAttribute("snowSaveResult",gpnService.saveVdiNumber(vdiNumber, vdi, sapId, flagToDecide)?"Successfully saved !!":"Error");

			}
		}
		return "forward:../../pmoautomation/GPN/grsVdi.php";		
	}

}

//GPN
package com.hcl.pmoautomation.rnc.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.dao.DataAccessException;

import com.hcl.pmoautomation.rnc.vo.Gpn;

public class gpnReactExtractor {
	
	public Gpn extractData(ResultSet rs) throws SQLException,
	   DataAccessException {
	  
	Gpn gpn = new Gpn();
	gpn.setSnow_Ticket_Init_Date(rs.getTimestamp("snow_Ticket_Creation_Date"));
	gpn.setSnow_Ticket_Number(rs.getString("snow_Ticket_No"));
	gpn.setContract_End_Date(rs.getDate("contract_end_date"));
	gpn.setBgvid(rs.getInt("bgv_Id"));
	gpn.setEmp_Client_Id(rs.getInt("emp_Client_Id"));
	  
	  return gpn;
}


}

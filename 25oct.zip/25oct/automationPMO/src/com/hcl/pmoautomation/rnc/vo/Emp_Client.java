package com.hcl.pmoautomation.rnc.vo;

import java.sql.Time;
import java.sql.Timestamp;

import com.mysql.jdbc.Blob;

public class Emp_Client {
	
	private int id;
	private boolean RAS;
	private Timestamp RAS_Start_Date;
	private int LM_GPN;
	private String LM_Name;
	private String LM_Mail_Id;
	private String Client_Mail_Id;
	private String stream;
	private String Sector;
	private int sap_Id;
	private Timestamp nda_Signed_Date;
	private boolean nda_Signed_Status;
	private boolean nda_Copy;
	private String nda_Index;
	private Blob nda_Attachment;
	private String nda_Compliance_Status;
	private boolean grs_Request_Raised;
	private Timestamp grs_Request_Raised_Date;
	private String grs_Request_No; 
	private boolean vdi_Request_Raised;
	private Timestamp vdi_Request_Raised_Date;
	private String vdi_Request_Number; 
	private String vdi_No; 
	private Timestamp cit_Signed_Date;
	private int cit_Index_No;
	private String cit_Completion_Status;
	private Timestamp approval_Date_From_ODC_Manager;
	private boolean approval_Access_From_RnC;
	private Timestamp physical_Access_Given_Date;
	private Timestamp logical_Access_Given_Date;
	private String build_Name;
	private int tower_No;
	private int floor;
	private String odc_Number;
	private String odc_Type;
	private boolean email_Blocking;
	private String email_Blocking_Ticket_Number;
	private boolean internet_Blocking;
	private String internet_Blocking_Ticket_Number;
	private String emp_Type;
	private boolean bl_Applicable;
	private int bl_Taken_In_The_Year;
	private Timestamp bl_Start_Date;
	private Timestamp bl_End_Date;
	private String remarks;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public boolean isRAS() {
		return RAS;
	}
	public void setRAS(boolean rAS) {
		RAS = rAS;
	}
	public Timestamp getRAS_Start_Date() {
		return RAS_Start_Date;
	}
	public void setRAS_Start_Date(Timestamp rAS_Start_Date) {
		RAS_Start_Date = rAS_Start_Date;
	}
	public int getLM_GPN() {
		return LM_GPN;
	}
	public void setLM_GPN(int lM_GPN) {
		LM_GPN = lM_GPN;
	}
	public String getLM_Name() {
		return LM_Name;
	}
	public void setLM_Name(String lM_Name) {
		LM_Name = lM_Name;
	}
	public String getLM_Mail_Id() {
		return LM_Mail_Id;
	}
	public void setLM_Mail_Id(String lM_Mail_Id) {
		LM_Mail_Id = lM_Mail_Id;
	}
	public String getClient_Mail_Id() {
		return Client_Mail_Id;
	}
	public void setClient_Mail_Id(String client_Mail_Id) {
		Client_Mail_Id = client_Mail_Id;
	}
	public String getStream() {
		return stream;
	}
	public void setStream(String stream) {
		this.stream = stream;
	}
	public String getSector() {
		return Sector;
	}
	public void setSector(String sector) {
		Sector = sector;
	}
	public Timestamp getNda_Signed_Date() {
		return nda_Signed_Date;
	}
	public void setNda_Signed_Date(Timestamp nda_Signed_Date) {
		this.nda_Signed_Date = nda_Signed_Date;
	}
	public boolean isNda_Signed_Status() {
		return nda_Signed_Status;
	}
	public void setNda_Signed_Status(boolean nda_Signed_Status) {
		this.nda_Signed_Status = nda_Signed_Status;
	}
	public boolean isNda_Copy() {
		return nda_Copy;
	}
	public void setNda_Copy(boolean nda_Copy) {
		this.nda_Copy = nda_Copy;
	}
	public String getNda_Index() {
		return nda_Index;
	}
	public void setNda_Index(String nda_Index) {
		this.nda_Index = nda_Index;
	}
	public Blob getNda_Attachment() {
		return nda_Attachment;
	}
	public void setNda_Attachment(Blob nda_Attachment) {
		this.nda_Attachment = nda_Attachment;
	}
	public String getNda_Compliance_Status() {
		return nda_Compliance_Status;
	}
	public void setNda_Compliance_Status(String nda_Compliance_Status) {
		this.nda_Compliance_Status = nda_Compliance_Status;
	}
	public boolean isGrs_Request_Raised() {
		return grs_Request_Raised;
	}
	public void setGrs_Request_Raised(boolean grs_Request_Raised) {
		this.grs_Request_Raised = grs_Request_Raised;
	}
	public Timestamp getGrs_Request_Raised_Date() {
		return grs_Request_Raised_Date;
	}
	public void setGrs_Request_Raised_Date(Timestamp grs_Request_Raised_Date) {
		this.grs_Request_Raised_Date = grs_Request_Raised_Date;
	}
	public String getGrs_Request_No() {
		return grs_Request_No;
	}
	public void setGrs_Request_No(String grs_Request_No) {
		this.grs_Request_No = grs_Request_No;
	}
	public boolean isVdi_Request_Raised() {
		return vdi_Request_Raised;
	}
	public void setVdi_Request_Raised(boolean vdi_Request_Raised) {
		this.vdi_Request_Raised = vdi_Request_Raised;
	}
	public Timestamp getVdi_Request_Raised_Date() {
		return vdi_Request_Raised_Date;
	}
	public int getSap_Id() {
		return sap_Id;
	}
	public void setSap_Id(int sap_Id) {
		this.sap_Id = sap_Id;
	}
	public void setVdi_Request_Raised_Date(Timestamp vdi_Request_Raised_Date) {
		this.vdi_Request_Raised_Date = vdi_Request_Raised_Date;
	}
	public String getVdi_Request_Number() {
		return vdi_Request_Number;
	}
	public void setVdi_Request_Number(String vdi_Request_Number) {
		this.vdi_Request_Number = vdi_Request_Number;
	}
	public String getVdi_No() {
		return vdi_No;
	}
	public void setVdi_No(String vdi_No) {
		this.vdi_No = vdi_No;
	}
	public Timestamp getCit_Signed_Date() {
		return cit_Signed_Date;
	}
	public void setCit_Signed_Date(Timestamp cit_Signed_Date) {
		this.cit_Signed_Date = cit_Signed_Date;
	}
	public int getCit_Index_No() {
		return cit_Index_No;
	}
	public void setCit_Index_No(int cit_Index_No) {
		this.cit_Index_No = cit_Index_No;
	}
	public String getCit_Completion_Status() {
		return cit_Completion_Status;
	}
	public void setCit_Completion_Status(String cit_Completion_Status) {
		this.cit_Completion_Status = cit_Completion_Status;
	}
	public Timestamp getApproval_Date_From_ODC_Manager() {
		return approval_Date_From_ODC_Manager;
	}
	public void setApproval_Date_From_ODC_Manager(
			Timestamp approval_Date_From_ODC_Manager) {
		this.approval_Date_From_ODC_Manager = approval_Date_From_ODC_Manager;
	}
	public boolean isApproval_Access_From_RnC() {
		return approval_Access_From_RnC;
	}
	public void setApproval_Access_From_RnC(boolean approval_Access_From_RnC) {
		this.approval_Access_From_RnC = approval_Access_From_RnC;
	}
	public Timestamp getPhysical_Access_Given_Date() {
		return physical_Access_Given_Date;
	}
	public void setPhysical_Access_Given_Date(Timestamp physical_Access_Given_Date) {
		this.physical_Access_Given_Date = physical_Access_Given_Date;
	}
	public Timestamp getLogical_Access_Given_Date() {
		return logical_Access_Given_Date;
	}
	public void setLogical_Access_Given_Date(Timestamp logical_Access_Given_Date) {
		this.logical_Access_Given_Date = logical_Access_Given_Date;
	}
	public String getBuild_Name() {
		return build_Name;
	}
	public void setBuild_Name(String build_Name) {
		this.build_Name = build_Name;
	}
	public int getTower_No() {
		return tower_No;
	}
	public void setTower_No(int tower_No) {
		this.tower_No = tower_No;
	}
	public int getFloor() {
		return floor;
	}
	public void setFloor(int floor) {
		this.floor = floor;
	}
	public String getOdc_Number() {
		return odc_Number;
	}
	public void setOdc_Number(String odc_Number) {
		this.odc_Number = odc_Number;
	}
	public String getOdc_Type() {
		return odc_Type;
	}
	public void setOdc_Type(String odc_Type) {
		this.odc_Type = odc_Type;
	}
	public boolean isEmail_Blocking() {
		return email_Blocking;
	}
	public void setEmail_Blocking(boolean email_Blocking) {
		this.email_Blocking = email_Blocking;
	}
	public String getEmail_Blocking_Ticket_Number() {
		return email_Blocking_Ticket_Number;
	}
	public void setEmail_Blocking_Ticket_Number(String email_Blocking_Ticket_Number) {
		this.email_Blocking_Ticket_Number = email_Blocking_Ticket_Number;
	}
	public boolean isInternet_Blocking() {
		return internet_Blocking;
	}
	public void setInternet_Blocking(boolean internet_Blocking) {
		this.internet_Blocking = internet_Blocking;
	}
	public String getInternet_Blocking_Ticket_Number() {
		return internet_Blocking_Ticket_Number;
	}
	public void setInternet_Blocking_Ticket_Number(
			String internet_Blocking_Ticket_Number) {
		this.internet_Blocking_Ticket_Number = internet_Blocking_Ticket_Number;
	}
	public String getEmp_Type() {
		return emp_Type;
	}
	public void setEmp_Type(String emp_Type) {
		this.emp_Type = emp_Type;
	}
	public boolean isBl_Applicable() {
		return bl_Applicable;
	}
	public void setBl_Applicable(boolean bl_Applicable) {
		this.bl_Applicable = bl_Applicable;
	}
	public int getBl_Taken_In_The_Year() {
		return bl_Taken_In_The_Year;
	}
	public void setBl_Taken_In_The_Year(int bl_Taken_In_The_Year) {
		this.bl_Taken_In_The_Year = bl_Taken_In_The_Year;
	}
	public Timestamp getBl_Start_Date() {
		return bl_Start_Date;
	}
	public void setBl_Start_Date(Timestamp bl_Start_Date) {
		this.bl_Start_Date = bl_Start_Date;
	}
	public Timestamp getBl_End_Date() {
		return bl_End_Date;
	}
	public void setBl_End_Date(Timestamp bl_End_Date) {
		this.bl_End_Date = bl_End_Date;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
		
	

}

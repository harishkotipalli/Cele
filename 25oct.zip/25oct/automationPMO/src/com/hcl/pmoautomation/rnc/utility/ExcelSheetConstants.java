package com.hcl.pmoautomation.rnc.utility;

public interface ExcelSheetConstants {
	
	public String INITIATION_SHEET_NAME="Gpn Initiation";
	public String INITIATION_TABLE_NAME="gpn_initiation";
	//public int[] INITIATION_MANDATORY_FIELDS_INDEXS={15,16,17,18};
	

}

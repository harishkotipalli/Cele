package com.hcl.pmoautomation.rnc.dao;

import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.hcl.pmoautomation.ot.dao.DatabaseQuery;
import com.hcl.pmoautomation.rnc.vo.NewJoineeOdcAccess;

@Component
public class NewOdcAccessImpl implements OdcAccessDaoI {

	@Override
	public List<Map<String, Object>> getEmployee(int sapcode,
			JdbcTemplate jdbcTemplate) {
		String sql = "select emp_name,sap_code,project from ras where sapcode=?";
		Object[] params = { sapcode };
		return jdbcTemplate.queryForList(sql, params);

	}

	@Override
	public int addNewJoineeOdcdetails(NewJoineeOdcAccess odc,String gpn,
			JdbcTemplate jdbcTemplate) {

		String sql = "insert into odc_access (type,gpn,reason_for_access_request,effective_date_from,effective_date_to,target_build_name,target_tower_no,target_floor,odcnumber,odc_type,seat_code,requested_by,requested_date) values(?,?,?,?,?,?,?,?,?,?,?,?,?)";
		Object[] params = { odc.getType(), gpn,
				odc.getReason_For_Access(), odc.getEffective_Date_From(),
				odc.getEffective_Date_To(), odc.getTarget_Build_Name(),
				odc.getTarget_Tower_No(), odc.getTarget_Floor_No(),
				odc.getOdcNumber(), odc.getOdcType(), odc.getSeatCode(),
				odc.getRequestedBy(), odc.getRequestedDate() };

		return jdbcTemplate.update(sql, params);
	}

	public String getEmp(JdbcTemplate jdbcTemplate,String sapCode) {
		
		
		List<Map<String, Object>> emp=jdbcTemplate.queryForList("select EMP_FIRST_NAME,EMP_MIDDLE_NAME,EMP_LAST_NAME from bgv where SAP_ID=?", new Object[]{Integer.parseInt(sapCode)});
		return (String)(emp.get(0)).get("EMP_FIRST_NAME")+(String)(emp.get(0)).get("EMP_MIDDLE_NAME")+(String)(emp.get(0)).get("EMP_LAST_NAME");

	}
	public String getemployeename(JdbcTemplate jdbcTemplate, String parameter) {
		System.out.println("gettingemployeename");
		return jdbcTemplate.queryForObject(DataBaseRNCQuery.QUERY_TO_GET_employeename_forodcacess_usingsapcode+parameter, String.class);
		
	}
	public String getprojectname(JdbcTemplate jdbcTemplate, String parameter) {
		System.out.println("gettinprojectname");
		return jdbcTemplate.queryForObject(DataBaseRNCQuery.QUERY_TO_GET_projectname_forodcacess_usingsapcode+parameter, String.class);
		
	}
	public String getgpn(JdbcTemplate jdbcTemplate, String parameter) {
		System.out.println("gettinggpn");
		return jdbcTemplate.queryForObject(DataBaseRNCQuery.QUERY_TO_GET_gpn_forodcacess_usingsapcode+parameter, String.class);
		
	}
	public String getlocation(JdbcTemplate jdbcTemplate, String parameter) {
		System.out.println("gettinglocation");
		return jdbcTemplate.queryForObject(DataBaseRNCQuery.QUERY_TO_GET_location_forodcacess_usingsapcode+parameter, String.class);
		
	}
}

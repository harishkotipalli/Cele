package com.hcl.pmoautomation.rnc.model;

public class DownloadspathVO {
 String ndaformpath;

public String getNdaformpath() {
	return ndaformpath;
}

public void setNdaformpath(String ndaformpath) {
	this.ndaformpath = ndaformpath;
}

@Override
public String toString() {
	return  ndaformpath;
}
 
 
 
 
}

package com.hcl.pmoautomation.rnc.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service; 

import com.hcl.pmoautomation.ot.utility.ExcelGenericReader;
import com.hcl.pmoautomation.rnc.dao.GpnDao;
import com.hcl.pmoautomation.rnc.utility.GpnInitExcelGenericReader;
import com.hcl.pmoautomation.rnc.vo.Bgv;
import com.hcl.pmoautomation.rnc.vo.Gpn;

@Service
@Component
public class GpnServiceImpl implements GpnService {

 @Autowired(required=true)
 GpnDao Gpndao;
 JdbcTemplate jdbcTemplate;
// GpnInitExcelGenericReader gpnInitExcelGenericReader;

 /*@Override
 public boolean insertData(Gpn Gpn) {
 return Gpndao.insertData(Gpn);
 }
*/
 @Override
 public List<Object[]> getGpnList() {
  return Gpndao.getGpnList();
 }
 
 
 @Override
public List<Object[]> getReactList() {
	// TODO Auto-generated method stub
	 return Gpndao.getReactList();
	 }


 @Override
 public boolean updateData(String[] Gpn, String[] id, String[] gpnCreationDate, String[] startdate, String[] enddate, boolean flagToDecide ) {
  return Gpndao.updateData(Gpn,id, gpnCreationDate, startdate, enddate, flagToDecide);//gpn,bgvID, gpnCreationDate, gpnStartDate, contractEndDate,flagToDecide
 }




@Override
public boolean saveSnowTicketNumber( String[] snowTicketNumberList, String[] bgvID) {
return	Gpndao.saveSnowTicketNumber( snowTicketNumberList,bgvID);
	
}


@Override
public boolean updateReactSnowTicketNumber(String[] placedinSharePoint,
		String[] snowTicketNumberList, String[] gpn, String[] bgvid, String[] empclientid) {
	return Gpndao.updateReactSnowTicketNumber(placedinSharePoint, snowTicketNumberList, gpn, bgvid, empclientid);
}



@Override
public boolean updateReactGpn(String[] bgvid, String[] gpnStartDate,
		String[] contractEndDate, boolean flagToDecide) {
	return Gpndao.updateReactGpn(bgvid, gpnStartDate, contractEndDate, flagToDecide);
}


@Override
public List<Object[]> getTermiList() {
	return Gpndao.getTermiList();
}

@Override
public boolean updateTermData(String[] gpn, String[] physicalAccessRevokeDate, String[] logicalAccessRevokeDate, String[] vdiRevokeDate, String[] rsaSubmitted, String[] notepadSurrender) {
	return Gpndao.updateTermiData(gpn,physicalAccessRevokeDate,logicalAccessRevokeDate,vdiRevokeDate,rsaSubmitted,notepadSurrender);
}


@Override
public List<Object[]> getTermiDetails(String choose, boolean select, int sap) {
	return Gpndao.getTermiDetails(choose,select,sap);
}

@Override
public boolean saveTermiInfo(String gpn, String reason, String termiDate) {
	return Gpndao.saveTermiInfo(gpn,reason,termiDate);
}

@Override
public List<Object[]> getVdiList() {
	return Gpndao.getVdiDetails();
}


@Override
public boolean saveGrsNumber(String[] grsNumber,String[] sapId, boolean flagtodecide) {
	return Gpndao.saveGrsNumber(grsNumber,sapId,flagtodecide);
}


@Override
public boolean saveVdiNumber(String[] vdiNumber, String[] vdi, String[] sapID,
		boolean flagtodecide) {
	return Gpndao.saveVdiNumber(vdiNumber, vdi, sapID, flagtodecide);
}


@Override
public boolean updateDataBGVTable(String[] gpn, String[] id,
		String[] startDateList, String[] endDateList, boolean flagToDecide) {
	return Gpndao.updateDataBGVTable(gpn, id, startDateList, endDateList, flagToDecide);
}


@Override
public boolean updateTermiSnowTicketNumber(String[] snowTicketNumberList, String[] gpn) {
	  return Gpndao.updateTermiSnowTicketNumber(snowTicketNumberList,gpn);
}


@Override
public boolean saveinitDump(String attribute, String initiationSheetName,
		String initiationTableName) {
	boolean result=false;
	try {
//		System.out.println(gpnInitExcelGenericReader);
		 result= Gpndao.saveAllDataDynamically(GpnInitExcelGenericReader
				.readExcelAllDynamically(attribute, initiationSheetName, initiationTableName,jdbcTemplate,Gpndao),
				initiationTableName);
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return result;
} 

}







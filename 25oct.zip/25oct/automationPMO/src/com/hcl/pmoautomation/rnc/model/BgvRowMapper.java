package com.hcl.pmoautomation.rnc.model;

//RowMapper is a useful interface provided by spring JDBC, 
//it can be used to map rows in a resultset on per row basis. 
//RowMapper with ResultSetExtractor can be used as a powerful combination to map relational database rows to domain object.



import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;


import com.hcl.pmoautomation.rnc.vo.*;

public class BgvRowMapper implements RowMapper<Bgv> {

 @Override
 public Bgv mapRow(ResultSet resultSet, int line) throws SQLException {
  BgvExtractor bgvExtractor = new BgvExtractor();
  return  bgvExtractor.extractData(resultSet);
 }
 

}
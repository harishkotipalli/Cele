package com.hcl.pmoautomation.rnc.vo;

import java.util.Date;

public class NewJoineeOdcAccess {
	
    private String type;
	private String gpn;
	private String empName;
	private String sapcode;
	private String projectName;
	private String reason_For_Access;
	private String effective_Date_From;
	private String effective_Date_To;
	private String target_Build_Name;
	private String target_Tower_No;
	private String target_Floor_No;
	private String odcNumber;
	private String odcType;
	private String seatCode;
	private String location;
	private String requestedBy;
	private String requestedDate;
	
	

	public NewJoineeOdcAccess() {
		// TODO Auto-generated constructor stub
	}



	public String getType() {
		return type;
	}



	public void setType(String type) {
		this.type = type;
	}



	



	public String getGpn() {
		return gpn;
	}



	public void setGpn(String gpn) {
		this.gpn = gpn;
	}



	public String getEmpName() {
		return empName;
	}



	public void setEmpName(String empName) {
		this.empName = empName;
	}



	public String getSapcode() {
		return sapcode;
	}



	public void setSapcode(String sapcode) {
		this.sapcode = sapcode;
	}



	public String getProjectName() {
		return projectName;
	}



	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}



	public String getReason_For_Access() {
		return reason_For_Access;
	}



	public void setReason_For_Access(String reason_For_Access) {
		this.reason_For_Access = reason_For_Access;
	}



	public String getEffective_Date_From() {
		return effective_Date_From;
	}



	public void setEffective_Date_From(String effective_Date_From) {
		this.effective_Date_From = effective_Date_From;
	}



	public String getEffective_Date_To() {
		return effective_Date_To;
	}



	public void setEffective_Date_To(String effective_Date_To) {
		this.effective_Date_To = effective_Date_To;
	}



	public String getTarget_Build_Name() {
		return target_Build_Name;
	}



	public void setTarget_Build_Name(String target_Build_Name) {
		this.target_Build_Name = target_Build_Name;
	}







	public String getTarget_Tower_No() {
		return target_Tower_No;
	}



	public void setTarget_Tower_No(String target_Tower_No) {
		this.target_Tower_No = target_Tower_No;
	}






	public String getTarget_Floor_No() {
		return target_Floor_No;
	}



	public void setTarget_Floor_No(String target_Floor_No) {
		this.target_Floor_No = target_Floor_No;
	}



	public String getOdcNumber() {
		return odcNumber;
	}



	public void setOdcNumber(String odcNumber) {
		this.odcNumber = odcNumber;
	}



	public String getOdcType() {
		return odcType;
	}



	public void setOdcType(String odcType) {
		this.odcType = odcType;
	}



	public String getSeatCode() {
		return seatCode;
	}



	public void setSeatCode(String seatCode) {
		this.seatCode = seatCode;
	}



	public String getLocation() {
		return location;
	}



	public void setLocation(String location) {
		this.location = location;
	}



	public String getRequestedBy() {
		return requestedBy;
	}



	public void setRequestedBy(String requestedBy) {
		this.requestedBy = requestedBy;
	}



	public String getRequestedDate() {
		return requestedDate;
	}



	public void setRequestedDate(String requestedDate) {
		this.requestedDate = requestedDate;
	}



	public NewJoineeOdcAccess(String type, String gpn, String empName,
			String sapcode, String projectName, String reason_For_Access,
			String effective_Date_From, String effective_Date_To,
			String target_Build_Name, String target_Tower_No, String target_Floor_No,
			String odcNumber, String odcType, String seatCode, String location,
			String requestedBy, String requestedDate) {
		super();
		this.type = type;
		this.gpn = gpn;
		this.empName = empName;
		this.sapcode = sapcode;
		this.projectName = projectName;
		this.reason_For_Access = reason_For_Access;
		this.effective_Date_From = effective_Date_From;
		this.effective_Date_To = effective_Date_To;
		this.target_Build_Name = target_Build_Name;
		this.target_Tower_No = target_Tower_No;
		this.target_Floor_No = target_Floor_No;
		this.odcNumber = odcNumber;
		this.odcType = odcType;
		this.seatCode = seatCode;
		this.location = location;
		this.requestedBy = requestedBy;
		this.requestedDate = requestedDate;
	}



	@Override
	public String toString() {
		return "NewJoineeOdcAccess [type=" + type + ", gpn=" + gpn
				+ ", empName=" + empName + ", sapcode=" + sapcode
				+ ", projectName=" + projectName + ", reason_For_Access="
				+ reason_For_Access + ", effective_Date_From="
				+ effective_Date_From + ", effective_Date_To="
				+ effective_Date_To + ", target_Build_Name="
				+ target_Build_Name + ", target_Tower_No=" + target_Tower_No
				+ ", target_Floor_No=" + target_Floor_No + ", odcNumber="
				+ odcNumber + ", odcType=" + odcType + ", seatCode=" + seatCode
				+ ", location=" + location + ", requestedBy=" + requestedBy
				+ ", requestedDate=" + requestedDate + "]";
	}

   










	

}

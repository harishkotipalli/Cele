package com.hcl.pmoautomation.rnc.controller;

import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.hcl.pmoautomation.rnc.vo.NewJoineeOdcAccess;

public class OdcValidator implements Validator{

	@Override
	public boolean supports(Class clazz) {
	
		return NewJoineeOdcAccess.class.equals(clazz);
	}

	@Override
	public void validate(Object obj, Errors errors) {
		NewJoineeOdcAccess odcaccess = (NewJoineeOdcAccess) obj;
		
		if(odcaccess.getType()==null  || odcaccess.getType().length()==0  || odcaccess.getType().equals("--Select--")){
			errors.rejectValue("type", "errors.type",new Object[]{},"Select type of odc");
		
	}
		if(odcaccess.getGpn()==null  || odcaccess.getGpn().length()==0){
			errors.rejectValue("gpn","errors.gpn.required", new Object[]{},"Gpn is required" );
		}
		else if(odcaccess.getGpn().length()!=8){
			errors.rejectValue("gpn", "errors.gpn.invalid",new Object[]{},"Gpn contains only 8 digits");
		}
		else if(odcaccess.getGpn().length()==8){
			try{
				Integer.parseInt(odcaccess.getGpn());
			}catch(Exception e){
				errors.rejectValue("gpn", "errors.gpn.invalid", new Object[]{}, "Gpn contains only digits");
			}
			
		}
		if(odcaccess.getSapcode()==null || odcaccess.getSapcode().length()==0){
			errors.rejectValue("sapcode", "errors.sapcode.required", new Object[]{},"Sap Code is required");
		}
		else if(odcaccess.getSapcode().length()!=8){
			errors.rejectValue("sapcode", "errors.sapcode.invaild", new Object[]{},"Sap Code contains 8 digits");
		}
		else if(odcaccess.getSapcode().length()==8){
			try{
				Integer.parseInt(odcaccess.getSapcode());
			}catch(Exception e){
				errors.rejectValue("sapcode", "errors.sapcode.invalid", new Object[]{},"Sap Code contains only digits");
			}
		}
		if(odcaccess.getReason_For_Access()==null  || odcaccess.getReason_For_Access().length()==0  || odcaccess.getReason_For_Access().equals("--Select--") ){
			errors.rejectValue("reason_For_Access", "errors.reason_For_Access.required", new Object[]{},"Select reason for access");
		}
		if(odcaccess.getTarget_Build_Name()==null || odcaccess.getTarget_Build_Name().length()==0 || odcaccess.getTarget_Build_Name().equals("--Select--") ){
			errors.rejectValue("target_Build_Name", "errors.target_Build_Name.required", new Object[]{},"Select Building Name");
		}
		if(odcaccess.getTarget_Tower_No()==null || odcaccess.getTarget_Tower_No().length()==0 || odcaccess.getTarget_Tower_No().equals("--Select--")){
			errors.rejectValue("target_Tower_No", "errors.target_Tower_No.required", new Object[]{}, "Select Tower Number");
		}
		if(odcaccess.getTarget_Floor_No()==null || odcaccess.getTarget_Floor_No().length()==0 || odcaccess.getTarget_Floor_No().equals("--Select--")){
			errors.rejectValue("target_Floor_No", "errors.target_Floor_No.required", new Object[]{}, "Select Floor Number" );
		}
		if(odcaccess.getOdcNumber()==null || odcaccess.getOdcNumber().length()==0){
			errors.rejectValue("odcNumber","errors.odcNumber.required" , new Object[]{}, "Select ODC Number");
		}
		if(odcaccess.getOdcType()==null || odcaccess.getOdcType().length()==0 || odcaccess.getOdcType().equals("--Select--")){
			errors.rejectValue("odcType", "errors.odcType.required", new Object[]{},"Select Odc Type");
		}
		
	}

}

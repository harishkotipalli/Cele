package com.hcl.pmoautomation.rnc.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.hcl.pmoautomation.rnc.vo.NewJoineeOdcAccess;

public interface RncNewAccessDao {
	
	List<NewJoineeOdcAccess> getOdcDetails(JdbcTemplate jdbcTemplate);
	
	public boolean saveEmpClient(JdbcTemplate jdbcTemplate, Object[] odcDetail);

}

package com.hcl.pmoautomation.rnc.vo;

import java.util.Date;
import java.sql.Timestamp;

public class Gpn {

	private int gpn;
	private String requested_By;
	private Timestamp requested_Date_By_Del;
	private Timestamp pre_Start_Check_Comp_Date;
	private int bgv_Status;
	private Date gpn_Creation_Date;
	private Timestamp client_Contract_Rehire_Date;
	private java.util.Date contract_End_Date;
	private int ageing;
	private int sla;
	private boolean gpn_Created_Flag;
	private Date share_Point_Add_Date;
	private String placed_In_Sharepoint_For_WMA;
	private Timestamp snow_Ticket_Init_Date;
	private String snow_Ticket_Number;
	private String snow_Ticket_Status;
	private Date gpn_Start_Date;
	private String requestor_PMO;
	private Timestamp gpn_Requested_Date;
	private String modified_By;
	private Timestamp modified_On;
	private String status;
	private int emp_Client_Id;
	private int bgvid;
	
	
	
	public int getEmp_Client_Id() {
		return emp_Client_Id;
	}
	public void setEmp_Client_Id(int emp_Client_Id) {
		this.emp_Client_Id = emp_Client_Id;
	}
	public int getBgvid() {
		return bgvid;
	}
	public void setBgvid(int bgvid) {
		this.bgvid = bgvid;
	}
	public int getGpn() {
		return gpn;
	}
	public void setGpn(int gpn) {
		this.gpn = gpn;
	}
	public String getRequested_By() {
		return requested_By;
	}
	public void setRequested_By(String requested_By) {
		this.requested_By = requested_By;
	}
	public Timestamp getRequested_Date_By_Del() {
		return requested_Date_By_Del;
	}
	public void setRequested_Date_By_Del(Timestamp requested_Date_By_Del) {
		this.requested_Date_By_Del = requested_Date_By_Del;
	}
	public Timestamp getPre_Start_Check_Comp_Date() {
		return pre_Start_Check_Comp_Date;
	}
	public void setPre_Start_Check_Comp_Date(Timestamp date) {
		this.pre_Start_Check_Comp_Date = date;
	}
	public int getBgv_Status() {
		return bgv_Status;
	}
	public void setBgv_Status(int bgv_Status) {
		this.bgv_Status = bgv_Status;
	}
	public Date getGpn_Creation_Date() {
		return gpn_Creation_Date;
	}
	public void setGpn_Creation_Date(Date createDate) {
		this.gpn_Creation_Date = createDate;
	}
	public Timestamp getClient_Contract_Rehire_Date() {
		return client_Contract_Rehire_Date;
	}
	public void setClient_Contract_Rehire_Date(Timestamp client_Contract_Rehire_Date) {
		this.client_Contract_Rehire_Date = client_Contract_Rehire_Date;
	}
	public java.util.Date getContract_End_Date() {
		return contract_End_Date;
	}
	public void setContract_End_Date(java.util.Date gEndDate) {
		this.contract_End_Date = gEndDate;
	}
	public int getAgeing() {
		return ageing;
	}
	public void setAgeing(int ageing) {
		this.ageing = ageing;
	}
	public int getSla() {
		return sla;
	}
	public void setSla(int sla) {
		this.sla = sla;
	}
	public boolean isGpn_Created_Flag() {
		return gpn_Created_Flag;
	}
	public void setGpn_Created_Flag(boolean gpn_Created_Flag) {
		this.gpn_Created_Flag = gpn_Created_Flag;
	}
	public Date getShare_Point_Add_Date() {
		return share_Point_Add_Date;
	}
	public void setShare_Point_Add_Date(Date sharepointDate) {
		this.share_Point_Add_Date = sharepointDate;
	}
	public String getPlaced_In_Sharepoint_For_WMA() {
		return placed_In_Sharepoint_For_WMA;
	}
	public void setPlaced_In_Sharepoint_For_WMA(String string) {
		this.placed_In_Sharepoint_For_WMA = string;
	}
	public Timestamp getSnow_Ticket_Init_Date() {
		return snow_Ticket_Init_Date;
	}
	public void setSnow_Ticket_Init_Date(Timestamp snow_Ticket_Init_Date) {
		this.snow_Ticket_Init_Date = snow_Ticket_Init_Date;
	}
	
	@Override
	public String toString() {
		return "Gpn [gpn=" + gpn + ", requested_By=" + requested_By
				+ ", requested_Date_By_Del=" + requested_Date_By_Del
				+ ", pre_Start_Check_Comp_Date=" + pre_Start_Check_Comp_Date
				+ ", bgv_Status=" + bgv_Status + ", gpn_Creation_Date="
				+ gpn_Creation_Date + ", client_Contract_Rehire_Date="
				+ client_Contract_Rehire_Date + ", contract_End_Date="
				+ contract_End_Date + ", ageing=" + ageing + ", sla=" + sla
				+ ", gpn_Created_Flag=" + gpn_Created_Flag
				+ ", share_Point_Add_Date=" + share_Point_Add_Date
				+ ", placed_In_Sharepoint_For_WMA="
				+ placed_In_Sharepoint_For_WMA + ", snow_Ticket_Init_Date="
				+ snow_Ticket_Init_Date + ", snow_Ticket_Number="
				+ snow_Ticket_Number + ", snow_Ticket_Status="
				+ snow_Ticket_Status + ", gpn_Start_Date=" + gpn_Start_Date
				+ ", requestor_PMO=" + requestor_PMO + ", gpn_Requested_Date="
				+ gpn_Requested_Date + ", modified_By=" + modified_By
				+ ", modified_On=" + modified_On + ", status=" + status
				+ ", emp_Client_Id=" + emp_Client_Id + ", bgvid=" + bgvid + "]";
	}
	public String getSnow_Ticket_Number() {
		return snow_Ticket_Number;
	}
	public void setSnow_Ticket_Number(String snow_Ticket_Number) {
		this.snow_Ticket_Number = snow_Ticket_Number;
	}
	public String getSnow_Ticket_Status() {
		return snow_Ticket_Status;
	}
	public void setSnow_Ticket_Status(String snow_Ticket_Status) {
		this.snow_Ticket_Status = snow_Ticket_Status;
	}
	public Date getGpn_Start_Date() {
		return gpn_Start_Date;
	}
	public void setGpn_Start_Date(Date sqldate) {
		this.gpn_Start_Date = sqldate;
	}
	public String getRequestor_PMO() {
		return requestor_PMO;
	}
	public void setRequestor_PMO(String requestor_PMO) {
		this.requestor_PMO = requestor_PMO;
	}
	public Timestamp getGpn_Requested_Date() {
		return gpn_Requested_Date;
	}
	public void setGpn_Requested_Date(Timestamp gpn_Requested_Date) {
		this.gpn_Requested_Date = gpn_Requested_Date;
	}
	public String getModified_By() {
		return modified_By;
	}
	public void setModified_By(String modified_By) {
		this.modified_By = modified_By;
	}
	public Timestamp getModified_On() {
		return modified_On;
	}
	public void setModified_On(Timestamp modified_On) {
		this.modified_On = modified_On;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public void setSap_Id(int int1) {
		// TODO Auto-generated method stub
		
	}
	
	
	
}

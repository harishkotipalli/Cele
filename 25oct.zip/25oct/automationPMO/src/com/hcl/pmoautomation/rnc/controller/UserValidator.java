package com.hcl.pmoautomation.rnc.controller;



import org.apache.catalina.User;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

public class UserValidator implements Validator {
	 public boolean supports(Class clazz) {
		 return User.class.equals(clazz);
	 }
	

	@Override
	public void validate(Object command,Errors errors) {
		     User user = (User) command;
			 if(user.getUsername()==null || user.getUsername().length()==0){
				 errors.rejectValue("username","error.username.required",null,"Username is required");
			 }
		 


		 if(user.getPassword()==null || user.getPassword().length()==0){
			 errors.rejectValue("password","error.password.required",null,"Password is required");
		 }

}

}


package com.hcl.pmoautomation.rnc.model;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;
import com.hcl.pmoautomation.rnc.vo.*;

public class BgvReactExtractor implements ResultSetExtractor<Bgv>{

 public Bgv extractData(ResultSet rs) throws SQLException,
   DataAccessException {
  
  Bgv bgv = new Bgv();
  Gpn gpn = new Gpn();
  
  bgv.setId(rs.getInt("id"));
  bgv.setSap_Id(rs.getInt("sap_id"));
	bgv.setEmp_First_Name(rs.getString("emp_First_Name"));
 	bgv.setGpn(rs.getInt("gpn"));
 	bgv.setProject_Name(rs.getString("project_Name"));
 	bgv.setEmp_Last_Name(rs.getString("emp_Last_Name"));
 	bgv.setRegion(rs.getString("region"));
 	
	
 	return bgv;
	
 }
 
  

}

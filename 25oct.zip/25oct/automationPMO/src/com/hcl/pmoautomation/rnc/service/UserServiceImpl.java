package com.hcl.pmoautomation.rnc.service;

import com.hcl.pmoautomation.rnc.dao.UserDaoI;

public class UserServiceImpl implements UserServiceI {
	private UserDaoI userdaoi;
	
    public UserDaoI getUserdaoi() {
		return userdaoi;
	}
 public void setUserdaoi(UserDaoI userdaoi) {
		this.userdaoi = userdaoi;
	}


	@Override
	public boolean isValidUser(String userName, String password, String role) {
		
		return userdaoi.isValidUser(userName, password, role);
	}
	

}

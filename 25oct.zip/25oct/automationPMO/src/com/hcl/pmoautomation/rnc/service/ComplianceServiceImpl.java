package com.hcl.pmoautomation.rnc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.hcl.pmoautomation.rnc.dao.ComplianceDao;
import com.hcl.pmoautomation.rnc.dao.GpnDao;
import com.hcl.pmoautomation.rnc.service.ComplianceService;

@Service
@Component
public class ComplianceServiceImpl implements ComplianceService {

	@Autowired(required=true)
	 ComplianceDao Compliancedao;

	
	@Override
	public List<Object[]> getCitList() {
		return Compliancedao.getCitList();
	}


	@Override
	public boolean saveCitInitData(String[] trainerList,
			String[] trainingPlace, String[] sapID) {
		System.out.println("inside service");
		return Compliancedao.saveCitInitData(trainerList,trainingPlace,sapID);
	}


	@Override
	public boolean updateCitData(String[] citIndex, String[] citDate,
			String[] sapID) {
		return Compliancedao.updateCitData(citIndex,citDate,sapID);
	}
	
	@Override
	public List<Object[]> getEIBlockList() {
		return Compliancedao.getEIBlockList();
	}
}

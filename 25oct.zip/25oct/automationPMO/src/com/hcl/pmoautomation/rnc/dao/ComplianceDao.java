package com.hcl.pmoautomation.rnc.dao;

import java.util.List;

public interface ComplianceDao {
	
	public List<Object[]> getCitList();

	public boolean saveCitInitData(String[] trainerList,
			String[] trainingPlace, String[] sapID);

	public boolean updateCitData(String[] citIndex, String[] citDate,
			String[] sapID);

	List<Object[]> getEIBlockList();

}

package com.hcl.pmoautomation.rnc.model;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.hcl.pmoautomation.rnc.vo.*;


public class EmpRowExtractor implements ResultSetExtractor<Emp_Client> {

	 public Emp_Client extractData(ResultSet rs) throws SQLException,
	   DataAccessException {
	  
	Emp_Client emp = new Emp_Client();
	emp.setSap_Id(rs.getInt("sap_Id"));
	emp.setGrs_Request_No(rs.getString("grs_Request_No"));
	emp.setVdi_Request_Number(rs.getString("vdi_Request_No"));
	emp.setVdi_No(rs.getString("vdi_No"));
	
		 
	  
	  return emp;
}
}
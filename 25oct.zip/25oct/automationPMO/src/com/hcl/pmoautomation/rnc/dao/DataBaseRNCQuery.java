package com.hcl.pmoautomation.rnc.dao;

public interface DataBaseRNCQuery {


	//	public String QUERY_TO_FETCH_GPN_INITIATION="select GPN,BGV_ID,EMP_CLIENT_ID from gpn_initiation";
	//1
	public String QUERY_TO_FETCH_ODC_ACCESS1="select TYPE,TARGET_BUILD_NAME,TARGET_TOWER_NO,TARGET_FLOOR,ODCNUMBER,REASON_FOR_ACCESS_REQUEST,EFFECTIVE_DATE_FROM,EFFECTIVE_DATE_TO from odc_access where GPN in (";

	//2
	public String QUERY_TO_FETCH_BGV="select SAP_ID,EMP_FIRST_NAME,EMP_MIDDLE_NAME,EMP_LAST_NAME,PROJECT_NAME from bgv where id in (";

	//3
	public String QUERY_TO_FETCH_EMP_CLIENT="select LM_NAME from emp_client where ID in (";


	public String QUERY_TO_FETCH_GPN_INITIATION_GPN = "select GPN from gpn_initiation";
	public String QUERY_TO_FETCH_GPN_INITIATION_BGV_ID = "select BGV_ID from gpn_initiation";
	public String QUERY_TO_FETCH_GPN_INITIATION_EMP_CLIENT_ID = "select EMP_CLIENT_ID from gpn_initiation";
	public String QUERY_TO_FETCH_VIEW="select * from odc_access_view where active_data='y'";

	public String QUERY_TO_SAVE_SNOWTICKETNUMBERS = "update gpn_initiation set snow_ticket_creation_date=sysdate(), snow_ticket_no=? where bgv_id=?";

	public String QUERY_TO_SAVE_GPN="Update gpn_initiation set  "
			+"gpn_start_date=?,contract_end_date=? , gpn_creation_date=?, gpn=?, gpn_status='Y'"
			+" where bgv_id=?;";
	//public String QUERY_TO_SAVE_REACTSNOWTICKETNUMBERS = "Update gpn_initiation set placed_in_sharepoint='?', sharepoint_add_date='?',snow_ticket_creation_date='?',snow_ticket_number='?',gpn_start_date='?'"
			//+",contract_end_date='?' gpn_created_flag='?' show_ticket_status='?' requestor_pno_name='?' status='?' where bgv_id=id;";

	public String QUERY_TO_SAVE_REACT_GPN="Update gpn_initiation set gpn_creation_date=sysdate(), "
			+"contract_end_date=? "
			+" where bgv_id=?;";


	/*
	 TODO: This Query will be removed after testing. NOT REQUIRED 
	 public String QUERY_TO_GET_GPNCREATELIST = "select bgv.id,e.id as eid,request_type, region, gpn.snow_ticket_no, project_name, country ,client_hiring_manager_gpn_no , datediff(curdate(),gpn.SNOW_TICKET_CREATION_DATE) as datediff, client_hiring_manager_mail_id ,"
			+"previously_worked_with_client ,emp_first_name , emp_middle_name ,emp_last_name ,date_of_birth ,"
			+"correspondence_language ,nationality, gender ,assignment_from ,assignment_to ,ou_code  "
			+"from bgv , emp_client e , gpn_initiation gpn where bgv.sap_id=e.sap_id and gpn.bgv_id=bgv.id and bgv.initiate_gpn='y'"
			+"and bgv.id in (select bgv_id from gpn_initiation where gpn is null);";
	 */
	public String QUERY_TO_GET_GPNCREATELIST = "Select bgv.id,bgv.SAP_ID,bgv.LOCATION,gpn.SNOW_TICKET_NO,e.id as eid,request_type, region, gpn.snow_ticket_no, project_name, country ,client_hiring_manager_gpn_no , datediff(curdate(),gpn.SNOW_TICKET_CREATION_DATE) as datediff, client_hiring_manager_mail_id ,"
	+ "emp_first_name , emp_middle_name ,emp_last_name ,date_of_birth ,"
	+ "correspondence_language ,nationality, gender ,assignment_from ,assignment_to ,ou_code  "
	+ "from bgv , emp_client e , gpn_initiation gpn "
	+ "where bgv.sap_id=e.sap_id And gpn.bgv_id=bgv.id and gpn.MOVE_TO_GPN_CREATION='Y'"
	+ "and bgv.id in (select bgv_id from gpn_initiation where gpn is null)";
	
	public String QUERY_TO_GET_NDA = "Select bgv.id,bgv.SAP_ID, bgv.emp_first_name ,bgv.LOCATION, "
			+ "bgv.PROJECT_NAME, bgv.country,gpn_initiation.INITIATE_NDA from mydb.bgv,mydb.gpn_initiation	"
			+ "where bgv.ID= gpn_initiation.BGV_ID and gpn_initiation.MOVE_TO_GPN_CREATION='N' and bgv.id in "
			+ "(select bgv_id from mydb.gpn_initiation where gpn_initiation.GPN is null);";
	/*+ "UNION "
	+ "select bgv.id,null as eid,request_type, region, null, project_name, country ,client_hiring_manager_gpn_no , null as datediff, client_hiring_manager_mail_id ,"
	+ "previously_worked_with_client ,emp_first_name , emp_middle_name ,emp_last_name ,date_of_birth ,"
	+ "correspondence_language ,nationality, gender ,assignment_from ,assignment_to ,ou_code  "
	+ "from bgv "
	+ "where bgv.initiate_gpn='y'"
	+ "and bgv.id in (select bgv_id from gpn_initiation where gpn is null)";
	//TODO : Removed not in the union query
*/

	public String QUERY_TO_GET_GPNREACTLIST =" select bgv.id,bgv.sap_id,bgv.emp_first_name,bgv.emp_last_name,bgv.gpn,bgv.project_name,ras.rep_mgr_name,datediff(sysdate(),SNOW_TICKET_CREATION_DATE) as dateduf, gpn.contract_end_date, gpn.bgv_id , bgv.region from gpn_initiation gpn,bgv,emp_client emp ,ras where bgv.id=gpn.bgv_id and emp.id=gpn.emp_client_id and ras.id=bgv.ras_id and datediff(gpn.contract_end_date , curdate()) between 0 and 45;";

	public String QUERY_TO_GET_GPNTERMINDETAILSUSINGSAP = "select bgv.SAP_ID,bgv.EMP_FIRST_NAME,bgv.EMP_LAST_NAME,bgv.PROJECT_CODE,bgv.PROJECT_NAME,bgv.gpn,bgv.GPN_START_DATE,emp_client.LM_NAME,ras.PM_NAME,bgv.LOCATION,bgv.COUNTRY from mydb.bgv, mydb.gpn_initiation, mydb.emp_client,mydb.ras where bgv.id=gpn_initiation.bgv_id and gpn_initiation.EMP_CLIENT_ID= emp_client.ID and bgv.RAS_ID = ras.ID and bgv.SAP_ID= emp_client.SAP_ID and bgv.SAP_ID = ?;";

	public String QUERY_TO_GET_GPNTERMINDETAILSUSINGGPN = "select bgv.SAP_ID,bgv.EMP_FIRST_NAME,bgv.EMP_LAST_NAME, bgv.PROJECT_CODE,bgv.PROJECT_NAME,bgv.gpn,bgv.GPN_START_DATE, emp_client.LM_NAME,ras.PM_NAME,bgv.LOCATION,bgv.COUNTRY from mydb.bgv, mydb.gpn_initiation, mydb.emp_client,mydb.ras where bgv.id=gpn_initiation.bgv_id and gpn_initiation.EMP_CLIENT_ID= emp_client.ID and bgv.RAS_ID = ras.ID and bgv.SAP_ID= emp_client.SAP_ID and gpn_initiation.gpn=bgv.gpn and gpn_initiation.GPN=?;";

	public String QUERY_TO_SAVE_TERMINATION_REQUEST="insert into resource_amendments(REQUEST_TYPE,REQUEST_DATE,REASON_FOR_LEAVING,GPN_TERMINATION_DATE,GPN) values('gpn termination',sysdate(),?,?,?)";
	
	public String QUERY_TO_GET_GRSVDILIST ="select bgv.EMP_FIRST_NAME, bgv.EMP_LAST_NAME, bgv.GPN, bgv.SAP_ID, bgv.COUNTRY, emp1.GRS_REQUEST_NO, emp1.VDI_REQUEST_NO, emp1.VDI_NO from mydb.emp_client emp1,mydb.bgv where bgv.SAP_ID= emp1.SAP_ID and (emp1.GRS_REQUEST_RAISED IS  NULL or emp1.VDI_REQUEST_RAISED IS  NULL) and not exists ( select emp2.SAP_ID from mydb.emp_client emp2 where emp2.GRS_REQUEST_RAISED IS  NULL and emp2.VDI_REQUEST_RAISED IS  NULL and emp1.sap_id=emp2.sap_id)";
	//+ "select emp1.GRS_REQUEST_NO, emp1.VDI_REQUEST_NO, emp1.VDI_NO, emp1.SAP_ID from mydb.emp_client emp1 where (emp1.GRS_REQUEST_RAISED IS  NULL or emp1.VDI_REQUEST_RAISED IS  NULL) and not exists ( select emp2.SAP_ID from mydb.emp_client emp2 where emp2.GRS_REQUEST_RAISED IS  NULL and emp2.VDI_REQUEST_RAISED IS  NULL and emp1.sap_id=emp2.sap_id );";
			//select bgv.EMP_FIRST_NAME,bgv.EMP_LAST_NAME,bgv.GPN,bgv.SAP_ID,bgv.COUNTRY from mydb.emp_client, mydb.bgv where bgv.SAP_ID= emp_client.SAP_ID and emp_client.GRS_REQUEST_RAISED IS NULL and emp_client.VDI_REQUEST_RAISED IS NULL and bgv.GPN IS NOT NULL ;";

	public String QUERY_TO_SAVE_GRSDATA = "update mydb.emp_client set emp_client.VDI_NO = ? ,emp_client.VDI_REQUEST_NO = ?,emp_client.VDI_REQUEST_RAISED = 'Y', emp_client.VDI_REQUESTED_DATE = curdate() where emp_client.SAP_ID=?;";
	
	public String QUERY_TO_SAVE_VDIDATA = "update mydb.emp_client set emp_client.VDI_NO = ? ,emp_client.VDI_REQUEST_NO = ?,emp_client.VDI_REQUEST_RAISED = 'Y', emp_client.VDI_REQUESTED_DATE = curdate() where emp_client.SAP_ID=?;";

	public String QUERY_TO_GET_GPNTERMINATIONLIST = "select bgv.EMP_FIRST_NAME,ras.ONSITE_OR_OFFSHORE,emp_client.LM_NAME,resource_amendments.GPN_TERMINATION_DATE,resource_amendments.ticket_no,"
+"resource_amendments.REASON_FOR_LEAVING,resource_amendments.PHYSICAL_ARC_DATE,resource_amendments.gpn as resGpn,resource_amendments.LOGICAL_ARC_DATE,bgv.LOCATION "
+" from mydb.resource_amendments, mydb.bgv, mydb.emp_client, mydb.ras, mydb.gpn_initiation"
+" where bgv.id=gpn_initiation.bgv_id and gpn_initiation.EMP_CLIENT_ID= emp_client.ID and bgv.RAS_ID = ras.ID and bgv.SAP_ID= emp_client.SAP_ID and resource_amendments.GPN= gpn_initiation.GPN and resource_amendments.gpn is not null "
+ "and resource_amendments.VDI_REVOKE_DATE is not null ;"; 

	/*"select bgv.sap_id,bgv.emp_first_name,bgv.emp_last_name,bgv.gpn,bgv.project_name,ras.rep_mgr_name,"
+"gpn.contract_end_date,bgv.region"
+"from gpn_initiation gpn,bgv,emp_client emp ,ras" 
+"where"
+"bgv.id=gpn.bgv_id"
+"and"
+"emp.id=gpn.emp_client_id"
+"and"
+"ras.id=bgv.ras_id"
+"and"
+"datediff(gpn.contract_end_date , curdate())<=45;"; 
	 */	



	//"select bgv.sap_id,bgv.emp_first_name,bgv.emp_last_name,bgv.gpn,bgv.project_name,gpn.contract_end_date,gpn.bgv_id,gpn.emp_client_id,bgv.region,gpn.snow_ticket_no from gpn_initiation gpn,bgv,emp_client emp ,ras where bgv.id=gpn.bgv_id and ras.id=bgv.ras_id and datediff(gpn.contract_end_date , curdate())<=45;";

	public String QUERY_TO_GET_CITLIST = "select emp.SAP_id, concat(bgv.EMP_FIRST_NAME,' ',bgv.EMP_LAST_NAME)  as EmpName, bgv.Project_Name, gpn.GPN_creation_Date, bgv.location, emp.CIT_COMPLETETION_STATUS, emp.CIT_COMPLETED_DATE, emp.CIT_TRAINER_NAME, emp.CIT_LOCATION, gpn.gpn, datediff(sysdate(),gpn.GPN_START_DATE) as ageing from gpn_initiation gpn, bgv, emp_client emp where bgv.id=gpn.bgv_id and bgv.sap_id=emp.sap_id and gpn.gpn is not null and emp.CIT_COMPLETETION_STATUS is null;";

	public String QUERY_TO_GET_EMAIL_INTERNET_BLOCKLIST="select emp.SAP_id,	concat(bgv.EMP_FIRST_NAME,' ',bgv.EMP_LAST_NAME)  as EmpName, bgv.Project_Name, gpn.gpn , gpn.gpn_start_date,datediff(sysdate(),gpn.GPN_START_DATE) as ageing,bgv.location, emp.EMAIL_BLOCKING_TICKET_NO,emp.INTERNET_BLOCKING_TICKET_NO from gpn_initiation gpn, bgv, emp_client emp where bgv.id=gpn.bgv_id and bgv.sap_id=emp.sap_id and gpn.gpn is not null and EMAIL_BLOCKING ='Y';";
	public String QUERY_TO_GET_employeename_forodcacess_usingsapcode="select EMP_FIRST_NAME from mydb.bgv where SAP_ID=";
	public String QUERY_TO_GET_projectname_forodcacess_usingsapcode="select PROJECT_NAME from mydb.bgv where SAP_ID=";
	public String QUERY_TO_GET_gpn_forodcacess_usingsapcode="select GPN from mydb.bgv where SAP_ID=";
	public String QUERY_TO_GET_location_forodcacess_usingsapcode="select LOCATION from mydb.bgv where SAP_ID=";
	public String Query_to_fetch_gpndetails = "select bgv.SAP_ID,bgv.EMP_FIRST_NAME,bgv.PROJECT_CODE,bgv.PROJECT_NAME,bgv.REGION from"
            + " mydb.gpn_initiation,"
            + "  mydb.bgv,"
            + " mydb.emp_client"
            + " where"
            + " gpn_initiation.BGV_ID=bgv.ID"
            + " and"
            + " gpn_initiation.EMP_CLIENT_ID= emp_client.ID"
            + " and"
            + " emp_client.SAP_ID = bgv.SAP_ID";
	
	/*public String QUERY_TO_GET_GPNCOMPLETESTSTUS = "SELECT SAP_ID,EMP_FIRST_NAME,GPN,GPN_START_DATE,GPN_END_DATE FROM mydb.bgv where GPN_STATUS='active'";*/
	

	public String QUERY_TO_GET_GPNCOMPLETESTSTUS = "select bgv.SAP_ID,bgv.EMP_FIRST_NAME,bgv.PROJECT_NAME,gpn_initiation.GPN,gpn_initiation.GPN_START_DATE,gpn_initiation.GPN_END_DATE from"
			+ " mydb.bgv,"
			+ " mydb.gpn_initiation"
			+ " where" 
			+ " bgv.ID=gpn_initiation.BGV_ID"
			+ " and"
			+ " gpn_initiation.GPN=bgv.GPN"
			+ " and"
			+ " gpn_initiation.GPN_Status='ACTIVE'";
	
	public String QUERY_TO_GET_NDA_path="select NDA_FORM_PATH from mydb.nda_forms where nda_forms.COUNTRY='";

	public String QUERY_TO_GET_sapid_name="SELECT EMP_FIRST_NAME,SAP_ID FROM mydb.bgv where SAP_ID='";
	public String QUERY_TO_GET_sapid_for_linkchecking="select gpn_initiation.ACTIVEFLAG_LINK from mydb.gpn_initiation where gpn_initiation.BGV_ID=(select bgv.id from mydb.bgv where bgv.SAP_ID='";
	public String QUERY_TO_GET_NDA_Download_link1="select gpn_initiation.NDA_UPLOAD_PATH_1 from mydb.gpn_initiation where gpn_initiation.BGV_ID=(select bgv.id from mydb.bgv where bgv.SAP_ID=";
	public String QUERY_TO_GET_NDA_Download_link2="select gpn_initiation.NDA_UPLOAD_PATH_2 from mydb.gpn_initiation where gpn_initiation.BGV_ID=(select bgv.id from mydb.bgv where bgv.SAP_ID=";
	public String QUERY_TO_GET_NDA_Download_link3="select gpn_initiation.NDA_UPLOAD_PATH_3 from mydb.gpn_initiation where gpn_initiation.BGV_ID=(select bgv.id from mydb.bgv where bgv.SAP_ID=";
	public String QUERY_TO_GET_NDA_Download_link4="select gpn_initiation.NDA_UPLOAD_PATH_4 from mydb.gpn_initiation where gpn_initiation.BGV_ID=(select bgv.id from mydb.bgv where bgv.SAP_ID=";
	public String QUERY_TO_GET_NDA_Download_link5="select gpn_initiation.NDA_UPLOAD_PATH_5 from mydb.gpn_initiation where gpn_initiation.BGV_ID=(select bgv.id from mydb.bgv where bgv.SAP_ID=";
	public String QUERY_TO_GET_NDA_refer_null_check="select ACTIVEFLAG_LINK from mydb.gpn_initiation where gpn_initiation.BGV_ID=(select bgv.id from mydb.bgv where bgv.SAP_ID=";
	public String QUERY_TO_GET_NDA_paths_null_check="select NDA_UPLOAD_PATH_1,NDA_UPLOAD_PATH_2,NDA_UPLOAD_PATH_3,NDA_UPLOAD_PATH_4,NDA_UPLOAD_PATH_5,ACTIVEFLAG_LINK from mydb.gpn_initiation where gpn_initiation.BGV_ID=(select bgv.id from mydb.bgv where bgv.SAP_ID=";


}


package com.hcl.pmoautomation.rnc.vo;

public class NDAdownloadPath {
String Path;

public String getPath() {
	return Path;
}

public void setPath(String path) {
	Path = path;
}

@Override
public String toString() {
	return Path;
}

}

package com.hcl.pmoautomation.rnc.vo;

public class Visitor_Access {
	private String request_type;
	private String full_name;
	private String designation;
	private String department;
	private String company;
	private String odc_No;
	private String floor;
	private String tower_no;
	private String build_name;
	private String location;
	private String purpose_Of_Visit;
	private String project_Team_To_Be_Visited;
	private String proposed_Date_Of_Visit;
	private String project_Name;
	private String devices_Brought_Inside_Odc;
	private String client_Related_Audit;
	private String escort_Full_Name;
	private String escort_Designation;
	private String escort_Department;
	private	String requested_By;
	private String requested_Date;
	
	
	
	
	public String getRequest_type() {
		return request_type;
	}




	public void setRequest_type(String request_type) {
		this.request_type = request_type;
	}




	public String getFull_name() {
		return full_name;
	}




	public void setFull_name(String full_name) {
		this.full_name = full_name;
	}




	public String getDesignation() {
		return designation;
	}




	public void setDesignation(String designation) {
		this.designation = designation;
	}




	public String getDepartment() {
		return department;
	}




	public void setDepartment(String department) {
		this.department = department;
	}




	public String getCompany() {
		return company;
	}




	public void setCompany(String company) {
		this.company = company;
	}




	public String getOdc_No() {
		return odc_No;
	}




	public void setOdc_No(String odc_No) {
		this.odc_No = odc_No;
	}




	public String getFloor() {
		return floor;
	}




	public void setFloor(String floor) {
		this.floor = floor;
	}




	public String getTower_no() {
		return tower_no;
	}




	public void setTower_no(String tower_no) {
		this.tower_no = tower_no;
	}




	public String getBuild_name() {
		return build_name;
	}




	public void setBuild_name(String build_name) {
		this.build_name = build_name;
	}




	public String getLocation() {
		return location;
	}




	public void setLocation(String location) {
		this.location = location;
	}




	public String getPurpose_Of_Visit() {
		return purpose_Of_Visit;
	}




	public void setPurpose_Of_Visit(String purpose_Of_Visit) {
		this.purpose_Of_Visit = purpose_Of_Visit;
	}




	public String getProject_Team_To_Be_Visited() {
		return project_Team_To_Be_Visited;
	}




	public void setProject_Team_To_Be_Visited(String project_Team_To_Be_Visited) {
		this.project_Team_To_Be_Visited = project_Team_To_Be_Visited;
	}




	public String getProposed_Date_Of_Visit() {
		return proposed_Date_Of_Visit;
	}




	public void setProposed_Date_Of_Visit(String proposed_Date_Of_Visit) {
		this.proposed_Date_Of_Visit = proposed_Date_Of_Visit;
	}




	public String getProject_Name() {
		return project_Name;
	}




	public void setProject_Name(String project_Name) {
		this.project_Name = project_Name;
	}




	public String getDevices_Brought_Inside_Odc() {
		return devices_Brought_Inside_Odc;
	}




	public void setDevices_Brought_Inside_Odc(String devices_Brought_Inside_Odc) {
		this.devices_Brought_Inside_Odc = devices_Brought_Inside_Odc;
	}




	public String getClient_Related_Audit() {
		return client_Related_Audit;
	}




	public void setClient_Related_Audit(String client_Related_Audit) {
		this.client_Related_Audit = client_Related_Audit;
	}




	public String getEscort_Full_Name() {
		return escort_Full_Name;
	}




	public void setEscort_Full_Name(String escort_Full_Name) {
		this.escort_Full_Name = escort_Full_Name;
	}




	public String getEscort_Designation() {
		return escort_Designation;
	}




	public void setEscort_Designation(String escort_Designation) {
		this.escort_Designation = escort_Designation;
	}




	public String getEscort_Department() {
		return escort_Department;
	}




	public void setEscort_Department(String escort_Department) {
		this.escort_Department = escort_Department;
	}




	public String getRequested_By() {
		return requested_By;
	}




	public void setRequested_By(String requested_By) {
		this.requested_By = requested_By;
	}




	public String getRequested_Date() {
		return requested_Date;
	}




	public void setRequested_Date(String requested_Date) {
		this.requested_Date = requested_Date;
	}




	@Override
	public String toString() {
		return "Visitor_Access [request_type=" + request_type + ", full_name="
				+ full_name + ", designation=" + designation + ", department="
				+ department + ", company=" + company + ", odc_No=" + odc_No
				+ ", floor=" + floor + ", tower_no=" + tower_no
				+ ", build_name=" + build_name + ", location=" + location
				+ ", purpose_Of_Visit=" + purpose_Of_Visit
				+ ", project_Team_To_Be_Visited=" + project_Team_To_Be_Visited
				+ ", proposed_Date_Of_Visit=" + proposed_Date_Of_Visit
				+ ", project_Name=" + project_Name
				+ ", devices_Brought_Inside_Odc=" + devices_Brought_Inside_Odc
				+ ", client_Related_Audit=" + client_Related_Audit
				+ ", escort_Full_Name=" + escort_Full_Name
				+ ", escort_Designation=" + escort_Designation
				+ ", escort_Department=" + escort_Department
				+ ", requested_By=" + requested_By + ", requested_Date="
				+ requested_Date + "]";
	}
	

}

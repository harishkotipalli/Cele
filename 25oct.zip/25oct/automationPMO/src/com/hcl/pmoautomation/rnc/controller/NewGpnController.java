package com.hcl.pmoautomation.rnc.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLEncoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hcl.pmoautomation.bgv.dao.DownloadPathDao;
import com.hcl.pmoautomation.bgv.model.Bgvhclmailvo;
import com.hcl.pmoautomation.bgv.model.DownloadPathvo;
import com.hcl.pmoautomation.email.App;
import com.hcl.pmoautomation.rnc.dao.NewGpnDaoImpl;
import com.hcl.pmoautomation.rnc.model.DownloadspathVO;
import com.hcl.pmoautomation.rnc.model.NDAformpath;
import com.hcl.pmoautomation.rnc.service.NewGpnServiceImpl;
import com.hcl.pmoautomation.rnc.vo.Bgv;
import com.hcl.pmoautomation.rnc.vo.NDAdownloadPath;
import com.hcl.pmoautomation.rnc.vo.NDApathsCheckNull;



@Controller
@RequestMapping(value = "GpnController/Gpn")
public class NewGpnController {
	
	@InitBinder
	public void initBinder( WebDataBinder binder )
	{
	    // tell spring to set empty values as null instead of empty string.
		
	    binder.registerCustomEditor( String.class, new StringTrimmerEditor( true ));
	    SimpleDateFormat simpleDateFormat=new SimpleDateFormat("YYYY-MM-dd hh:mm:ss");
	    simpleDateFormat.setLenient(false);
	    binder.registerCustomEditor( Date.class, new CustomDateEditor( simpleDateFormat,false));
        System.out.println("working");
	}
	
@Autowired(required = true)
JdbcTemplate jdbcTemplate;
	
	@RequestMapping(value = "/newGpnInitiation.php")
	public String newGpnCreation(HttpServletRequest request) {
		try{
		NewGpnServiceImpl impl = new NewGpnServiceImpl();
		System.out.println(jdbcTemplate);
		System.out.println("hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii");
		request.setAttribute("getGpnDetails", impl.getGpnDetails(jdbcTemplate));
		}
		catch(Exception e){
			 //return "forward:../../pmoAutomation/Login/errorPage.php";
			e.printStackTrace();
		}
		return "GPN/GpnCreation";
		//return "Bgv/Bgvinitpmoapl";

	}
	
	@RequestMapping(value = "/NDAInitiation.php")
	public String NDAInitiation(HttpServletRequest request) {
		try{
		NewGpnServiceImpl impl = new NewGpnServiceImpl();
		
		request.setAttribute("getGpnDetails", impl.getNDADetails(jdbcTemplate));
		}
		catch(Exception e){
			 //return "forward:../../pmoAutomation/Login/errorPage.php";
			e.printStackTrace();
		}
		return "GPN/GpnNDAInitiate";  
		

	}
	@RequestMapping(value = "/NDAInitiationButton.php")
	public String NDAInitiationButton(HttpServletRequest request) {
		
		String sapidfornda = request.getParameter("sapNDA"
				+ request.getParameter("cou"));
		int sapconvert=Integer.parseInt(sapidfornda);
		NewGpnDaoImpl nda=new NewGpnDaoImpl();
		String namefornada = request.getParameter("nameforNDA");
				String countryfornada = request.getParameter("countryforNDA");				
				List<NDAformpath> NDApath= nda.pathforNDAform(countryfornada, jdbcTemplate);
				System.out.println("ndaa "+sapidfornda+" "+namefornada+"  "+countryfornada+"  "+NDApath);
				List<Bgv> sapname= nda.sapname(sapidfornda, jdbcTemplate);	
				App mailtrigger = new App();
				
				String[] array = new String[NDApath.size()];
				int index = 0;
				for (Object value : NDApath) {
					array[index] = String.valueOf( value );
				mailtrigger.Mailtrigger("celeritas@hcl.com","kotipalliv@hcl.com",  "Attn.!! NDA to be SIGNED", namefornada, "/NDAFormMailTrig.jsp", sapname, array[index]);
				}
				
		jdbcTemplate.update("update mydb.gpn_initiation set gpn_initiation.ACTIVEFLAG_LINK='Y', gpn_initiation.INITIATE_NDA='Y'  where gpn_initiation.BGV_ID=(select bgv.id from mydb.bgv where bgv.SAP_ID="+sapconvert+")");
				return "forward:../../GpnController/Gpn/NDAInitiation.php";
		

	}
	
	@RequestMapping(value = "/NDAInitiationButton.php",params="GPNcreation")
	public String NDAInitiationButtonforGpnmoving(HttpServletRequest request) {
		String sapidfornda = request.getParameter("sapNDA"
				+ request.getParameter("cou"));
		int sapconvert=Integer.parseInt(sapidfornda);
		System.out.println("ndaa "+sapidfornda);
		jdbcTemplate.update("update mydb.gpn_initiation set gpn_initiation.MOVE_TO_GPN_CREATION ='Y'  where gpn_initiation.BGV_ID=(select bgv.id from mydb.bgv where bgv.SAP_ID="+sapconvert+")");
				return "forward:../../GpnController/Gpn/NDAInitiation.php";
		

	}
	@RequestMapping(value = "/NDAUploadReferBack.php")
	public void NDAUploadReferBack(HttpServletRequest request,
			HttpServletResponse response) throws IOException, URISyntaxException {
		
		String sapidfornda = request.getParameter("ndalinks");
		String commentbox=request.getParameter("commentsformail");
				System.out.println("11111 "+sapidfornda+commentbox);
		int sapconvert=Integer.parseInt(sapidfornda);
		NewGpnDaoImpl nda=new NewGpnDaoImpl();
		
			/*	
				List<Bgv> sapname= nda.sapname(sapidfornda, jdbcTemplate);	
				App mailtrigger = new App();
				
				
				mailtrigger.Mailtrigger("celeritas@hcl.com","kotipalliv@hcl.com",  "Attn.!! NDA to be SIGNED", null, "/NDAFormMailTrig.jsp", sapname, null);
				
				*/
		jdbcTemplate.update("update mydb.gpn_initiation set gpn_initiation.ACTIVEFLAG_LINK='Y'  where gpn_initiation.BGV_ID=(select bgv.id from mydb.bgv where bgv.SAP_ID="+sapconvert+")");
		PrintWriter out = response.getWriter();
		 out.println("<html><body><script>alert('Refer Back Successfully!!!');window.close();</script></body></html>");


	}
	@RequestMapping(value = "/newGpnInitiationPmoDetails.php")
	public String getGpnDetails(HttpServletRequest request){
		try{
			NewGpnServiceImpl getGpnDetails = new NewGpnServiceImpl();
			request.setAttribute("getGpnPmoDetails", getGpnDetails.getGpnPmo(jdbcTemplate));
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return "GPN/GpnCompletion";
	}
	
	@RequestMapping(value = "/viewNDAlinks.php")
	public String viewNDAlinks(HttpServletRequest request){
		try{
			String NDAsap=request.getParameter("viewndaformsusingsap");
			request.setAttribute("NDAlinksUsingsap", NDAsap);
			NewGpnDaoImpl nda=new NewGpnDaoImpl();
			int convert=Integer.parseInt(NDAsap);
			List<NDApathsCheckNull> paths=nda.NDApathcheks(convert, jdbcTemplate);
			
			request.setAttribute("nullchecks", paths);
			
			System.out.println("linkssss "+paths);
		}catch(Exception e){
			e.printStackTrace();
		}
		return "GPN/NDAformLinks";
	}
	
	@RequestMapping(value = "/saveSnow.php")
	public String newSnowTicketnumber(HttpServletRequest request){
		
		String bgv_id = request.getParameter("bgv_id"+request.getParameter("bgvid"));
		System.out.println(bgv_id);
		String snowTicket = request.getParameter("snowTicketNumb");
		System.out.println(snowTicket);
		
		NewGpnServiceImpl impl = new NewGpnServiceImpl();
		 impl.saveSnowTicketDetails(jdbcTemplate,Integer.parseInt(snowTicket), Integer.parseInt(bgv_id));
		
		
		
	
		return "forward:../../GpnController/Gpn/newGpnInitiation.php";
	
		
	}
	@InitBinder
	@RequestMapping(value = "/savegpn.php")
	public String newGpnnumber(HttpServletRequest request){
		
		String bgv_id = request.getParameter("bgv_id"+request.getParameter("bgvid"));
		System.out.println(bgv_id);
		
		String gpnNumber = request.getParameter("gpn");
		System.out.println(gpnNumber);
		String gpnCreationDate = request.getParameter("gpnCreationDateowTicketNumb");
	
		String gpnStartDate = request.getParameter("gpnStartDate");
		String gpnendDate = request.getParameter("contractEndDate");
		

	     NewGpnServiceImpl impl = new NewGpnServiceImpl();
		 impl.savegpnnumber(jdbcTemplate,Integer.parseInt(gpnNumber),gpnCreationDate,gpnStartDate,gpnendDate, Integer.parseInt(bgv_id));
		 impl.savegpnbgv(jdbcTemplate,gpnNumber,gpnCreationDate,gpnStartDate,gpnendDate, Integer.parseInt(bgv_id));
		 impl.savegpnras(jdbcTemplate,Integer.parseInt(bgv_id));
		
		
		 return "forward:../../GpnController/Gpn/newGpnInitiation.php";
	
		
	}
	
	@RequestMapping(value = "/NDAdownload.php")
	public void NDAdownload(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
	
		String country=request.getParameter("searchcountryfordownload");
		
		System.out.println("controller country from jsp    "+country);
		NewGpnDaoImpl path=new NewGpnDaoImpl();
		List<DownloadspathVO> downloadPathlink=path.NDADownloadPath(country, jdbcTemplate);
		
		String[] array = new String[downloadPathlink.size()];
		int index = 0;
		for (Object value : downloadPathlink) {
			array[index] = String.valueOf( value );
		}
		
		HttpSession session = request.getSession();
        session.setAttribute("downloadpathforNDA", array[index]);
		// TODO:Spring Multipart enable it,Servlet disable it
		request.setAttribute("fileTypepdfdown", "pdfdownload");
		
		request.getRequestDispatcher("/fileUpload.downloadNDA").forward(request,
				response);
		
 }
	

}


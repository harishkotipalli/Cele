package com.hcl.pmoautomation.rnc.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;

import com.hcl.pmoautomation.rnc.vo.NewJoineeOdcAccess;
//import com.sun.istack.internal.Builder;

public class RncNewAccessDaoImpl implements RncNewAccessDao {

	@Override
	public List<NewJoineeOdcAccess> getOdcDetails(JdbcTemplate jdbcTemplate) {
		/*
		 * List<Map<String, Object>>
		 * odcDetailList=jdbcTemplate.queryForList(""); List<NewJoineeOdcAccess>
		 * newJoineeOdcAccesses=new ArrayList<NewJoineeOdcAccess>(); for(Map
		 * odcDeatail:odcDetailList){ NewJoineeOdcAccess newJoineeOdcAccess=new
		 * NewJoineeOdcAccess();
		 * 
		 * newJoineeOdcAccess.setType(odcDetailList.get("","type"));
		 * 
		 * 
		 * 
		 * 
		 * 
		 * newJoineeOdcAccesses.add(newJoineeOdcAccess);
		 * 
		 * }
		 */
		// return newJoineeOdcAccesses;

		/*int maxid = 123;
		Object[] parm = { maxid };
		String sql = "";
		return jdbcTemplate.query(sql, parm, new NewJoineeOdcMapper());*/
		return null;
	}

	public List<Integer> getListOfGpn(JdbcTemplate jdbcTemplate) {

		String sqlQuery = DataBaseRNCQuery.QUERY_TO_FETCH_GPN_INITIATION_GPN;

		List<Integer> gpnLists = new ArrayList<Integer>();
		List<Map<String, Object>> gpnInitiation = jdbcTemplate.queryForList(sqlQuery);
		for (Map map : gpnInitiation) {
			gpnLists.add((Integer) map.get("GPN"));
			System.out.println((Integer) map.get("GPN"));

		}

		return gpnLists;
	}

	public List<Integer> getListOfBGV_ID(JdbcTemplate jdbcTemplate) {

		String sqlQuery = DataBaseRNCQuery.QUERY_TO_FETCH_GPN_INITIATION_BGV_ID;

		List<Integer> bgvIDLists = new ArrayList<Integer>();
		List<Map<String, Object>> gpnInitiation = jdbcTemplate.queryForList(sqlQuery);
		for (Map map : gpnInitiation) {
			bgvIDLists.add((Integer) map.get("BGV_ID"));
			System.out.println((Integer) map.get("BGV_ID"));
		}
		return bgvIDLists;
	}

	public List<Integer> getListOfEMP_CLIENT_ID(JdbcTemplate jdbcTemplate) {

		String sqlQuery = DataBaseRNCQuery.QUERY_TO_FETCH_GPN_INITIATION_EMP_CLIENT_ID;

		List<Integer> EMP_CLIENT_IDLists = new ArrayList<Integer>();
		List<Map<String, Object>> gpnInitiation = jdbcTemplate.queryForList(sqlQuery);
		for (Map map : gpnInitiation) {
			EMP_CLIENT_IDLists.add((Integer) map.get("EMP_CLIENT_ID"));
			System.out.println((Integer) map.get("EMP_CLIENT_ID"));
		}
		return EMP_CLIENT_IDLists;
	}

	public List<Map<String, Object>> getODC_Details(List<Integer> gpnLists, JdbcTemplate jdbcTemplate) {

		String sqlQuery = DataBaseRNCQuery.QUERY_TO_FETCH_ODC_ACCESS1;
		StringBuilder builder = new StringBuilder();
		List<ArrayList<String>> odcDetails = new ArrayList<ArrayList<String>>();
		List<String> odcDetail = new ArrayList<String>();

		int count = 0;
		for (Integer gpn : gpnLists) {
			if (count == gpnLists.size() - 1) {
				if (gpn != null) {
					builder.append(gpn.toString() + ")");
					break;
				}
			}
			if (gpn != null) {
				builder.append(gpn.toString() + ",");
			}

			count++;
		}
		sqlQuery = sqlQuery + builder.toString();
		System.out.println(sqlQuery);

		return jdbcTemplate.queryForList(sqlQuery);

	}

	public List<Map<String, Object>> getBgvId_Details(List<Integer> bgvIDLists, JdbcTemplate jdbcTemplate) {

		String sqlQuery = DataBaseRNCQuery.QUERY_TO_FETCH_BGV;
		StringBuilder builder = new StringBuilder();
		List<ArrayList<String>> bgvIdDetails = new ArrayList<ArrayList<String>>();
		List<String> bgvIdDetail = new ArrayList<String>();

		int count = 0;
		for (Integer bgvId : bgvIDLists) {
			if (count == bgvIDLists.size() - 1) {

				builder.append(bgvId.toString() + ")");
				break;

			}
			builder.append(bgvId.toString() + ",");

			count++;
		}

		sqlQuery = sqlQuery + builder.toString();
		System.out.println(sqlQuery);

		return jdbcTemplate.queryForList(sqlQuery);

	}

	public List<Map<String, Object>> getEmpClient_Details(List<Integer> EMP_CLIENT_IDLists, JdbcTemplate jdbcTemplate) {

		String sqlQuery = DataBaseRNCQuery.QUERY_TO_FETCH_EMP_CLIENT;
		StringBuilder builder = new StringBuilder();
		List<ArrayList<String>> empClientDetails = new ArrayList<ArrayList<String>>();
		List<String> empClientDetail = new ArrayList<String>();

		int count = 0;
		for (Integer empClientId : EMP_CLIENT_IDLists) {
			if (count == EMP_CLIENT_IDLists.size() - 1) {

				builder.append(empClientId.toString() + ")");
				break;

			}
			builder.append(empClientId.toString() + ",");

			count++;
		}

		sqlQuery = sqlQuery + builder.toString();
		System.out.println(sqlQuery);

		return jdbcTemplate.queryForList(sqlQuery);

	}

	public List<Object[]> getDataForRNCApproval(JdbcTemplate jdbcTemplate) {
		String sqlquery = DataBaseRNCQuery.QUERY_TO_FETCH_VIEW;
		List<Map<String, Object>> maps = jdbcTemplate.queryForList(sqlquery);
		List<Object[]> list = new ArrayList<Object[]>();
		for (Map tempMap : maps) {
			Object[] objects = new Object[tempMap.size()];

			objects[0] = ((String) tempMap.get("type"));
			objects[1] = ((Integer) tempMap.get("gpn"));
			objects[2] = ((String) tempMap.get("target_build_name"));
			objects[3] = ((int) tempMap.get("target_tower_no"));
			objects[4] = ((Integer) tempMap.get("target_floor"));
			objects[5] = ((String) tempMap.get("odcnumber"));
			objects[6] = ((String) tempMap.get("reason_for_access_request"));
			objects[7] = ((Date) tempMap.get("effective_date_from"));
			objects[8] = ((Date) tempMap.get("effective_date_to"));
			objects[9] = ((Integer) tempMap.get("sap_id"));
			objects[10] = ((String) tempMap.get("emp_first_name"));
			objects[11] = ((String) tempMap.get("emp_middle_name"));
			objects[12] = ((String) tempMap.get("emp_last_name"));
			objects[13] = ((String) tempMap.get("project_name"));
			objects[14] = ((String) tempMap.get("lm_name"));
			objects[15] = ((int) tempMap.get("ODCID"));

			list.add(objects);

		}
		System.out.println(sqlquery);
		System.out.println(list);
		return list;

	}

	public boolean saveEmpClient(JdbcTemplate jdbcTemplate, Object[] odcDetail) {
		System.out.println(Arrays.asList(odcDetail));
		
		boolean flag=jdbcTemplate.update("update emp_client set BUILD_NAME=?,TOWER_NO=?,FLOOR=?,ODC_NO=?,LM_NAME=? where SAP_ID="+odcDetail[9],
				new Object[]{odcDetail[2],odcDetail[3],odcDetail[4],odcDetail[5],odcDetail[14]})>0?true:false;
		
		if(flag){
			System.out.println(odcDetail[15]);
			jdbcTemplate.update("update odc_access set ACTIVE_FLAG='N' where ID="+odcDetail[15]);
		}
		return flag;
	}
}

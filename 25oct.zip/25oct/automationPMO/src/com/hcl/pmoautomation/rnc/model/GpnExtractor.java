package com.hcl.pmoautomation.rnc.model;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.hcl.pmoautomation.rnc.vo.*;


public class GpnExtractor implements ResultSetExtractor<Gpn> {

	 public Gpn extractData(ResultSet rs) throws SQLException,
	   DataAccessException {
	  
	  Gpn gpn = new Gpn();
	gpn.setBgvid(rs.getInt("bgv_id"));
	gpn.setSnow_Ticket_Number(rs.getString("snow_ticket_no"));
	//gpn.setSnow_Ticket_Init_Date(rs.getTimestamp("snow_Ticket_Init_Date"));	
	//gpn.setPlaced_In_Sharepoint_For_WMA(rs.getString("placed_In_Sharepoint_For_WMA"));
	//gpn.setContract_End_Date(rs.getDate("contract_end_date"));

	  
	  return gpn;
}
}
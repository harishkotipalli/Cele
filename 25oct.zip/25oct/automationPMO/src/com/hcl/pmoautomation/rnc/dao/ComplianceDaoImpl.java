package com.hcl.pmoautomation.rnc.dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.hcl.pmoautomation.rnc.vo.Bgv;
import com.hcl.pmoautomation.rnc.vo.Gpn;

@Component
public class ComplianceDaoImpl implements ComplianceDao{
	@Autowired(required=true)
	JdbcTemplate jdbcTemplate;
	
	
	@Override
	public List<Object[]> getCitList() {
		List<Object[]> list=null;
		ArrayList<Object[]> objlist = new ArrayList<Object[]>();

		try{
			Object[] objects=null;
			List<Map<String, Object>> lst = new ArrayList<Map<String,Object>>();
			
			lst =  jdbcTemplate.queryForList(DataBaseRNCQuery.QUERY_TO_GET_CITLIST, new Objects[]{}); 
//select emp.SAP_id, coalesce(bgv.EMP_FIRST_NAME,bgv.EMP_LAST_NAME)  as EmpName, bgv.Project_Name, gpn.GPN_creation_Date, bgv.location, emp.CIT_COMPLETETION_STATUS, emp.CIT_COMPLETED_DATE, emp.CIT_TRAINER_NAME, emp.CIT_LOCATION, gpn.gpn, datediff(sysdate(),gpn.GPN_CREATION_DATE) as ageing from gpn_initiation gpn, bgv, emp_client emp where bgv.id=gpn.bgv_id and bgv.sap_id=emp.sap_id and gpn.gpn is not null and emp.CIT_COMPLETETION_STATUS is null;
			int count=0;
			System.out.println(lst.toString());
			for(Map<String, Object> map:lst)
			{
				objects=new Object[9];
				objects[0]=map.get("Sap_id");
				objects[1]=map.get("empname");
				objects[2]=map.get("project_name");
				objects[3]=map.get("gpn_creation_date");
				objects[4]=map.get("location");
				objects[5]=map.get("CIT_LOCATION");
				objects[6]=map.get("cit_trainer_name");
				objects[7]=map.get("ageing");
				objects[8]=map.get("gpn");
				System.out.println(objects[5]);
				objlist.add(objects);	
				count++;
				System.out.println(Arrays.asList(objects));
				
			}
			}
		catch(Exception e){
			e.printStackTrace();
		}
		return objlist;
	}


	@Override
	public boolean saveCitInitData(String[] trainerList,
			String[] trainingPlace, String[] sapID) {
		final String[]trainers=trainerList;
		final String[]sapList=sapID;
		final String[]placeList=trainingPlace;
//trainerList,trainingPlace,sapID		
		System.out.println("entered citInitDAta");
			return(jdbcTemplate.batchUpdate("update emp_client set CIT_TRAINER_NAME=?,CIT_LOCATION=? where sap_id=?;", new BatchPreparedStatementSetter() {

				@Override
				public void setValues(PreparedStatement ps, int i) throws SQLException {
					int sap=Integer.parseInt(sapList[i]);
					String place=placeList[i];
					String trainer=trainers[i];
					System.out.println(trainer);
					ps.setString(1,trainer);
					ps.setString(2, place);
					ps.setInt(3, sap);

				}

				@Override
				public int getBatchSize() {
					// TODO Auto-generated method stub
					return sapList.length;
				}
			})).length==sapList.length;
		}


	@Override
	public boolean updateCitData(String[] citIndex, String[] citDate,
			String[] sapID) {
		final String[]indexstr=citIndex;
		final String[]sapList=sapID;
		final String[]dateList=citDate;
		
		
			return(jdbcTemplate.batchUpdate("update emp_client set CIT_INDEX_NO=?,CIT_COMPLETED_DATE=?, CIT_COMPLETETION_STATUS='y' where sap_id=?;", new BatchPreparedStatementSetter() {

				@Override
				public void setValues(PreparedStatement ps, int i) throws SQLException {
					int sap=Integer.parseInt(sapList[i]);
					int index=Integer.parseInt(indexstr[i]);
					//System.out.println(gpn);
					SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd"); 
					java.util.Date date = null;
					String gpnStartDate=dateList[i];
					try {
						date = sdf1.parse(gpnStartDate);
					} catch (ParseException e) {
						e.printStackTrace();
					} 
					java.sql.Date sqlDate = new java.sql.Date(date.getTime()); 
					
					

					ps.setInt(3, sap);
					ps.setDate(2, sqlDate);
					ps.setInt(1,index);

				}

				@Override
				public int getBatchSize() {
					// TODO Auto-generated method stub
					return sapList.length;
				}
			})).length==sapList.length;
	}


@Override
public List<Object[]> getEIBlockList() {
	List<Object[]> list=null;
	ArrayList<Object[]> objlist = new ArrayList<Object[]>();

	try{
		Object[] objects=null;
		List<Map<String, Object>> lst = new ArrayList<Map<String,Object>>();
		
		lst =  jdbcTemplate.queryForList(DataBaseRNCQuery.QUERY_TO_GET_EMAIL_INTERNET_BLOCKLIST, new Objects[]{}); 
//select emp.SAP_id,	concat(bgv.EMP_FIRST_NAME,' ',bgv.EMP_LAST_NAME)  as EmpName, bgv.Project_Name, gpn.gpn,bgv.location, emp.EMAIL_BLOCKING_TICKET_NO,emp.INTERNET_BLOCKING_TICKET_NO from gpn_initiation gpn, bgv, emp_client emp where bgv.id=gpn.bgv_id and bgv.sap_id=emp.sap_id and gpn.gpn is not null and EMAIL_BLOCKING ='Y' ;
		int count=0;
		System.out.println(lst.toString());
		for(Map<String, Object> map:lst)
		{
			objects=new Object[9];
			objects[0]=map.get("Sap_id");
			objects[1]=map.get("empname");
			objects[2]=map.get("project_name");
			objects[3]=map.get("gpn_start_date");
			objects[4]=map.get("location");
			objects[5]=map.get("INTERNET_BLOCKING_TICKET_NO");
			objects[6]=map.get("EMAIL_BLOCKING_TICKET_NO");
			objects[7]=map.get("ageing");
			objects[8]=map.get("gpn");
			System.out.println(objects[5]);
			objlist.add(objects);	
			count++;
			System.out.println(Arrays.asList(objects));
			
		}
		}
	catch(Exception e){
		e.printStackTrace();
	}
	return objlist;
}
}
package com.hcl.pmoautomation.rnc.controller;

	import java.io.IOException;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

	import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

	import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service; 
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

	import com.hcl.pmoautomation.ot.service.SRMappingService;
import com.hcl.pmoautomation.ot.service.SRMappingServiceImpl;
import com.hcl.pmoautomation.rnc.utility.ExcelSheetConstants;
import com.hcl.pmoautomation.rnc.vo.Bgv;
import com.hcl.pmoautomation.rnc.vo.Gpn;
import com.hcl.pmoautomation.rnc.vo.NewJoineeOdcAccess;
import com.hcl.pmoautomation.rnc.vo.Resource_amendments;
import com.hcl.pmoautomation.rnc.dao.ComplianceDao;
import com.hcl.pmoautomation.rnc.dao.GpnDao;
import com.hcl.pmoautomation.rnc.dao.GpnDaoImpl;
import com.hcl.pmoautomation.rnc.service.*;

	
		@Controller
	@RequestMapping("pmoautomation/Complianc")
		public class ComplianceController {


		@Autowired(required=true)
		ComplianceService complianceService;
		ComplianceDao complianceDao;
		private JdbcTemplate jdbcTemplate;

		@RequestMapping(value="/home.php", method = RequestMethod.GET)
		public String getOnOffPage(HttpServletRequest request) {
			System.out.println("inside home");
			List<Object[]> userList = complianceService.getCitList();
			request.setAttribute("citList", userList);
			List<Object[]> userList1 = complianceService.getEIBlockList();
			request.setAttribute("blockList", userList1);
			/*List<Object[]> userList1 = gpnService.getReactList();
			request.setAttribute("gpnreactList", userList1);
			List<Object[]> userList3 = gpnService.getVdiList();
			request.setAttribute("vdiDetails", userList3);
			List<Object[]> userList4 = gpnService.getTermiList();
			request.setAttribute("termiDetails", userList4);*/
			return "Compliance/ComplianceHome";
		}


		@RequestMapping(value = "/cit.php", method = RequestMethod.GET)
		public String getUserLIst(HttpServletRequest request) {
			System.out.println("loading cit data");
			request.setAttribute("checkForFirst", true);
			List<Object[]> userList = complianceService.getCitList();
			request.setAttribute("citList", userList);
			return "Compliance/Cit";
		}
		
		
		@RequestMapping(value = "/downloadExcel.php", method = RequestMethod.GET)
	    public ModelAndView downloadExcel() {
	        // create some sample data
			List<Object[]> userList = complianceService.getCitList();
			// return a view which will be resolved by an excel view resolver
	        return new ModelAndView("excelView", "userList", userList);
	    }
		
		@RequestMapping(value = "/initiaitonUpload.php", method = RequestMethod.POST)
		public void excaliburUpload(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {

			// Internally hitting another Servlet

			// TODO:Spring Multipart enable it,Servlet disable it
			request.setAttribute("fileType", "GpnInitiator");
			request.getRequestDispatcher("/fileUpload.aspx").forward(request,
					response);
		}

		/*@RequestMapping(value = "/initExcelReadSave.php", method = RequestMethod.POST)
		public String initSaveData(HttpServletRequest request,
				HttpServletResponse response) throws Exception {

			// Internally hitting another Servlet

			// TODO:Spring Multipart enable it,Servlet disable it
			//SRMappingService srMappingService = new SRMappingServiceImpl();
			boolean resultFlag = gpnService.saveinitDump(
					(String) request.getAttribute("filePath"),
					ExcelSheetConstants.INITIATION_SHEET_NAME,
					ExcelSheetConstants.INITIATION_TABLE_NAME, jdbcTemplate);
			if (resultFlag) {
				request.setAttribute("initDataSaveResult", "Data Save Successfully!!!");
				return "GPN/GpnInit";
			}
			return "GPN/GpnInit";
		}
*/
		

		@RequestMapping(value = "/saveCitData.php", method = RequestMethod.GET)
		public String saveSharePointData(HttpServletRequest request) {

			String button = request.getParameter("btn");
			boolean flagToDecide= button.equalsIgnoreCase("Initiate Training")?true:button.equalsIgnoreCase("CIT completed")?false:false;
			System.out.println(flagToDecide);
			int countNumb=0;
			String[] chkDataList=request.getParameterValues("chkToSave");
			String[] trainerList = new String[chkDataList.length] ;
			String[] trainingPlace = new String[chkDataList.length] ;
			String[] citIndex = new String[chkDataList.length] ;
			String[] sapID = new String[chkDataList.length] ; 
			String[] citDate = new String[chkDataList.length] ;
			for(String count:chkDataList ){

				
				if(flagToDecide){
					sapID[countNumb]=request.getParameter("sapid"+count);
					trainerList[countNumb]=request.getParameter("trainerName"+count)!=null?request.getParameter("trainerName"+count):request.getParameter("snowTicketNumb"+count);//snowTicketNumb
					trainingPlace[countNumb]=request.getParameter("trainingLocation"+count)!=null?request.getParameter("trainingLocation"+count):null;
					countNumb++;
					System.out.println("sap  "+sapID+"trainer  "+trainerList+"place  "+trainingPlace);
					request.setAttribute("snowSaveResult",complianceService.saveCitInitData(trainerList,trainingPlace,sapID)?"Successfully saved !!":"Error");
				}
				if(!flagToDecide){
					sapID[countNumb]=request.getParameter("sapid"+count);
					citIndex[countNumb]=request.getParameter("citIndexNo"+count)!=null?request.getParameter("citIndexNo"+count):null;
					citDate[countNumb]=request.getParameter("citCompletionDate"+count)!=null?request.getParameter("citCompletionDate"+count):null;
					countNumb++;
					request.setAttribute("gpnDataSaveResult",complianceService.updateCitData(citIndex,citDate,sapID)?"GPN no. Succcessfully Saved!!!":"Error");
				}
			}

			return "forward:../../pmoautomation/Complianc/cit.php";		
		}
		
		@RequestMapping(value = "/block.php", method = RequestMethod.GET)
		public String getBlockLIst(HttpServletRequest request) {
			System.out.println("loading internet block data");
			request.setAttribute("checkForFirst", true);
			List<Object[]> userList = complianceService.getEIBlockList();
			request.setAttribute("blockList", userList);
			return "Compliance/EmailInternetBlock";
		}



}

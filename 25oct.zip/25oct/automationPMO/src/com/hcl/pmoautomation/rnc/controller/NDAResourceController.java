package com.hcl.pmoautomation.rnc.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.hcl.pmoautomation.bgv.dao.DownloadPathDao;
import com.hcl.pmoautomation.bgv.model.DownloadPathvo;
import com.hcl.pmoautomation.rnc.dao.NewGpnDaoImpl;
import com.hcl.pmoautomation.rnc.model.NDAActivFlagCheck;
import com.hcl.pmoautomation.rnc.service.NewGpnServiceImpl;
import com.hcl.pmoautomation.rnc.vo.Bgv;
import com.hcl.pmoautomation.rnc.vo.NDAdownloadPath;

@Controller
@RequestMapping(value = "GpnInitiation/NDA")
public class NDAResourceController {
	@Autowired(required = true)
	JdbcTemplate jdbcTemplate;
	
	
	@RequestMapping(value = "/uploadNDAform.php")
	public String NDAInitiation(HttpServletRequest request) {
		String sapid=request.getParameter("SapIdforNDA");
		NewGpnDaoImpl nda=new NewGpnDaoImpl();
		List<NDAActivFlagCheck> sapname= nda.linkactive(sapid, jdbcTemplate);
		System.out.println("console   "+sapname);
		String[] array = new String[sapname.size()];
		int index = 0;
		for (Object value : sapname) {
			array[index] = String.valueOf( value );
		}
		
		if(array[index].equalsIgnoreCase("Y")){
			request.setAttribute("NDAsapidLink", sapid);	
			
			System.out.println("hiiii1 "+sapid);
			int sapcodeconvert=Integer.parseInt(sapid);
			System.out.println("hiiii11 "+sapcodeconvert);
			HttpSession session = request.getSession();
		    session.setAttribute("NdaUploadsapcode", sapcodeconvert);
		}
		else{
			return"GPN/NDABlockPage";
		}
		
		
		
		return "GPN/NDAResourceupload";
		

	}
	
	@RequestMapping(value = "/uploadNDAformSubmit.php")
	public void uploadNDAformSubmit(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
System.out.println("hi in nda upload");
	
	request.setAttribute("NDAresourceUpload", "resourceuploadNDA");
	request.getRequestDispatcher("/fileUploadbgv.NDAformUpload").forward(request,
			response);
		

	}
	
	 @RequestMapping(value = "/NDAuploadsaveDatabase.php")
	    public void uploadpageDU(HttpServletRequest request,
	    		HttpServletResponse response) throws ServletException, IOException 
	    {
		
	 int sapid=(int) request.getSession().getAttribute("NdaUploadsapcode");
	 
		 String finaluploadPathbgv=(String) request.getSession().getAttribute("finaluploadforNDA");
		 if(finaluploadPathbgv!=null){
				 
		 
	        System.out.println("servlet sapbgv du"+sapid);
	        System.out.println("final path in controller bgv  du "+finaluploadPathbgv);
	        jdbcTemplate.update("call mydb.nda_form_path("+sapid+",'"+finaluploadPathbgv+"')");
	        jdbcTemplate.update("update mydb.gpn_initiation set gpn_initiation.ACTIVEFLAG_LINK='N' where gpn_initiation.BGV_ID=(select bgv.id from mydb.bgv where bgv.SAP_ID="+sapid+")");
			
	        request.setAttribute("message", "File successfully uploaded!!!");
		 PrintWriter out = response.getWriter();
		 out.println("<html><body><script>window.alert('File successfully uploaded!!!');window.close();</script></body></html>");
		 request.getSession().invalidate();
		 }
else{
	request.getSession().invalidate();
	PrintWriter out = response.getWriter();
	 out.println("<html><body><script>alert('Error in uploading File!!!');window.close();</script></body></html>");
}
	    }
	 
	 
	 @RequestMapping(value = "/NdaUploadForm1.php")
		public void NdaUploadForm1(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			
		
			String sapid=request.getParameter("searchNDAupload1");
			int sapidconvert=Integer.parseInt(sapid);
			System.out.println("controller sap from jsp    "+sapid);
			NewGpnDaoImpl nda=new NewGpnDaoImpl();
			List<NDAdownloadPath> downloadPathlink=nda.NDAdownload1(sapidconvert, jdbcTemplate);
			
			String[] array = new String[downloadPathlink.size()];
			int index = 0;
			for (Object value : downloadPathlink) {
				array[index] = String.valueOf( value );
			}
			
			HttpSession session = request.getSession();
	        session.setAttribute("downloadpathsessionforNDA1", array[index]);
			// TODO:Spring Multipart enable it,Servlet disable it
			request.setAttribute("fileTypepdfdown", "pdfdownload");
			
			request.getRequestDispatcher("/fileUpload.NdaUploadForm1").forward(request,
					response);
			
	 }
	
	 @RequestMapping(value = "/NdaUploadForm2.php")
		public void NdaUploadForm2(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			
		
			String sapid=request.getParameter("searchNDAupload2");
			int sapidconvert=Integer.parseInt(sapid);
			System.out.println("controller sap from jsp    "+sapid);
			NewGpnDaoImpl nda=new NewGpnDaoImpl();
			List<NDAdownloadPath> downloadPathlink=nda.NDAdownload2(sapidconvert, jdbcTemplate);
			
			String[] array = new String[downloadPathlink.size()];
			int index = 0;
			for (Object value : downloadPathlink) {
				array[index] = String.valueOf( value );
			}
			
			HttpSession session = request.getSession();
	        session.setAttribute("downloadpathsessionforNDA2", array[index]);
			// TODO:Spring Multipart enable it,Servlet disable it
			request.setAttribute("fileTypepdfdown", "pdfdownload");
			
			request.getRequestDispatcher("/fileUpload.NdaUploadForm2").forward(request,
					response);
			
	 }
	 
	 @RequestMapping(value = "/NdaUploadForm3.php")
		public void NdaUploadForm3(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			
		
			String sapid=request.getParameter("searchNDAupload3");
			int sapidconvert=Integer.parseInt(sapid);
			System.out.println("controller sap from jsp    "+sapid);
			NewGpnDaoImpl nda=new NewGpnDaoImpl();
			List<NDAdownloadPath> downloadPathlink=nda.NDAdownload3(sapidconvert, jdbcTemplate);
			
			String[] array = new String[downloadPathlink.size()];
			int index = 0;
			for (Object value : downloadPathlink) {
				array[index] = String.valueOf( value );
			}
			
			HttpSession session = request.getSession();
	        session.setAttribute("downloadpathsessionforNDA3", array[index]);
			// TODO:Spring Multipart enable it,Servlet disable it
			request.setAttribute("fileTypepdfdown", "pdfdownload");
			
			request.getRequestDispatcher("/fileUpload.NdaUploadForm3").forward(request,
					response);
			
	 }
	 
	 @RequestMapping(value = "/NdaUploadForm4.php")
		public void NdaUploadForm4(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			
		
			String sapid=request.getParameter("searchNDAupload4");
			int sapidconvert=Integer.parseInt(sapid);
			System.out.println("controller sap from jsp    "+sapid);
			NewGpnDaoImpl nda=new NewGpnDaoImpl();
			List<NDAdownloadPath> downloadPathlink=nda.NDAdownload4(sapidconvert, jdbcTemplate);
			
			String[] array = new String[downloadPathlink.size()];
			int index = 0;
			for (Object value : downloadPathlink) {
				array[index] = String.valueOf( value );
			}
			
			HttpSession session = request.getSession();
	        session.setAttribute("downloadpathsessionforNDA4", array[index]);
			// TODO:Spring Multipart enable it,Servlet disable it
			request.setAttribute("fileTypepdfdown", "pdfdownload");
			
			request.getRequestDispatcher("/fileUpload.NdaUploadForm4").forward(request,
					response);
			
	 }
	 
	 @RequestMapping(value = "/NdaUploadForm5.php")
		public void NdaUploadForm5(HttpServletRequest request,
				HttpServletResponse response) throws ServletException, IOException {
			
		
			String sapid=request.getParameter("searchNDAupload5");
			int sapidconvert=Integer.parseInt(sapid);
			System.out.println("controller sap from jsp    "+sapid);
			NewGpnDaoImpl nda=new NewGpnDaoImpl();
			List<NDAdownloadPath> downloadPathlink=nda.NDAdownload5(sapidconvert, jdbcTemplate);
			
			String[] array = new String[downloadPathlink.size()];
			int index = 0;
			for (Object value : downloadPathlink) {
				array[index] = String.valueOf( value );
			}
			
			HttpSession session = request.getSession();
	        session.setAttribute("downloadpathsessionforNDA5", array[index]);
			// TODO:Spring Multipart enable it,Servlet disable it
			request.setAttribute("fileTypepdfdown", "pdfdownload");
			
			request.getRequestDispatcher("/fileUpload.NdaUploadForm5").forward(request,
					response);
			
	 }
	 
}

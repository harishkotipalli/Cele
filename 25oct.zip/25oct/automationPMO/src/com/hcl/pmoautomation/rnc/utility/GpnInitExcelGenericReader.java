package com.hcl.pmoautomation.rnc.utility;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.hcl.pmoautomation.ot.dao.DatabaseUtil;
import com.hcl.pmoautomation.ot.dao.ExcaliburDaoImpl;
import com.hcl.pmoautomation.rnc.dao.GpnDao;
import com.hcl.pmoautomation.rnc.dao.GpnDaoImpl;

//@Component
public class GpnInitExcelGenericReader {

//	@Autowired(required = true)
//	JdbcTemplate jdbcTemplate;
//	GpnDao gpnDao;

	// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	public static List<ArrayList<String>> readExcelAllDynamically(String file,
			String sheetName, String tableName,JdbcTemplate jdbcTemplate,GpnDao gpnDao) throws FileNotFoundException,
			IOException, Exception {
		Workbook myExcelBook = new WorkbookFactory()
				.create(new FileInputStream(file));
		Sheet myExcelSheet = myExcelBook.getSheet(sheetName);
		String tempData = null;

		int tempReadCount = 0;
		List<String> tempStrings = new ArrayList<String>();
		List<ArrayList<String>> tempStringList = new ArrayList<ArrayList<String>>();
		// GpnDaoImpl oppTrcakerImpl = new GpnDaoImpl();
		List<Map<String, Object>> colNames = gpnDao
				.getAllColumnNamesDynamically(tableName);
		List<Integer> rowCount = new ArrayList<Integer>();
		System.out.println("Size : " + colNames.size());
		for (Map columnMapRowData : colNames) {
			// System.out.println((Integer) columnMapRowData.get("column_id"));
			rowCount.add((Integer) columnMapRowData.get("column_id"));
		}
		System.out.println("Name : " + myExcelBook.getSheetName(0));
		System.out.println(myExcelSheet.getPhysicalNumberOfRows());
		Row row = null;
		for (int j = 1; j < myExcelSheet.getPhysicalNumberOfRows(); j++) {

			row = myExcelSheet.getRow(j);
			System.out.println(row.getRowNum());
			for (int i = 0; i < rowCount.size(); i++) {

				tempReadCount = rowCount.get(i) - 1;
				 System.out.println(row);
				// System.out.println(row.getCell(tempReadCount).getStringCellValue());
				System.out.println(row.getCell(tempReadCount).getCellType()+"ASASASAS");
				if (row.getCell(tempReadCount).getCellType() == Cell.CELL_TYPE_STRING) {

					tempData = row.getCell(tempReadCount).getStringCellValue();

					if (row.getCell(tempReadCount).getStringCellValue()
							.equals("")) {
						tempData = null;
					}

				}

				if (row.getCell(tempReadCount).getCellType() == Cell.CELL_TYPE_BLANK) {
					tempData = null;
				}
				if (row.getCell(tempReadCount).getCellType() == Cell.CELL_TYPE_NUMERIC) {

					if (HSSFDateUtil.isCellDateFormatted(row
							.getCell(tempReadCount))) {

						tempData = new SimpleDateFormat("dd-MMM-yyyy")
								.format(row.getCell(tempReadCount)
										.getDateCellValue())
								+ "";

					} else {
						// System.out.println(tempData);
						tempData = new Double(row.getCell(tempReadCount)
								.getNumericCellValue()).longValue() + "";

					}
				}
				if (row.getCell(tempReadCount).getCellType() == Cell.CELL_TYPE_FORMULA) {
					if (row.getCell(tempReadCount).getCachedFormulaResultType() == Cell.CELL_TYPE_NUMERIC) {
						if (!HSSFDateUtil.isCellDateFormatted(row
								.getCell(tempReadCount)))
							tempData = (int) row.getCell(tempReadCount)
									.getNumericCellValue() + "";
					}
					if (row.getCell(tempReadCount).getCellType() == Cell.CELL_TYPE_STRING) {
						if (!HSSFDateUtil.isCellDateFormatted(row
								.getCell(tempReadCount)))
							tempData = row.getCell(tempReadCount)
									.getStringCellValue();
					}
				}
				if (tempReadCount == 0
						&& (tempData == null || tempData
								.equalsIgnoreCase((0 + "")))) {
					break;
				}
				// System.out.println(tempData);
				tempStrings.add(tempData);
				// tempData = null;

			}
			// System.out.println(tempStrings);
			if (!(tempStrings.size() == 0)) {
				tempStringList.add(new ArrayList<String>(tempStrings));
			}
			tempStrings.clear();
		}

		// System.out.println(tempStringList.size());
		return tempStringList;

	}

}

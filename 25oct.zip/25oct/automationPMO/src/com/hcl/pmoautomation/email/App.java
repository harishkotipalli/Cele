package com.hcl.pmoautomation.email;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.hcl.pmoautomation.email.vo.Mail;
import com.technicalkeeda.services.MailService;

public class App {
	//public static void main(String args[],) {
	String htmlEmailTemplate = ".... <img src=\"0.PNG\"> ....";
		public void Mailtrigger(String From_mail,String To_mail,String subject,String Name,String vm,List list, String attachment){
		
		        Mail mail = new Mail();
		        mail.setMailFrom(From_mail);
		        mail.setMailTo(To_mail);
		        
		        mail.setMailSubject(subject);
		      mail.setEmbed(htmlEmailTemplate);
		        mail.setContentType(Name);
		        //mail.setAttachments(attachment);
		        
		        Map < String, Object > model = new HashMap < String, Object > ();
		        model.put("Name", Name);
		        model.put("firstName",list);
		        model.put("tempattachment",attachment);
		     
		        
		       
		    
		        mail.setModel(model);
		 
		      
		        
		        ApplicationContext context = new ClassPathXmlApplicationContext("com/hcl/pmoautomation/email/vm/spring-beans.xml");
		       
              	

		        MailService mailService = (MailService) context.getBean("mailService");
		        mailService.sendEmail(mail,vm);
		        
		    }
	/*	public static void main(String args[]){
			App mm=new App();
			mm.Mailtrigger("shyamsunder.p@hcl.com", "shyamsunder.p@hcl.com","hi ","subbject", "temp.jsp",null,null);
		}*/
}

package com.hcl.pmoautomation.AddAction.vo;

public class statusVO {
	private String countopen;
	private String countopenmedium;
	private String countopenlow;
	private String countclosemedium;
	private String countoverduemedium;
	private String countontrackmedium;
	private String countassignedmedium;
	private String countunassignedmedium;
	private String countcloselow;
	private String countoverduelow;
	private String countontracklow;
	private String countassignedlow;
	private String countunassignedlow;
	private String countclose;
	private String countoverdue;
	private String countontrack;
	private String countassigned;
	private String countunassigned;
	public String getCountopen() {
		return countopen;
	}
	public void setCountopen(String countopen) {
		this.countopen = countopen;
	}
	public String getCountopenmedium() {
		return countopenmedium;
	}
	public void setCountopenmedium(String countopenmedium) {
		this.countopenmedium = countopenmedium;
	}
	public String getCountopenlow() {
		return countopenlow;
	}
	public void setCountopenlow(String countopenlow) {
		this.countopenlow = countopenlow;
	}
	public String getCountclosemedium() {
		return countclosemedium;
	}
	public void setCountclosemedium(String countclosemedium) {
		this.countclosemedium = countclosemedium;
	}
	public String getCountoverduemedium() {
		return countoverduemedium;
	}
	public void setCountoverduemedium(String countoverduemedium) {
		this.countoverduemedium = countoverduemedium;
	}
	public String getCountontrackmedium() {
		return countontrackmedium;
	}
	public void setCountontrackmedium(String countontrackmedium) {
		this.countontrackmedium = countontrackmedium;
	}
	public String getCountassignedmedium() {
		return countassignedmedium;
	}
	public void setCountassignedmedium(String countassignedmedium) {
		this.countassignedmedium = countassignedmedium;
	}
	public String getCountunassignedmedium() {
		return countunassignedmedium;
	}
	public void setCountunassignedmedium(String countunassignedmedium) {
		this.countunassignedmedium = countunassignedmedium;
	}
	public String getCountcloselow() {
		return countcloselow;
	}
	public void setCountcloselow(String countcloselow) {
		this.countcloselow = countcloselow;
	}
	public String getCountoverduelow() {
		return countoverduelow;
	}
	public void setCountoverduelow(String countoverduelow) {
		this.countoverduelow = countoverduelow;
	}
	public String getCountontracklow() {
		return countontracklow;
	}
	public void setCountontracklow(String countontracklow) {
		this.countontracklow = countontracklow;
	}
	public String getCountassignedlow() {
		return countassignedlow;
	}
	public void setCountassignedlow(String countassignedlow) {
		this.countassignedlow = countassignedlow;
	}
	public String getCountunassignedlow() {
		return countunassignedlow;
	}
	public void setCountunassignedlow(String countunassignedlow) {
		this.countunassignedlow = countunassignedlow;
	}
	public String getCountclose() {
		return countclose;
	}
	public void setCountclose(String countclose) {
		this.countclose = countclose;
	}
	public String getCountoverdue() {
		return countoverdue;
	}
	public void setCountoverdue(String countoverdue) {
		this.countoverdue = countoverdue;
	}
	public String getCountontrack() {
		return countontrack;
	}
	public void setCountontrack(String countontrack) {
		this.countontrack = countontrack;
	}
	public String getCountassigned() {
		return countassigned;
	}
	public void setCountassigned(String countassigned) {
		this.countassigned = countassigned;
	}
	public String getCountunassigned() {
		return countunassigned;
	}
	public void setCountunassigned(String countunassigned) {
		this.countunassigned = countunassigned;
	}
	@Override
	public String toString() {
		return "statusVO [countopen=" + countopen + ", countopenmedium=" + countopenmedium + ", countopenlow="
				+ countopenlow + ", countclosemedium=" + countclosemedium + ", countoverduemedium=" + countoverduemedium
				+ ", countontrackmedium=" + countontrackmedium + ", countassignedmedium=" + countassignedmedium
				+ ", countunassignedmedium=" + countunassignedmedium + ", countcloselow=" + countcloselow
				+ ", countoverduelow=" + countoverduelow + ", countontracklow=" + countontracklow
				+ ", countassignedlow=" + countassignedlow + ", countunassignedlow=" + countunassignedlow
				+ ", countclose=" + countclose + ", countoverdue=" + countoverdue + ", countontrack=" + countontrack
				+ ", countassigned=" + countassigned + ", countunassigned=" + countunassigned + "]";
	}
	


}

package com.hcl.pmoautomation.AddAction.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.hcl.pmoautomation.AddAction.vo.ActionAdd;
import com.hcl.pmoautomation.AddAction.vo.autocompleteVo;
import com.hcl.pmoautomation.rnc.dao.DataBaseRNCQuery;
import com.mysql.jdbc.Connection;

public class DataDao {

	

    
    
    
 /*   public List<autocompleteVo> getFrameWork(String frameWork, JdbcTemplate jdbcTemplate) { 
	{
		//int it=(int)session.getAttribute("managerId");
	
			String sql = "SELECT NAME FROM mydb.login  WHERE NAME  LIKE "+"'"+frameWork+"%'";
			System.out.println(sql);
		 List<autocompleteVo> listaa = jdbcTemplate.query(sql, new RowMapper<autocompleteVo>() 
	
	    				 {
			@Override
			public autocompleteVo mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				autocompleteVo aa = new autocompleteVo();
				
				aa.setLoginUsername(rs.getString("NAME"));
				
				return aa;
			}
	    });//---------------new Object[]{year, month});
	    return listaa;
	    
	  
	    
		
	
		
		
	}
    
    
}*/
    
    
    
    private Connection connection;

    public DataDao() throws Exception {
            connection = DBUtility.getConnection();
    }

    public ArrayList<String> getFrameWork(String frameWork) {
    ArrayList<String> list = new ArrayList<String>();
    PreparedStatement ps = null;
    String data;
    try {
    ps = connection.prepareStatement("SELECT * FROM mydb.login  WHERE NAME  LIKE ?");
            ps.setString(1, frameWork + "%");
            ResultSet rs = ps.executeQuery();
            System.out.println("helooooooo "+ps+"byeeee "+rs);
            while (rs.next()) {
                    data = rs.getString("NAME");
                    list.add(data);
            }
    } catch (Exception e) {
            System.out.println(e.getMessage());
    }
    return list;
}
    
    
    public String getemployeeSapId(JdbcTemplate jdbcTemplate, String parameter) {
		System.out.println("gettingemployeesapid");
		return jdbcTemplate.queryForObject(DataBaseQueryForAddAction.QUERY_TO_GET_employeesapid_foraddaction_usingempname+parameter+"'", String.class);
		
	}
	public String getemployeeMailId(JdbcTemplate jdbcTemplate, String parameter) {
		System.out.println("gettinemployeemailid");
		return jdbcTemplate.queryForObject(DataBaseQueryForAddAction.QUERY_TO_GET_employeemailid_foraddaction_usingempname+parameter+"'", String.class);
		
	}
	
	public String getemployeetotalactions(JdbcTemplate jdbcTemplate, String parameter) {
		System.out.println("gettinemployeetotalactions");
		
		String s= jdbcTemplate.queryForObject(DataBaseQueryForAddAction.QUERY_TO_GET_employeetotalActions_foraddaction_usingsapcode+parameter+"'", String.class);
		System.out.println("heloooooo"+s);
		return s;
	}
	public String getemployeetotalhours(JdbcTemplate jdbcTemplate, String parameter) {
		System.out.println("gettinemployeetoatlhours");
		return jdbcTemplate.queryForObject(DataBaseQueryForAddAction.QUERY_TO_GET_employeetotalhours_foraddaction_usingsapcode+parameter+"'", String.class);
		
	}
    
}

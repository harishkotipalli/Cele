package com.hcl.pmoautomation.AddAction.dao;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.jdbc.core.JdbcTemplate;



public interface addActionInterface {

	
	
	
	     


	

		
	}



package com.hcl.pmoautomation.AddAction.dao;

public interface DataBaseQueryForAddAction {

	public	String QUERY_TO_FETCH_ADDACTION_DATA = "SELECT * FROM  gat where ownersap=?;";
	public String QUERY_TO_FETCH_ADDACTION_UPDATEDATA = "UPDATE  gat SET  meeting=?,category =?,"
			+ "raid =?,description=?,status=?,tracks_clustures=?,ownername=? ,ownersap=? ,"
			+ "ownermail=?,meetingdate=?,targetclosuredate=?,Re_baselinedate=? ,"
			+ "ActualClosureDate=?,Status_Update=? where sl=?;";
	public String QUERY_TO_FETCH_ADDACTION_INSERTDATA="insert into  gat (meeting,category ,raid ,"
			+ "description,status,tracks_clustures,ownername ,ownersap ,ownermail,meetingdate,targetclosuredate,"
			+ "Re_baselinedate ,ActualClosureDate,Status_Update) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
	public String QUERY_TO_FETCH_ADDACTION_DELETE="DELETE FROM  gat WHERE id=?;";
	public String QUERY_TO_FETCH_ADDACTION_GETRECORD="SELECT * FROM  gat WHERE id=?";
	public String QUERY_TO_FETCH_SkillSearch_GETRECORD="select * from mydb.rupa_table where upload_date=?,Cluster=?,RAG=?";
	public String QUERY_TO_FETCH_GAT_Search1="SELECT * FROM mydb.gat where raid=";
	public String QUERY_TO_FETCH_GAT_Search2=" And Category=";
	public String QUERY_TO_FETCH_GAT_Search3=" and Status=";
	public String QUERY_TO_FETCH_GAT_Search4=" and meetingdate=";
	public	String QUERY_TO_FETCH_GAT_Search5=" and ownersap=";
	
	public String QUERY_TO_FETCH_GAT_Search6=" and type in(";
	public String QUERY_TO_FETCH_GAT_SearchSAP="where ownersap=?";
	public String QUERY_TO_FETCH_SkillSearch_GETedit="select meeting_adhoc,category,raid,Shortdesc,description,Business_Criticality,status,tracks_clustures,ownername,ownersap,ownermail,meetingdate,targetclosuredate,Re_baselinedate,ActualClosureDate,Remarks,Status_Update,type,RecentUpdate,sl from mydb.gat where raid=";
	public String QUERY_TO_FETCH_SkillSearch_GETedit2=" And category= ";
	public String QUERY_TO_FETCH_SkillSearch_GETedit3= " And status =";
	public String QUERY_TO_FETCH_SkillSearch_GETedit4= " And type=";
	public String QUERY_TO_FETCH_SkillSearch_GETedit5= " And sl=";
	public String QUERY_TO_FETCH_SkillSearch_GATINSERT="insert into  mydb.gat values";
	
	
	public String QUERY_TO_FETCH_SkillSearch_GETupdate="UPDATE mydb.gat SET  description=";
	public String QUERY_TO_FETCH_SkillSearch_GETupdate1=" ,status= ";
	public String QUERY_TO_FETCH_SkillSearch_GETupdate2=",ownername=";
	public String QUERY_TO_FETCH_SkillSearch_GETupdate3=",ownersap=";
	public String QUERY_TO_FETCH_SkillSearch_GETupdate4=",ownermail=";
	public String QUERY_TO_FETCH_SkillSearch_GETupdate5=",targetclosuredate=";
	public String QUERY_TO_FETCH_SkillSearch_GETupdate6=",Re_baselinedate=";
	public String QUERY_TO_FETCH_SkillSearch_GETupdate7=",ActualClosureDate=";
	public String QUERY_TO_FETCH_SkillSearch_GETupdate8=",Remarks=";
	public String QUERY_TO_FETCH_SkillSearch_GETupdate9=",Status_Update=";
	public String QUERY_TO_FETCH_SkillSearch_GETupdate10="  where sl=";
	public String QUERY_TO_FETCH_SkillSearch_GETupdate101="UPDATE mydb.gat SET  description=?,status=?,tracks_clustures=?,ownername=? ,ownersap=? ,ownermail=?,meetingdate=?,targetclosuredate=?,Re_baselinedate=? ,ActualClosureDate=?,Status_Update=? where sl=?";

	
	
	public String QUERY_TO_FETCH_actionstatus_overdue="select count(3) from mydb.gat where gat.status='OverDue' and gat.Business_Criticality='high' and gat.ownersap=";
    public String QUERY_TO_FETCH_actionstatus_overduemedium="select count(9) from mydb.gat where gat.status='OverDue' and gat.Business_Criticality='medium' and gat.ownersap=";
    public String QUERY_TO_FETCH_actionstatus_overduelow="select count(10) from mydb.gat where gat.status='OverDue' and gat.Business_Criticality='low' and gat.ownersap=";
	
	public String QUERY_TO_FETCH_actionstatus_open="select count(1) from mydb.gat where gat.status='Open' and gat.Business_Criticality='high' and gat.ownersap=";
	public String QUERY_TO_FETCH_actionstatus_openmedium="select count(7) from mydb.gat where gat.status='Open' and gat.Business_Criticality='medium' and gat.ownersap=";
	public String QUERY_TO_FETCH_actionstatus_openlow="select count(8) from mydb.gat where gat.status='Open' and gat.Business_Criticality='low' and gat.ownersap=";
	
	public String QUERY_TO_FETCH_actionstatus_close="select count(2) from mydb.gat where gat.status='Close' and gat.Business_Criticality='high' and gat.ownersap=";
	public String QUERY_TO_FETCH_actionstatus_closemedium="select count(11) from mydb.gat where gat.status='Close' and gat.Business_Criticality='medium' and gat.ownersap=";
	public String QUERY_TO_FETCH_actionstatus_closelow="select count(12) from mydb.gat where gat.status='Close' and gat.Business_Criticality='low' and gat.ownersap=";
	
	public String QUERY_TO_FETCH_actionstatus_ontrack="select count(4) from mydb.gat where gat.status='On-Track' and gat.Business_Criticality='high' and gat.ownersap=";
	public String QUERY_TO_FETCH_actionstatus_ontrackmedium="select count(13) from mydb.gat where gat.status='On-Track' and gat.Business_Criticality='medium' and gat.ownersap=";
	public String QUERY_TO_FETCH_actionstatus_ontracklow="select count(14) from mydb.gat where gat.status='On-Track' and gat.Business_Criticality='low' and gat.ownersap=";
	
	public String QUERY_TO_FETCH_actionstatus_assigned="select count(5) from mydb.gat where gat.status='Assigned' and gat.Business_Criticality='high' and gat.ownersap=";
	public String QUERY_TO_FETCH_actionstatus_assignedmedium="select count(15) from mydb.gat where gat.status='Assigned' and gat.Business_Criticality='medium' and gat.ownersap=";
	public String QUERY_TO_FETCH_actionstatus_assignedlow="select count(16) from mydb.gat where gat.status='Assigned' and gat.Business_Criticality='low' and gat.ownersap=";
	
	public String QUERY_TO_FETCH_actionstatus_unassigned="select count(6) from mydb.gat where gat.status='Unassigned' and gat.Business_Criticality='high' and gat.ownersap=";
	public String QUERY_TO_FETCH_actionstatus_unassignedmedium="select count(17) from mydb.gat where gat.status='Unassigned' and gat.Business_Criticality='medium' and gat.ownersap=";
	public String QUERY_TO_FETCH_actionstatus_unassignedlow="select count(18) from mydb.gat where gat.status='Unassigned' and gat.Business_Criticality='low' and gat.ownersap=";
	
	        public String QUERY_TO_FETCH_actionstatus_open_DATA="select gat.raid, gat.category, gat.Shortdesc,gat.status,gat.meetingdate,gat.type ,gat.sl from mydb.gat where gat.status='open' and gat.Business_Criticality='high' and gat.ownersap=";
	        public String QUERY_TO_FETCH_actionstatus_open_DATAmedium="select gat.raid, gat.category, gat.Shortdesc,gat.status,gat.meetingdate,gat.type ,gat.sl from mydb.gat where gat.status='open' and gat.Business_Criticality='medium' and gat.ownersap=";
	        public String QUERY_TO_FETCH_actionstatus_open_DATAlow="select gat.raid, gat.category, gat.Shortdesc,gat.status,gat.meetingdate,gat.type ,gat.sl from mydb.gat where gat.status='open' and gat.Business_Criticality='low' and gat.ownersap=";
	        
	        public String QUERY_TO_FETCH_actionstatus_close_DATA="select gat.raid, gat.category, gat.Shortdesc,gat.status,gat.meetingdate,gat.type,gat.sl from mydb.gat where gat.status='close' and gat.Business_Criticality='high' and gat.ownersap=";
	        public String QUERY_TO_FETCH_actionstatus_close_DATAmedium="select gat.raid, gat.category, gat.Shortdesc,gat.status,gat.meetingdate,gat.type ,gat.sl from mydb.gat where gat.status='close' and gat.Business_Criticality='medium' and gat.ownersap=";
	        public String QUERY_TO_FETCH_actionstatus_close_DATAlow="select gat.raid, gat.category, gat.Shortdesc,gat.status,gat.meetingdate,gat.type ,gat.sl from mydb.gat where gat.status='close' and gat.Business_Criticality='low' and gat.ownersap=";
	        
	        public String QUERY_TO_FETCH_actionstatus_overdue_DATA="select gat.raid, gat.category, gat.Shortdesc,gat.status,gat.meetingdate,gat.type,gat.sl from mydb.gat where gat.status='overdue' and gat.Business_Criticality='high' and gat.ownersap=";
	        public String QUERY_TO_FETCH_actionstatus_overdue_DATAmedium="select gat.raid, gat.category, gat.Shortdesc,gat.status,gat.meetingdate,gat.type ,gat.sl from mydb.gat where gat.status='overdue' and gat.Business_Criticality='medium' and gat.ownersap=";
	        public String QUERY_TO_FETCH_actionstatus_overdue_DATAlow="select gat.raid, gat.category, gat.Shortdesc,gat.status,gat.meetingdate,gat.type ,gat.sl from mydb.gat where gat.status='overdue' and gat.Business_Criticality='low' and gat.ownersap=";
	        
	        public String QUERY_TO_FETCH_actionstatus_ontrack_DATA="select gat.raid, gat.category, gat.Shortdesc,gat.status,gat.meetingdate,gat.type,gat.sl from mydb.gat where gat.status='on-track' and gat.Business_Criticality='high' and gat.ownersap=";
	        public String QUERY_TO_FETCH_actionstatus_ontrack_DATAmedium="select gat.raid, gat.category, gat.Shortdesc,gat.status,gat.meetingdate,gat.type ,gat.sl from mydb.gat where gat.status='on-track' and gat.Business_Criticality='medium' and gat.ownersap=";
	        public String QUERY_TO_FETCH_actionstatus_ontrack_DATAlow="select gat.raid, gat.category, gat.Shortdesc,gat.status,gat.meetingdate,gat.type ,gat.sl from mydb.gat where gat.status='on-track' and gat.Business_Criticality='low' and gat.ownersap=";
	        
	        public String QUERY_TO_FETCH_actionstatus_assigned_DATA="select gat.raid, gat.category, gat.Shortdesc,gat.status,gat.meetingdate,gat.type,gat.sl from mydb.gat where gat.status='assigned' and gat.Business_Criticality='high' and gat.ownersap=";
	        public String QUERY_TO_FETCH_actionstatus_assigned_DATAmedium="select gat.raid, gat.category, gat.Shortdesc,gat.status,gat.meetingdate,gat.type ,gat.sl from mydb.gat where gat.status='assigned' and gat.Business_Criticality='medium' and gat.ownersap=";
	        public String QUERY_TO_FETCH_actionstatus_assigned_DATAlow="select gat.raid, gat.category, gat.Shortdesc,gat.status,gat.meetingdate,gat.type ,gat.sl from mydb.gat where gat.status='assigned' and gat.Business_Criticality='low' and gat.ownersap=";
	        
	        public String QUERY_TO_FETCH_actionstatus_unassigned_DATA="select gat.raid, gat.category, gat.Shortdesc,gat.status,gat.meetingdate,gat.type,gat.sl from mydb.gat where gat.status='unassigned' and gat.Business_Criticality='high' and gat.ownersap=";
	        public String QUERY_TO_FETCH_actionstatus_unassigned_DATAmedium="select gat.raid, gat.category, gat.Shortdesc,gat.status,gat.meetingdate,gat.type ,gat.sl from mydb.gat where gat.status='unassigned' and gat.Business_Criticality='medium' and gat.ownersap=";
	        public String QUERY_TO_FETCH_actionstatus_unassigned_DATAlow="select gat.raid, gat.category, gat.Shortdesc,gat.status,gat.meetingdate,gat.type ,gat.sl from mydb.gat where gat.status='unassigned' and gat.Business_Criticality='low' and gat.ownersap=";
	        
			
			
			public String QUERY_TO_FETCH_actionstatusassigned_open="select count(1) from mydb.gat where gat.status='Open' and gat.Business_Criticality='high' and gat.Assigned_sapid=";
			public String QUERY_TO_FETCH_actionstatusassigned_openmedium="select count(7) from mydb.gat where gat.status='Open' and gat.Business_Criticality='medium' and gat.Assigned_sapid=";
			public String QUERY_TO_FETCH_actionstatusassigned_openlow="select count(8) from mydb.gat where gat.status='Open' and gat.Business_Criticality='low' and gat.Assigned_sapid=";
			
			public String QUERY_TO_FETCH_actionstatusassigned_close="select count(2) from mydb.gat where gat.status='Close' and gat.Business_Criticality='high'  and gat.Assigned_sapid=";
			public String QUERY_TO_FETCH_actionstatusassigned_closemedium="select count(9) from mydb.gat where gat.status='Close' and gat.Business_Criticality='medium' and gat.Assigned_sapid=";
			public String QUERY_TO_FETCH_actionstatusassigned_closelow="select count(10) from mydb.gat where gat.status='Close' and gat.Business_Criticality='low' and gat.Assigned_sapid=";
			
			public String QUERY_TO_FETCH_actionstatusassigned_overdue="select count(3) from mydb.gat where gat.status='OverDue' and gat.Business_Criticality='high'  and gat.Assigned_sapid=";
			public String QUERY_TO_FETCH_actionstatusassigned_overduemedium="select count(11) from mydb.gat where gat.status='OverDue' and gat.Business_Criticality='medium' and gat.Assigned_sapid=";
			public String QUERY_TO_FETCH_actionstatusassigned_overduelow="select count(12) from mydb.gat where gat.status='OverDue' and gat.Business_Criticality='low' and gat.Assigned_sapid=";
			
			public String QUERY_TO_FETCH_actionstatusassigned_ontrack="select count(4) from mydb.gat where gat.status='On-Track' and gat.Business_Criticality='high'  and gat.Assigned_sapid=";
			public String QUERY_TO_FETCH_actionstatusassigned_ontrackmedium="select count(13) from mydb.gat where gat.status='On-Track' and gat.Business_Criticality='medium' and gat.Assigned_sapid=";
			public String QUERY_TO_FETCH_actionstatusassigned_ontracklow="select count(14) from mydb.gat where gat.status='On-Track' and gat.Business_Criticality='low' and gat.Assigned_sapid=";
			
			public String QUERY_TO_FETCH_actionstatusassigned_assigned="select count(5) from mydb.gat where gat.status='Assigned' and gat.Business_Criticality='high'  and gat.Assigned_sapid=";
			public String QUERY_TO_FETCH_actionstatusassigned_assignedmedium="select count(15) from mydb.gat where gat.status='Assigned' and gat.Business_Criticality='medium' and gat.Assigned_sapid=";
			public String QUERY_TO_FETCH_actionstatusassigned_assignedlow="select count(16) from mydb.gat where gat.status='Assigned' and gat.Business_Criticality='low' and gat.Assigned_sapid=";
			
			public String QUERY_TO_FETCH_actionstatusassigned_unassigned="select count(6) from mydb.gat where gat.status='Unassigned' and gat.Business_Criticality='high'  and gat.Assigned_sapid=";
			public String QUERY_TO_FETCH_actionstatusassigned_unassignedmedium="select count(17) from mydb.gat where gat.status='Unassigned' and gat.Business_Criticality='medium' and gat.Assigned_sapid=";
			public String QUERY_TO_FETCH_actionstatusassigned_unassignedlow="select count(18) from mydb.gat where gat.status='Unassigned' and gat.Business_Criticality='low' and gat.Assigned_sapid=";
			
//open
		
            public String QUERY_TO_FETCH_Assignactionstatus_open_DATA="select gat.raid, gat.category, gat.Shortdesc,gat.ownername,gat.ownersap,gat.targetclosuredate,gat.Business_Criticality,gat.status,gat.meetingdate,gat.type ,gat.sl,gat.RecentUpdate from mydb.gat where gat.status='open' and gat.Business_Criticality='high' and gat.Assigned_sapid=";
            public String QUERY_TO_FETCH_Assignactionstatus_open_DATAmedium="select gat.raid, gat.category, gat.Shortdesc,gat.ownername,gat.ownersap,gat.targetclosuredate,gat.Business_Criticality,gat.status,gat.meetingdate,gat.type ,gat.sl,gat.RecentUpdate  from mydb.gat where gat.status='open' and gat.Business_Criticality='medium' and gat.Assigned_sapid=";
            public String QUERY_TO_FETCH_Assignactionstatus_open_DATAlow="select gat.raid, gat.category, gat.Shortdesc,gat.ownername,gat.ownersap,gat.targetclosuredate,gat.Business_Criticality,gat.status,gat.meetingdate,gat.type ,gat.sl,gat.RecentUpdate  from mydb.gat where gat.status='open' and gat.Business_Criticality='low' and gat.Assigned_sapid=";
            
            public String QUERY_TO_FETCH_Assignactionstatus_close_DATA="select gat.raid, gat.category, gat.Shortdesc,gat.ownername,gat.ownersap,gat.targetclosuredate,gat.Business_Criticality,gat.status,gat.meetingdate,gat.type,gat.sl,gat.RecentUpdate  from mydb.gat where gat.status='close' and gat.Business_Criticality='high'  and gat.Assigned_sapid=";
            public String QUERY_TO_FETCH_Assignactionstatus_close_DATAmedium="select gat.raid, gat.category, gat.Shortdesc,gat.ownername,gat.ownersap,gat.targetclosuredate,gat.Business_Criticality,gat.status,gat.meetingdate,gat.type ,gat.sl,gat.RecentUpdate  from mydb.gat where gat.status='close' and gat.Business_Criticality='medium' and gat.Assigned_sapid=";
            public String QUERY_TO_FETCH_Assignactionstatus_close_DATAlow="select gat.raid, gat.category, gat.Shortdesc,gat.ownername,gat.ownersap,gat.targetclosuredate,gat.Business_Criticality,gat.status,gat.meetingdate,gat.type ,gat.sl,gat.RecentUpdate  from mydb.gat where gat.status='close' and gat.Business_Criticality='low' and gat.Assigned_sapid=";
            
            public String QUERY_TO_FETCH_Assignactionstatus_overdue_DATA="select gat.raid, gat.category, gat.Shortdesc,gat.ownername,gat.ownersap,gat.targetclosuredate,gat.Business_Criticality,gat.status,gat.meetingdate,gat.type,gat.sl,gat.RecentUpdate  from mydb.gat where gat.status='overdue' and gat.Business_Criticality='high'  and gat.Assigned_sapid=";
            public String QUERY_TO_FETCH_Assignactionstatus_overdue_DATAmedium="select gat.raid, gat.category, gat.Shortdesc,gat.ownername,gat.ownersap,gat.targetclosuredate,gat.Business_Criticality,gat.status,gat.meetingdate,gat.type ,gat.sl,gat.RecentUpdate  from mydb.gat where gat.status='overdue' and gat.Business_Criticality='medium' and gat.Assigned_sapid=";
            public String QUERY_TO_FETCH_Assignactionstatus_overdue_DATAlow="select gat.raid, gat.category, gat.Shortdesc,gat.ownername,gat.ownersap,gat.targetclosuredate,gat.Business_Criticality,gat.status,gat.meetingdate,gat.type ,gat.sl,gat.RecentUpdate  from mydb.gat where gat.status='overdue' and gat.Business_Criticality='low' and gat.Assigned_sapid=";
            
            public String QUERY_TO_FETCH_Assignactionstatus_ontrack_DATA="select gat.raid, gat.category, gat.Shortdesc,gat.ownername,gat.ownersap,gat.targetclosuredate,gat.Business_Criticality,gat.status,gat.meetingdate,gat.type,gat.sl,gat.RecentUpdate  from mydb.gat where gat.status='on-track' and gat.Business_Criticality='high'  and gat.Assigned_sapid=";
            public String QUERY_TO_FETCH_Assignactionstatus_ontrack_DATAmedium="select gat.raid, gat.category, gat.Shortdesc,gat.ownername,gat.ownersap,gat.targetclosuredate,gat.Business_Criticality,gat.status,gat.meetingdate,gat.type ,gat.sl,gat.RecentUpdate  from mydb.gat where gat.status='on-track' and gat.Business_Criticality='medium' and gat.Assigned_sapid=";
            public String QUERY_TO_FETCH_Assignactionstatus_ontrack_DATAlow="select gat.raid, gat.category, gat.Shortdesc,gat.ownername,gat.ownersap,gat.targetclosuredate,gat.Business_Criticality,gat.status,gat.meetingdate,gat.type ,gat.sl,gat.RecentUpdate  from mydb.gat where gat.status='on-track' and gat.Business_Criticality='low' and gat.Assigned_sapid=";
            
            public String QUERY_TO_FETCH_Assignactionstatus_assigned_DATA="select gat.raid, gat.category, gat.Shortdesc,gat.ownername,gat.ownersap,gat.targetclosuredate,gat.Business_Criticality,gat.status,gat.meetingdate,gat.type,gat.sl,gat.RecentUpdate from mydb.gat where gat.status='assigned' and gat.Business_Criticality='high'  and gat.Assigned_sapid=";
            public String QUERY_TO_FETCH_Assignactionstatus_assigned_DATAmedium="select gat.raid, gat.category, gat.Shortdesc,gat.ownername,gat.ownersap,gat.targetclosuredate,gat.Business_Criticality,gat.status,gat.meetingdate,gat.type ,gat.sl,gat.RecentUpdate  from mydb.gat where gat.status='assigned' and gat.Business_Criticality='medium' and gat.Assigned_sapid=";
            public String QUERY_TO_FETCH_Assignactionstatus_assigned_DATAlow="select gat.raid, gat.category, gat.Shortdesc,gat.ownername,gat.ownersap,gat.targetclosuredate,gat.Business_Criticality,gat.status,gat.meetingdate,gat.type ,gat.sl,gat.RecentUpdate  from mydb.gat where gat.status='assigned' and gat.Business_Criticality='low' and gat.Assigned_sapid=";
            
            public String QUERY_TO_FETCH_Assignactionstatus_unassigned_DATA="select gat.raid, gat.category, gat.Shortdesc,gat.ownername,gat.ownersap,gat.targetclosuredate,gat.Business_Criticality,gat.status,gat.meetingdate,gat.type,gat.sl,gat.RecentUpdate  from mydb.gat where gat.status='unassigned' and gat.Business_Criticality='high'  and gat.Assigned_sapid=";
            public String QUERY_TO_FETCH_Assignactionstatus_unassigned_DATAmedium="select gat.raid, gat.category, gat.Shortdesc,gat.ownername,gat.ownersap,gat.targetclosuredate,gat.Business_Criticality,gat.status,gat.meetingdate,gat.type ,gat.sl,gat.RecentUpdate  from mydb.gat where gat.status='unassigned' and gat.Business_Criticality='medium' and gat.Assigned_sapid=";
            public String QUERY_TO_FETCH_Assignactionstatus_unassigned_DATAlow="select gat.raid, gat.category, gat.Shortdesc,gat.ownername,gat.ownersap,gat.targetclosuredate,gat.Business_Criticality,gat.status,gat.meetingdate,gat.type ,gat.sl,gat.RecentUpdate  from mydb.gat where gat.status='unassigned' and gat.Business_Criticality='low' and gat.Assigned_sapid=";
            

			public String QUERY_TO_FETCH_AutoComplete_loginname="SELECT * FROM mydb.login  WHERE NAME  LIKE ?";

			public String QUERY_TO_GET_employeesapid_foraddaction_usingempname="select SAPCODE from mydb.login where NAME='";
			public String QUERY_TO_GET_employeemailid_foraddaction_usingempname="select Hcl_Mail_Id from mydb.login where NAME='";

			public String QUERY_TO_GET_employeetotalActions_foraddaction_usingsapcode="SELECT count(gat.Assigned_hrs) FROM mydb.gat where   gat.Assigned_hrs !=0 and gat.ownername='";
			public String QUERY_TO_GET_employeetotalhours_foraddaction_usingsapcode="SELECT sum(gat.Assigned_hrs) FROM mydb.gat where  gat.Assigned_hrs !=0 and gat.ownername='";
			public String QUERY_TO_ActionID="select coalesce(max(gat.ActionID),0)+1 as ActionID from mydb.gat" ;
}

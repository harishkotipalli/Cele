package com.hcl.pmoautomation.AddAction.dao;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hcl.pmoautomation.AddAction.vo.ActionAdd;
import com.hcl.pmoautomation.AddAction.vo.statusVO;
import com.hcl.pmoautomation.sk.dao.DatabaseQuery;
import com.hcl.pmoautomation.sk.vo.skillSearch;
import com.mysql.jdbc.Statement;


public class AddActiondao implements addActionInterface 
{
	
	public List<ActionAdd> list(String raid, String cat,String status, Date  date, int actType, String actionVal, int sapid,JdbcTemplate jdbcTemplate) 
	{
		//int it=(int)session.getAttribute("managerId");
	
			String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_GAT_Search1+"'"+raid+"'"+DataBaseQueryForAddAction.QUERY_TO_FETCH_GAT_Search5+sapid;
		
			if (!status.equalsIgnoreCase("select"))
			{
				sql +=DataBaseQueryForAddAction.QUERY_TO_FETCH_GAT_Search3+"'"+status+"'";
			
			}
		if (!cat.equalsIgnoreCase("select"))
		{
			sql +=DataBaseQueryForAddAction.QUERY_TO_FETCH_GAT_Search2+"'"+cat+"'";
			
		}
		
		if (!(date==null))
		{
			sql +=DataBaseQueryForAddAction.QUERY_TO_FETCH_GAT_Search4+"'"+date+"'";
			
		}
		

		if (actionVal != null){
			sql +=DataBaseQueryForAddAction.QUERY_TO_FETCH_GAT_Search6 + "'" + actionVal + "')";
		}
		
			   
	    		 List<ActionAdd> listaa = jdbcTemplate.query(sql, new RowMapper<ActionAdd>() 
	
	    				 {
			@Override
			public ActionAdd mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				ActionAdd aa = new ActionAdd();
				
				aa.setRaid(rs.getString("raid"));
				aa.setCategory(rs.getString("category"));
				aa.setStatus(rs.getString("status"));
				aa.setMeetingDate(rs.getDate("meetingdate"));
				aa.setType(rs.getString("type"));
				aa.setShortDesc(rs.getString("shortDesc"));
				aa.setSl(rs.getInt("sl"));
					
				
				return aa;
			}
	 
			
			
			
			
			
			
	    });//---------------new Object[]{year, month});
	    		
	    		
	    return listaa;
	    
	  
	    
		
	
		
		
	}
	public List<ActionAdd> edit(String raid, String cat,String status,String type, String sl, JdbcTemplate jdbcTemplate) 
	{
		String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_SkillSearch_GETedit+"'"+raid+"'"+
					DataBaseQueryForAddAction.QUERY_TO_FETCH_SkillSearch_GETedit2+"'"+cat+"'"+                                                                
					DataBaseQueryForAddAction.QUERY_TO_FETCH_SkillSearch_GETedit3+"'"+status+"'"+ 
					DataBaseQueryForAddAction.QUERY_TO_FETCH_SkillSearch_GETedit4+"'"+type+"'"+
		            DataBaseQueryForAddAction.QUERY_TO_FETCH_SkillSearch_GETedit5+"'"+sl+"'";
		
	System.out.println("addactioneditquery------------"+sql);
		
		
	    		 List<ActionAdd> listaa = jdbcTemplate.query(sql, new RowMapper<ActionAdd>() 
	
	    				 {
			@Override
			public ActionAdd mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				ActionAdd aa = new ActionAdd();
				
				aa.setMeeting(rs.getString("meeting_adhoc"));
				aa.setCategory(rs.getString("category"));
				aa.setRaid(rs.getString("raid"));
				aa.setDescription(rs.getString("description"));
				aa.setBussinesscriticality(rs.getString("Business_Criticality"));
				aa.setStatus(rs.getString("status"));
				aa.setTracksclusters(rs.getString("tracks_clustures"));
												  
				aa.setOwnerName(rs.getString("ownerName"));
				aa.setOwnerSap(rs.getInt("ownerSap"));
				aa.setOwnerMail(rs.getString("OwnerMail"));
				aa.setMeetingDate(rs.getDate("meetingDate"));
				aa.setTargetCloseDate(rs.getDate("targetclosuredate"));
				aa.setRe_baselineDate(rs.getDate("re_baselineDate"));
				aa.setActualClosureDate(rs.getDate("actualClosureDate"));
				aa.setStatusUpdate(rs.getString("Status_Update"));
				aa.setType(rs.getString("type"));
				aa.setShortDesc(rs.getString("shortDesc"));
				aa.setRemarks(rs.getString("remarks"));
				aa.setSl(rs.getInt("sl"));
				aa.setRecentUpdate(rs.getString("RecentUpdate"));
				
				
				
				
				return aa;
			}
	 
			
			
			
			
			
			
	    });//---------------new Object[]{year, month});
	    		
	    		
	    return listaa;
	    
	  
	    
		
	
		
		
	}
	
	
	
	public List<ActionAdd> update(String desc,String sta,String on,int i,String om,	String 	tcd,String 	rd, String 	ac,	String 	rem,String 	su,int slno, JdbcTemplate jdbcTemplate) 
	{
		
		Statement stmt = null;
		String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_SkillSearch_GETupdate+"'"+desc+"'"+
				DataBaseQueryForAddAction.QUERY_TO_FETCH_SkillSearch_GETupdate1+"'"+sta+"'"+
				DataBaseQueryForAddAction.QUERY_TO_FETCH_SkillSearch_GETupdate2+"'"+on+"'"+
				DataBaseQueryForAddAction.QUERY_TO_FETCH_SkillSearch_GETupdate3+i+
				DataBaseQueryForAddAction.QUERY_TO_FETCH_SkillSearch_GETupdate4+"'"+om+"'"+
				DataBaseQueryForAddAction.QUERY_TO_FETCH_SkillSearch_GETupdate5+"'"+tcd+"'"+
				DataBaseQueryForAddAction.QUERY_TO_FETCH_SkillSearch_GETupdate6+"'"+rd+"'"+
				DataBaseQueryForAddAction.QUERY_TO_FETCH_SkillSearch_GETupdate7+"'"+ac+"'"+
				DataBaseQueryForAddAction.QUERY_TO_FETCH_SkillSearch_GETupdate8+"'"+rem+"'"+
				DataBaseQueryForAddAction.QUERY_TO_FETCH_SkillSearch_GETupdate9+"'"+su+"'"+
				DataBaseQueryForAddAction.QUERY_TO_FETCH_SkillSearch_GETupdate10+slno;
				
	
	
		
	    		 List<ActionAdd> listaa = jdbcTemplate.query(sql, new RowMapper<ActionAdd>()
	
	    				 {
			@Override
			public ActionAdd mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				ActionAdd aa = new ActionAdd();
				
				aa.setMeeting(rs.getString("meeting_adhoc"));
				aa.setCategory(rs.getString("category"));
				aa.setRaid(rs.getString("raid"));
				aa.setShortDesc(rs.getString("shortDesc"));
				aa.setDescription(rs.getString("description"));
				aa.setStatus(rs.getString("status"));
				aa.setTracksclusters(rs.getString("tracks_clustures"));
												  
				aa.setOwnerName(rs.getString("ownerName"));
				aa.setOwnerSap(rs.getInt("ownerSap"));
				aa.setOwnerMail(rs.getString("OwnerMail"));
				aa.setMeetingDate(rs.getDate("meetingDate"));
				aa.setTargetCloseDate(rs.getDate("targetclosuredate"));
				aa.setRe_baselineDate(rs.getDate("re_baselineDate"));
				aa.setActualClosureDate(rs.getDate("actualClosureDate"));
				aa.setStatusUpdate(rs.getString("Status_Update"));
				aa.setType(rs.getString("type"));
				
				aa.setRemarks(rs.getString("remarks"));
				aa.setSl(rs.getInt("sl"));
				aa.setRecentUpdate(rs.getString("RecentUpdate"));
				
				
				
				//rs = stmt.executeQuery(sql);
				
				
				return aa;
			}
	 
			
			
			
			
			
			
	    });//---------------new Object[]{year, month});
	    		
	    		
	    return listaa;
	    
	  
	    
		
	
		
		
	}
	public List<ActionAdd> ADDAction(String meeting_adhoc,String category,
	String raid,
	String Shortdesc,
	String description,
	String status,
	 String tracksclusters,
	 String ownerName,
	 int ownerSap,
	 String ownerMail,
	 Date meetingDate,
	 Date targetCloseDate,
	 Date re_baselineDate,
	 Date actualClosureDate,
	 String remarks,
	 String statusUpdate,
	 int sl,
	 String type,
	 String recentUpdate,
			JdbcTemplate jdbcTemplate) 
	{
		
		
		String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_SkillSearch_GETupdate+"'"+meeting_adhoc+"'"+"'"+category+"'"+"'"+"'"+raid+"'"+"'"+Shortdesc+"'"+"'"+description+"'"+"'"+status+"'"+"'"+ownerSap+"'"+"'"+meetingDate+"'"+"'"+remarks+"'";
		
				
		
	
		
	    		 List<ActionAdd> listaa = jdbcTemplate.query(sql, new RowMapper<ActionAdd>()
	
	    				 {
			@Override
			public ActionAdd mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				ActionAdd aa = new ActionAdd();
				
				aa.setMeeting(rs.getString("meeting_adhoc"));
				aa.setCategory(rs.getString("category"));
				aa.setRaid(rs.getString("raid"));
				aa.setShortDesc(rs.getString("shortDesc"));
				aa.setDescription(rs.getString("description"));
				aa.setStatus(rs.getString("status"));
				aa.setTracksclusters(rs.getString("tracks_clustures"));
												  
				aa.setOwnerName(rs.getString("ownerName"));
				aa.setOwnerSap(rs.getInt("ownerSap"));
				aa.setOwnerMail(rs.getString("OwnerMail"));
				aa.setMeetingDate(rs.getDate("meetingDate"));
				aa.setTargetCloseDate(rs.getDate("targetclosuredate"));
				aa.setRe_baselineDate(rs.getDate("re_baselineDate"));
				aa.setActualClosureDate(rs.getDate("actualClosureDate"));
				aa.setStatusUpdate(rs.getString("Status_Update"));
				aa.setType(rs.getString("type"));
				
				aa.setRemarks(rs.getString("remarks"));
				aa.setSl(rs.getInt("sl"));
				aa.setRecentUpdate(rs.getString("RecentUpdate"));
				
				
				
				//rs = stmt.executeQuery(sql);
				
				
				return aa;
			}
	 
			
			
			
			
			
			
	    });//---------------new Object[]{year, month});
	    		
	    		
	    return listaa;
	    
	  
	    
		
	
		
		
	}
	public List<statusVO> actionStatusopen(int sapid, JdbcTemplate jdbcTemplate) 
	{
		String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_actionstatus_open+sapid;
		System.out.println("query for action status "+sql);
	 List<statusVO> listaa = jdbcTemplate.query(sql, new RowMapper<statusVO>() 
				 {
			@Override
			public statusVO mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				statusVO dashboardopen = new statusVO();
			
				dashboardopen.setCountopen(rs.getString("count(1)"));
			
				return dashboardopen;
			}
	 			  	
	    });//---------------new Object[]{year, month});
	   
		 return listaa;
	}
	public List<statusVO> actionStatusopenmedium(int sapid, JdbcTemplate jdbcTemplate) 
	{
		String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_actionstatus_openmedium+sapid;
	 List<statusVO> listaa = jdbcTemplate.query(sql, new RowMapper<statusVO>() 
				 {
			@Override
			public statusVO mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				statusVO dashboardopenmedium = new statusVO();
			
				dashboardopenmedium.setCountopenmedium(rs.getString("count(7)"));
			
				return dashboardopenmedium;
			}
	 			  	
	    });//---------------new Object[]{year, month});
	   
		 return listaa;
	}
	public List<statusVO> actionStatusopenlow(int sapid, JdbcTemplate jdbcTemplate) 
	{
		String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_actionstatus_openlow+sapid;
	 List<statusVO> listaa = jdbcTemplate.query(sql, new RowMapper<statusVO>() 
				 {
			@Override
			public statusVO mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				statusVO dashboardopenlow = new statusVO();
			
				dashboardopenlow.setCountopenlow(rs.getString("count(8)"));
			
				return dashboardopenlow;
			}
	 			  	
	    });//---------------new Object[]{year, month});
	   
		 return listaa;
	}
	public List<statusVO> actionStatusclose(int sapid, JdbcTemplate jdbcTemplate) 
	{
		String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_actionstatus_close+sapid;
	 List<statusVO> listaa = jdbcTemplate.query(sql, new RowMapper<statusVO>() 
				 {
			@Override
			public statusVO mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				statusVO dashboardclose = new statusVO();
			
				dashboardclose.setCountclose(rs.getString("count(2)"));
			
				return dashboardclose;
			}
	 			  	
	    });//---------------new Object[]{year, month});
	   
		 return listaa;
	}
	public List<statusVO> actionStatusclosemedium(int sapid, JdbcTemplate jdbcTemplate) 
	{
		String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_actionstatus_closemedium+sapid;
	 List<statusVO> listaa = jdbcTemplate.query(sql, new RowMapper<statusVO>() 
				 {
			@Override
			public statusVO mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				statusVO dashboardclosemedium = new statusVO();
			
				dashboardclosemedium.setCountclosemedium(rs.getString("count(11)"));
			
				return dashboardclosemedium;
			}
	 			  	
	    });//---------------new Object[]{year, month});
	   
		 return listaa;
	}
	public List<statusVO> actionStatuscloselow(int sapid, JdbcTemplate jdbcTemplate) 
	{
		String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_actionstatus_closelow+sapid;
	 List<statusVO> listaa = jdbcTemplate.query(sql, new RowMapper<statusVO>() 
				 {
			@Override
			public statusVO mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				statusVO dashboardcloselow = new statusVO();
			
				dashboardcloselow.setCountcloselow(rs.getString("count(12)"));
			
				return dashboardcloselow;
			}
	 			  	
	    });//---------------new Object[]{year, month});
	   
		 return listaa;
	}
	public List<statusVO> actionStatusoverdue(int sapid, JdbcTemplate jdbcTemplate) 
	{
		String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_actionstatus_overdue+sapid;
	 List<statusVO> listaa = jdbcTemplate.query(sql, new RowMapper<statusVO>() 
				 {
			@Override
			public statusVO mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				statusVO dashboardoverdue = new statusVO();
			
				dashboardoverdue.setCountoverdue(rs.getString("count(3)"));
			
				return dashboardoverdue;
			}
	 			  	
	    });//---------------new Object[]{year, month});
	   
		 return listaa;
	}
	public List<statusVO> actionStatusoverduemedium(int sapid, JdbcTemplate jdbcTemplate) 
	{
		String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_actionstatus_overduemedium+sapid;
	 List<statusVO> listaa = jdbcTemplate.query(sql, new RowMapper<statusVO>() 
				 {
			@Override
			public statusVO mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				statusVO dashboardoverduemedium = new statusVO();
			
				dashboardoverduemedium.setCountoverduemedium(rs.getString("count(9)"));
			
				return dashboardoverduemedium;
			}
	 			  	
	    });//---------------new Object[]{year, month});
	   
		 return listaa;
	}
	public List<statusVO> actionStatusoverduelow(int sapid, JdbcTemplate jdbcTemplate) 
	{
		String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_actionstatus_overduelow+sapid;
	 List<statusVO> listaa = jdbcTemplate.query(sql, new RowMapper<statusVO>() 
				 {
			@Override
			public statusVO mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				statusVO dashboardoverduelow = new statusVO();
			
				dashboardoverduelow.setCountoverduelow(rs.getString("count(10)"));
			
				return dashboardoverduelow;
			}
	 			  	
	    });//---------------new Object[]{year, month});
	   
		 return listaa;
	}
	public List<statusVO> actionStatusontrack(int sapid, JdbcTemplate jdbcTemplate) 
	{
		String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_actionstatus_ontrack+sapid;
	 List<statusVO> listaa = jdbcTemplate.query(sql, new RowMapper<statusVO>() 
				 {
			@Override
			public statusVO mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				statusVO dashboardontrack = new statusVO();
			
				dashboardontrack.setCountontrack(rs.getString("count(4)"));
			
				return dashboardontrack;
			}
	 			  	
	    });//---------------new Object[]{year, month});
	   
		 return listaa;
	}
	public List<statusVO> actionStatusontrackmedium(int sapid, JdbcTemplate jdbcTemplate) 
	{
		String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_actionstatus_ontrackmedium+sapid;
	 List<statusVO> listaa = jdbcTemplate.query(sql, new RowMapper<statusVO>() 
				 {
			@Override
			public statusVO mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				statusVO dashboardontrackmedium = new statusVO();
			
				dashboardontrackmedium.setCountontrackmedium(rs.getString("count(13)"));
			
				return dashboardontrackmedium;
			}
	 			  	
	    });//---------------new Object[]{year, month});
	   
		 return listaa;
	}
	public List<statusVO> actionStatusontracklow(int sapid, JdbcTemplate jdbcTemplate) 
	{
		String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_actionstatus_ontracklow+sapid;
	 List<statusVO> listaa = jdbcTemplate.query(sql, new RowMapper<statusVO>() 
				 {
			@Override
			public statusVO mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				statusVO dashboardontracklow = new statusVO();
			
				dashboardontracklow.setCountontracklow(rs.getString("count(14)"));
			
				return dashboardontracklow;
			}
	 			  	
	    });//---------------new Object[]{year, month});
	   
		 return listaa;
	}
	public List<statusVO> actionStatusassigned(int sapid, JdbcTemplate jdbcTemplate) 
	{
		String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_actionstatus_assigned+sapid;
	 List<statusVO> listaa = jdbcTemplate.query(sql, new RowMapper<statusVO>() 
				 {
			@Override
			public statusVO mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				statusVO dashboardassigned = new statusVO();
			
				dashboardassigned.setCountassigned(rs.getString("count(5)"));
			
				return dashboardassigned;
			}
	 			  	
	    });//---------------new Object[]{year, month});
	   
		 return listaa;
	}
	public List<statusVO> actionStatusassignedmedium(int sapid, JdbcTemplate jdbcTemplate) 
	{
		String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_actionstatus_assignedmedium+sapid;
	 List<statusVO> listaa = jdbcTemplate.query(sql, new RowMapper<statusVO>() 
				 {
			@Override
			public statusVO mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				statusVO dashboardassignedmedium = new statusVO();
			
				dashboardassignedmedium.setCountassignedmedium(rs.getString("count(15)"));
			
				return dashboardassignedmedium;
			}
	 			  	
	    });//---------------new Object[]{year, month});
	   
		 return listaa;
	}
	public List<statusVO> actionStatusassignedlow(int sapid, JdbcTemplate jdbcTemplate) 
	{
		String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_actionstatus_assignedlow+sapid;
	 List<statusVO> listaa = jdbcTemplate.query(sql, new RowMapper<statusVO>() 
				 {
			@Override
			public statusVO mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				statusVO dashboardassignedlow = new statusVO();
			
				dashboardassignedlow.setCountassignedlow(rs.getString("count(16)"));
			
				return dashboardassignedlow;
			}
	 			  	
	    });//---------------new Object[]{year, month});
	   
		 return listaa;
	}
	public List<statusVO> actionStatusunassigned(int sapid, JdbcTemplate jdbcTemplate) 
	{
		String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_actionstatus_unassigned+sapid;
	 List<statusVO> listaa = jdbcTemplate.query(sql, new RowMapper<statusVO>() 
				 {
			@Override
			public statusVO mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				statusVO dashboardunassigned = new statusVO();
			
				dashboardunassigned.setCountunassigned(rs.getString("count(6)"));
			
				return dashboardunassigned;
			}
	 			  	
	    });//---------------new Object[]{year, month});
	   
		 return listaa;
	}
	public List<statusVO> actionStatusunassignedmedium(int sapid, JdbcTemplate jdbcTemplate) 
	{
		String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_actionstatus_unassignedmedium+sapid;
	 List<statusVO> listaa = jdbcTemplate.query(sql, new RowMapper<statusVO>() 
				 {
			@Override
			public statusVO mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				statusVO dashboardunassignedmedium = new statusVO();
			
				dashboardunassignedmedium.setCountunassignedmedium(rs.getString("count(17)"));
			
				return dashboardunassignedmedium;
			}
	 			  	
	    });//---------------new Object[]{year, month});
	   
		 return listaa;
	}
	public List<statusVO> actionStatusunassignedlow(int sapid, JdbcTemplate jdbcTemplate) 
	{
		String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_actionstatus_unassignedlow+sapid;
	 List<statusVO> listaa = jdbcTemplate.query(sql, new RowMapper<statusVO>() 
				 {
			@Override
			public statusVO mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				statusVO dashboardunassignedlow = new statusVO();
			
				dashboardunassignedlow.setCountunassignedlow(rs.getString("count(18)"));
			
				return dashboardunassignedlow;
			}
	 			  	
	    });//---------------new Object[]{year, month});
	   
		 return listaa;
	}
	
	public List<ActionAdd> StatusOPEN( int sapid,JdbcTemplate jdbcTemplate) 
	{
		//int it=(int)session.getAttribute("managerId");
	
			String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_actionstatus_open_DATA+sapid;
		

		
			   
	    		 List<ActionAdd> listaa = jdbcTemplate.query(sql, new RowMapper<ActionAdd>() 
	
	    				 {
			@Override
			public ActionAdd mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				ActionAdd aa = new ActionAdd();
				
				aa.setRaid(rs.getString("raid"));
				aa.setCategory(rs.getString("category"));
				aa.setStatus(rs.getString("status"));
				aa.setMeetingDate(rs.getDate("meetingdate"));
				aa.setType(rs.getString("type"));
				aa.setShortDesc(rs.getString("shortDesc"));
				aa.setSl(rs.getInt("sl"));
					
				
				return aa;
			}
	 
			
			
			
			
			
			
	    });//---------------new Object[]{year, month});
	    		
	    		
	    return listaa;
	    
	  
	    
		
	
		
		
	}
	public List<ActionAdd> StatusOPENmedium( int sapid,JdbcTemplate jdbcTemplate) 
	{
		//int it=(int)session.getAttribute("managerId");
	
			String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_actionstatus_open_DATAmedium+sapid;
		

		
			   
	    		 List<ActionAdd> listaa = jdbcTemplate.query(sql, new RowMapper<ActionAdd>() 
	
	    				 {
			@Override
			public ActionAdd mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				ActionAdd aa = new ActionAdd();
				
				aa.setRaid(rs.getString("raid"));
				aa.setCategory(rs.getString("category"));
				aa.setStatus(rs.getString("status"));
				aa.setMeetingDate(rs.getDate("meetingdate"));
				aa.setType(rs.getString("type"));
				aa.setShortDesc(rs.getString("shortDesc"));
				aa.setSl(rs.getInt("sl"));
					
				
				return aa;
			}
	 
			
			
			
			
			
			
	    });//---------------new Object[]{year, month});
	    		
	    		
	    return listaa;
	    
	  
	    
		
	
		
		
	}
	public List<ActionAdd> StatusOPENlow( int sapid,JdbcTemplate jdbcTemplate) 
	{
		//int it=(int)session.getAttribute("managerId");
	
			String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_actionstatus_open_DATAlow+sapid;
		

		
			   
	    		 List<ActionAdd> listaa = jdbcTemplate.query(sql, new RowMapper<ActionAdd>() 
	
	    				 {
			@Override
			public ActionAdd mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				ActionAdd aa = new ActionAdd();
				
				aa.setRaid(rs.getString("raid"));
				aa.setCategory(rs.getString("category"));
				aa.setStatus(rs.getString("status"));
				aa.setMeetingDate(rs.getDate("meetingdate"));
				aa.setType(rs.getString("type"));
				aa.setShortDesc(rs.getString("shortDesc"));
				aa.setSl(rs.getInt("sl"));
					
				
				return aa;
			}
	 
			
			
			
			
			
			
	    });//---------------new Object[]{year, month});
	    		
	    		
	    return listaa;
	    
	  
	    
		
	
		
		
	}
	public List<ActionAdd> StatusClose( int sapid,JdbcTemplate jdbcTemplate) 
	{
		//int it=(int)session.getAttribute("managerId");
	
			String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_actionstatus_close_DATA+sapid;
		

		
			   
	    		 List<ActionAdd> listaa = jdbcTemplate.query(sql, new RowMapper<ActionAdd>() 
	
	    				 {
			@Override
			public ActionAdd mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				ActionAdd aa = new ActionAdd();
				
				aa.setRaid(rs.getString("raid"));
				aa.setCategory(rs.getString("category"));
				aa.setStatus(rs.getString("status"));
				aa.setMeetingDate(rs.getDate("meetingdate"));
				aa.setType(rs.getString("type"));
				aa.setShortDesc(rs.getString("shortDesc"));
				aa.setSl(rs.getInt("sl"));
					
				
				return aa;
			}
	 
			
			
			
			
			
			
	    });//---------------new Object[]{year, month});
	    		
	    		
	    return listaa;
	    
	  
	    
		
	
		
		
	}
	public List<ActionAdd> StatusClosemedium( int sapid,JdbcTemplate jdbcTemplate) 
	{
		//int it=(int)session.getAttribute("managerId");
	
			String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_actionstatus_close_DATAmedium+sapid;
		

		
			   
	    		 List<ActionAdd> listaa = jdbcTemplate.query(sql, new RowMapper<ActionAdd>() 
	
	    				 {
			@Override
			public ActionAdd mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				ActionAdd aa = new ActionAdd();
				
				aa.setRaid(rs.getString("raid"));
				aa.setCategory(rs.getString("category"));
				aa.setStatus(rs.getString("status"));
				aa.setMeetingDate(rs.getDate("meetingdate"));
				aa.setType(rs.getString("type"));
				aa.setShortDesc(rs.getString("shortDesc"));
				aa.setSl(rs.getInt("sl"));
					
				
				return aa;
			}
	 
			
			
			
			
			
			
	    });//---------------new Object[]{year, month});
	    		
	    		
	    return listaa;
	    
	  
	    
		
	
		
		
	}
	public List<ActionAdd> StatusCloselow( int sapid,JdbcTemplate jdbcTemplate) 
	{
		//int it=(int)session.getAttribute("managerId");
	
			String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_actionstatus_close_DATAlow+sapid;
		

		
			   
	    		 List<ActionAdd> listaa = jdbcTemplate.query(sql, new RowMapper<ActionAdd>() 
	
	    				 {
			@Override
			public ActionAdd mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				ActionAdd aa = new ActionAdd();
				
				aa.setRaid(rs.getString("raid"));
				aa.setCategory(rs.getString("category"));
				aa.setStatus(rs.getString("status"));
				aa.setMeetingDate(rs.getDate("meetingdate"));
				aa.setType(rs.getString("type"));
				aa.setShortDesc(rs.getString("shortDesc"));
				aa.setSl(rs.getInt("sl"));
					
				
				return aa;
			}
	 
			
			
			
			
			
			
	    });//---------------new Object[]{year, month});
	    		
	    		
	    return listaa;
	    
	  
	    
		
	
		
		
	}
	public List<ActionAdd> Statusoverdue( int sapid,JdbcTemplate jdbcTemplate) 
	{
		//int it=(int)session.getAttribute("managerId");
	
			String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_actionstatus_overdue_DATA+sapid;
		

		
			   
	    		 List<ActionAdd> listaa = jdbcTemplate.query(sql, new RowMapper<ActionAdd>() 
	
	    				 {
			@Override
			public ActionAdd mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				ActionAdd aa = new ActionAdd();
				
				aa.setRaid(rs.getString("raid"));
				aa.setCategory(rs.getString("category"));
				aa.setStatus(rs.getString("status"));
				aa.setMeetingDate(rs.getDate("meetingdate"));
				aa.setType(rs.getString("type"));
				aa.setShortDesc(rs.getString("shortDesc"));
				aa.setSl(rs.getInt("sl"));
					
				
				return aa;
			}
	 
			
			
			
			
			
			
	    });//---------------new Object[]{year, month});
	    		
	    		
	    return listaa;
	    
	  
	    
		
	
		
		
	}
	public List<ActionAdd> Statusoverduemedium( int sapid,JdbcTemplate jdbcTemplate) 
	{
		//int it=(int)session.getAttribute("managerId");
	
			String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_actionstatus_overdue_DATAmedium+sapid;
		

		
			   
	    		 List<ActionAdd> listaa = jdbcTemplate.query(sql, new RowMapper<ActionAdd>() 
	
	    				 {
			@Override
			public ActionAdd mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				ActionAdd aa = new ActionAdd();
				
				aa.setRaid(rs.getString("raid"));
				aa.setCategory(rs.getString("category"));
				aa.setStatus(rs.getString("status"));
				aa.setMeetingDate(rs.getDate("meetingdate"));
				aa.setType(rs.getString("type"));
				aa.setShortDesc(rs.getString("shortDesc"));
				aa.setSl(rs.getInt("sl"));
					
				
				return aa;
			}
	 
			
			
			
			
			
			
	    });//---------------new Object[]{year, month});
	    		
	    		
	    return listaa;
	    
	  
	    
		
	
		
		
	}
	public List<ActionAdd> Statusoverduelow( int sapid,JdbcTemplate jdbcTemplate) 
	{
		//int it=(int)session.getAttribute("managerId");
	
			String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_actionstatus_overdue_DATAlow+sapid;
		

		
			   
	    		 List<ActionAdd> listaa = jdbcTemplate.query(sql, new RowMapper<ActionAdd>() 
	
	    				 {
			@Override
			public ActionAdd mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				ActionAdd aa = new ActionAdd();
				
				aa.setRaid(rs.getString("raid"));
				aa.setCategory(rs.getString("category"));
				aa.setStatus(rs.getString("status"));
				aa.setMeetingDate(rs.getDate("meetingdate"));
				aa.setType(rs.getString("type"));
				aa.setShortDesc(rs.getString("shortDesc"));
				aa.setSl(rs.getInt("sl"));
					
				
				return aa;
			}
	 
			
			
			
			
			
			
	    });//---------------new Object[]{year, month});
	    		
	    		
	    return listaa;
	    
	  
	    
		
	
		
		
	}
	public List<ActionAdd> Statusontrack( int sapid,JdbcTemplate jdbcTemplate) 
	{
		//int it=(int)session.getAttribute("managerId");
	
			String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_actionstatus_ontrack_DATA+sapid;
		

		
			   
	    		 List<ActionAdd> listaa = jdbcTemplate.query(sql, new RowMapper<ActionAdd>() 
	
	    				 {
			@Override
			public ActionAdd mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				ActionAdd aa = new ActionAdd();
				
				aa.setRaid(rs.getString("raid"));
				aa.setCategory(rs.getString("category"));
				aa.setStatus(rs.getString("status"));
				aa.setMeetingDate(rs.getDate("meetingdate"));
				aa.setType(rs.getString("type"));
				aa.setShortDesc(rs.getString("shortDesc"));
				aa.setSl(rs.getInt("sl"));
					
				
				return aa;
			}
	 
			
			
			
			
			
			
	    });//---------------new Object[]{year, month});
	    		
	    		
	    return listaa;
	    
	  
	    
		
	
		
		
	}
	public List<ActionAdd> Statusontrackmedium( int sapid,JdbcTemplate jdbcTemplate) 
	{
		//int it=(int)session.getAttribute("managerId");
	
			String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_actionstatus_ontrack_DATAmedium+sapid;
		

		
			   
	    		 List<ActionAdd> listaa = jdbcTemplate.query(sql, new RowMapper<ActionAdd>() 
	
	    				 {
			@Override
			public ActionAdd mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				ActionAdd aa = new ActionAdd();
				
				aa.setRaid(rs.getString("raid"));
				aa.setCategory(rs.getString("category"));
				aa.setStatus(rs.getString("status"));
				aa.setMeetingDate(rs.getDate("meetingdate"));
				aa.setType(rs.getString("type"));
				aa.setShortDesc(rs.getString("shortDesc"));
				aa.setSl(rs.getInt("sl"));
					
				
				return aa;
			}
	 
			
			
			
			
			
			
	    });//---------------new Object[]{year, month});
	    		
	    		
	    return listaa;
	    
	  
	    
		
	
		
		
	}
	public List<ActionAdd> Statusontracklow( int sapid,JdbcTemplate jdbcTemplate) 
	{
		//int it=(int)session.getAttribute("managerId");
	
			String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_actionstatus_ontrack_DATAlow+sapid;
		

		
			   
	    		 List<ActionAdd> listaa = jdbcTemplate.query(sql, new RowMapper<ActionAdd>() 
	
	    				 {
			@Override
			public ActionAdd mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				ActionAdd aa = new ActionAdd();
				
				aa.setRaid(rs.getString("raid"));
				aa.setCategory(rs.getString("category"));
				aa.setStatus(rs.getString("status"));
				aa.setMeetingDate(rs.getDate("meetingdate"));
				aa.setType(rs.getString("type"));
				aa.setShortDesc(rs.getString("shortDesc"));
				aa.setSl(rs.getInt("sl"));
					
				
				return aa;
			}
	 
			
			
			
			
			
			
	    });//---------------new Object[]{year, month});
	    		
	    		
	    return listaa;
	    
	  
	    
		
	
		
		
	}
	public List<ActionAdd> Statusassigned( int sapid,JdbcTemplate jdbcTemplate) 
	{
		//int it=(int)session.getAttribute("managerId");
	
			String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_actionstatus_assigned_DATA+sapid;
		

		
			   
	    		 List<ActionAdd> listaa = jdbcTemplate.query(sql, new RowMapper<ActionAdd>() 
	
	    				 {
			@Override
			public ActionAdd mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				ActionAdd aa = new ActionAdd();
				
				aa.setRaid(rs.getString("raid"));
				aa.setCategory(rs.getString("category"));
				aa.setStatus(rs.getString("status"));
				aa.setMeetingDate(rs.getDate("meetingdate"));
				aa.setType(rs.getString("type"));
				aa.setShortDesc(rs.getString("shortDesc"));
				aa.setSl(rs.getInt("sl"));
					
				
				return aa;
			}
	 
			
			
			
			
			
			
	    });//---------------new Object[]{year, month});
	    		
	    		
	    return listaa;
	    
	  
	    
		
	
		
		
	}
	public List<ActionAdd> Statusassignedmedium( int sapid,JdbcTemplate jdbcTemplate) 
	{
		//int it=(int)session.getAttribute("managerId");
	
			String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_actionstatus_assigned_DATAmedium+sapid;
		

		
			   
	    		 List<ActionAdd> listaa = jdbcTemplate.query(sql, new RowMapper<ActionAdd>() 
	
	    				 {
			@Override
			public ActionAdd mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				ActionAdd aa = new ActionAdd();
				
				aa.setRaid(rs.getString("raid"));
				aa.setCategory(rs.getString("category"));
				aa.setStatus(rs.getString("status"));
				aa.setMeetingDate(rs.getDate("meetingdate"));
				aa.setType(rs.getString("type"));
				aa.setShortDesc(rs.getString("shortDesc"));
				aa.setSl(rs.getInt("sl"));
					
				
				return aa;
			}
	 
			
			
			
			
			
			
	    });//---------------new Object[]{year, month});
	    		
	    		
	    return listaa;
	    
	  
	    
		
	
		
		
	}
	public List<ActionAdd> Statusassignedlow( int sapid,JdbcTemplate jdbcTemplate) 
	{
		//int it=(int)session.getAttribute("managerId");
	
			String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_actionstatus_assigned_DATAlow+sapid;
		

		
			   
	    		 List<ActionAdd> listaa = jdbcTemplate.query(sql, new RowMapper<ActionAdd>() 
	
	    				 {
			@Override
			public ActionAdd mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				ActionAdd aa = new ActionAdd();
				
				aa.setRaid(rs.getString("raid"));
				aa.setCategory(rs.getString("category"));
				aa.setStatus(rs.getString("status"));
				aa.setMeetingDate(rs.getDate("meetingdate"));
				aa.setType(rs.getString("type"));
				aa.setShortDesc(rs.getString("shortDesc"));
				aa.setSl(rs.getInt("sl"));
					
				
				return aa;
			}
	 
			
			
			
			
			
			
	    });//---------------new Object[]{year, month});
	    		
	    		
	    return listaa;
	    
	  
	    
		
	
		
		
	}
	public List<ActionAdd> Statusunassigned( int sapid,JdbcTemplate jdbcTemplate) 
	{
		//int it=(int)session.getAttribute("managerId");
	
			String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_actionstatus_unassigned_DATA+sapid;
		

		
			   
	    		 List<ActionAdd> listaa = jdbcTemplate.query(sql, new RowMapper<ActionAdd>() 
	
	    				 {
			@Override
			public ActionAdd mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				ActionAdd aa = new ActionAdd();
				
				aa.setRaid(rs.getString("raid"));
				aa.setCategory(rs.getString("category"));
				aa.setStatus(rs.getString("status"));
				aa.setMeetingDate(rs.getDate("meetingdate"));
				aa.setType(rs.getString("type"));
				aa.setShortDesc(rs.getString("shortDesc"));
				aa.setSl(rs.getInt("sl"));
					
				
				return aa;
			}
	 
			
			
			
			
			
			
	    });//---------------new Object[]{year, month});
	    		
	    		
	    return listaa;
	    
	  
	    
		
	
		
		
	}
	public List<ActionAdd> Statusunassignedmedium( int sapid,JdbcTemplate jdbcTemplate) 
	{
		//int it=(int)session.getAttribute("managerId");
	
			String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_actionstatus_unassigned_DATAmedium+sapid;
		

		
			   
	    		 List<ActionAdd> listaa = jdbcTemplate.query(sql, new RowMapper<ActionAdd>() 
	
	    				 {
			@Override
			public ActionAdd mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				ActionAdd aa = new ActionAdd();
				
				aa.setRaid(rs.getString("raid"));
				aa.setCategory(rs.getString("category"));
				aa.setStatus(rs.getString("status"));
				aa.setMeetingDate(rs.getDate("meetingdate"));
				aa.setType(rs.getString("type"));
				aa.setShortDesc(rs.getString("shortDesc"));
				aa.setSl(rs.getInt("sl"));
					
				
				return aa;
			}
	 
			
			
			
			
			
			
	    });//---------------new Object[]{year, month});
	    		
	    		
	    return listaa;
	    
	  
	    
		
	
		
		
	}
	public List<ActionAdd> Statusunassignedlow( int sapid,JdbcTemplate jdbcTemplate) 
	{
		//int it=(int)session.getAttribute("managerId");
	
			String sql = DataBaseQueryForAddAction.QUERY_TO_FETCH_actionstatus_unassigned_DATAlow+sapid;
		

		
			   
	    		 List<ActionAdd> listaa = jdbcTemplate.query(sql, new RowMapper<ActionAdd>() 
	
	    				 {
			@Override
			public ActionAdd mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				ActionAdd aa = new ActionAdd();
				
				aa.setRaid(rs.getString("raid"));
				aa.setCategory(rs.getString("category"));
				aa.setStatus(rs.getString("status"));
				aa.setMeetingDate(rs.getDate("meetingdate"));
				aa.setType(rs.getString("type"));
				aa.setShortDesc(rs.getString("shortDesc"));
				aa.setSl(rs.getInt("sl"));
					
				
				return aa;
			}
	 
			
			
			
			
			
			
	    });//---------------new Object[]{year, month});
	    		
	    		
	    return listaa;
	    
	  
	    
		
	
		
		
	}
}

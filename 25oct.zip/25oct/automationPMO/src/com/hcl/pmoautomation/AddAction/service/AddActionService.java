package com.hcl.pmoautomation.AddAction.service;

import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;




public class AddActionService {

	/*public List<Map<String, Object>> validateAndGetRole(String meeting,String category ,String raid ,String description,String status,String tracks_clustures,String ownername ,String ownersap ,String ownermail,String meetingdate, String targetclosuredate,String Re_baselinedate ,String ActualClosureDate,String Status_Update, JdbcTemplate jdbcTemplate){
		AddActiondao addActiondao=new AddActiondao();
		
	return	addActiondao.validateAndGetRole( meeting, category, raid, description, status, tracks_clustures, ownername, ownersap, ownermail, meetingdate, targetclosuredate, Re_baselinedate, ActualClosureDate, Status_Update, jdbcTemplate);
		
	}

	public List<ActionAdd> viewAction(JdbcTemplate jdbcTemplate) {
		AddActiondao addActiondao=new AddActiondao();
		
		return addActiondao.viewAction(jdbcTemplate);
	}
*/}

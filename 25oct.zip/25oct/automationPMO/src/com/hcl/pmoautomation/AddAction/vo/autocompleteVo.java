package com.hcl.pmoautomation.AddAction.vo;

public class autocompleteVo {

	private String loginUsername;

	public String getLoginUsername() {
		return loginUsername;
	}

	public void setLoginUsername(String loginUsername) {
		this.loginUsername = loginUsername;
	}

	@Override
	public String toString() {
		return loginUsername;
	}


	

}

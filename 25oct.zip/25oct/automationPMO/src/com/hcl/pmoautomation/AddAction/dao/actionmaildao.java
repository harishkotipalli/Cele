package com.hcl.pmoautomation.AddAction.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.orm.jpa.vendor.Database;

import com.hcl.pmoautomation.AddAction.vo.templatevo;
import com.hcl.pmoautomation.ot.dao.DatabaseQuery;
import com.hcl.pmoautomation.ot.vo.mailVO;

public class actionmaildao {

	
	public List<templatevo> actionmail(String category,String raid,String ownermail,String status,JdbcTemplate jdbcTemplate) 
	{
		
	 	String sql = DatabaseQuery.QUERY_TO_FETCH_mailQuery_template+category+"'"+DatabaseQuery.QUERY_TO_FETCH_mailQuery_template1+raid+"'"+DatabaseQuery.QUERY_TO_FETCH_mailQuery_template2+ownermail+"'"+DatabaseQuery.QUERY_TO_FETCH_mailQuery_template3+status+"'";
		
		
		
		System.out.println(sql);
	   
	    		 List<templatevo> listaa = jdbcTemplate.query(sql, new RowMapper<templatevo>() 
	
	    				 {
			@Override
			public templatevo mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				templatevo mailtemp = new templatevo();
					
			
				
	            	
					mailtemp.setShortdescription(rs.getString("Shortdesc"));
				
				
				return mailtemp;
			}
	 
			
			
			
			
			
			
	    });
	    		
	    		
	    return listaa;
	    
	  
	    
	    }
}

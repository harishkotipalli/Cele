package com.hcl.pmoautomation.AddAction.vo;



import java.sql.Date;


public class ActionAdd {
	
	private String meeting;
	private String category;
	private String raid;
	private String description;
	private int sl;
	
	private String status;
	private String tracksclusters;
	private String ownerName;
	private int ownerSap;
	private String ownerMail;
	private Date meetingDate;
	private Date targetCloseDate;
	private Date re_baselineDate;
	private Date actualClosureDate;
	private String statusUpdate;
	private String type;
	private String shortDesc;
	private String remarks;
	private String recentUpdate;
	private String bussinesscriticality;
	private String loginUsername;
	public String getMeeting() {
		return meeting;
	}
	public void setMeeting(String meeting) {
		this.meeting = meeting;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getRaid() {
		return raid;
	}
	public void setRaid(String raid) {
		this.raid = raid;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public String getOwnerName() {
		
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	public int getOwnerSap() {
		return ownerSap;
	}
	public void setOwnerSap(int ownerSap) {
		this.ownerSap = ownerSap;
	}
	
	public Date getMeetingDate() {
		return meetingDate;
	}
	public void setMeetingDate(Date meetingDate) {
		this.meetingDate = meetingDate;
	}
	
	public String getStatusUpdate() {
		return statusUpdate;
	}
	public void setStatusUpdate(String statusUpdate) {
		this.statusUpdate = statusUpdate;
	}
	
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getShortDesc() {
		return shortDesc;
	}
	public void setShortDesc(String shortDesc) {
		this.shortDesc = shortDesc;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	public String getTracksclusters() {
		return tracksclusters;
	}
	public void setTracksclusters(String tracksclusters) {
		this.tracksclusters = tracksclusters;
	}
	public int getSl() {
		return sl;
	}
	public void setSl(int sl) {
		this.sl = sl;
	}
	public String getOwnerMail() {
		return ownerMail;
	}
	public void setOwnerMail(String ownerMail) {
		this.ownerMail = ownerMail;
	}
	public Date getTargetCloseDate() {
		return targetCloseDate;
	}
	public void setTargetCloseDate(Date targetCloseDate) {
		this.targetCloseDate = targetCloseDate;
	}
	public Date getRe_baselineDate() {
		return re_baselineDate;
	}
	public void setRe_baselineDate(Date re_baselineDate) {
		this.re_baselineDate = re_baselineDate;
	}
	public Date getActualClosureDate() {
		return actualClosureDate;
	}
	public void setActualClosureDate(Date actualClosureDate) {
		this.actualClosureDate = actualClosureDate;
	}
	
	public String getRecentUpdate() {
		return recentUpdate;
	}
	public void setRecentUpdate(String recentUpdate) {
		this.recentUpdate = recentUpdate;
	}
	
	public String getBussinesscriticality() {
		return bussinesscriticality;
	}
	public void setBussinesscriticality(String bussinesscriticality) {
		this.bussinesscriticality = bussinesscriticality;
	}
	
	public String getLoginUsername() {
		return loginUsername;
	}
	public void setLoginUsername(String loginUsername) {
		this.loginUsername = loginUsername;
	}
	@Override
	public String toString() {
		return "ActionAdd [meeting=" + meeting + ", category=" + category + ", raid=" + raid + ", description="
				+ description + ", sl=" + sl + ", status=" + status + ", tracksclusters=" + tracksclusters
				+ ", ownerName=" + ownerName + ", ownerSap=" + ownerSap + ", ownerMail=" + ownerMail + ", meetingDate="
				+ meetingDate + ", targetCloseDate=" + targetCloseDate + ", re_baselineDate=" + re_baselineDate
				+ ", actualClosureDate=" + actualClosureDate + ", statusUpdate=" + statusUpdate + ", type=" + type
				+ ", shortDesc=" + shortDesc + ", remarks=" + remarks + ", recentUpdate=" + recentUpdate
				+ ", bussinesscriticality=" + bussinesscriticality + ", loginUsername=" + loginUsername + "]";
	}
	
	
	
	

	
	
	
	

}

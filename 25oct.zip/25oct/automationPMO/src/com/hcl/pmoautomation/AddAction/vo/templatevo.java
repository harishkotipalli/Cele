package com.hcl.pmoautomation.AddAction.vo;

public class templatevo {
private String shortdescription;


public String getShortdescription() {
	return shortdescription;
}

public void setShortdescription(String shortdescription) {
	this.shortdescription = shortdescription;
}

@Override
public String toString() {
	return shortdescription ;
}


}

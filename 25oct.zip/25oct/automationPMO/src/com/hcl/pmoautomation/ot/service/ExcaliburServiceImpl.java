package com.hcl.pmoautomation.ot.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.hcl.pmoautomation.ot.dao.ExcaliburDao;
import com.hcl.pmoautomation.ot.dao.ExcaliburDaoImpl;
import com.hcl.pmoautomation.ot.utility.ExcelGenericReader;
import com.hcl.pmoautomation.ot.utility.ExcelSheetConstants;


public class ExcaliburServiceImpl implements ExcaliburService {

	
	

	@Override
	public boolean saveExcalibur(String filePath, String tableName,
			String sheetName,JdbcTemplate jdbcTemplate) {
//	ExcaliburDao	excaliburReaderDao = new ExcaliburDaoImpl();
		boolean resultFlag=false;
		ExcaliburDao excaliburDao=new ExcaliburDaoImpl();
			 try {
			resultFlag=excaliburDao.saveAllDataDynamically(ExcelGenericReader
						.readExcelAllDynamically(filePath, sheetName, tableName,jdbcTemplate),
						tableName,jdbcTemplate);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		return resultFlag;
	}

	


	/*public boolean checkMandatoryFields(String filePath, String tableName,
			String sheetName) {
		System.out.println("ASAS@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@AS");
		try {
			Map<String, Boolean> mandatoryFields = ExcelGenericReader
					.checkForExcaliburMandatoryFields(filePath, sheetName,
							tableName);
			for (String columnName : mandatoryFields.keySet()) {

				if (columnName
						.equalsIgnoreCase(ExcelSheetConstants.KEY_FIELD_EXCALIBURID)) {
					System.out.println(columnName);
					if (!mandatoryFields.get(columnName)) {
						return false;
					}
				}

			}

		} catch (Exception e) {

			e.printStackTrace();
		}
		return true;
	}

	public Map<String, Boolean> getMandatoryFieldNames(String filePath,
			String tableName, String sheetName) {

		Map<String, Boolean> mandatoryFields = null;

		try {
			mandatoryFields = ExcelGenericReader
					.checkForExcaliburMandatoryFields(filePath, sheetName,
							tableName);
			mandatoryFields.putAll(ExcelGenericReader
					.checkForSRMandatoryFields(filePath, sheetName, tableName));

		} catch (Exception e) {

			e.printStackTrace();
		}

		return mandatoryFields;

	}*/

	
	/*public List<ArrayList<String>> viewExcalibur() {

		return null;
	}*/

/*	@Override
	public boolean saveExcalibur(String filePath, String sheetName,
			String tableName, Map<String, Boolean> mandatoryFieldList) {
		excaliburReaderDao = new ExcaliburDaoImpl();
		boolean flag = false;
		try {
//			flag = excaliburReaderDao.saveAllDataDynamically(ExcelGenericReader
//					.readExcelAllDynamically(filePath, sheetName, tableName),
//					tableName, mandatoryFieldList);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;

	}*/

}

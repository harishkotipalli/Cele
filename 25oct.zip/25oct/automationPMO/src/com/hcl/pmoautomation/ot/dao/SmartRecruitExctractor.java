package com.hcl.pmoautomation.ot.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.hcl.pmoautomation.ot.vo.SmartRecruit;

public class SmartRecruitExctractor implements ResultSetExtractor<SmartRecruit> {

	@Override
	public SmartRecruit extractData(ResultSet rs) throws SQLException, DataAccessException {
		SmartRecruit smartRecruit=new SmartRecruit();
		smartRecruit.setReqNo(rs.getString("SR_ID"));
		smartRecruit.setPrimarySkills(rs.getString("PRIMARY_SKILLS"));
		smartRecruit.setSecondarySkills(rs.getString("SECONDARY_SKILLS"));
		smartRecruit.setProject(rs.getString("PROJECT"));
		smartRecruit.setProjectCode(rs.getString("PROJECT_CODE"));
		smartRecruit.setProjectArchetype(rs.getString("PROJECTARCHETYPE"));
		smartRecruit.setDesignation(rs.getString("DESIGNATION"));
		smartRecruit.setPersonalSubArea(rs.getString("PERSONAL_SUBAREA"));
		return smartRecruit;
	}

}

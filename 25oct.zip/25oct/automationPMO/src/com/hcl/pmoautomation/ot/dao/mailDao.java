package com.hcl.pmoautomation.ot.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.hcl.pmoautomation.ot.vo.OtTemplateUploadVO;
import com.hcl.pmoautomation.ot.vo.mailVO;
import com.hcl.pmoautomation.ot.vo.mailvoforpm;
import com.hcl.pmoautomation.ot.dao.DatabaseQuery;
import com.hcl.pmoautomation.sk.vo.skillSearch;

public class mailDao {

	public List<mailVO> list(JdbcTemplate jdbcTemplate) 
	{
		
	 	String sql = DatabaseQuery.QUERY_TO_FETCH_mailQuery;
		
		
		
		System.out.println(sql);
	   
	    		 List<mailVO> listaa = jdbcTemplate.query(sql, new RowMapper<mailVO>() 
	
	    				 {
			@Override
			public mailVO mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				mailVO mail = new mailVO();
					
			
				
	            	
					mail.setDm_mail_id(rs.getString("Dm_mail"));
				/*	mail.setPm_mail_id(rs.getString(""));*/
					
				
				return mail;
			}
	 
			
			
			
			
			
			
	    });
	    		
	    		
	    return listaa;
	    
	  
	    
	    }
	public List<OtTemplateUploadVO> templateData(String array,JdbcTemplate jdbcTemplate) 
	{
		
	 	String sql = DatabaseQuery.QUERY_TO_FETCH_mailQueryTemplate+array+"'";
		
		
		
		System.out.println("velocity------"+sql);
	   
	    		 List<OtTemplateUploadVO> listaa1 = jdbcTemplate.query(sql, new RowMapper<OtTemplateUploadVO>() 
	
	    				 {
			@Override
			public OtTemplateUploadVO mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				OtTemplateUploadVO templt = new OtTemplateUploadVO();
				
				templt.setExcaliburID(rs.getString("Excalibur_Id"));
				templt.setOpp_name(rs.getString("OPPORTUNITY_NAME"));
			
					return templt;
			}
	   });
	       return listaa1;
	    
	    }

	public List<mailvoforpm> listdmpm(JdbcTemplate jdbcTemplate) 
	{
		
	 	String sql = DatabaseQuery.QUERY_TO_FETCH_mailQueryfordmpm_mappingmail;
		
		
		
		System.out.println("pmmailsql---------"+sql);
	   
	    		 List<mailvoforpm> listaa = jdbcTemplate.query(sql, new RowMapper<mailvoforpm>() 
	
	    				 {
			@Override
			public mailvoforpm mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				mailvoforpm mail = new mailvoforpm();
					
			
				
	            	
					mail.setPm_mail_id(rs.getString("PM_MAIL_ID"));
			
					
				
				return mail;
			}
	 
			
			
			
			
			
			
	    });
	    		
	    		
	    return listaa;
	    
	  
	    
	    }
	
	
}

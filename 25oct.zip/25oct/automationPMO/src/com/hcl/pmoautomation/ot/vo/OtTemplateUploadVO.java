package com.hcl.pmoautomation.ot.vo;

public class OtTemplateUploadVO {

	private String ExcaliburID;
	private String opp_name;

	public String getExcaliburID() {
		return ExcaliburID;
	}

	public void setExcaliburID(String excaliburID) {
		ExcaliburID = excaliburID;
	}
	

	public String getOpp_name() {
		return opp_name;
	}

	public void setOpp_name(String opp_name) {
		this.opp_name = opp_name;
	}

	@Override
	public String toString() {
		return "OtTemplateUploadVO [ExcaliburID=" + ExcaliburID + ", opp_name=" + opp_name + "]";
	}

	
	
}

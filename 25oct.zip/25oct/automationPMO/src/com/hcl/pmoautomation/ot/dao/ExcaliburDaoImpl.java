package com.hcl.pmoautomation.ot.dao;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;


import com.hcl.pmoautomation.ot.vo.Excalibur;



public class ExcaliburDaoImpl implements ExcaliburDao {


	
	public List<Map<String, Object>> getAllColumnNamesDynamically(
			String tableName, JdbcTemplate jdbcTemplate) {

		String queryToFetchColumns = DatabaseQuery.QUERY_FETCH_COLUMNS1
				+ tableName + DatabaseQuery.QUERY_FETCH_COLUMNS2;

		//System.out.println(queryToFetchColumns);
		// jdbcTemplate=new JdbcTemplate();
		// System.out.println(getJdbcTemplate());
		return jdbcTemplate.queryForList(queryToFetchColumns);
	}

	public boolean saveAllDataDynamically(final List<ArrayList<String>> arrayLists,
			String tableName, JdbcTemplate jdbcTemplate) {
//System.out.println(arrayLists);
		// JdbcTemplate jdbcTemplate = new JdbcTemplate();
		int count = 0;boolean resultFlag=false;
		String[] returnData=null;
		final List<Map<String, Object>> columnNames = getAllColumnNamesDynamically(
				tableName, jdbcTemplate);

		StringBuilder sqlQuery = new StringBuilder();
		sqlQuery = sqlQuery.append("call excalibur1  (");

		/*for (Map columnMapRowData : columnNames) {
			String tempData = (String) columnMapRowData.get("column_name");

			if (count == columnNames.size() - 1) {
				sqlQuery.append("`" + tempData.trim() + "`,`MODIFIED_DATE`) values (");
				break;
			}
			sqlQuery.append("`" + tempData.trim() + "`,");

			count++;
		}*/

		// For Adding the Values
		count = 1;
		for (Map columnMapRowData : columnNames) {

			if (count == columnNames.size() - 1) {
				sqlQuery.append("?" + ",?,?)");
				break;
			}
			sqlQuery.append("?" + ",");

			count++;
		}
		System.out.println(sqlQuery);

		/*if ((jdbcTemplate.update(sqlQuery.toString(),
				setAllDataDynamically(arrayLists, columnNames))) > 0

		) {
					returnData=pmChecker(arrayLists.get(0));
					if(returnData[0].equalsIgnoreCase("NO")){
						resultFlag=	jdbcTemplate.update(DatabaseQuery.QUERY_TO_UPDATE_PM_DM_STATUS_NO+returnData[1]+"'")>0?true:false;
						
					}
					if(returnData[0].equalsIgnoreCase("YES")){
						resultFlag=jdbcTemplate.update(DatabaseQuery.QUERY_TO_UPDATE_PM_DM_STATUS_YES+returnData[1]+"'")>0?true:false;
						
					}
		}*/
		
		final int size=setAllDataDynamically(arrayLists, columnNames).size();
	boolean flagInsert=	(jdbcTemplate.batchUpdate(sqlQuery.toString(),new BatchPreparedStatementSetter() {
			
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				
				Object[] excalibur=(setAllDataDynamically(arrayLists, columnNames)).get(i);
				
				ps.setString(1,(String)excalibur[0]);
				ps.setString(2,(String)excalibur[1]);
				ps.setString(3,(String)excalibur[2]);
				ps.setString(4,(String)excalibur[3]);
				ps.setString(5,(String)excalibur[4]);
				ps.setString(6,(String)excalibur[5]);
				if (!(excalibur[6] == null)) {
					ps.setDate(7, new java.sql.Date(
							((Date) excalibur[6]).getTime()));
				}
				if ((excalibur[6] == null)) {
					ps.setDate(7, null);
				}
				ps.setString(8,(String)excalibur[7]);
				ps.setString(9,(String)excalibur[8]);
				ps.setString(10,(String)excalibur[9]);
				ps.setString(11,(String)excalibur[10]);
				ps.setInt(12,(int)excalibur[11]);
				
				ps.setInt(13,(int)excalibur[12]);
			
				ps.setString(14,(String)excalibur[13]);
				
				
				ps.setDate(15,new Date(new java.util.Date().getTime()));
				//System.out.println(ps);
				
			}
			
			@Override
			public int getBatchSize() {
				
				return size;
			}
		}).length==size)?true:false;
		String[] strings=null;
		if(flagInsert){
			
			for(ArrayList<String> temp:arrayLists){
			strings=pmChecker(temp);
			if(strings[0].equalsIgnoreCase("NO")){
			resultFlag=	jdbcTemplate.update(DatabaseQuery.QUERY_TO_UPDATE_PM_DM_STATUS_NO+strings[1]+"'")>0?true:false;
				
			}
			if(strings[0].equalsIgnoreCase("YES")){
				resultFlag=jdbcTemplate.update(DatabaseQuery.QUERY_TO_UPDATE_PM_DM_STATUS_YES+strings[1]+"'")>0?true:false;
				
			}
			}
		}	
		
		return flagInsert;

	}

	@SuppressWarnings({ "deprecation", "unused" })
	private List<Object[]> setAllDataDynamically(List<ArrayList<String>> arrayLists,
			List<Map<String, Object>> columnNames) {

	final	List<Object[]> objectDataList = new ArrayList<Object[]>();
	Object[] objectData=null;
//		ArrayList<String> excaliburData = arrayLists.get(0);
//		System.out.println(arr);
		int tempCount = 0;
		for(ArrayList<String> excaliburData:arrayLists){
			objectData=new Object[excaliburData.size()];
//			System.out.println(excaliburData);
			for (Map columnMapRowData : columnNames) {
				
//				System.out.println(objectData.length);
				
				
				// System.out.println(dataList.get(tempModCount));
				if (((String) columnMapRowData.get("column_datatype"))
						.equalsIgnoreCase("STRING")) {
//					System.out.println(columnMapRowData);
//					System.out.println(excaliburData.get(tempCount));
					objectData[tempCount] = excaliburData.get(tempCount);
				}
				if (((String) columnMapRowData.get("column_datatype"))
						.equalsIgnoreCase("INT")) {
//					System.out.println(columnMapRowData);
//					System.out.println(excaliburData.get(tempCount));
					if (!(excaliburData.get(tempCount) == null)) {
						objectData[tempCount] = Integer.parseInt(excaliburData
								.get(tempCount));

					}
					if (excaliburData.get(tempCount) == null) {
						objectData[tempCount] = 0;
					}
				}
				if (((String) columnMapRowData.get("column_datatype"))
						.equalsIgnoreCase("Date")) {
//					System.out.println(columnMapRowData);
//					System.out.println(excaliburData.get(tempCount));

					if (!(excaliburData.get(tempCount) == null)) {
						objectData[tempCount] = new Date(new java.util.Date(
								excaliburData.get(tempCount)).getTime());
						
						
						 
					}

					if (excaliburData.get(tempCount) == null) {
						objectData[tempCount] = null;
					}
				}

//				System.out.println(objectData[tempCount]);

				tempCount++;
					
			}
			tempCount=0;
			objectDataList.add(objectData);
		}

		return objectDataList;
	}

	private String[] pmChecker(ArrayList<String> arrayList) {

		if (!(arrayList.get(2) == null)) {
			return new String[] { "YES", (String) arrayList.get(4) };
		}

		return new String[] { "NO", (String) arrayList.get(4) };
	}

	public String getOppName(JdbcTemplate jdbcTemplate, String parameter) {
		System.out.println("gettingoppname");
		return jdbcTemplate.queryForObject(DatabaseQuery.QUERY_TO_FETCH_OPPORTUNITY_NAME+parameter+"'", String.class);
		
	}
	public String getaccname(JdbcTemplate jdbcTemplate, String parameter) {
		System.out.println("gettingaccountname");
		return jdbcTemplate.queryForObject(DatabaseQuery.QUERY_TO_FETCH_accountmanager_NAME+parameter+"'", String.class);
		
	}
	public String getOppName1(JdbcTemplate jdbcTemplate, String parameter) {
		System.out.println("asasass");
		return jdbcTemplate.queryForObject(DatabaseQuery.QUERY_TO_FETCH_OPPORTUNITY_NAME1+parameter+"'", String.class);
		
	}


	

	public List<Map<String, Object>> getExcaliburView(Date startingDate, Date endingDate,JdbcTemplate jdbcTemplate) {
		List<Map<String, Object>> excaliburList= jdbcTemplate.queryForList(DatabaseQuery.QUERY_TO_FETCH_EXCALIBURVIEW+"'"+startingDate+"' AND '"+endingDate+"'");
//		System.out.println(excaliburList);
		return excaliburList;
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public List<Excalibur> updateRadio( String PROJECT_MANAGER , String Excaliburid ,JdbcTemplate jdbcTemplate) 
	{
		
	
			String sql = DatabaseQuery.QUERY_TO_Update_pm_name1+PROJECT_MANAGER+DatabaseQuery.QUERY_TO_Update_pm_name2+Excaliburid;
		
			   
	    		 List<Excalibur> listaa = jdbcTemplate.query(sql, new RowMapper<Excalibur>() 
	
	    				 {
			@Override
			public Excalibur mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				Excalibur aa = new Excalibur();
				
				aa.setExcalinburID(rs.getString("EXCALIBUR_ID"));
				aa.setOpportunityName(rs.getString("OPPORTUNITY_NAME"));
				aa.setAccountManager(rs.getString("ACCOUNT_MANAGER"));
				aa.setDM(rs.getString("DM"));
				aa.setPM(rs.getString("PM_CM"));
				aa.setSl_no(rs.getInt("sl_no"));
				
				
				
				return aa;
			}
	 
			
			
			
			
			
			
	    });//---------------new Object[]{year, month});
	    		
	    		
	    return listaa;
	    
	  
	    
		
	
		
		
	}
		
	
}

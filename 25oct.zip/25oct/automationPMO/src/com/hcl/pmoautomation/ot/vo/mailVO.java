package com.hcl.pmoautomation.ot.vo;

public class mailVO {

	
	
private String dm_mail_id;
/*private String pm_mail_id;*/
public String getDm_mail_id() {
	return dm_mail_id;
}
public void setDm_mail_id(String dm_mail_id) {
	this.dm_mail_id = dm_mail_id;
}
/*public String getPm_mail_id() {
	return pm_mail_id;
}
public void setPm_mail_id(String pm_mail_id) {
	this.pm_mail_id = pm_mail_id;
}*/
@Override
public String toString() {
	return  dm_mail_id;
}



}

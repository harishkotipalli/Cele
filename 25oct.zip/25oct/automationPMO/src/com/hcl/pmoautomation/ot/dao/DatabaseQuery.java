package com.hcl.pmoautomation.ot.dao;

import org.springframework.jdbc.core.PreparedStatementCreator;

public interface DatabaseQuery {

	public String QUERY_FETCH_COLUMNS1 = "select column_id ,column_name ,column_datatype from  mydb.type_configuration where table_name='";
	public String QUERY_FETCH_COLUMNS2 = "' and active_flag='Y' order by column_id";
	
	public String QUERY_TO_FETCH_EXCALIBUR = "select * FROM excalibur1 where PM_CM is null And DM='";
	public String QUERY_TO_UPDATE_EXCALIBUR1="update excalibur1 set STATUS_DM_PM ='Y', PM_CM='";
	public String QUERY_TO_UPDATE_EXCALIBUR2="' where excalibur_id='";
	public String QUERY_TO_UPDATE_PM_DM_STATUS_NO = "update excalibur1 set STATUS_DM_PM='N',STATUS_EMAIL='N' where EXCALIBUR_ID='";
	public String QUERY_TO_UPDATE_PM_DM_STATUS_YES = "update excalibur1 set STATUS_DM_PM='Y',STATUS_EMAIL='N' where EXCALIBUR_ID='";
	public String QUERY_TO_FETCH_PM_NAMES = "select PM_NAME FROM dm_pm_mapping where DM_NAME like '%";
	
	public String QUERY_TO_UPDATE_EXCALIBUR_PM1 ="update excalibur1 set PM_CM='";
	public String QUERY_TO_UPDATE_EXCALIBUR_PM2 ="',STATUS_DM_PM='Y' where EXCALIBUR_ID='";
	public String QUERY_TO_FETCH_SR_DATA = "select SR_ID,PRIMARY_SKILLS,PROJECT,PROJECT_CODE from sr where INITIATOR like '%";
	public String QUERY_TO_FETCH_EXCALIBUR_PMNAME = "select EXCALIBUR_ID from excalibur1 where PM_CM='";
	public String QUERY_TO_FETCH_AM_DM_NAME = "select ACCOUNT_MANAGER,DM from excalibur1 where PM_CM like '";
	public String QUERY_TO_FETCH_OPPORTUNITY_NAME = "select OPPORTUNITY_NAME from excalibur1 where EXCALIBUR_ID='";
	public String QUERY_TO_FETCH_accountmanager_NAME = "select ACCOUNT_MANAGER from excalibur1 where EXCALIBUR_ID='";
	
	public String QUERY_TO_FETCH_OPPORTUNITY_NAME1 = "select DM from excalibur1 where EXCALIBUR_ID='";
	public String QUERY_TO_INSERT_SR_EXCALIBUR = "insert into excalibur_sr_mapping (EXCALIBUR_ID,SR_ID,PM_MAP_ID,MODIFIED_DATE) values(?,?,?,sysdate())";
	public String QUERY_TO_FETCH_SR_FROM_SREXCALIBUR = "select SR_ID from excalibur_sr_mapping";
	public String QUERY_TO_FETCH_RAS_HAVING_PM = "select * from ras where PM_CODE=? AND SR_ID IS NULL AND  NOT(SAPCODE=?)";
	public String QUERY_TO_FETCH_SR_HAVING_PMNAME = "select SR_ID from excalibur_sr_mapping where PM_MAP_ID=";
	public String QUERY_TO_FETCH_SRDETAIL_FOR_SRID = "select PRIMARY_SKILLS from sr where sr_id=?";
	public String QUERY_TO_UPDATE_RAS_FOR_SAPID_WITH_SRID = "update ras set SR_ID=? where SAPCODE=?";
	public String QUERY_TO_FETCH_TSC = "select * from tsc";
	public String QUERY_TO_FETCH_EXCALIBURVIEW = "select * from excalibur1 where STATUS_DM_PM='Y' AND MODIFIED_DATE between ";
	public String QUERY_TO_FETCH_SMARTRECRUIT_DATA = "select * from sr where INITIATOR like '%";
	
	public String QUERY_TO_Update_pm_name1 = "update excalibur1 set PM_CM='";
	public String QUERY_TO_Update_pm_name2="',STATUS_DM_PM='Y' where EXCALIBUR_ID='";
	public String QUERY_TO_Update_dmpm_name="select dm_pm_mapping.PM_NAME from mydb.dm_pm_mapping where dm_pm_mapping.DM_NAME='";
	public String QUERY_TO_FETCH_SrExaclVIEW="select excalibur_sr_mapping.EXCALIBUR_ID, excalibur_sr_mapping.SR_ID, "
			+ "	excalibur1.ACCOUNT_MANAGER, sr.PROJECT_CODE,"
			+ "sr.PROJECT,	sr.PRIMARY_SKILLS,excalibur1.DM,excalibur1.OPPORTUNITY_NAME"
			+ " 	from mydb.excalibur_sr_mapping,	mydb.sr,mydb.excalibur1"
	+" where excalibur_sr_mapping.PM_MAP_ID= ";
	public String QUERY_TO_FETCH_SrExaclVIEW2= " and sr.SR_ID= excalibur_sr_mapping.SR_ID and excalibur_sr_mapping.EXCALIBUR_ID= excalibur1.EXCALIBUR_ID "
	+ "and excalibur_sr_mapping.MODIFIED_DATE between '";
	
	public String QUERY_TO_FETCH_SrExaclVIEW3= "' and ";
	
	public String QUERY_TO_FETCH_mailQuery="select distinct excalibur1.Dm_mail  from mydb.excalibur1 where excalibur1.MODIFIED_DATE= curdate() and  excalibur1.EmailTriggedDM='N'";
	public String QUERY_TO_FETCH_mailQueryUpdateDMStatus=" update mydb.excalibur1 	set  excalibur1.EmailTriggedDM='Y' where excalibur1.MODIFIED_DATE= current_date() and excalibur1.Dm_mail='";
	
	public String QUERY_TO_FETCH_mailQueryTemplate="select excalibur1.Excalibur_Id,excalibur1.OPPORTUNITY_NAME from mydb.excalibur1 where excalibur1.MODIFIED_DATE= curdate() and excalibur1.EmailTriggedDM='N' and  excalibur1.Dm_mail='";
	public String QUERY_TO_FETCH_mailQueryfordmpm_mapping="select dm_pm_mapping.PM_MAIL_ID from mydb.dm_pm_mapping, mydb.excalibur1 where excalibur1.PM_CM= dm_pm_mapping.PM_NAME and excalibur1.STATUS_DM_PM='Y' and excalibur1.EmailTriggedPM='N'";	
	
	
	public String QUERY_TO_FETCH_mailQueryfordmpm_mappingmail="select dm_pm_mapping.PM_MAIL_ID from mydb.dm_pm_mapping, mydb.excalibur1 where excalibur1.PM_CM= dm_pm_mapping.PM_NAME and excalibur1.STATUS_DM_PM='Y' and excalibur1.EmailTriggedPM='N'";
	
	public String QUERY_TO_FETCH_mailQueryUpdatePMMailStatus="update excalibur1 set excalibur1.EmailTriggedPM='Y' where excalibur1.STATUS_DM_PM='Y' and excalibur1.PM_CM=(select dm_pm_mapping.PM_NAME from dm_pm_mapping where dm_pm_mapping.PM_MAIL_ID='";

	public String QUERY_TO_FETCH_mailQuery_template="select gat.Shortdesc from mydb.gat where gat.category='";
public String QUERY_TO_FETCH_mailQuery_template1=" and gat.raid='" ;
public String QUERY_TO_FETCH_mailQuery_template2=" and gat.ownermail='";
public String QUERY_TO_FETCH_mailQuery_template3=" and gat.status='";


}

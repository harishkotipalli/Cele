package com.hcl.pmoautomation.ot.vo;

public class SmartRecruit {

	public String reqNo;
	public String joiningLevel1;
	public String joiningLevel2;
	public String joiningLevel3;
	public String joiningLevel4;
	public String initiator;
	public String status;
	public String reason;
	public String pendingWith;
	public String primarySkills;
	public String secondarySkills;
	public String primarySkillCategory;
	public String primarySkillArea;
	public String customer;
	public String customerCode;
	public String project;
	public String projectCategory;
	//public String project;
	public String projectCode;
	public String projectL1;
	public String projectL4;
	public String projectArchetype;
	public String band;
	public String subBand;
	public String designation;
	public String experience;
	public String tRating;
	public String pendingWithNameAndID;
	public String jobFamily;
	public String job;
	public String jobDescription;
	public String country;
	public String personalArea;
	public String personalSubArea;
	public String oNBoardingDate;
	public String reqDate;
	public String approvalDate;
	public String requisitionSource;
	public String employeeGroup;
	public String billingType;
	public String billingStartDate;
	public String age;
	public String vacancy;
	public String internal_Filled;
	public String external_Offered;
	public String external_Joined;
	public String TPG_To_TAG_Assign_dt;
	public String TAG_Exe_Assign_dt;
	public String initiatorLevel1;
	public String initiatorLevel2;
	public String initiatorLevel3;
	public String initiatorLevel4;
	public String req_Close_dt;
	public String closure_Remarks;
	public String closed_By;
	public String req_Resubmission_dt;
	public String balance_Postions;
	public String offer_Declined;
	public String total_Attached;
	public String total_forwarded;
	public String total_Blocked;
	public String total_Rejected;
	public String total_Shortlisted;
	public String total_Final_Select;
	public String internal_Filled_SAP_Codes;
	public String position_End_Date;
	public String internal_Filled_SAP_Codes1;
	public String actionable_Position;
	public String valid_Till_Date;
	public String initialSourceByFinalApprover;
	public String bservSource;
	public String initialDemand;
	public String droppedPos;
	public String client_Interview;
	public String BGV;
	public String TP1;
	public String TP2;
	public String projectArchetype1;
	public String referBackCount;
	public String latestReferBackRemarks;
	public String first_ReferBack_DT;
	public String last_ReferBack_DT;
	public String first_BSD_DT;
	public String last_BSD_DT;
	public String first_Resubmission_dt;
	public String last_Resubmission_dt;
	public String latestReferBackBy;
	public String approver1;
	public String approved1_By;
	public String approver1_dt;
	public String approver2;
	public String approved2_By;
	public String approver2_dt;
	public String approver3;
	public String approver3_dt;
	public String TPAllowed;
	public String forceFull_Final_Select;
	public String final_Select_After_ShortList;
	public String reasonCodeforL4JobFamily;
	public String oldBillingStartDate;
	public String oldPositionEndDate;
	public String oldValidTillDate;
	public String totalExtCandAttached;
	public String vAdditionalRemarks;
	public String actionTakenBy;
	public String pullbackBy;
	public String pullbackReason;
	public String pullbackRemarks;
	public String actualTP1TP2;
	public String reportingManager;
	public String referBackAgeingLessThan2Days;
	public String referBackAgeingGreaterThan2Days;
	public String targetDeviation;
	public String exceptionallyApproved;

	public SmartRecruit() {
		// TODO Auto-generated constructor stub
	}

	public SmartRecruit(String reqNo, String joiningLevel1,
			String joiningLevel2, String joiningLevel3, String joiningLevel4,
			String initiator, String status, String reason, String pendingWith,
			String primarySkills, String secondarySkills,
			String primarySkillCategory, String primarySkillArea,
			String customer, String customerCode, String projectCategory,
			String project, String projectCode, String projectL1,
			String projectL4, String projectArchetype, String band,
			String subBand, String designation, String experience,
			String tRating, String pendingWithNameAndID, String jobFamily,
			String job, String jobDescription, String country,
			String personalArea, String personalSubArea, String oNBoardingDate,
			String reqDate, String approvalDate, String requisitionSource,
			String employeeGroup, String billingType, String billingStartDate,
			String age, String vacancy, String internal_Filled,
			String external_Offered, String external_Joined,
			String tPG_To_TAG_Assign_dt, String tAG_Exe_Assign_dt,
			String initiatorLevel1, String initiatorLevel2,
			String initiatorLevel3, String initiatorLevel4,
			String req_Close_dt, String closure_Remarks, String closed_By,
			String req_Resubmission_dt, String balance_Postions,
			String offer_Declined, String total_Attached,
			String total_forwarded, String total_Blocked,
			String total_Rejected, String total_Shortlisted,
			String total_Final_Select, String internal_Filled_SAP_Codes,
			String position_End_Date, String internal_Filled_SAP_Codes1,
			String actionable_Position, String valid_Till_Date,
			String initialSourceByFinalApprover, String bservSource,
			String initialDemand, String droppedPos, String client_Interview,
			String bGV, String tP1, String tP2, String projectArchetype1,
			String referBackCount, String latestReferBackRemarks,
			String first_ReferBack_DT, String last_ReferBack_DT,
			String first_BSD_DT, String last_BSD_DT,
			String first_Resubmission_dt, String last_Resubmission_dt,
			String latestReferBackBy, String approver1, String approved1_By,
			String approver1_dt, String approver2, String approved2_By,
			String approver2_dt, String approver3, String approver3_dt,
			String tPAllowed, String forceFull_Final_Select,
			String final_Select_After_ShortList,
			String reasonCodeforL4JobFamily, String oldBillingStartDate,
			String oldPositionEndDate, String oldValidTillDate,
			String totalExtCandAttached, String vAdditionalRemarks,
			String actionTakenBy, String pullbackBy, String pullbackReason,
			String pullbackRemarks, String actualTP1TP2,
			String reportingManager, String referBackAgeingLessThan2Days,
			String referBackAgeingGreaterThan2Days, String targetDeviation,
			String exceptionallyApproved) {
		super();
		this.reqNo = reqNo;
		this.joiningLevel1 = joiningLevel1;
		this.joiningLevel2 = joiningLevel2;
		this.joiningLevel3 = joiningLevel3;
		this.joiningLevel4 = joiningLevel4;
		this.initiator = initiator;
		this.status = status;
		this.reason = reason;
		this.pendingWith = pendingWith;
		this.primarySkills = primarySkills;
		this.secondarySkills = secondarySkills;
		this.primarySkillCategory = primarySkillCategory;
		this.primarySkillArea = primarySkillArea;
		this.customer = customer;
		this.customerCode = customerCode;
		this.projectCategory = projectCategory;
		this.project = project;
		this.projectCode = projectCode;
		this.projectL1 = projectL1;
		this.projectL4 = projectL4;
		this.projectArchetype = projectArchetype;
		this.band = band;
		this.subBand = subBand;
		this.designation = designation;
		this.experience = experience;
		this.tRating = tRating;
		this.pendingWithNameAndID = pendingWithNameAndID;
		this.jobFamily = jobFamily;
		this.job = job;
		this.jobDescription = jobDescription;
		this.country = country;
		this.personalArea = personalArea;
		this.personalSubArea = personalSubArea;
		this.oNBoardingDate = oNBoardingDate;
		this.reqDate = reqDate;
		this.approvalDate = approvalDate;
		this.requisitionSource = requisitionSource;
		this.employeeGroup = employeeGroup;
		this.billingType = billingType;
		this.billingStartDate = billingStartDate;
		this.age = age;
		this.vacancy = vacancy;
		this.internal_Filled = internal_Filled;
		this.external_Offered = external_Offered;
		this.external_Joined = external_Joined;
		this.TPG_To_TAG_Assign_dt = tPG_To_TAG_Assign_dt;
		this.TAG_Exe_Assign_dt = tAG_Exe_Assign_dt;
		this.initiatorLevel1 = initiatorLevel1;
		this.initiatorLevel2 = initiatorLevel2;
		this.initiatorLevel3 = initiatorLevel3;
		this.initiatorLevel4 = initiatorLevel4;
		this.req_Close_dt = req_Close_dt;
		this.closure_Remarks = closure_Remarks;
		this.closed_By = closed_By;
		this.req_Resubmission_dt = req_Resubmission_dt;
		this.balance_Postions = balance_Postions;
		this.offer_Declined = offer_Declined;
		this.total_Attached = total_Attached;
		this.total_forwarded = total_forwarded;
		this.total_Blocked = total_Blocked;
		this.total_Rejected = total_Rejected;
		this.total_Shortlisted = total_Shortlisted;
		this.total_Final_Select = total_Final_Select;
		this.internal_Filled_SAP_Codes = internal_Filled_SAP_Codes;
		this.position_End_Date = position_End_Date;
		this.internal_Filled_SAP_Codes1 = internal_Filled_SAP_Codes1;
		this.actionable_Position = actionable_Position;
		this.valid_Till_Date = valid_Till_Date;
		this.initialSourceByFinalApprover = initialSourceByFinalApprover;
		this.bservSource = bservSource;
		this.initialDemand = initialDemand;
		this.droppedPos = droppedPos;
		this.client_Interview = client_Interview;
		this.BGV = bGV;
		this.TP1 = tP1;
		this.TP2 = tP2;
		this.projectArchetype1 = projectArchetype1;
		this.referBackCount = referBackCount;
		this.latestReferBackRemarks = latestReferBackRemarks;
		this.first_ReferBack_DT = first_ReferBack_DT;
		this.last_ReferBack_DT = last_ReferBack_DT;
		this.first_BSD_DT = first_BSD_DT;
		this.last_BSD_DT = last_BSD_DT;
		this.first_Resubmission_dt = first_Resubmission_dt;
		this.last_Resubmission_dt = last_Resubmission_dt;
		this.latestReferBackBy = latestReferBackBy;
		this.approver1 = approver1;
		this.approved1_By = approved1_By;
		this.approver1_dt = approver1_dt;
		this.approver2 = approver2;
		this.approved2_By = approved2_By;
		this.approver2_dt = approver2_dt;
		this.approver3 = approver3;
		this.approver3_dt = approver3_dt;
		this.TPAllowed = tPAllowed;
		this.forceFull_Final_Select = forceFull_Final_Select;
		this.final_Select_After_ShortList = final_Select_After_ShortList;
		this.reasonCodeforL4JobFamily = reasonCodeforL4JobFamily;
		this.oldBillingStartDate = oldBillingStartDate;
		this.oldPositionEndDate = oldPositionEndDate;
		this.oldValidTillDate = oldValidTillDate;
		this.totalExtCandAttached = totalExtCandAttached;
		this.vAdditionalRemarks = vAdditionalRemarks;
		this.actionTakenBy = actionTakenBy;
		this.pullbackBy = pullbackBy;
		this.pullbackReason = pullbackReason;
		this.pullbackRemarks = pullbackRemarks;
		this.actualTP1TP2 = actualTP1TP2;
		this.reportingManager = reportingManager;
		this.referBackAgeingLessThan2Days = referBackAgeingLessThan2Days;
		this.referBackAgeingGreaterThan2Days = referBackAgeingGreaterThan2Days;
		this.targetDeviation = targetDeviation;
		this.exceptionallyApproved = exceptionallyApproved;
	}

	public String getReqNo() {
		return reqNo;
	}

	public void setReqNo(String reqNo) {
		this.reqNo = reqNo;
	}

	public String getJoiningLevel1() {
		return joiningLevel1;
	}

	public void setJoiningLevel1(String joiningLevel1) {
		this.joiningLevel1 = joiningLevel1;
	}

	public String getJoiningLevel2() {
		return joiningLevel2;
	}

	public void setJoiningLevel2(String joiningLevel2) {
		this.joiningLevel2 = joiningLevel2;
	}

	public String getJoiningLevel3() {
		return joiningLevel3;
	}

	public void setJoiningLevel3(String joiningLevel3) {
		this.joiningLevel3 = joiningLevel3;
	}

	public String getJoiningLevel4() {
		return joiningLevel4;
	}

	public void setJoiningLevel4(String joiningLevel4) {
		this.joiningLevel4 = joiningLevel4;
	}

	public String getInitiator() {
		return initiator;
	}

	public void setInitiator(String initiator) {
		this.initiator = initiator;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getPendingWith() {
		return pendingWith;
	}

	public void setPendingWith(String pendingWith) {
		this.pendingWith = pendingWith;
	}

	public String getPrimarySkills() {
		return primarySkills;
	}

	public void setPrimarySkills(String primarySkills) {
		this.primarySkills = primarySkills;
	}

	public String getSecondarySkills() {
		return secondarySkills;
	}

	public void setSecondarySkills(String secondarySkills) {
		this.secondarySkills = secondarySkills;
	}

	public String getPrimarySkillCategory() {
		return primarySkillCategory;
	}

	public void setPrimarySkillCategory(String primarySkillCategory) {
		this.primarySkillCategory = primarySkillCategory;
	}

	public String getPrimarySkillArea() {
		return primarySkillArea;
	}

	public void setPrimarySkillArea(String primarySkillArea) {
		this.primarySkillArea = primarySkillArea;
	}

	public String getCustomer() {
		return customer;
	}

	public void setCustomer(String customer) {
		this.customer = customer;
	}

	public String getCustomerCode() {
		return customerCode;
	}

	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	public String getProjectCategory() {
		return projectCategory;
	}

	public void setProjectCategory(String projectCategory) {
		this.projectCategory = projectCategory;
	}

	
	public String getProject() {
		return project;
	}

	public void setProject(String project) {
		this.project = project;
	}

	public String getProjectCode() {
		return projectCode;
	}

	public void setProjectCode(String projectCode) {
		this.projectCode = projectCode;
	}

	public String getProjectL1() {
		return projectL1;
	}

	public void setProjectL1(String projectL1) {
		this.projectL1 = projectL1;
	}

	public String getProjectL4() {
		return projectL4;
	}

	public void setProjectL4(String projectL4) {
		this.projectL4 = projectL4;
	}

	public String getProjectArchetype() {
		return projectArchetype;
	}

	public void setProjectArchetype(String projectArchetype) {
		this.projectArchetype = projectArchetype;
	}

	public String getBand() {
		return band;
	}

	public void setBand(String band) {
		this.band = band;
	}

	public String getSubBand() {
		return subBand;
	}

	public void setSubBand(String subBand) {
		this.subBand = subBand;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getExperience() {
		return experience;
	}

	public void setExperience(String experience) {
		this.experience = experience;
	}

	public String gettRating() {
		return tRating;
	}

	public void settRating(String tRating) {
		this.tRating = tRating;
	}

	public String getPendingWithNameAndID() {
		return pendingWithNameAndID;
	}

	public void setPendingWithNameAndID(String pendingWithNameAndID) {
		this.pendingWithNameAndID = pendingWithNameAndID;
	}

	public String getJobFamily() {
		return jobFamily;
	}

	public void setJobFamily(String jobFamily) {
		this.jobFamily = jobFamily;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public String getJobDescription() {
		return jobDescription;
	}

	public void setJobDescription(String jobDescription) {
		this.jobDescription = jobDescription;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getPersonalArea() {
		return personalArea;
	}

	public void setPersonalArea(String personalArea) {
		this.personalArea = personalArea;
	}

	public String getPersonalSubArea() {
		return personalSubArea;
	}

	public void setPersonalSubArea(String personalSubArea) {
		this.personalSubArea = personalSubArea;
	}

	public String getoNBoardingDate() {
		return oNBoardingDate;
	}

	public void setoNBoardingDate(String oNBoardingDate) {
		this.oNBoardingDate = oNBoardingDate;
	}

	public String getReqDate() {
		return reqDate;
	}

	public void setReqDate(String reqDate) {
		this.reqDate = reqDate;
	}

	public String getApprovalDate() {
		return approvalDate;
	}

	public void setApprovalDate(String approvalDate) {
		this.approvalDate = approvalDate;
	}

	public String getRequisitionSource() {
		return requisitionSource;
	}

	public void setRequisitionSource(String requisitionSource) {
		this.requisitionSource = requisitionSource;
	}

	public String getEmployeeGroup() {
		return employeeGroup;
	}

	public void setEmployeeGroup(String employeeGroup) {
		this.employeeGroup = employeeGroup;
	}

	public String getBillingType() {
		return billingType;
	}

	public void setBillingType(String billingType) {
		this.billingType = billingType;
	}

	public String getBillingStartDate() {
		return billingStartDate;
	}

	public void setBillingStartDate(String billingStartDate) {
		this.billingStartDate = billingStartDate;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getVacancy() {
		return vacancy;
	}

	public void setVacancy(String vacancy) {
		this.vacancy = vacancy;
	}

	public String getInternal_Filled() {
		return internal_Filled;
	}

	public void setInternal_Filled(String internal_Filled) {
		this.internal_Filled = internal_Filled;
	}

	public String getExternal_Offered() {
		return external_Offered;
	}

	public void setExternal_Offered(String external_Offered) {
		this.external_Offered = external_Offered;
	}

	public String getExternal_Joined() {
		return external_Joined;
	}

	public void setExternal_Joined(String external_Joined) {
		this.external_Joined = external_Joined;
	}

	public String getTPG_To_TAG_Assign_dt() {
		return TPG_To_TAG_Assign_dt;
	}

	public void setTPG_To_TAG_Assign_dt(String tPG_To_TAG_Assign_dt) {
		TPG_To_TAG_Assign_dt = tPG_To_TAG_Assign_dt;
	}

	public String getTAG_Exe_Assign_dt() {
		return TAG_Exe_Assign_dt;
	}

	public void setTAG_Exe_Assign_dt(String tAG_Exe_Assign_dt) {
		TAG_Exe_Assign_dt = tAG_Exe_Assign_dt;
	}

	public String getInitiatorLevel1() {
		return initiatorLevel1;
	}

	public void setInitiatorLevel1(String initiatorLevel1) {
		this.initiatorLevel1 = initiatorLevel1;
	}

	public String getInitiatorLevel2() {
		return initiatorLevel2;
	}

	public void setInitiatorLevel2(String initiatorLevel2) {
		this.initiatorLevel2 = initiatorLevel2;
	}

	public String getInitiatorLevel3() {
		return initiatorLevel3;
	}

	public void setInitiatorLevel3(String initiatorLevel3) {
		this.initiatorLevel3 = initiatorLevel3;
	}

	public String getInitiatorLevel4() {
		return initiatorLevel4;
	}

	public void setInitiatorLevel4(String initiatorLevel4) {
		this.initiatorLevel4 = initiatorLevel4;
	}

	public String getReq_Close_dt() {
		return req_Close_dt;
	}

	public void setReq_Close_dt(String req_Close_dt) {
		this.req_Close_dt = req_Close_dt;
	}

	public String getClosure_Remarks() {
		return closure_Remarks;
	}

	public void setClosure_Remarks(String closure_Remarks) {
		this.closure_Remarks = closure_Remarks;
	}

	public String getClosed_By() {
		return closed_By;
	}

	public void setClosed_By(String closed_By) {
		this.closed_By = closed_By;
	}

	public String getReq_Resubmission_dt() {
		return req_Resubmission_dt;
	}

	public void setReq_Resubmission_dt(String req_Resubmission_dt) {
		this.req_Resubmission_dt = req_Resubmission_dt;
	}

	public String getBalance_Postions() {
		return balance_Postions;
	}

	public void setBalance_Postions(String balance_Postions) {
		this.balance_Postions = balance_Postions;
	}

	public String getOffer_Declined() {
		return offer_Declined;
	}

	public void setOffer_Declined(String offer_Declined) {
		this.offer_Declined = offer_Declined;
	}

	public String getTotal_Attached() {
		return total_Attached;
	}

	public void setTotal_Attached(String total_Attached) {
		this.total_Attached = total_Attached;
	}

	public String getTotal_forwarded() {
		return total_forwarded;
	}

	public void setTotal_forwarded(String total_forwarded) {
		this.total_forwarded = total_forwarded;
	}

	public String getTotal_Blocked() {
		return total_Blocked;
	}

	public void setTotal_Blocked(String total_Blocked) {
		this.total_Blocked = total_Blocked;
	}

	public String getTotal_Rejected() {
		return total_Rejected;
	}

	public void setTotal_Rejected(String total_Rejected) {
		this.total_Rejected = total_Rejected;
	}

	public String getTotal_Shortlisted() {
		return total_Shortlisted;
	}

	public void setTotal_Shortlisted(String total_Shortlisted) {
		this.total_Shortlisted = total_Shortlisted;
	}

	public String getTotal_Final_Select() {
		return total_Final_Select;
	}

	public void setTotal_Final_Select(String total_Final_Select) {
		this.total_Final_Select = total_Final_Select;
	}

	public String getInternal_Filled_SAP_Codes() {
		return internal_Filled_SAP_Codes;
	}

	public void setInternal_Filled_SAP_Codes(String internal_Filled_SAP_Codes) {
		this.internal_Filled_SAP_Codes = internal_Filled_SAP_Codes;
	}

	public String getPosition_End_Date() {
		return position_End_Date;
	}

	public void setPosition_End_Date(String position_End_Date) {
		this.position_End_Date = position_End_Date;
	}

	public String getInternal_Filled_SAP_Codes1() {
		return internal_Filled_SAP_Codes1;
	}

	public void setInternal_Filled_SAP_Codes1(String internal_Filled_SAP_Codes1) {
		this.internal_Filled_SAP_Codes1 = internal_Filled_SAP_Codes1;
	}

	public String getActionable_Position() {
		return actionable_Position;
	}

	public void setActionable_Position(String actionable_Position) {
		this.actionable_Position = actionable_Position;
	}

	public String getValid_Till_Date() {
		return valid_Till_Date;
	}

	public void setValid_Till_Date(String valid_Till_Date) {
		this.valid_Till_Date = valid_Till_Date;
	}

	public String getInitialSourceByFinalApprover() {
		return initialSourceByFinalApprover;
	}

	public void setInitialSourceByFinalApprover(
			String initialSourceByFinalApprover) {
		this.initialSourceByFinalApprover = initialSourceByFinalApprover;
	}

	public String getBservSource() {
		return bservSource;
	}

	public void setBservSource(String bservSource) {
		this.bservSource = bservSource;
	}

	public String getInitialDemand() {
		return initialDemand;
	}

	public void setInitialDemand(String initialDemand) {
		this.initialDemand = initialDemand;
	}

	public String getDroppedPos() {
		return droppedPos;
	}

	public void setDroppedPos(String droppedPos) {
		this.droppedPos = droppedPos;
	}

	public String getClient_Interview() {
		return client_Interview;
	}

	public void setClient_Interview(String client_Interview) {
		this.client_Interview = client_Interview;
	}

	public String getBGV() {
		return BGV;
	}

	public void setBGV(String bGV) {
		BGV = bGV;
	}

	public String getTP1() {
		return TP1;
	}

	public void setTP1(String tP1) {
		TP1 = tP1;
	}

	public String getTP2() {
		return TP2;
	}

	public void setTP2(String tP2) {
		TP2 = tP2;
	}

	public String getProjectArchetype1() {
		return projectArchetype1;
	}

	public void setProjectArchetype1(String projectArchetype1) {
		this.projectArchetype1 = projectArchetype1;
	}

	public String getReferBackCount() {
		return referBackCount;
	}

	public void setReferBackCount(String referBackCount) {
		this.referBackCount = referBackCount;
	}

	public String getLatestReferBackRemarks() {
		return latestReferBackRemarks;
	}

	public void setLatestReferBackRemarks(String latestReferBackRemarks) {
		this.latestReferBackRemarks = latestReferBackRemarks;
	}

	public String getFirst_ReferBack_DT() {
		return first_ReferBack_DT;
	}

	public void setFirst_ReferBack_DT(String first_ReferBack_DT) {
		this.first_ReferBack_DT = first_ReferBack_DT;
	}

	public String getLast_ReferBack_DT() {
		return last_ReferBack_DT;
	}

	public void setLast_ReferBack_DT(String last_ReferBack_DT) {
		this.last_ReferBack_DT = last_ReferBack_DT;
	}

	public String getFirst_BSD_DT() {
		return first_BSD_DT;
	}

	public void setFirst_BSD_DT(String first_BSD_DT) {
		this.first_BSD_DT = first_BSD_DT;
	}

	public String getLast_BSD_DT() {
		return last_BSD_DT;
	}

	public void setLast_BSD_DT(String last_BSD_DT) {
		this.last_BSD_DT = last_BSD_DT;
	}

	public String getFirst_Resubmission_dt() {
		return first_Resubmission_dt;
	}

	public void setFirst_Resubmission_dt(String first_Resubmission_dt) {
		this.first_Resubmission_dt = first_Resubmission_dt;
	}

	public String getLast_Resubmission_dt() {
		return last_Resubmission_dt;
	}

	public void setLast_Resubmission_dt(String last_Resubmission_dt) {
		this.last_Resubmission_dt = last_Resubmission_dt;
	}

	public String getLatestReferBackBy() {
		return latestReferBackBy;
	}

	public void setLatestReferBackBy(String latestReferBackBy) {
		this.latestReferBackBy = latestReferBackBy;
	}

	public String getApprover1() {
		return approver1;
	}

	public void setApprover1(String approver1) {
		this.approver1 = approver1;
	}

	public String getApproved1_By() {
		return approved1_By;
	}

	public void setApproved1_By(String approved1_By) {
		this.approved1_By = approved1_By;
	}

	public String getApprover1_dt() {
		return approver1_dt;
	}

	public void setApprover1_dt(String approver1_dt) {
		this.approver1_dt = approver1_dt;
	}

	public String getApprover2() {
		return approver2;
	}

	public void setApprover2(String approver2) {
		this.approver2 = approver2;
	}

	public String getApproved2_By() {
		return approved2_By;
	}

	public void setApproved2_By(String approved2_By) {
		this.approved2_By = approved2_By;
	}

	public String getApprover2_dt() {
		return approver2_dt;
	}

	public void setApprover2_dt(String approver2_dt) {
		this.approver2_dt = approver2_dt;
	}

	public String getApprover3() {
		return approver3;
	}

	public void setApprover3(String approver3) {
		this.approver3 = approver3;
	}

	public String getApprover3_dt() {
		return approver3_dt;
	}

	public void setApprover3_dt(String approver3_dt) {
		this.approver3_dt = approver3_dt;
	}

	public String getTPAllowed() {
		return TPAllowed;
	}

	public void setTPAllowed(String tPAllowed) {
		TPAllowed = tPAllowed;
	}

	public String getForceFull_Final_Select() {
		return forceFull_Final_Select;
	}

	public void setForceFull_Final_Select(String forceFull_Final_Select) {
		this.forceFull_Final_Select = forceFull_Final_Select;
	}

	public String getFinal_Select_After_ShortList() {
		return final_Select_After_ShortList;
	}

	public void setFinal_Select_After_ShortList(
			String final_Select_After_ShortList) {
		this.final_Select_After_ShortList = final_Select_After_ShortList;
	}

	public String getReasonCodeforL4JobFamily() {
		return reasonCodeforL4JobFamily;
	}

	public void setReasonCodeforL4JobFamily(String reasonCodeforL4JobFamily) {
		this.reasonCodeforL4JobFamily = reasonCodeforL4JobFamily;
	}

	public String getOldBillingStartDate() {
		return oldBillingStartDate;
	}

	public void setOldBillingStartDate(String oldBillingStartDate) {
		this.oldBillingStartDate = oldBillingStartDate;
	}

	public String getOldPositionEndDate() {
		return oldPositionEndDate;
	}

	public void setOldPositionEndDate(String oldPositionEndDate) {
		this.oldPositionEndDate = oldPositionEndDate;
	}

	public String getOldValidTillDate() {
		return oldValidTillDate;
	}

	public void setOldValidTillDate(String oldValidTillDate) {
		this.oldValidTillDate = oldValidTillDate;
	}

	public String getTotalExtCandAttached() {
		return totalExtCandAttached;
	}

	public void setTotalExtCandAttached(String totalExtCandAttached) {
		this.totalExtCandAttached = totalExtCandAttached;
	}

	public String getvAdditionalRemarks() {
		return vAdditionalRemarks;
	}

	public void setvAdditionalRemarks(String vAdditionalRemarks) {
		this.vAdditionalRemarks = vAdditionalRemarks;
	}

	public String getActionTakenBy() {
		return actionTakenBy;
	}

	public void setActionTakenBy(String actionTakenBy) {
		this.actionTakenBy = actionTakenBy;
	}

	public String getPullbackBy() {
		return pullbackBy;
	}

	public void setPullbackBy(String pullbackBy) {
		this.pullbackBy = pullbackBy;
	}

	public String getPullbackReason() {
		return pullbackReason;
	}

	public void setPullbackReason(String pullbackReason) {
		this.pullbackReason = pullbackReason;
	}

	public String getPullbackRemarks() {
		return pullbackRemarks;
	}

	public void setPullbackRemarks(String pullbackRemarks) {
		this.pullbackRemarks = pullbackRemarks;
	}

	public String getActualTP1TP2() {
		return actualTP1TP2;
	}

	public void setActualTP1TP2(String actualTP1TP2) {
		this.actualTP1TP2 = actualTP1TP2;
	}

	public String getReportingManager() {
		return reportingManager;
	}

	public void setReportingManager(String reportingManager) {
		this.reportingManager = reportingManager;
	}

	public String getReferBackAgeingLessThan2Days() {
		return referBackAgeingLessThan2Days;
	}

	public void setReferBackAgeingLessThan2Days(
			String referBackAgeingLessThan2Days) {
		this.referBackAgeingLessThan2Days = referBackAgeingLessThan2Days;
	}

	public String getReferBackAgeingGreaterThan2Days() {
		return referBackAgeingGreaterThan2Days;
	}

	public void setReferBackAgeingGreaterThan2Days(
			String referBackAgeingGreaterThan2Days) {
		this.referBackAgeingGreaterThan2Days = referBackAgeingGreaterThan2Days;
	}

	public String getTargetDeviation() {
		return targetDeviation;
	}

	public void setTargetDeviation(String targetDeviation) {
		this.targetDeviation = targetDeviation;
	}

	public String getExceptionallyApproved() {
		return exceptionallyApproved;
	}

	public void setExceptionallyApproved(String exceptionallyApproved) {
		this.exceptionallyApproved = exceptionallyApproved;
	}

	@Override
	public String toString() {
		return "SmartRecruit [reqNo=" + reqNo + ", joiningLevel1="
				+ joiningLevel1 + ", joiningLevel2=" + joiningLevel2
				+ ", joiningLevel3=" + joiningLevel3 + ", joiningLevel4="
				+ joiningLevel4 + ", initiator=" + initiator + ", status="
				+ status + ", reason=" + reason + ", pendingWith="
				+ pendingWith + ", primarySkills=" + primarySkills
				+ ", secondarySkills=" + secondarySkills
				+ ", primarySkillCategory=" + primarySkillCategory
				+ ", primarySkillArea=" + primarySkillArea + ", customer="
				+ customer + ", customerCode=" + customerCode
				+ ", projectCategory=" + projectCategory + ", project="
				+ project + ", projectCode=" + projectCode + ", projectL1="
				+ projectL1 + ", projectL4=" + projectL4
				+ ", projectArchetype=" + projectArchetype + ", band=" + band
				+ ", subBand=" + subBand + ", designation=" + designation
				+ ", experience=" + experience + ", tRating=" + tRating
				+ ", pendingWithNameAndID=" + pendingWithNameAndID
				+ ", jobFamily=" + jobFamily + ", job=" + job
				+ ", jobDescription=" + jobDescription + ", country=" + country
				+ ", personalArea=" + personalArea + ", personalSubArea="
				+ personalSubArea + ", oNBoardingDate=" + oNBoardingDate
				+ ", reqDate=" + reqDate + ", approvalDate=" + approvalDate
				+ ", requisitionSource=" + requisitionSource
				+ ", employeeGroup=" + employeeGroup + ", billingType="
				+ billingType + ", billingStartDate=" + billingStartDate
				+ ", age=" + age + ", vacancy=" + vacancy
				+ ", internal_Filled=" + internal_Filled
				+ ", external_Offered=" + external_Offered
				+ ", external_Joined=" + external_Joined
				+ ", TPG_To_TAG_Assign_dt=" + TPG_To_TAG_Assign_dt
				+ ", TAG_Exe_Assign_dt=" + TAG_Exe_Assign_dt
				+ ", initiatorLevel1=" + initiatorLevel1 + ", initiatorLevel2="
				+ initiatorLevel2 + ", initiatorLevel3=" + initiatorLevel3
				+ ", initiatorLevel4=" + initiatorLevel4 + ", req_Close_dt="
				+ req_Close_dt + ", closure_Remarks=" + closure_Remarks
				+ ", closed_By=" + closed_By + ", req_Resubmission_dt="
				+ req_Resubmission_dt + ", balance_Postions="
				+ balance_Postions + ", offer_Declined=" + offer_Declined
				+ ", total_Attached=" + total_Attached + ", total_forwarded="
				+ total_forwarded + ", total_Blocked=" + total_Blocked
				+ ", total_Rejected=" + total_Rejected + ", total_Shortlisted="
				+ total_Shortlisted + ", total_Final_Select="
				+ total_Final_Select + ", internal_Filled_SAP_Codes="
				+ internal_Filled_SAP_Codes + ", position_End_Date="
				+ position_End_Date + ", internal_Filled_SAP_Codes1="
				+ internal_Filled_SAP_Codes1 + ", actionable_Position="
				+ actionable_Position + ", valid_Till_Date=" + valid_Till_Date
				+ ", initialSourceByFinalApprover="
				+ initialSourceByFinalApprover + ", bservSource=" + bservSource
				+ ", initialDemand=" + initialDemand + ", droppedPos="
				+ droppedPos + ", client_Interview=" + client_Interview
				+ ", BGV=" + BGV + ", TP1=" + TP1 + ", TP2=" + TP2
				+ ", projectArchetype1=" + projectArchetype1
				+ ", referBackCount=" + referBackCount
				+ ", latestReferBackRemarks=" + latestReferBackRemarks
				+ ", first_ReferBack_DT=" + first_ReferBack_DT
				+ ", last_ReferBack_DT=" + last_ReferBack_DT
				+ ", first_BSD_DT=" + first_BSD_DT + ", last_BSD_DT="
				+ last_BSD_DT + ", first_Resubmission_dt="
				+ first_Resubmission_dt + ", last_Resubmission_dt="
				+ last_Resubmission_dt + ", latestReferBackBy="
				+ latestReferBackBy + ", approver1=" + approver1
				+ ", approved1_By=" + approved1_By + ", approver1_dt="
				+ approver1_dt + ", approver2=" + approver2 + ", approved2_By="
				+ approved2_By + ", approver2_dt=" + approver2_dt
				+ ", approver3=" + approver3 + ", approver3_dt=" + approver3_dt
				+ ", TPAllowed=" + TPAllowed + ", forceFull_Final_Select="
				+ forceFull_Final_Select + ", final_Select_After_ShortList="
				+ final_Select_After_ShortList + ", reasonCodeforL4JobFamily="
				+ reasonCodeforL4JobFamily + ", oldBillingStartDate="
				+ oldBillingStartDate + ", oldPositionEndDate="
				+ oldPositionEndDate + ", oldValidTillDate=" + oldValidTillDate
				+ ", totalExtCandAttached=" + totalExtCandAttached
				+ ", vAdditionalRemarks=" + vAdditionalRemarks
				+ ", actionTakenBy=" + actionTakenBy + ", pullbackBy="
				+ pullbackBy + ", pullbackReason=" + pullbackReason
				+ ", pullbackRemarks=" + pullbackRemarks + ", actualTP1TP2="
				+ actualTP1TP2 + ", reportingManager=" + reportingManager
				+ ", referBackAgeingLessThan2Days="
				+ referBackAgeingLessThan2Days
				+ ", referBackAgeingGreaterThan2Days="
				+ referBackAgeingGreaterThan2Days + ", targetDeviation="
				+ targetDeviation + ", exceptionallyApproved="
				+ exceptionallyApproved + "]";
	}

}

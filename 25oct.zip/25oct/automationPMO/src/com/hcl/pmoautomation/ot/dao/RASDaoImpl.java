package com.hcl.pmoautomation.ot.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;

public class RASDaoImpl implements RASDao{

	@Override
	public boolean saveRASDumpData(
			List<ArrayList<String>> readExcelAllDynamically,
			String rasTableName, JdbcTemplate jdbcTemplate) 
	{

		// JdbcTemplate jdbcTemplate = new JdbcTemplate();
		int count = 0;
		boolean resultFlag = false;
		String[] returnData = null;
		List<Map<String, Object>> columnNames = getAllColumnNamesDynamically(
				rasTableName, jdbcTemplate);

		StringBuilder sqlQuery = new StringBuilder();
		//sqlQuery = sqlQuery.append("insert into " + rasTableName + "(");
		sqlQuery = sqlQuery.append("call RAS  (");
/*
		for (Map columnMapRowData : columnNames) {
			String tempData = (String) columnMapRowData.get("column_name");

			if (count == columnNames.size() - 1) {
				sqlQuery.append("`" + tempData.trim() + "`,`MODIFIED_DATE`) values (");
				break;
			}
			sqlQuery.append("`" + tempData.trim() + "`,");

			count++;
		}*/

		// For Adding the Values
		count = 0;
		
		for (Map columnMapRowData : columnNames) 
		{
			System.out.println("Index:" + count + " Value:"+columnMapRowData);
			if (count == columnNames.size() -1 ) {
				//sqlQuery.append("?" + ",?)");
				sqlQuery.append("?" +")");
				break;
			}
			sqlQuery.append("?" + ",");

			count++;
		}
		//
		System.out.println("sqlQuery 1 :" + sqlQuery);
		// final Object[] objects =
		// setAllDataDynamically(readExcelAllDynamically,
		// columnNames);
		final List<Object[]> objects2 = setAllDataDynamically(
				readExcelAllDynamically, columnNames);
		/*for (ArrayList<String> ps : readExcelAllDynamically) {
			// System.out.println(ps);
		}
		for (Object[] objects : objects2) {
			System.out.println(Arrays.toString(objects));
		}*/
		// System.out.println("Size :" + objects2.size());
		final List<String> columnDataTypes = new ArrayList<String>();
	
		for (Map map : columnNames) 
		{
			columnDataTypes.add((String) map.get("COLUMN_DATATYPE"));
		}
		try {
			// resultFlag= jdbcTemplate.update(
			// sqlQuery.toString(),
			// setAllDataDynamically(readExcelAllDynamically,
			// columnNames))>0?true:false;
			System.out.println("sqlQuery 2:"+sqlQuery);

			resultFlag = (jdbcTemplate.batchUpdate(sqlQuery.toString(),
					new BatchPreparedStatementSetter() 
			{

						@Override
						public void setValues(java.sql.PreparedStatement ps,
								int j) throws SQLException {
							Object[] objects = objects2.get(j);

							// System.out.println(j);
							/*ps.setInt(1, (int) objects[0]);
							ps.setString(2, (String) objects[1]);
							ps.setString(3, (String) objects[2]);
							ps.setString(4, (String) objects[3]);
							ps.setString(5, (String) objects[4]);
							//ps.setString(6, (String) objects[5]);
							if (!(objects[5] == null)) {
								ps.setDate(6, new java.sql.Date(
										((Date) objects[5]).getTime()));
							}
							ps.setString(7, (String) objects[6]);							
							ps.setInt(8, (int) objects[7]);
							ps.setString(9, (String) objects[8]);
							ps.setInt(10, (int) objects[9]);
							ps.setInt(11, (int) objects[10]);
							ps.setInt(12, (int) objects[11]);
							ps.setInt(13, (int) objects[12]);
							ps.setInt(14, (int) objects[13]);
							ps.setString(15, (String) objects[14]);
							ps.setString(16, (String) objects[15]);
							ps.setString(17, (String) objects[16]);
							ps.setString(18, (String) objects[17]);
							ps.setString(19, (String) objects[18]);
							ps.setInt(20, (int) objects[19]);
							ps.setString(21, (String) objects[20]);
							ps.setString(22, (String) objects[21]);
							
							if ((objects[21] == null)) {
								ps.setDate(22, null);
							}
							//ps.setString(22, (Date) objects[21]);
							if (!(objects[22] == null)) {
								ps.setDate(23, new java.sql.Date(
										((Date) objects[22]).getTime()));
							}
							if ((objects[22] == null)) {
								ps.setDate(23, null);
							}
							//ps.setString(23, (Date) objects[22]);
							if (!(objects[23] == null)) {
								ps.setDate(24, new java.sql.Date(
										((Date) objects[23]).getTime()));
							}
							if ((objects[23] == null)) {
								ps.setDate(24, null);
							}
							//ps.setString(24, (Date) objects[23]);
							//ps.setInt(25, (int) objects[24]);
							if (!(objects[24] == null)) {
								ps.setDate(25, new java.sql.Date(
										((Date) objects[24]).getTime()));
							}
							if ((objects[24] == null)) {
								ps.setDate(25, null);
							}
							ps.setInt(26, (int) objects[25]);
							ps.setString(27, (String) objects[26]);
							ps.setInt(28, (int) objects[27]);
							ps.setString(29, (String) objects[28]);
							ps.setInt(30, (int) objects[29]);
							ps.setString(31, (String) objects[30]);
							ps.setInt(32, (int) objects[31]);
							ps.setInt(33, (int) objects[32]);
							ps.setInt(34, (int) objects[33]);
							ps.setInt(35, (int) objects[34]);
							ps.setString(36, (String) objects[35]);
							ps.setInt(37, (int) objects[36]);
							ps.setString(38, (String) objects[37]);
							ps.setInt(39, (int) objects[38]);
							ps.setString(40, (String) objects[39]);
							ps.setString(41, (String) objects[40]);
							ps.setString(42, (String) objects[41]);
							ps.setInt(43, (int) objects[42]);
							ps.setInt(44, (int) objects[43]);*/
						
							
							if (!(objects[0] == null)) {
								ps.setDate(1, new java.sql.Date(
										((Date) objects[0]).getTime()));
							}
							if ((objects[0] == null)) {
								ps.setDate(1, null);
							}
							ps.setString(2, (String) objects[1]);
							ps.setInt(3, (int) objects[2]);
							ps.setString(4, (String) objects[3]);
							ps.setString(5, (String) objects[4]);
							ps.setString(6, (String) objects[5]);
							ps.setString(7, (String) objects[6]);
							ps.setInt(8, (int) objects[7]);
							ps.setString(9, (String) objects[8]);
							ps.setInt(10, (int) objects[9]);
							ps.setInt(11, (int) objects[10]);
							ps.setInt(12, (int) objects[11]);
							ps.setInt(13, (int) objects[12]);
							ps.setInt(14, (int) objects[13]);
							ps.setString(15, (String) objects[14]);
							ps.setString(16, (String) objects[15]);
							ps.setString(17, (String) objects[16]);
							ps.setString(18, (String) objects[17]);
							ps.setString(19, (String) objects[18]);
							ps.setInt(20, (int) objects[19]);
							ps.setString(21, (String) objects[20]);
							ps.setString(22, (String) objects[21]);
							if (!(objects[22] == null)) {
								ps.setDate(23, new java.sql.Date(
										((Date) objects[22]).getTime()));
							}
							if ((objects[22] == null)) {
								ps.setDate(23, null);
							}
							if (!(objects[23] == null)) {
								ps.setDate(24, new java.sql.Date(
										((Date) objects[23]).getTime()));
							}
							if ((objects[23] == null)) {
								ps.setDate(24, null);
							}
							if (!(objects[24] == null)) {
								ps.setDate(25, new java.sql.Date(
										((Date) objects[24]).getTime()));
							}
							if ((objects[24] == null)) {
								ps.setDate(25, null);
							}
							ps.setInt(26, (int) objects[25]);
							ps.setString(27, (String) objects[26]);
							ps.setInt(28, (int) objects[27]);
							ps.setString(29, (String) objects[28]);
							ps.setInt(30, (int) objects[29]);
							ps.setString(31, (String) objects[30]);
							ps.setInt(32, (int) objects[31]);
							ps.setInt(33, (int) objects[32]);
							ps.setInt(34, (int) objects[33]);
							ps.setInt(35, (int) objects[34]);
							ps.setString(36, (String) objects[35]);
							ps.setInt(37, (int) objects[36]);
							ps.setString(38, (String) objects[37]);
							ps.setInt(39, (int) objects[38]);
							ps.setString(40, (String) objects[39]);
							ps.setString(41, (String) objects[40]);
							ps.setString(42, (String) objects[41]);
							ps.setInt(43, (int) objects[42]);
							
						}
						
						

						@Override
						public int getBatchSize() 
						{

							return objects2.size();
						}
					})).length >=1 ? true : false;

		} catch (Exception e) {
			
			e.printStackTrace();
		}

		// TODO:LOGIC TO SENT MAIL

		return resultFlag;

	}

	
	public List<Map<String, Object>> getAllColumnNamesDynamically(
			String tableName, JdbcTemplate jdbcTemplate) 
	{
		System.out.println("Table Name : " + tableName);

		String queryToFetchColumns = DatabaseQuery.QUERY_FETCH_COLUMNS1
				+ tableName + DatabaseQuery.QUERY_FETCH_COLUMNS2;

		System.out.println("queryToFetchColumns:" + queryToFetchColumns);
		// jdbcTemplate=new JdbcTemplate();
		// System.out.println(getJdbcTemplate());
		return jdbcTemplate.queryForList(queryToFetchColumns);
	}
	
	@SuppressWarnings("deprecation")
	private List<Object[]> setAllDataDynamically(
			
			List<ArrayList<String>> arrayLists,
			List<Map<String, Object>> columnNames) 
	{
		List<Object[]> objects = new ArrayList<Object[]>();
		Object[] objectData = null;
		// ArrayList<String> excaliburData = arrayLists.get(0);
		// System.out.println(excaliburData);
		// System.out.println(arrayLists.size());
		int tempCount = 0;
		for (ArrayList<String> excaliburData : arrayLists) 
		{
			objectData = new Object[columnNames.size()];
			for (Map columnMapRowData : columnNames) {
//				 System.out.println(columnMapRowData);
				 System.out.println(excaliburData);
				if (((String) columnMapRowData.get("column_datatype"))
						.equalsIgnoreCase("STRING")) {
					objectData[tempCount] = excaliburData.get(tempCount);
				}
				if (((String) columnMapRowData.get("column_datatype"))
						.equalsIgnoreCase("INT")) {
					if (!(excaliburData.get(tempCount) == null)) {
						objectData[tempCount] = Integer.parseInt(excaliburData
								.get(tempCount));

					}
					if (excaliburData.get(tempCount) == null) {
						objectData[tempCount] = 0;
					}
				}
				if (((String) columnMapRowData.get("column_datatype"))
						.equalsIgnoreCase("Date")) {

					if (!(excaliburData.get(tempCount) == null)) {
						objectData[tempCount] = new Date(new java.util.Date(
								excaliburData.get(tempCount)).getTime());

					}

					if (excaliburData.get(tempCount) == null) {
						objectData[tempCount] = null;
					}
				}

				// System.out.println(objectData[tempCount]);
				tempCount++;

			}

			tempCount = 0;
			objects.add(objectData);

		}
		// System.out.println("Ending Setter");

		return objects;
	}


	@Override
	public List<Object[]> getRASDataWithNOSRMapped(JdbcTemplate jdbcTemplate,
			String pmCode) {
		List<Object[]> rasActualDataForPMName=new ArrayList<Object[]>();
		List<Map<String, Object>> rasDataForPMName=jdbcTemplate.queryForList(DatabaseQuery.QUERY_TO_FETCH_RAS_HAVING_PM,new Object[]{Integer.parseInt(pmCode),Integer.parseInt(pmCode)});
		Object[] objects=null;
		
		for(Map<String,Object> ras:rasDataForPMName){
			
			objects=new Object[12];
			
			objects[0]=(int)ras.get("SAPCODE");
			objects[1]=(String)ras.get("EMPNAME");
			objects[2]=(String)ras.get("BAND");
			objects[3]=(String)ras.get("FRESHER_LATERAL_TP");
			objects[4]=(String)ras.get("DESIG");
			objects[5]=(int)ras.get("REP_MGR_CODE");
			objects[6]=(String)ras.get("REP_MGR_NAME");
			objects[7]=(int)ras.get("TOTAL_EXPERIENCE");
			objects[8]=(String)ras.get("LOB_DESC");
			objects[9]=(String)ras.get("LOCATION");
			objects[10]=(String)ras.get("PROJECT_CODE");
			objects[11]=(String)ras.get("PROJECT_NAME");
			
			
			
	
			rasActualDataForPMName.add(objects);

			//RAS according to RAS Sheet
			//SRID -> ajax Primary Skill Secondary Skill
			
		}

				return rasActualDataForPMName;
		
		
	}


	@Override
	public boolean saveSRRASMapping(JdbcTemplate jdbcTemplate, int sapCode,String srID) {
	boolean flag=jdbcTemplate.update(DatabaseQuery.QUERY_TO_UPDATE_RAS_FOR_SAPID_WITH_SRID, new Object[]{srID,sapCode})>0?true:false;
		return flag;
	}
}

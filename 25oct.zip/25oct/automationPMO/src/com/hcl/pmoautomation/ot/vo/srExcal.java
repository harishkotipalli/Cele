package com.hcl.pmoautomation.ot.vo;

public class srExcal {
	private int PM_MAP_ID;
	private String EXCALIBUR_ID;
	private String SR_ID;
	private String ACCOUNT_MANAGER;
	private String projectcode;
	private String projectname;
	private String primaryskills;
	private String oppname;
	private String dm;
	
	
	public int getPM_MAP_ID() {
		return PM_MAP_ID;
	}
	public void setPM_MAP_ID(int pM_MAP_ID) {
		PM_MAP_ID = pM_MAP_ID;
	}
	public String getEXCALIBUR_ID() {
		return EXCALIBUR_ID;
	}
	public void setEXCALIBUR_ID(String eXCALIBUR_ID) {
		EXCALIBUR_ID = eXCALIBUR_ID;
	}
	public String getSR_ID() {
		return SR_ID;
	}
	public void setSR_ID(String sR_ID) {
		SR_ID = sR_ID;
	}
	public String getACCOUNT_MANAGER() {
		return ACCOUNT_MANAGER;
	}
	public void setACCOUNT_MANAGER(String aCCOUNT_MANAGER) {
		ACCOUNT_MANAGER = aCCOUNT_MANAGER;
	}
	public String getProjectcode() {
		return projectcode;
	}
	public void setProjectcode(String projectcode) {
		this.projectcode = projectcode;
	}
	public String getProjectname() {
		return projectname;
	}
	public void setProjectname(String projectname) {
		this.projectname = projectname;
	}
	public String getPrimaryskills() {
		return primaryskills;
	}
	public void setPrimaryskills(String primaryskills) {
		this.primaryskills = primaryskills;
	}
	public String getOppname() {
		return oppname;
	}
	public void setOppname(String oppname) {
		this.oppname = oppname;
	}
	
	public String getDm() {
		return dm;
	}
	public void setDm(String dm) {
		this.dm = dm;
	}
	@Override
	public String toString() {
		return "srExcal [PM_MAP_ID=" + PM_MAP_ID + ", EXCALIBUR_ID=" + EXCALIBUR_ID + ", SR_ID=" + SR_ID
				+ ", ACCOUNT_MANAGER=" + ACCOUNT_MANAGER + ", projectcode=" + projectcode + ", projectname="
				+ projectname + ", primaryskills=" + primaryskills + ", oppname=" + oppname + ", dm=" + dm + "]";
	}
	
	

}

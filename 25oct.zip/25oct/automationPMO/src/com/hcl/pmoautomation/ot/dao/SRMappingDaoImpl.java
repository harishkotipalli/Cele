package com.hcl.pmoautomation.ot.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Stack;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.catalina.connector.Request;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.hcl.pmoautomation.ot.vo.Excalibur;
import com.hcl.pmoautomation.ot.vo.SmartRecruit;
import com.hcl.pmoautomation.ot.vo.dmpmmap;
import com.hcl.pmoautomation.ot.vo.srExcal;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

public class SRMappingDaoImpl implements SRMappingDao {
	


	@Override
	public List<Excalibur> getExcaliburData(String loginname, JdbcTemplate jdbcTemplate) {
		
		
		List<Map<String, Object>> excaliburList = jdbcTemplate
				.queryForList(DatabaseQuery.QUERY_TO_FETCH_EXCALIBUR+loginname+"'");

		List<Excalibur> excaliburs = new ArrayList<Excalibur>();
		for (Map excaliburMapData : excaliburList) {

			Excalibur excalibur = new Excalibur();

			setExcaliburData(excalibur, excaliburMapData);
			excaliburs.add(excalibur);

		}

		return excaliburs;
	}

	private void setExcaliburData(Excalibur excalibur, Map excaliburMapData) {
		System.out.println(excaliburMapData);

		excalibur.setAccountManager((String) excaliburMapData
				.get("ACCOUNT_MANAGER"));
		excalibur.setDM((String) excaliburMapData.get("DM"));
		excalibur.setPM((String) excaliburMapData.get("PM_CM"));
		excalibur.setNew_opp_received_date((Date) excaliburMapData
				.get("NEW OPP RECEIVED DATE"));
		excalibur
				.setExcalinburID((String) excaliburMapData.get("EXCALIBUR_ID"));
		excalibur.setExcalinburDate((Date) excaliburMapData
				.get("EXCALIBUR_DATE"));
		excalibur.setOpportunityName(((String) excaliburMapData
				.get("OPPORTUNITY_NAME")));
		excalibur
				.setLevelL4_L0((String) excaliburMapData.get("LEVEL[L4 - L0]"));
		excalibur.setOpportunityType((String) excaliburMapData.get("OPP_TYPE"));
		excalibur.setRequisitionSource((String) excaliburMapData
				.get("REQUISITION_SOURCE"));
		excalibur.setClassification((String) excaliburMapData
				.get("CLASSIFICATION"));
		excalibur.setComponent((String) excaliburMapData.get("COMPONENT"));
		excalibur.setLocation((String) excaliburMapData.get("LOCATION"));
		excalibur.setSR_Type((String) excaliburMapData.get("SR_TYPE"));
		excalibur.setBAND((String) excaliburMapData.get("BAND"));
		excalibur.setBSD((Date) excaliburMapData.get("BSD"));
	//	excalibur.setExperience((int) excaliburMapData
		//		.get("EXPERIENCE(IN_YEARS)"));
		excalibur.setPrimarySkill((String) excaliburMapData
				.get("PRIMARY_SKILL"));
		excalibur.setSecondarySkill((String) excaliburMapData
				.get("SECONDARY_SKILL"));
		excalibur.setRole((String) excaliburMapData.get("ROLE"));
		excalibur.setDetailedJD((String) excaliburMapData
				.get("DETAILED_JOB_DESC"));
		excalibur.setRemarks((String) excaliburMapData.get("REMARKS"));
		excalibur.setTcvcurrency((int) excaliburMapData.get("TCV(K)_CURRENCY"));
		excalibur.setTcvconverted((String) excaliburMapData.get("TCV_CONVERTED"));
		excalibur.setPropability((int) excaliburMapData.get("PROBABILITY"));
		excalibur.setBillingmodel((String) excaliburMapData.get("BILLING_MODEL"));
		
		/*excalibur
				.setInitialDemand((int) excaliburMapData.get("INITIAL_DEMAND"));
		excalibur
				.setDroppedDemand((int) excaliburMapData.get("DROPPED_DEMAND"));
		excalibur
				.setCurrentDemand((int) excaliburMapData.get("CURRENT_DEMAND"));
		excalibur.setBalancePositions((int) excaliburMapData
				.get("BALANCE_POSITIONS"));
		excalibur.setFullfilledDemand((int) excaliburMapData
				.get("FULFILLED_DEMAND"));
		excalibur.setHCLOnboarded((String) excaliburMapData
				.get("HCL Onboarded"));*/
		excalibur.setSl_no((int) excaliburMapData.get("sl_no"));

	}

	@Override
	public List<String> getMappedPM(String DMName, JdbcTemplate jdbcTemplate) {

		String sqlQuery = DatabaseQuery.QUERY_TO_FETCH_PM_NAMES + DMName + "%'";
		System.out.println(sqlQuery);
		List<String> pmNameList = jdbcTemplate.query(sqlQuery,
				new RowMapper<String>() {
					public String mapRow(ResultSet rs, int rowNum)
							throws SQLException {
						return rs.getString(1);
					}
				});

		return pmNameList;
	}

	
	
	
	
	
	    
	
	
	
	
	
	@Override
	public List<String> fetchPMName() {
		Connection connection = DatabaseUtil.getConnection();

		List<String> pmNames = new ArrayList<String>();
		ArrayList<String> tempData = new ArrayList<String>();
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;

		try {
			preparedStatement = (PreparedStatement) connection
					.prepareStatement(DatabaseQuery.QUERY_TO_FETCH_PM_NAMES);
			resultSet = preparedStatement.executeQuery();
			//System.out.println(preparedStatement);
			while (resultSet.next()) {
				// System.out.println("TTTTTTTTTTTTT");

				pmNames.add(resultSet.getString(1));

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return pmNames;
	}

	@Override
	public boolean saveExcalibur(String parameter, String excaliburID,
			JdbcTemplate jdbcTemplate) {
		Connection connection = DatabaseUtil.getConnection();

		boolean result = jdbcTemplate
				.update(DatabaseQuery.QUERY_TO_UPDATE_EXCALIBUR1 + parameter
						+ DatabaseQuery.QUERY_TO_UPDATE_EXCALIBUR2
						+ excaliburID + "'") > 0 ? true : false;
		return result;

	}

	@Override
	public boolean saveSRDumpData(
			List<ArrayList<String>> readExcelAllDynamically,
			String srTableName, JdbcTemplate jdbcTemplate) {

		// JdbcTemplate jdbcTemplate = new JdbcTemplate();
		int count = 0;
		boolean resultFlag = false;
		String[] returnData = null;
		List<Map<String, Object>> columnNames = getAllColumnNamesDynamically(
				srTableName, jdbcTemplate);

		StringBuilder sqlQuery = new StringBuilder();
		//sqlQuery = sqlQuery.append("insert into " + srTableName + "(");
		sqlQuery = sqlQuery.append("call SR  (");

		/*for (Map columnMapRowData : columnNames) {
			String tempData = (String) columnMapRowData.get("column_name");

			if (count == columnNames.size() - 1) {
				sqlQuery.append("`" + tempData.trim() + "`,`MODIFIED_DATE`) values (");
				break;
			}
			sqlQuery.append("`" + tempData.trim() + "`,");

			count++;
		}*/

		// For Adding the Values
		count = 0;
		for (Map columnMapRowData : columnNames) {
			
			if (count == columnNames.size() - 1) {
				
				//sqlQuery.append("?" + ",?)");
				sqlQuery.append("?" +")");
				break;
			}
			sqlQuery.append("?" + ",");
			

			count++;
		}
		
		// final Object[] objects =
		// setAllDataDynamically(readExcelAllDynamically,
		// columnNames);
		final List<Object[]> objects2 = setAllDataDynamically(
				readExcelAllDynamically, columnNames);
		for (ArrayList<String> ps : readExcelAllDynamically) {
			// System.out.println(ps);
		}
		for (Object[] objects : objects2) {
//			System.out.println(Arrays.toString(objects));
		}
		
		final List<String> columnDataTypes = new ArrayList<String>();
		

		for (Map map : columnNames) {
			columnDataTypes.add((String) map.get("COLUMN_DATATYPE"));
		}
		try {
			// resultFlag= jdbcTemplate.update(
			// sqlQuery.toString(),
			// setAllDataDynamically(readExcelAllDynamically,
			// columnNames))>0?true:false;

			resultFlag = (jdbcTemplate.batchUpdate(sqlQuery.toString(),
					new BatchPreparedStatementSetter() {

						@Override
						public void setValues(java.sql.PreparedStatement ps,
								int j) throws SQLException {

							Object[] objects = objects2.get(j);
							
							ps.setString(1, (String) objects[0]);
							ps.setString(2, (String) objects[1]);
							ps.setString(3, (String) objects[2]);
							ps.setString(4, (String) objects[3]);
							ps.setString(5, (String) objects[4]);
							ps.setString(6, (String) objects[5]);
							ps.setString(7, (String) objects[6]);
							ps.setString(8, (String) objects[7]);
							ps.setString(9, (String) objects[8]);
							ps.setString(10, (String) objects[9]);
							ps.setString(11, (String) objects[10]);
							ps.setString(12, (String) objects[11]);
							ps.setString(13, (String) objects[12]);
							ps.setString(14, (String) objects[13]);
							ps.setInt(15, (int) objects[14]);
							ps.setString(16, (String) objects[15]);
							ps.setString(17, (String) objects[16]);
							ps.setString(18, (String) objects[17]);
							ps.setString(19, (String) objects[18]);
							ps.setString(20, (String) objects[19]);
							ps.setString(21, (String) objects[20]);
							ps.setString(22, (String) objects[21]);
							ps.setString(23, (String) objects[22]);
							ps.setString(24, (String) objects[23]);
							ps.setString(25, (String) objects[24]);
							ps.setString(26, (String) objects[25]);
							ps.setString(27, (String) objects[26]);
							ps.setString(28, (String) objects[27]);
							ps.setString(29, (String) objects[28]);
							ps.setString(30, (String) objects[29]);
							ps.setString(31, (String) objects[30]);
							ps.setString(32, (String) objects[31]);
							ps.setString(33, (String) objects[32]);
							if (!(objects[33] == null)) {
								ps.setDate(34, new java.sql.Date(
										((Date) objects[33]).getTime()));
							}
							if ((objects[33] == null)) {
								ps.setDate(34, null);
							}
							if (!(objects[34] == null)) {
								ps.setDate(35, new java.sql.Date(
										((Date) objects[34]).getTime()));
							}
							if ((objects[34] == null)) {
								ps.setDate(35, null);
							}
							if (!(objects[35] == null)) {
								ps.setDate(36, new java.sql.Date(
										((Date) objects[35]).getTime()));
							}
							if ((objects[35] == null)) {
								ps.setDate(36, null);
							}

							ps.setString(37, (String) objects[36]);
							ps.setString(38, (String) objects[37]);
							ps.setString(39, (String) objects[38]);
							if (!(objects[39] == null)) {
								ps.setDate(40, new java.sql.Date(
										((Date) objects[39]).getTime()));
							}
							if ((objects[39] == null)) {
								ps.setDate(40, null);
							}

							ps.setInt(41, (int) objects[40]);
							ps.setInt(42, (int) objects[41]);
							ps.setInt(43, (int) objects[42]);
							ps.setInt(44, (int) objects[43]);
							ps.setInt(45, (int) objects[44]);
							
							if (!(objects[45] == null)) {
								ps.setDate(46, new java.sql.Date(
										((Date) objects[45]).getTime()));
							}
							if ((objects[45] == null)) {
								ps.setDate(46, null);
							}

							if (!(objects[46] == null)) {
								ps.setDate(47, new java.sql.Date(
										((Date) objects[46]).getTime()));
							}
							if ((objects[46] == null)) {
								ps.setDate(47, null);
							}
							
							ps.setString(48, (String) objects[47]);
							ps.setString(49, (String) objects[48]);
							ps.setString(50, (String) objects[49]);
							ps.setString(51, (String) objects[50]);
							

							if (!(objects[51] == null)) {
								ps.setDate(52, new java.sql.Date(
										((Date) objects[51]).getTime()));
							}
							if ((objects[51] == null)) {
								ps.setDate(52, null);
							}

							ps.setString(53, (String) objects[52]);
							ps.setString(54, (String) objects[53]);

							if (!(objects[54] == null)) {
								ps.setDate(55, new java.sql.Date(
										((Date) objects[54]).getTime()));
							}
							if ((objects[54] == null)) {
								ps.setDate(55, null);
							}
							

							ps.setInt(56, (int) objects[55]);
							ps.setInt(57, (int) objects[56]);
							ps.setInt(58, (int) objects[57]);
							ps.setInt(59, (int) objects[58]);
							ps.setInt(60, (int) objects[59]);
							ps.setInt(61, (int) objects[60]);
							ps.setInt(62, (int) objects[61]);
							ps.setInt(63, (int) objects[62]);
							
							ps.setString(64, (String) objects[63]);
							if (!(objects[64] == null)) {
								ps.setDate(65, new java.sql.Date(
										((Date) objects[64]).getTime()));
							}
							if ((objects[64] == null)) {
								ps.setDate(65, null);
							}

							ps.setString(66, (String) objects[65]);
							ps.setInt(67, (int) objects[66]);
							if (!(objects[67] == null)) {
								ps.setDate(68, new java.sql.Date(
										((Date) objects[67]).getTime()));
							}
							if ((objects[67] == null)) {
								ps.setDate(68, null);
							}
							
							ps.setString(69, (String) objects[68]);
							ps.setString(70, (String) objects[69]);
							ps.setInt(71, (int) objects[70]);
							ps.setInt(72, (int) objects[71]);
							ps.setString(73, (String) objects[72]);
							ps.setString(74, (String) objects[73]);
							ps.setString(75, (String) objects[74]);
							ps.setString(76, (String) objects[75]);
							ps.setString(77, (String) objects[76]);
							ps.setInt(78, (int) objects[77]);
							ps.setString(79, (String) objects[78]);

							if (!(objects[79] == null)) {
								ps.setDate(80, new java.sql.Date(
										((Date) objects[79]).getTime()));
							}
							if ((objects[79] == null)) {
								ps.setDate(80, null);
							}
							
							if (!(objects[80] == null)) {
								ps.setDate(81, new java.sql.Date(
										((Date) objects[80]).getTime()));
							}
							if ((objects[80] == null)) {
								ps.setDate(81, null);
							}
							
							if (!(objects[81] == null)) {
								ps.setDate(82, new java.sql.Date(
								((Date) objects[81]).getTime()));
							}
							if ((objects[81] == null)) {
								ps.setDate(82, null);
							}
							
							if (!(objects[82] == null)) {
								ps.setDate(83, new java.sql.Date(
								((Date) objects[82]).getTime()));
							}
							if ((objects[82] == null)) {
								ps.setDate(83, null);
							}
							
							if (!(objects[83] == null)) {
								ps.setDate(84, new java.sql.Date(
								((Date) objects[83]).getTime()));
							}
							if ((objects[83] == null)) {
								ps.setDate(84, null);
							}
							
							if (!(objects[84] == null)) {
								ps.setDate(85, new java.sql.Date(
								((Date) objects[84]).getTime()));
							}
							if ((objects[84] == null)) {
								ps.setDate(85, null);
							}
							
							ps.setString(86, (String) objects[85]);
							ps.setString(87, (String) objects[86]);
							
							ps.setString(88, (String) objects[87]);
							if (!(objects[88] == null)) {
								ps.setDate(89, new java.sql.Date(
										((Date) objects[88]).getTime()));
							}
							if ((objects[88] == null)) {
								ps.setDate(89, null);
							}
							
							ps.setString(90, (String) objects[89]);
							ps.setString(91, (String) objects[90]);
							if (!(objects[91] == null)) {
								ps.setDate(92, new java.sql.Date(
										((Date) objects[91]).getTime()));
							}
							if ((objects[91] == null)) {
								ps.setDate(92, null);
							}
							
							ps.setString(93, (String) objects[92]);
							if (!(objects[93] == null)) {
								ps.setDate(94, new java.sql.Date(
										((Date) objects[93]).getTime()));
							}
							if ((objects[93] == null)) {
								ps.setDate(94, null);
							}
							
							ps.setString(95, (String) objects[94]);
							ps.setString(96, (String) objects[95]);
							ps.setString(97, (String) objects[96]);
							ps.setString(98, (String) objects[97]);
							ps.setString(99, (String) objects[98]);
							ps.setString(100, (String) objects[99]);
							ps.setInt(101, (int) objects[100]);
							ps.setString(102, (String) objects[101]);
							//ps.setDate(113,  new java.sql.Date(new java.util.Date().getTime()));
							// System.out.println(ps);

						}

						@Override
						public int getBatchSize() {

							return objects2.size();
						}
					})).length >=1 ? true : false;

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		// TODO:LOGIC TO SENT MAIL

		return resultFlag;

	}

	public List<Map<String, Object>> getAllColumnNamesDynamically(
			String tableName, JdbcTemplate jdbcTemplate) {

		String queryToFetchColumns = DatabaseQuery.QUERY_FETCH_COLUMNS1
				+ tableName + DatabaseQuery.QUERY_FETCH_COLUMNS2;

		System.out.println(queryToFetchColumns);
		// jdbcTemplate=new JdbcTemplate();
		// System.out.println(getJdbcTemplate());
		return jdbcTemplate.queryForList(queryToFetchColumns);
	}

	@SuppressWarnings("deprecation")
	private List<Object[]> setAllDataDynamically(
			List<ArrayList<String>> arrayLists,
			List<Map<String, Object>> columnNames) {
		List<Object[]> objects = new ArrayList<Object[]>();
		Object[] objectData = null;
		// ArrayList<String> excaliburData = arrayLists.get(0);
		// System.out.println(excaliburData);
		// System.out.println(arrayLists.size());
		int tempCount = 0;
		for (ArrayList<String> excaliburData : arrayLists) {
			objectData = new Object[columnNames.size()];
			for (Map columnMapRowData : columnNames) {
				// System.out.println(columnMapRowData);
				// System.out.println(dataList.get(tempModCount));
				if (((String) columnMapRowData.get("column_datatype"))
						.equalsIgnoreCase("STRING")) {
					objectData[tempCount] = excaliburData.get(tempCount);
				}
				if (((String) columnMapRowData.get("column_datatype"))
						.equalsIgnoreCase("INT")) {
					if (!(excaliburData.get(tempCount) == null)) {
						objectData[tempCount] = Integer.parseInt(excaliburData
								.get(tempCount));

					}
					if (excaliburData.get(tempCount) == null) {
						objectData[tempCount] = 0;
					}
				}
				if (((String) columnMapRowData.get("column_datatype"))
						.equalsIgnoreCase("Date")) {

					if (!(excaliburData.get(tempCount) == null)) {
						objectData[tempCount] = new Date(new java.util.Date(
								excaliburData.get(tempCount)).getTime());

					}

					if (excaliburData.get(tempCount) == null) {
						objectData[tempCount] = null;
					}
				}

				// System.out.println(objectData[tempCount]);
				tempCount++;

			}

			tempCount = 0;
			objects.add(objectData);

		}
		// System.out.println("Ending Setter");

		return objects;
	}

	@Override
	public List<Map<String, Object>> getAllSRData(JdbcTemplate jdbcTemplate,
			String attribute) {
		List<Map<String, Object>> excaliburFromExcalibur=	jdbcTemplate.queryForList(DatabaseQuery.QUERY_TO_FETCH_SR_DATA
				+ attribute + "%'");
		System.out.println("HERE IS THE PROBLEM"+excaliburFromExcalibur);
		Map<String, Object> srFromSREXcalibur=null;
		
		
		List<String> srIDNotPresent = jdbcTemplate.query(DatabaseQuery.QUERY_TO_FETCH_SR_FROM_SREXCALIBUR,
				new RowMapper<String>() {
					public String mapRow(ResultSet rs, int rowNum)
							throws SQLException {
						return rs.getString(1);
					}
				});
		
		ListIterator<Map<String, Object>> listIterator=excaliburFromExcalibur.listIterator();
		while(listIterator.hasNext()){
			srFromSREXcalibur=listIterator.next();
			for(String excalibutTORemove:srIDNotPresent){
				if(((String)srFromSREXcalibur.get("SR_ID")).equalsIgnoreCase(excalibutTORemove)){
					listIterator.remove();
				}
				
			}
		}
		
		return excaliburFromExcalibur;
	}

	@Override
	public List<String> getAllExcaliburData(JdbcTemplate jdbcTemplate,
			String attribute) {
		
		String excaliburFromExcalibur,sqlQuery = DatabaseQuery.QUERY_TO_FETCH_EXCALIBUR_PMNAME + attribute + "'";
		System.out.println(sqlQuery);
		List<String> excaliburIDList = jdbcTemplate.query(sqlQuery,
				new RowMapper<String>() {
					public String mapRow(ResultSet rs, int rowNum)
							throws SQLException {
						return rs.getString(1);
					}
	
		});
		
//Code to Check Excalibur ID if present in SR-Excalibur Mapping table
//		If YES->Dont include it in the list
//		IF No->Include it
		
		/*List<String> excaliburIDNotPresent = jdbcTemplate.query(DatabaseQuery.QUERY_TO_FETCH_EXCALIBUR_FROM_SREXCALIBUR,
				new RowMapper<String>() {
					public String mapRow(ResultSet rs, int rowNum)
							throws SQLException {
						return rs.getString(1);
					}
				});
		
		ListIterator<String> listIterator=excaliburIDList.listIterator();
		while(listIterator.hasNext()){
			excaliburFromExcalibur=listIterator.next();
			for(String excalibutTORemove:excaliburIDNotPresent){
				if(excaliburFromExcalibur.equalsIgnoreCase(excalibutTORemove)){
					listIterator.remove();
				}
				
			}
		}*/
		
		
		return excaliburIDList;
	}

	@Override
	public List<Map<String, Object>> getAMDMName(JdbcTemplate jdbcTemplate,
			String attribute) {
		
		return jdbcTemplate.queryForList(DatabaseQuery.QUERY_TO_FETCH_AM_DM_NAME+attribute+"%'");
	}

	@Override
	public boolean saveSRExcaliburMapping(JdbcTemplate jdbcTemplate,
			 String srID, String excaliburID,String pmCode) {
		
		return (jdbcTemplate.update(DatabaseQuery.QUERY_TO_INSERT_SR_EXCALIBUR, new Object[]{excaliburID,srID,Integer.parseInt(pmCode)}))>0?true:false;
		
		
	}

	@Override
	public List<String> getSRData(JdbcTemplate jdbcTemplate,String pmCode) {
		
		
		String sqlQuery = DatabaseQuery.QUERY_TO_FETCH_SR_HAVING_PMNAME + Integer.parseInt(pmCode);
		System.out.println(sqlQuery);
		
		
		List<String> srList = jdbcTemplate.query(sqlQuery,
				new RowMapper<String>() {
					public String mapRow(ResultSet rs, int rowNum)
							throws SQLException {
						return rs.getString(1);
					}
				});

		return srList;
	}

	@Override
	public String getSRDetail(JdbcTemplate jdbcTemplate, String srID) {
		
		
		String srDetails= jdbcTemplate.queryForObject(DatabaseQuery.QUERY_TO_FETCH_SRDETAIL_FOR_SRID, new Object[]{srID},String.class);
		
		
		
		return srDetails;
	}

	public List<SmartRecruit> fetchAllSrData(JdbcTemplate jdbcTemplate, String managerId) {
		List<SmartRecruit> smartRecruits=jdbcTemplate.query(DatabaseQuery.QUERY_TO_FETCH_SMARTRECRUIT_DATA+managerId+"%'", new SmartRecruitMapper());
		return smartRecruits;
	}

	public List<dmpmmap> pmautopop( String dmname ,JdbcTemplate jdbcTemplate) 
	{
		
	
			String sql = DatabaseQuery.QUERY_TO_Update_dmpm_name+dmname+"'";
		
			   System.out.println(sql);
	    		 List<dmpmmap> dmmap = jdbcTemplate.query(sql, new RowMapper<dmpmmap>() 
	
	    				 {
			@Override
			public dmpmmap mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				dmpmmap dname = new dmpmmap();
				
			dname.setPmname(rs.getString("PM_NAME"));
		
				
				
				
				
				return dname;
			}
	 
			
			
			
			
			
			
	    });//---------------new Object[]{year, month});
	    		
	    		
	    return dmmap;
	    
	  
	}
	public List<srExcal> srexcalview( int profile ,Date startdate,Date enddate,JdbcTemplate jdbcTemplate) 
	{
		
	
			String sql = DatabaseQuery.QUERY_TO_FETCH_SrExaclVIEW+profile+DatabaseQuery.QUERY_TO_FETCH_SrExaclVIEW2+startdate+DatabaseQuery.QUERY_TO_FETCH_SrExaclVIEW3+"'"+enddate+"'";
		
			   System.out.println(sql);
	    		 List<srExcal> srex = jdbcTemplate.query(sql, new RowMapper<srExcal>() 
	
	    				 {
			@Override
			public srExcal mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				srExcal srexc = new srExcal();
				
			
		      srexc.setACCOUNT_MANAGER(rs.getString("ACCOUNT_MANAGER"));
		      srexc.setEXCALIBUR_ID(rs.getString("EXCALIBUR_ID"));
		     // srexc.setPM_MAP_ID(rs.getInt("PM_MAP_ID"));
		      srexc.setSR_ID(rs.getString("SR_ID"));
		      srexc.setPrimaryskills(rs.getString("PRIMARY_SKILLS"));
		      srexc.setProjectcode(rs.getString("PROJECT_CODE"));
		      srexc.setProjectname(rs.getString("PROJECT"));
		      srexc.setOppname(rs.getString("OPPORTUNITY_NAME"));
		      srexc.setDm(rs.getString("DM"));
				
				return srexc;
				
			}
	 
			
			
			
			
			
			
	    });//---------------new Object[]{year, month});
	    		
	    		
	    return srex;
	    
	  
	}
	public List<srExcal> srexcalview1( String PM_MAP_ID ,String EXCALIBUR_ID,String SR_ID,String ACCOUNT_MANAGER,JdbcTemplate jdbcTemplate) 
	{
		
	
			String sql = DatabaseQuery.QUERY_TO_FETCH_SrExaclVIEW;
		
			   System.out.println(sql);
	    		 List<srExcal> srex = jdbcTemplate.query(sql, new RowMapper<srExcal>() 
	
	    				 {
			@Override
			public srExcal mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				srExcal srexc = new srExcal();
				
			
		      srexc.setACCOUNT_MANAGER(rs.getString("ACCOUNT_MANAGER"));
		      srexc.setEXCALIBUR_ID(rs.getString("EXCALIBUR_ID"));
		    //  srexc.setPM_MAP_ID(rs.getString("PM_MAP_ID"));
		      srexc.setSR_ID(rs.getString("SR_ID"));
		      
		 
				
				
				
				return srexc;
			}
	 
			
			
			
			
			
			
	    });//---------------new Object[]{year, month});
	    		
	    		
	    return srex;
	    
	  
	}


}

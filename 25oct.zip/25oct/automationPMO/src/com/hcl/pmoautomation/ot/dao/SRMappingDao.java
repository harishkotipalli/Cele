package com.hcl.pmoautomation.ot.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.jdbc.core.JdbcTemplate;

import com.hcl.pmoautomation.ot.vo.Excalibur;

public interface SRMappingDao {

	List<Excalibur> getExcaliburData(String loginname, JdbcTemplate jdbcTemplate);
	
	public List<String> getMappedPM(String DMName, JdbcTemplate jdbcTemplate);

	List<String> fetchPMName();

	boolean saveExcalibur(String parameter, String excaliburID, JdbcTemplate jdbcTemplate);

	boolean saveSRDumpData(List<ArrayList<String>> readExcelAllDynamically,
			String srTableName, JdbcTemplate jdbcTemplate);

	
	

	List<String> getAllExcaliburData(JdbcTemplate jdbcTemplate, String attribute);

	List<Map<String, Object>> getAllSRData(JdbcTemplate jdbcTemplate,
			String attribute);

	List<Map<String, Object>> getAMDMName(JdbcTemplate jdbcTemplate,
			String attribute);

	boolean saveSRExcaliburMapping(JdbcTemplate jdbcTemplate,
		 String srID, String excaliburID, String pmCode);

	List<String> getSRData(JdbcTemplate jdbcTemplate,String pmCode);

	String getSRDetail(JdbcTemplate jdbcTemplate, String srID);
	
}

package com.hcl.pmoautomation.ot.dao;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;

public interface yettoDao {


	boolean saveRASDumpData(List<ArrayList<String>> readExcelAllDynamically,
			String rasTableName, JdbcTemplate jdbcTemplate) throws ParseException;

	List<Object[]> getRASDataWithNOSRMapped(JdbcTemplate jdbcTemplate, String pmCode);

	boolean saveSRRASMapping(JdbcTemplate jdbcTemplate, int sapCode, String srID);

}
package com.hcl.pmoautomation.ot.service;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

public interface RASService {
	
	public boolean saveRASDump(String rasFilePath, String rasSheetName,
			String rasTableName, JdbcTemplate jdbcTemplate);

	public List<Object[]> getRASDataWithNOSRMapped(JdbcTemplate jdbcTemplate,
			String pmCode);

	public boolean saveSRRASMapping(JdbcTemplate jdbcTemplate, int sapCode, String srID);

}

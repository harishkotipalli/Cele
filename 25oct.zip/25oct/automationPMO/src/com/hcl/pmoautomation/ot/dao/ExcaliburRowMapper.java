package com.hcl.pmoautomation.ot.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.hcl.pmoautomation.ot.vo.Excalibur;

public class ExcaliburRowMapper implements RowMapper{

	@Override
	public Object mapRow(ResultSet res, int arg1) throws SQLException {
		/*Excalibur excalibur=new Excalibur();
		excalibur.setAccountManager(res.getString(""));
		
		excalibur.setAccountManager(res.getString(""));
		excalibur.setAccountManager(res.getString(""));
		excalibur.setAccountManager(res.getString(""));
		excalibur.setAccountManager(res.getString(""));
		excalibur.setAccountManager(res.getString(""));
		excalibur.setAccountManager(res.getString(""));excalibur.setAccountManager(res.getString(""));
		
		excalibur.setAccountManager(res.getString(""));
		*/
		return null;
	}

}

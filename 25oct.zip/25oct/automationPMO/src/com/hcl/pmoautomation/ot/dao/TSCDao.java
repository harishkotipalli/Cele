package com.hcl.pmoautomation.ot.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

public interface TSCDao {

	boolean saveTSCDumpData(List<ArrayList<String>> readExcelAllDynamically,
			String tscTableName, JdbcTemplate jdbcTemplate);

	List<Object[]> getTSCDataH(JdbcTemplate jdbcTemplate);

}

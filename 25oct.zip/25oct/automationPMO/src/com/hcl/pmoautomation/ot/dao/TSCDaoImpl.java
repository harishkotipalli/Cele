package com.hcl.pmoautomation.ot.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;

public class TSCDaoImpl implements TSCDao {

	@Override
	public boolean saveTSCDumpData(
			List<ArrayList<String>> readExcelAllDynamically,
			String tscTableName, JdbcTemplate jdbcTemplate) {

		// JdbcTemplate jdbcTemplate = new JdbcTemplate();
		int count = 0;
		boolean resultFlag = false;
		String[] returnData = null;
		List<Map<String, Object>> columnNames = getAllColumnNamesDynamically(
				tscTableName, jdbcTemplate);

		StringBuilder sqlQuery = new StringBuilder();
		//sqlQuery = sqlQuery.append("insert into " + tscTableName + "(");
		sqlQuery = sqlQuery.append("call TSC  (");

/*	for (Map columnMapRowData : columnNames) {
			String tempData = (String) columnMapRowData.get("column_name");

			if (count == columnNames.size() - 1) {
				sqlQuery.append("`" + tempData.trim() + "`,`MODIFIED_DATE`) values (");
				break;
			}
			sqlQuery.append("`" + tempData.trim() + "`,");

			count++;
		}*/

		// For Adding the Values
		count = 0;
		for (Map columnMapRowData : columnNames) {

			if (count == columnNames.size() - 1) {
				//sqlQuery.append("?" + ",?)");
				sqlQuery.append("?" +")");
				System.out.println("columnNames are"  +  columnNames);
				break;
			}
			sqlQuery.append("?" + ",");

			count++;
		}
		//
		System.out.println(sqlQuery);
		// final Object[] objects =
		// setAllDataDynamically(readExcelAllDynamically,
		// columnNames);
		final List<Object[]> objects2 = setAllDataDynamically(
				readExcelAllDynamically, columnNames);
		for (ArrayList<String> ps : readExcelAllDynamically) {
			// System.out.println(ps);
		}
		for (Object[] objects : objects2) {
			// System.out.println(Arrays.toString(objects));
		}
		// System.out.println("Size :" + objects2.size());
		final List<String> columnDataTypes = new ArrayList<String>();
		// System.out.println(objects2.size() + "SOMETHING");

		for (Map map : columnNames) {
			columnDataTypes.add((String) map.get("COLUMN_DATATYPE"));
		}
		try {
			// resultFlag= jdbcTemplate.update(
			// sqlQuery.toString(),
			// setAllDataDynamically(readExcelAllDynamically,
			// columnNames))>0?true:false;

			resultFlag = (jdbcTemplate.batchUpdate(sqlQuery.toString(),
					new BatchPreparedStatementSetter() {

						@Override
						public void setValues(java.sql.PreparedStatement ps,
								int j) throws SQLException {

							Object[] objects = objects2.get(j);

							/*ps.setString(1, (String) objects[0]);
							ps.setString(2, (String) objects[1]);
							ps.setString(3, (String) objects[2]);
							ps.setString(4, (String) objects[3]);
							ps.setString(5, (String) objects[4]);
							ps.setInt(6, (int) objects[5]);
							ps.setString(7, (String) objects[6]);
							ps.setString(8, (String) objects[7]);
							ps.setString(9, (String) objects[8]);
							if (!(objects[9] == null)) {
								ps.setDate(10, new java.sql.Date(
										((Date) objects[9]).getTime()));
							}
							if ((objects[9] == null)) {
								ps.setDate(10, null);
							}
							if (!(objects[10] == null)) {
								ps.setDate(11, new java.sql.Date(
										((Date) objects[10]).getTime()));
							}
							if ((objects[10] == null)) {
								ps.setDate(11, null);
							}

							if (!(objects[11] == null)) {
								ps.setDate(12, new java.sql.Date(
										((Date) objects[11]).getTime()));
							}
							if ((objects[11] == null)) {
								ps.setDate(12, null);
							}
							if (!(objects[12] == null)) {
								ps.setDate(13, new java.sql.Date(
										((Date) objects[12]).getTime()));
							}
							if ((objects[12] == null)) {
								ps.setDate(13, null);
							}
							ps.setString(14, (String) objects[13]);
							ps.setString(15, (String) objects[14]);
							ps.setString(16, (String) objects[15]);
							ps.setString(17, (String) objects[16]);
							ps.setString(18, (String) objects[17]);
							ps.setString(19, (String) objects[18]);
							ps.setString(20, (String) objects[19]);
							ps.setLong(21, (long) objects[20]);
							ps.setString(22, (String) objects[21]);
							ps.setString(23, (String) objects[22]);
							ps.setString(24, (String) objects[23]);
							ps.setString(25, (String) objects[24]);
							ps.setString(26, (String) objects[25]);
							ps.setString(27, (String) objects[26]);
							ps.setString(28, (String) objects[27]);
							ps.setString(29, (String) objects[28]);
							ps.setString(30, (String) objects[29]);
							ps.setString(31, (String) objects[30]);
							ps.setString(32, (String) objects[31]);
							ps.setString(33, (String) objects[32]);
							ps.setString(34, (String) objects[33]);
							ps.setString(35, (String) objects[34]);
							ps.setString(36, (String) objects[35]);
							ps.setString(37, (String) objects[36]);
							ps.setString(38, (String) objects[37]);
							ps.setString(39, (String) objects[38]);
							ps.setString(40, (String) objects[39]);
							ps.setString(41, (String) objects[40]);
							ps.setString(42, (String) objects[41]);
							ps.setString(43, (String) objects[42]);
							ps.setString(44, (String) objects[43]);
							ps.setString(45, (String) objects[44]);
						    if (!(objects[45] == null)) {
								ps.setDate(46, new java.sql.Date(
										((Date) objects[45]).getTime()));
							}
							if ((objects[45] == null)) {
								ps.setDate(46, null);
							}
							ps.setString(47, (String) objects[46]);
							ps.setString(48, (String) objects[47]);
							ps.setString(49, (String) objects[48]);
							if (!(objects[49] == null)) {
								ps.setDate(50, new java.sql.Date(
										((Date) objects[49]).getTime()));
							}
							if ((objects[49] == null)) {
								ps.setDate(50, null);
							}

							if (!(objects[50] == null)) {
								ps.setDate(51, new java.sql.Date(
										((Date) objects[50]).getTime()));
							}
							if ((objects[50] == null)) {
								ps.setDate(51, null);
							}
							ps.setString(52, (String) objects[51]);
							ps.setString(53, (String) objects[52]);
							ps.setString(54, (String) objects[53]);
							ps.setString(55, (String) objects[54]);
							if (!(objects[55] == null)) {
								ps.setDate(56, new java.sql.Date(
										((Date) objects[55]).getTime()));
							}
							if ((objects[55] == null)) {
								ps.setDate(56, null);
							}
							if (!(objects[56] == null)) {
								ps.setDate(57, new java.sql.Date(
										((Date) objects[56]).getTime()));
							}
							if ((objects[56] == null)) {
								ps.setDate(57, null);
							}
							ps.setString(58, (String) objects[57]);
							ps.setString(59, (String) objects[58]);
							ps.setString(60, (String) objects[59]);
							ps.setString(61, (String) objects[60]);
							ps.setString(62, (String) objects[61]);
							ps.setString(63, (String) objects[62]);
							ps.setLong(64, (long) objects[63]);
							ps.setString(65, (String) objects[64]);
							ps.setString(66, (String) objects[65]);
							ps.setString(67, (String) objects[66]);
							ps.setString(68, (String) objects[67]);
							ps.setString(69, (String) objects[68]);
							ps.setString(70, (String) objects[69]);
							ps.setString(71, (String) objects[70]);
							ps.setString(72, (String) objects[71]);
							if (!(objects[72] == null)) {
								ps.setDate(73, new java.sql.Date(
										((Date) objects[72]).getTime()));
							}
							if ((objects[72] == null)) {
								ps.setDate(73, null);
							}
							ps.setString(74, (String) objects[73]);
							ps.setString(75, (String) objects[74]);
							ps.setString(76, (String) objects[75]);
							ps.setString(77, (String) objects[76]);
							ps.setString(78, (String) objects[77]);
							ps.setInt(79, (int) objects[78]);
							ps.setInt(80, (int) objects[79]);

							ps.setString(81, (String) objects[80]);
							
							ps.setString(82, (String) objects[81]);
							
							ps.setString(83, (String) objects[82]);

							ps.setString(84, (String) objects[83]);
							if (!(objects[84] == null)) {
								ps.setDate(85, new java.sql.Date(
										((Date) objects[84]).getTime()));
							}
							if ((objects[84] == null)) {
								ps.setDate(85, null);
							}
							ps.setString(86, (String) objects[85]);
							ps.setString(87, (String) objects[86]);
							ps.setString(88, (String) objects[87]);
							ps.setString(89, (String) objects[88]);
							ps.setString(90, (String) objects[89]);
							ps.setString(91, (String) objects[90]);
							ps.setString(92, (String) objects[91]);
							ps.setString(93, (String) objects[92]);*/
							
							ps.setInt(1, (int) objects[0]);
							ps.setString(2, (String) objects[1]);
							ps.setString(3, (String) objects[2]);
							ps.setString(4, (String) objects[3]);
							if (!(objects[4] == null)) {
								ps.setDate(5, new java.sql.Date(
										((Date) objects[4]).getTime()));
							}
							if ((objects[4] == null)) {
								ps.setDate(5, null);
							}
							if (!(objects[5] == null)) {
								ps.setDate(6, new java.sql.Date(
										((Date) objects[5]).getTime()));
							}
							if ((objects[5] == null)) {
								ps.setDate(6, null);
							}
							if (!(objects[6] == null)) {
								ps.setDate(7, new java.sql.Date(
										((Date) objects[6]).getTime()));
							}
							if ((objects[6] == null)) {
								ps.setDate(7, null);
							}
							if (!(objects[7] == null)) {
								ps.setDate(8, new java.sql.Date(
										((Date) objects[7]).getTime()));
							}
							if ((objects[7] == null)) {
								ps.setDate(8, null);
							}
							if (!(objects[8] == null)) {
								ps.setDate(9, new java.sql.Date(
										((Date) objects[8]).getTime()));
							}
							if ((objects[8] == null)) {
								ps.setDate(9, null);
							}
							ps.setString(10, (String) objects[9]);
							ps.setString(11, (String) objects[10]);
							ps.setString(12, (String) objects[11]);
							ps.setString(13, (String) objects[12]);
							ps.setString(14, (String) objects[13]);
							ps.setString(15, (String) objects[14]);
							ps.setString(16, (String) objects[15]);
							ps.setString(17, (String) objects[16]);
							ps.setString(18, (String) objects[17]);
							ps.setString(19, (String) objects[18]);
							ps.setString(20, (String) objects[19]);
							ps.setString(21, (String) objects[20]);
							ps.setString(22, (String) objects[21]);
							ps.setString(23, (String) objects[22]);
							ps.setString(24, (String) objects[23]);
							ps.setString(25, (String) objects[24]);
							ps.setString(26, (String) objects[25]);
							ps.setString(27, (String) objects[26]);
							ps.setString(28, (String) objects[27]);
							ps.setString(29, (String) objects[28]);
							ps.setString(30, (String) objects[29]);
							ps.setString(31, (String) objects[30]);
							ps.setString(32, (String) objects[31]);
							ps.setString(33, (String) objects[32]);
							ps.setString(34, (String) objects[33]);
							ps.setString(35, (String) objects[34]);
							ps.setString(36, (String) objects[35]);
							if (!(objects[36] == null)) {
								ps.setDate(37, new java.sql.Date(
										((Date) objects[36]).getTime()));
							}
							if ((objects[36] == null)) {
								ps.setDate(37, null);
							}
							
						    ps.setString(38, (String) objects[37]);
						    ps.setString(39, (String) objects[38]);
						    ps.setString(40, (String) objects[39]);	
							
							
							
							if (!(objects[40] == null)) {
								ps.setDate(41, new java.sql.Date(
										((Date) objects[40]).getTime()));
							}
							if ((objects[40] == null)) {
								ps.setDate(41, null);
							}
							if (!(objects[41] == null)) {
								ps.setDate(42, new java.sql.Date(
										((Date) objects[41]).getTime()));
							}
							if ((objects[41] == null)) {
								ps.setDate(42, null);
							}
							ps.setString(43, (String) objects[42]);//rm sap id to b added
							ps.setString(44, (String) objects[43]);
							ps.setString(45, (String) objects[44]);
							ps.setString(46, (String) objects[45]);
							ps.setString(47, (String) objects[46]);
							if (!(objects[47] == null)) {
								ps.setDate(48, new java.sql.Date(
										((Date) objects[47]).getTime()));
							}
							if ((objects[47] == null)) {
								ps.setDate(48, null);
							}
							if (!(objects[48] == null)) {
								ps.setDate(49, new java.sql.Date(
										((Date) objects[48]).getTime()));
							}
							if ((objects[48] == null)) {
								ps.setDate(49, null);
							}
							ps.setString(50, (String) objects[49]);
							ps.setString(51, (String) objects[50]);
							ps.setString(52, (String) objects[51]);
							ps.setString(53, (String) objects[52]);
							ps.setString(54, (String) objects[53]);
							ps.setString(55, (String) objects[54]);
							ps.setString(56, (String) objects[55]);
							ps.setString(57, (String) objects[56]);
							if (!(objects[57] == null)) {
								ps.setDate(58, new java.sql.Date(
										((Date) objects[57]).getTime()));
							}
							if ((objects[57] == null)) {
								ps.setDate(58, null);
							}
							ps.setString(59, (String) objects[58]);
							ps.setString(60, (String) objects[59]);
							ps.setString(61, (String) objects[60]);
							ps.setString(62, (String) objects[61]);
							ps.setString(63, (String) objects[62]);
							ps.setString(64, (String) objects[63]);
							if (!(objects[64] == null)) {
								ps.setDate(65, new java.sql.Date(
										((Date) objects[64]).getTime()));
							}
							if ((objects[64] == null)) {
								ps.setDate(65, null);
							}
							ps.setString(66, (String) objects[65]);
							ps.setString(67, (String) objects[66]);
							ps.setString(68, (String) objects[67]);
							ps.setString(69, (String) objects[68]);
							ps.setString(70, (String) objects[69]);
							ps.setString(71, (String) objects[70]);
							ps.setString(72, (String) objects[71]);
							ps.setString(73, (String) objects[72]);
							ps.setString(74, (String) objects[73]);
							ps.setString(75, (String) objects[74]);
							
							
							
							
							
							System.out.println(ps);

						}

						@Override
						public int getBatchSize() {

							return objects2.size();
						}
					})).length >=1 ? true : false;

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		// TODO:LOGIC TO SENT MAIL

		return resultFlag;

	}

	public List<Map<String, Object>> getAllColumnNamesDynamically(
			String tableName, JdbcTemplate jdbcTemplate) {

		String queryToFetchColumns = DatabaseQuery.QUERY_FETCH_COLUMNS1
				+ tableName + DatabaseQuery.QUERY_FETCH_COLUMNS2;

		System.out.println(queryToFetchColumns);
		// jdbcTemplate=new JdbcTemplate();
		// System.out.println(getJdbcTemplate());
		return jdbcTemplate.queryForList(queryToFetchColumns);
	}

	@SuppressWarnings("deprecation")
	private List<Object[]> setAllDataDynamically(
			List<ArrayList<String>> arrayLists,
			List<Map<String, Object>> columnNames) {
		List<Object[]> objects = new ArrayList<Object[]>();
		Object[] objectData = null;
		// ArrayList<String> excaliburData = arrayLists.get(0);
		// System.out.println(excaliburData);
		// System.out.println(arrayLists.size());
		System.out.println(arrayLists.size());
		int tempCount = 0;
		String homePhone = null;
		for (ArrayList<String> excaliburData : arrayLists) {
			objectData = new Object[columnNames.size()];
//			 System.out.println(excaliburData);
			for (Map columnMapRowData : columnNames) {
				// System.out.println(columnMapRowData+"===="+excaliburData.get(tempCount));
				// System.out.println(excaliburData);
				// System.out.println(dataList.get(tempModCount));
				if (((String) columnMapRowData.get("column_datatype"))
						.equalsIgnoreCase("STRING")) {
					objectData[tempCount] = excaliburData.get(tempCount);
				}
				if (((String) columnMapRowData.get("column_datatype"))
						.equalsIgnoreCase("INT")) {
					if (!(excaliburData.get(tempCount) == null)) {
						if (((String) columnMapRowData.get("column_name"))
								.equalsIgnoreCase("Home_phone")
								|| ((String) columnMapRowData
										.get("column_name"))
										.equalsIgnoreCase("Contact Number")) {
//							System.out.println("ASAS"+excaliburData.get(tempCount));
							homePhone = excaliburData.get(tempCount).length() > 10 ? excaliburData
									.get(tempCount).split(" ")[1]
									: excaliburData.get(tempCount);
//									System.out.println(homePhone);
							if (homePhone.matches("-?\\d+")) {
//								System.out.println("YEAH");
								objectData[tempCount] = Long
										.parseLong(homePhone);
//								System.out.println("Inside of IF Phone"+objectData[tempCount]);
							}
						} else {
							
//								System.out.println("Inside of IF Not PHone"+objectData[tempCount]);
							objectData[tempCount] = Integer
									.parseInt((excaliburData.get(tempCount))
											.trim());
						}
						
					}
					if (excaliburData.get(tempCount) == null) {
						if (((String) columnMapRowData.get("column_name"))
								.equalsIgnoreCase("Home_phone")
								|| ((String) columnMapRowData
										.get("column_name"))
										.equalsIgnoreCase("Contact Number")) {
						objectData[tempCount]=new Long(0);	
						}else{
							objectData[tempCount] = 0;
						}
						
					}
//					System.out.println("Outer OF Every IF"+objectData[tempCount]);
				}
				if (((String) columnMapRowData.get("column_datatype"))
						.equalsIgnoreCase("Date")) {

					if (!(excaliburData.get(tempCount) == null)) {
						objectData[tempCount] = new Date(new java.util.Date(
								excaliburData.get(tempCount)).getTime());
						
						System.out.println( "date :" +tempCount+" :"+objectData[tempCount]);
					}

					if (excaliburData.get(tempCount) == null) {
						objectData[tempCount] = null;
					}
				}

				// System.out.println(objectData[tempCount]);
				tempCount++;

			}
//			System.out.println(Arrays.asList(objectData));
			tempCount = 0;
			objects.add(objectData);

		}
		// System.out.println("Ending Setter");

		return objects;
	}

	@Override
	public List<Object[]> getTSCDataH(JdbcTemplate jdbcTemplate) {
	List<Map<String, Object>>	tscDetails=jdbcTemplate.queryForList(DatabaseQuery.QUERY_TO_FETCH_TSC);
	List<Object[]> tscActualDetails=new ArrayList<Object[]>();
	
	for(Object[] tsc:tscActualDetails){
		
//		Object[]  objects=new Object[];
		
		
	}
		return null;
	}

}

package com.hcl.pmoautomation.ot.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

import com.hcl.pmoautomation.ot.vo.SmartRecruit;

public class SmartRecruitMapper implements RowMapper<SmartRecruit> {

	@Override
	public SmartRecruit mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		return new SmartRecruitExctractor().extractData(rs);
	}


}

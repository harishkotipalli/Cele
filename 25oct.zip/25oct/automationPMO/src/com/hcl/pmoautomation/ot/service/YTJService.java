package com.hcl.pmoautomation.ot.service;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

public interface YTJService {

	
	
	public boolean saveExcalibur(String filePath, String sheetName,
			String tableName,JdbcTemplate jdbcTemplate);

}

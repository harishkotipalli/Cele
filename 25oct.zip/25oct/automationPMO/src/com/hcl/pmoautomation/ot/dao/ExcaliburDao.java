package com.hcl.pmoautomation.ot.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;


public interface ExcaliburDao {
	
	

	public List<Map<String, Object>> getAllColumnNamesDynamically(
			String tableName,JdbcTemplate jdbcTemplate);

	public boolean saveAllDataDynamically(List<ArrayList<String>> arrayLists,
			String tableName,JdbcTemplate jdbcTemplate);

	

	/*public boolean saveAllDataDynamically(List<ArrayList<String>> arrayLists,
			String tableName);

	public PreparedStatement setAllDataDynamically(
			PreparedStatement preparedStatement,
			List<ArrayList<String>> columnNames, ArrayList<String> dataList);

	

	public boolean saveAllDataDynamically(
			List<ArrayList<String>> readExcelAllDynamically, String tableName,
			Map<String, Boolean> mandatoryFieldList);*/

}

package com.hcl.pmoautomation.ot.vo;

import java.util.Date;

public class Excalibur {

	private String accountManager;
	private String DM;
	private String PM;
	private Date new_opp_received_date;
	private String excalinburID;
	private Date excalinburDate;
	private String opportunityName;
	private String levelL4_L0;
	private String opportunityType;
	private String requisitionSource;
	private String classification;
	private String component;
	private String location;
	private String SR_Type;
	private Date BSD;
	private String BAND;
	private int experience;
	private String primarySkill;
	private String secondarySkill;
	private String role;
	private String detailedJD;
	private String remarks;
	private int initialDemand;
	private int droppedDemand;
	private int currentDemand;
	private int fullfilledDemand;
	private int balancePositions;
	private int identifiedPostiions;
	private String HCLOnboarded;
	private int sl_no;
	private int tcvcurrency;
	private String tcvconverted;
	private int propability;
	private String billingmodel;

	public Excalibur() {
		// TODO Auto-generated constructor stub
	}

	public Excalibur(String accountManager, String dM, String pM, Date new_opp_received_date, String excalinburID,
			Date excalinburDate, String opportunityName, String levelL4_L0, String opportunityType,
			String requisitionSource, String classification, String component, String location, String sR_Type,
			Date bSD, String bAND, int experience, String primarySkill, String secondarySkill, String role,
			String detailedJD, String remarks, int initialDemand, int droppedDemand, int currentDemand,
			int fullfilledDemand, int balancePositions, int identifiedPostiions, String hCLOnboarded, int sl_no,
			int tcvcurrency, String tcvconverted, int propability, String billingmodel) {
		super();
		this.accountManager = accountManager;
		DM = dM;
		PM = pM;
		this.new_opp_received_date = new_opp_received_date;
		this.excalinburID = excalinburID;
		this.excalinburDate = excalinburDate;
		this.opportunityName = opportunityName;
		this.levelL4_L0 = levelL4_L0;
		this.opportunityType = opportunityType;
		this.requisitionSource = requisitionSource;
		this.classification = classification;
		this.component = component;
		this.location = location;
		SR_Type = sR_Type;
		BSD = bSD;
		BAND = bAND;
		this.experience = experience;
		this.primarySkill = primarySkill;
		this.secondarySkill = secondarySkill;
		this.role = role;
		this.detailedJD = detailedJD;
		this.remarks = remarks;
		this.initialDemand = initialDemand;
		this.droppedDemand = droppedDemand;
		this.currentDemand = currentDemand;
		this.fullfilledDemand = fullfilledDemand;
		this.balancePositions = balancePositions;
		this.identifiedPostiions = identifiedPostiions;
		HCLOnboarded = hCLOnboarded;
		this.sl_no = sl_no;
		this.tcvcurrency = tcvcurrency;
		this.tcvconverted = tcvconverted;
		this.propability = propability;
		this.billingmodel = billingmodel;
	}

	public String getAccountManager() {
		return accountManager;
	}

	public void setAccountManager(String accountManager) {
		this.accountManager = accountManager;
	}

	public String getDM() {
		return DM;
	}

	public void setDM(String dM) {
		DM = dM;
	}

	public String getPM() {
		return PM;
	}

	public void setPM(String pM) {
		PM = pM;
	}

	public Date getNew_opp_received_date() {
		return new_opp_received_date;
	}

	public void setNew_opp_received_date(Date new_opp_received_date) {
		this.new_opp_received_date = new_opp_received_date;
	}

	public String getExcalinburID() {
		return excalinburID;
	}

	public void setExcalinburID(String excalinburID) {
		this.excalinburID = excalinburID;
	}

	public Date getExcalinburDate() {
		return excalinburDate;
	}

	public void setExcalinburDate(Date excalinburDate) {
		this.excalinburDate = excalinburDate;
	}

	public String getOpportunityName() {
		return opportunityName;
	}

	public void setOpportunityName(String opportunityName) {
		this.opportunityName = opportunityName;
	}

	public String getLevelL4_L0() {
		return levelL4_L0;
	}

	public void setLevelL4_L0(String levelL4_L0) {
		this.levelL4_L0 = levelL4_L0;
	}

	public String getOpportunityType() {
		return opportunityType;
	}

	public void setOpportunityType(String opportunityType) {
		this.opportunityType = opportunityType;
	}

	public String getRequisitionSource() {
		return requisitionSource;
	}

	public void setRequisitionSource(String requisitionSource) {
		this.requisitionSource = requisitionSource;
	}

	public String getClassification() {
		return classification;
	}

	public void setClassification(String classification) {
		this.classification = classification;
	}

	public String getComponent() {
		return component;
	}

	public void setComponent(String component) {
		this.component = component;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getSR_Type() {
		return SR_Type;
	}

	public void setSR_Type(String sR_Type) {
		SR_Type = sR_Type;
	}

	public Date getBSD() {
		return BSD;
	}

	public void setBSD(Date bSD) {
		BSD = bSD;
	}

	public String getBAND() {
		return BAND;
	}

	public void setBAND(String bAND) {
		BAND = bAND;
	}

	public int getExperience() {
		return experience;
	}

	public void setExperience(int experience) {
		this.experience = experience;
	}

	public String getPrimarySkill() {
		return primarySkill;
	}

	public void setPrimarySkill(String primarySkill) {
		this.primarySkill = primarySkill;
	}

	public String getSecondarySkill() {
		return secondarySkill;
	}

	public void setSecondarySkill(String secondarySkill) {
		this.secondarySkill = secondarySkill;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getDetailedJD() {
		return detailedJD;
	}

	public void setDetailedJD(String detailedJD) {
		this.detailedJD = detailedJD;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public int getInitialDemand() {
		return initialDemand;
	}

	public void setInitialDemand(int initialDemand) {
		this.initialDemand = initialDemand;
	}

	public int getDroppedDemand() {
		return droppedDemand;
	}

	public void setDroppedDemand(int droppedDemand) {
		this.droppedDemand = droppedDemand;
	}

	public int getCurrentDemand() {
		return currentDemand;
	}

	public void setCurrentDemand(int currentDemand) {
		this.currentDemand = currentDemand;
	}

	public int getFullfilledDemand() {
		return fullfilledDemand;
	}

	public void setFullfilledDemand(int fullfilledDemand) {
		this.fullfilledDemand = fullfilledDemand;
	}

	public int getBalancePositions() {
		return balancePositions;
	}

	public void setBalancePositions(int balancePositions) {
		this.balancePositions = balancePositions;
	}

	public int getIdentifiedPostiions() {
		return identifiedPostiions;
	}

	public void setIdentifiedPostiions(int identifiedPostiions) {
		this.identifiedPostiions = identifiedPostiions;
	}

	public String getHCLOnboarded() {
		return HCLOnboarded;
	}

	public void setHCLOnboarded(String hCLOnboarded) {
		HCLOnboarded = hCLOnboarded;
	}

	public int getSl_no() {
		return sl_no;
	}

	public void setSl_no(int sl_no) {
		this.sl_no = sl_no;
	}

	public int getTcvcurrency() {
		return tcvcurrency;
	}

	public void setTcvcurrency(int tcvcurrency) {
		this.tcvcurrency = tcvcurrency;
	}

	public String getTcvconverted() {
		return tcvconverted;
	}

	public void setTcvconverted(String tcvconverted) {
		this.tcvconverted = tcvconverted;
	}

	public int getPropability() {
		return propability;
	}

	public void setPropability(int propability) {
		this.propability = propability;
	}

	public String getBillingmodel() {
		return billingmodel;
	}

	public void setBillingmodel(String billingmodel) {
		this.billingmodel = billingmodel;
	}

	@Override
	public String toString() {
		return "Excalibur [accountManager=" + accountManager + ", DM=" + DM + ", PM=" + PM + ", new_opp_received_date="
				+ new_opp_received_date + ", excalinburID=" + excalinburID + ", excalinburDate=" + excalinburDate
				+ ", opportunityName=" + opportunityName + ", levelL4_L0=" + levelL4_L0 + ", opportunityType="
				+ opportunityType + ", requisitionSource=" + requisitionSource + ", classification=" + classification
				+ ", component=" + component + ", location=" + location + ", SR_Type=" + SR_Type + ", BSD=" + BSD
				+ ", BAND=" + BAND + ", experience=" + experience + ", primarySkill=" + primarySkill
				+ ", secondarySkill=" + secondarySkill + ", role=" + role + ", detailedJD=" + detailedJD + ", remarks="
				+ remarks + ", initialDemand=" + initialDemand + ", droppedDemand=" + droppedDemand + ", currentDemand="
				+ currentDemand + ", fullfilledDemand=" + fullfilledDemand + ", balancePositions=" + balancePositions
				+ ", identifiedPostiions=" + identifiedPostiions + ", HCLOnboarded=" + HCLOnboarded + ", sl_no=" + sl_no
				+ ", tcvcurrency=" + tcvcurrency + ", tcvconverted=" + tcvconverted + ", propability=" + propability
				+ ", billingmodel=" + billingmodel + "]";
	}

	

	
}

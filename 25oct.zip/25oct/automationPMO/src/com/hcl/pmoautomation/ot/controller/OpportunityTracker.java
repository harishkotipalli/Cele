package com.hcl.pmoautomation.ot.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.Date;
import java.sql.ResultSet;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.runtime.RuntimeConstants;
import org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.portlet.ModelAndView;

import com.hcl.pmoautomation.bgv.utilities.BgvSql;
import com.hcl.pmoautomation.email.App;
import com.hcl.pmoautomation.ot.dao.DatabaseQuery;
import com.hcl.pmoautomation.ot.dao.ExcaliburDaoImpl;
import com.hcl.pmoautomation.ot.dao.SRMappingDao;
import com.hcl.pmoautomation.ot.dao.SRMappingDaoImpl;
import com.hcl.pmoautomation.ot.dao.TSCDao;
import com.hcl.pmoautomation.ot.dao.mailDao;
import com.hcl.pmoautomation.ot.service.ExcaliburService;
import com.hcl.pmoautomation.ot.service.ExcaliburServiceImpl;
import com.hcl.pmoautomation.ot.service.RASService;
import com.hcl.pmoautomation.ot.service.RASServiceImpl;
import com.hcl.pmoautomation.ot.service.SRMappingService;
import com.hcl.pmoautomation.ot.service.SRMappingServiceImpl;
import com.hcl.pmoautomation.ot.service.TSCService;
import com.hcl.pmoautomation.ot.service.TSCServiceImpl;
import com.hcl.pmoautomation.ot.service.YTJService;
import com.hcl.pmoautomation.ot.service.YTJServiceImpl;
import com.hcl.pmoautomation.ot.utility.ExcelGenericReader;
import com.hcl.pmoautomation.ot.utility.ExcelSheetConstants;
import com.hcl.pmoautomation.ot.vo.Excalibur;
import com.hcl.pmoautomation.ot.vo.OtTemplateUploadVO;
import com.hcl.pmoautomation.ot.vo.SmartRecruit;
import com.hcl.pmoautomation.ot.vo.mailVO;
import com.hcl.pmoautomation.ot.vo.mailvoforpm;
import com.hcl.pmoautomation.ot.vo.srExcal;

import javafx.scene.control.Alert;

@Controller
@RequestMapping("pmoAutomation/OpportunityTracker")
public class OpportunityTracker {
	@ExceptionHandler(Exception.class)
	public ModelAndView handleException(Exception ex, HttpServletRequest request, HttpServletResponse response) {
	    ModelAndView modelAndView = new ModelAndView();
	    modelAndView.addObject("errorMessage", ex.getMessage());
	    modelAndView.addObject("errorDetails", ExceptionUtils.getStackTrace(ex));
	    modelAndView.setViewName("Login/Error");

	    return modelAndView;
	}
	@Autowired
	private JdbcTemplate jdbcTemplate;
	private VelocityEngine velocityEngine;
	private MailSender mailSender;
	@RequestMapping(value = "/getPmName.php", method = RequestMethod.POST)
	public void getPMNames(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		// Internally hitting another Servlet

		// TODO:Spring Multipart enable it,Servlet disable it
//		System.out.println("sdsdsd");
		System.out.println(request.getParameter("dmName"));
		PrintWriter out = response.getWriter();
		String count = request.getParameter("count");
		SRMappingDao srMappingDao = new SRMappingDaoImpl();
		List<String> pmNameList = srMappingDao.getMappedPM(
				request.getParameter("dmName"), jdbcTemplate);
		System.out.println(pmNameList);
		System.out.println("LOOK HERE count "+count);
		out.print("<select id='pmName" + count + "' name='pmName" + count + "' onclick='toDisplay("+count+")'>");
		for (String pmName : pmNameList) {

			out.print("<option value='" + pmName + "'>");
			out.print(pmName);
			out.print("</option>");
		}
		out.print("</select>");
	

	}

	@RequestMapping(value = "/getExcalinurView.php", method = RequestMethod.POST)
	public void getExcaliburDataView(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		// Internally hitting another Servlet

		// TODO:Spring Multipart enable it,Servlet disable it

		String dateFirst = request.getParameter("dateStart");
		String dateSecond = request.getParameter("dateLast");
		System.out.println(dateFirst);
		PrintWriter out = response.getWriter();
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd"), sdf2 = new SimpleDateFormat(
				"yyyy-MM-dd");
		java.util.Date date1 = null, date2 = null;
		try {
			date1 = sdf1.parse(dateFirst);
			date2 = sdf2.parse(dateSecond);
		} catch (ParseException e) {

			e.printStackTrace();
		}
		java.sql.Date startingDate = new java.sql.Date(date1.getTime());
		java.sql.Date endingDate = new java.sql.Date(date2.getTime());

		System.out.println(startingDate + "+++++" + endingDate);

		List<Map<String, Object>> maps = new ExcaliburDaoImpl()
				.getExcaliburView(startingDate, endingDate, jdbcTemplate);

		
		displayExcaliburView(maps,out);
	}

	private void displayExcaliburView(List<Map<String, Object>> maps,
			PrintWriter out) {
		
		String accountM,excaliburId,excaliburDate,oppReceivedDate,oppName,dm,pm,loc,priSkill,initialDemand,currentDemand;
		String tcvconverted,billingmodel,tcvcurrency,propability;

if (maps.size() != 0) {
			
			out.print("<table  class='tablecreate' style='width: 100%;' border='5' cellpadding='10'>");
			
			out.print("<tr><th>ACCOUNT MANAGER</th>");
			out.print("<th>EXCALIBUR ID</th>");
			//out.print("<th>EXCALIBUR DATE</th>");
			out.print("<th>OPORTUNITY RECEIVED DATE</th>");
			out.print("<th>OOPRTUNITY NAME</th>");
			out.print("<th>Deleivery Manager</th>");
			out.print("<th>Project Manager</th>");
			out.print("<th>LOCATION</th>");
			out.print("<th>TCV(K)(converted)</th>");
			out.print("<th>TCV(K)Currency</th>");			
			out.print("<th>Probability(%)</th>");
			out.print("<th>Billing Model</th>");
			/*out.print("<th>PRIMARY SKILLS</th>");
			out.print("<th>INITIAL DEMAND</th>");
			out.print("<th>CURRENT DEMAND</th></tr>");*/
			for (Map map : maps) {
				
				accountM=!map.get("ACCOUNT_MANAGER").toString().equalsIgnoreCase("null")?map.get("ACCOUNT_MANAGER").toString():"Not Available";
				excaliburId= !map.get("EXCALIBUR_ID").toString().equalsIgnoreCase("null")?map.get("EXCALIBUR_ID").toString():"Not Available";
				excaliburDate=map.get("EXCALIBUR_DATE")!=null?map.get("EXCALIBUR_DATE").toString():"Not Available";
				oppReceivedDate=map.get("NEW OPP RECEIVED DATE")!=null?map.get("NEW OPP RECEIVED DATE").toString():"Not Available";
				oppName= map.get("OPPORTUNITY_NAME")!=null?map.get("OPPORTUNITY_NAME").toString():"Not Available";
				dm=map.get("DM")!=null?map.get("DM").toString():"Not Available";
				pm= map.get("PM_CM")!=null?map.get("PM_CM").toString():"Not Available" ;
				loc= map.get("LOCATION")!=null?map.get("LOCATION").toString():"Not Available";
				tcvcurrency=map.get("TCV(K)_CURRENCY")!=null?map.get("TCV(K)_CURRENCY").toString():"Not Available";
				tcvconverted=map.get("TCV_CONVERTED")!=null?map.get("TCV_CONVERTED").toString():"Not Available";
				billingmodel=map.get("BILLING_MODEL")!=null?map.get("BILLING_MODEL").toString():"Not Available";
				propability=map.get("PROBABILITY")!=null?map.get("PROBABILITY").toString():"Not Available";
				/*priSkill=map.get("PRIMARY_SKILL")!=null?map.get("PRIMARY_SKILL").toString():"Not Available";
				initialDemand=map.get("INITIAL_DEMAND")!=null?map.get("INITIAL_DEMAND").toString():"Not Available" ;
				currentDemand= map.get("CURRENT_DEMAND")!=null?map.get("CURRENT_DEMAND").toString():"Not Available";*/
				out.print("<tr><td>"+accountM+"</td>");
				out.print("<td>"+excaliburId+"</td>");
			//	out.print("<td>"+excaliburDate+"</td>");
				out.print("<td>"+ oppReceivedDate+"</td>");
				out.print("<td>"+oppName+"</td>");
				out.print("<td>"+dm +"</td>");
				out.print("<td>"+pm+"</td>");
				out.print("<td>"+loc +"</td>");				
				out.print("<td>"+tcvconverted +"</td>");
				out.print("<td>"+tcvcurrency +"</td>");
				out.print("<td>"+propability +"</td>");
				out.print("<td>"+billingmodel +"</td>");
				/*out.print("<td>"+ priSkill +"</td>");
				out.print("<td>"+ initialDemand+"</td>");
				out.print("<td>"+currentDemand+"</td></tr>");*/
				
			}
			out.print("</table>");
		} else {
			out.print("<font color='red'>Opps!!!No Data Found</font>");
		}
		
	}

	@RequestMapping(value = "/excaliburUpload.php", method = RequestMethod.POST)
	public void excaliburUpload(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		System.out.println("hi iam in controller");
		// Internally hitting another Servlet

		// TODO:Spring Multipart enable it,Servlet disable it
		request.setAttribute("fileType", "Excalibur");
		request.getRequestDispatcher("/fileUpload.asspx").forward(request,
				response);
		
		
		mailDao mail=new mailDao();
		List<mailVO> mm=mail.list(jdbcTemplate);
		App otuploadmailtrig = new App();
		String[] array = new String[mm.size()];
		int index = 0;
		for (Object value : mm) {
			array[index] = String.valueOf( value );
		
			
			List<OtTemplateUploadVO> templateUpload=mail.templateData(array[index], jdbcTemplate);
			
	         System.out.println("list of mailsssssss"+array[index]);
	         System.out.println("list of details in template-------"+templateUpload);
		      otuploadmailtrig.Mailtrigger("pmoappadmin_ou@hcl.com",array[index], " Assigned Excalibur Id's ","Harish", "/OTUPLOADtemplate.jsp",templateUpload, null);

			
		//	s.method("shyamsunder.p@hcl.com",array[index], "Checking Email Triggering", "/OTUploadTemp.vm",templateUpload);
			
			jdbcTemplate.update(DatabaseQuery.QUERY_TO_FETCH_mailQueryUpdateDMStatus+array[index]+"'");
			index++;
		}
			
			
			
		}
		
		
		

	

	@RequestMapping(value = "/srExcelUpoload.php", method = RequestMethod.POST)
	public void uplaodSRFile(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		// Internally hitting another Servlet

		// TODO:Spring Multipart enable it,Servlet disable it
		request.setAttribute("fileType", "SR");
		request.getRequestDispatcher("/fileUpload.asspx").forward(request,
				response);

	}

	@RequestMapping(value = "/srExcelReadSave.php", method = RequestMethod.POST)
	public String SRSaveData(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		// Internally hitting another Servlet

		// TODO:Spring Multipart enable it,Servlet disable it
		SRMappingService srMappingService = new SRMappingServiceImpl();
		boolean resultFlag = srMappingService.saveSRDump(
				(String) request.getAttribute("filePath"),
				ExcelSheetConstants.SR_SHEET_NAME,
				ExcelSheetConstants.SR_TABLE_NAME, jdbcTemplate);
		if (resultFlag) {
			request.setAttribute("srDataSaveResult", "Save Successfully!!!");

		} else {
			request.setAttribute("srDataSaveResult", "Error!!! File Upload");
		}

		return "opportunityTracker/srUpload";
	}

	@RequestMapping(value = "/oppTrcakerHome.php")
	public String home(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		return "opportunityTracker/excaliburUpload";

	}
	@RequestMapping(value = "/loader.php")
	public String loader(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
System.out.println("hiii1");
		return "opportunityTracker/loader";

	}
	@RequestMapping(value = "/loader1.php")
	public String loader1(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
System.out.println("hiii1");
		return "opportunityTracker/indexx";

	}
	@RequestMapping(value = "/getOppName.php", method = RequestMethod.GET)
	public void getOppName(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		ExcaliburDaoImpl daoImpl = new ExcaliburDaoImpl();

		response.getWriter().print(
				daoImpl.getOppName(jdbcTemplate,
						(String) request.getParameter("excalibur")));
		
	}
	@RequestMapping(value = "/getaccmanagerName.php", method = RequestMethod.GET)
	public void getaccmanagerName(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		ExcaliburDaoImpl daoImpl = new ExcaliburDaoImpl();

		response.getWriter().print(
				daoImpl.getaccname(jdbcTemplate,
						(String) request.getParameter("excalibur")));
		
	}

	@RequestMapping(value = "/srExcaliburMapping.php" )
	public String goToSRExcaliburMappingPage(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		try{
		HttpSession session=request.getSession(true);  
    int managerid=(int)session.getAttribute("managerId");
    System.out.println("srexmap     "+managerid);
   
try{
		SRMappingService srMappingService = new SRMappingServiceImpl();
		request.setAttribute("excaliburList", srMappingService
				.getALLExcaliburData(jdbcTemplate, (String) request
						.getSession().getAttribute("LOGINNAME")));
		request.setAttribute("srDataList", srMappingService.getAllSRData(
				jdbcTemplate,
				(String) request.getSession().getAttribute("LOGINNAME")));
		request.setAttribute(
				"managerList",
				srMappingService
						.getAMDMName(
								jdbcTemplate,
								(String) request.getSession().getAttribute(
										"LOGINNAME")).get(0));
		
		
}
catch(Exception e){
	return "opportunityTracker/srexcaliburmaperrorpage";
}
   
		}
		catch(Exception e){
			return"forward:../../pmoAutomation/Login/errorPage.php";
		}
		return "opportunityTracker/srExcaliburMapping";

	}
	@RequestMapping(value = "/ytjUpload.php", method = RequestMethod.GET)
	public String YTJ(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		return "opportunityTracker/Yettojoin";

	}
	@RequestMapping(value = "/YTJExcelUpload.php", method = RequestMethod.POST)
	public void uplaodYTJFile(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		// Internally hitting another Servlet
System.out.println("in ytjjjjjjj");
		// TODO:Spring Multipart enable it,Servlet disable it
		request.setAttribute("fileType", "YTJ");
		request.getRequestDispatcher("/fileUpload.asspx").forward(request,
				response);

	}
	@RequestMapping(value = "/YTJExcelReadSave.php", method = RequestMethod.POST)
	public String YTJExcelRedingAndSaving(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		System.out.println("in ytjjjjjjj 1");
		YTJService rasService = new YTJServiceImpl();
		boolean resultFlag = rasService.saveExcalibur(
				(String) request.getAttribute("filePath"),
				ExcelSheetConstants.YTJSHEETNAME,
				ExcelSheetConstants.YTJTABLENAME, jdbcTemplate);
		String excaliburSaveResult = resultFlag == true ? "Successfully Uploaded!!!"
				: "Error!!!Uploading the File";
		request.setAttribute("uploadDataSaveResult", excaliburSaveResult);
		return "opportunityTracker/Yettojoin";

	}

	@RequestMapping(value = "/srExcaliburMappingSave.php", method = {RequestMethod.GET,RequestMethod.POST })
	public String saveSRExcaliburMapping(Model model, HttpServletRequest request,
			HttpServletResponse response) throws Exception, ServletException, IOException {
	try{
		SRMappingService srMappingService = new SRMappingServiceImpl();

		String count = request.getParameter("id");
		String accountManager = request.getParameter("am" + count);
		String srID = request.getParameter("srID" + count);
		String excaliburID = request.getParameter("excaliburID" + count);
		System.out.println(count + " " + accountManager + "  " + srID + " "
				+ excaliburID);
		boolean flagResult = srMappingService.saveSRExcaliburMapping(
				jdbcTemplate, srID, excaliburID, request
						.getSession().getAttribute("managerId") + "");
		PrintWriter pw=response.getWriter();
		response.setContentType("text/html"); 
		pw.println("<html><head>");
		pw.println("<script type=\"text/javascript\">");  
		pw.println("alert('hiiiiiiiiiiiiiiiiiiiiiiiiii');");  
		pw.println("</script>");
		pw.println("</head><body></body></html>");
		if (flagResult) {
			
			//pw.println("alert");
			request.setAttribute("resultSRExcalibur", "Successfully Updated!!!");
			
		} else {
			request.setAttribute("resultSRExcalibur",
					"Error!!! Problem In Updation");
		}
	}
	catch(Exception e){
		return "forward:../../pmoAutomation/Login/errorPage.php";
	}
		
	
		return "forward:../../pmoAutomation/OpportunityTracker/srExcaliburMapping.php";

	}

	@RequestMapping(value = "/excelReadSave.php", method = RequestMethod.POST)
	public String excelRedingAndSaving(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		ExcaliburService excaliburService = new ExcaliburServiceImpl();
		boolean resultFlag = excaliburService.saveExcalibur(
				(String) request.getAttribute("filePath"),
				ExcelSheetConstants.EXCALIBUR_TABLE_NAME,
				ExcelSheetConstants.EXCALIBUR_SHEET_NAME, jdbcTemplate);
		String excaliburSaveResult = resultFlag == true ? "Successfully Uploaded!!!"
				: "Error!!!Uploading the File";
		request.setAttribute("excaliburSaveResult", excaliburSaveResult);
		return "opportunityTracker/excaliburUpload";

	}

	@RequestMapping(value = "/pmdmMapping.php")
	public String managerMapping(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		 String profile =  (String) session.getAttribute("LOGINNAME");
		 System.out.println(profile);

		SRMappingService srMappingService = new SRMappingServiceImpl();
		SRMappingDaoImpl srMappingDaoImpl =new SRMappingDaoImpl();
	request.setAttribute("excaliburAllData",
				srMappingService.getALLExcaliburData(profile, jdbcTemplate));
	    request.setAttribute("pmautopopulate", srMappingDaoImpl.pmautopop(profile, jdbcTemplate));
	    System.out.println(srMappingDaoImpl.pmautopop(profile, jdbcTemplate));
		return "opportunityTracker/dmPmMap";

	}

	@RequestMapping(value = "/srUpload.php", method = RequestMethod.GET)
	public String SRUpload(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		return "opportunityTracker/srUpload";

	}

	@RequestMapping(value = "/updateExcalibur.php", method = {RequestMethod.GET,RequestMethod.POST })
	public String fetchPMNames(Model model,HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException,Exception {
try{
		
		String radio_id=request.getParameter("rad");
		
		String[] 	sl=request.getParameterValues("sl22");
		String[] 	exeID=request.getParameterValues("1");

	//	System.out.println("radiooooooooooo----------"+radio_id);
		String pmnamee=request.getParameter("pmNameH");
		//System.out.println("updated  ----------------" +pmnamee);
		
		String 	pm[]=request.getParameterValues("dmpmn");
	//	System.out.println("888888888888 "+pm[0]);
		String 	loop=request.getParameter("loop1");
		int lp=Integer.parseInt(loop);
	
	//	System.out.println("lopppppp"+lp);
		
		
		for(int z=0;z<=lp-1;z++){
			
			
			if(radio_id.equalsIgnoreCase(sl[z])){
				System.out.println("serials....."+sl[z]);
				System.out.println("i am here in for loop and if loop");
			System.out.println("-----------------------------"+request.getParameter("pmNameH"));
		//ExcaliburDaoImpl Edao= new ExcaliburDaoImpl();
		SRMappingService srMappingService = new SRMappingServiceImpl();
		//System.out.println("updated-------------" +pmnamee);
	//	System.out.println("LOOK HERE"+request.getParameter("pmNameH"));
		boolean resultFlag = srMappingService.saveExcalibur(
				pm[z],exeID[z],
				jdbcTemplate);
	//	System.out.println("99999999999 "+pm[z]);
		if (resultFlag) {
			request.setAttribute("excaliburUpdate",
					"Successfully Excalibur Updated!!!");
		} else {
			request.setAttribute("excaliburUpdate",
					"Error!!! Problem In Updation");
		}
		mailDao mail=new mailDao();
		App dmpmmailtrig = new App();
		List<mailvoforpm> dmpmmail=mail.listdmpm(jdbcTemplate);
		
		List<String> stringList = new ArrayList<String>(Arrays.asList(exeID[z]));
		String[] array = new String[dmpmmail.size()];
		int index = 0;
		for (Object value : dmpmmail) {
			array[index] = String.valueOf( value );
		
		dmpmmailtrig.Mailtrigger("pmoappadmin_ou@hcl.com",array[index] , "ExcaliburID's Assigned by DM","Harish", "/DMPMMAPTEMP.jsp", stringList, null);
		  //  s.method("shyamsunder.p@hcl.com",array[index] , "Checking Email Triggering", "/dmpmmaptemp.vm", stringList);
		    jdbcTemplate.update(DatabaseQuery.QUERY_TO_FETCH_mailQueryUpdatePMMailStatus+array[index]+"')");
		index++;
		}
		
		
		
		
		
		
		
		//System.out.println("----------"+dmpmmail);
		

		
	
		
		/*List<Excalibur> Exc=Edao.updateRadio(request.getParameter("pmNameH"),exeID[z], jdbcTemplate);
	request.setAttribute("Excalibur123",Exc);*/
			}}
	
	/*	SRMappingService srMappingService = new SRMappingServiceImpl();
		// java.util.List<String> list=
		System.out.println("LOOK HERE"+request.getParameter("pmNameH"));
		
		System.out.println("Excalibur id : " + (String) request.getSession().getAttribute("excaliburID"));
		
		boolean resultFlag = srMappingService.saveExcalibur(
				(String) request.getParameter("pmNameH"),
				(String) request.getSession().getAttribute("excaliburID"),
				jdbcTemplate);
		if (resultFlag) {
			request.setAttribute("excaliburUpdate",
					"Successfully Excalibur Updated!!!");
		} else {
			request.setAttribute("excaliburUpdate",
					"Error!!! Problem In Updation");
		}*/
}
catch(Exception e){
	return "forward:../../pmoAutomation/OpportunityTracker/pmdmMapping.php";
}
		return ("forward:../../pmoAutomation/OpportunityTracker/pmdmMapping.php");

	}

	@RequestMapping(value = "/rasUpload.php", method = RequestMethod.GET)
	public String RASUpload(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		return "opportunityTracker/rasUpload";

	}

	@RequestMapping(value = "/rasExcelUpload.php", method = RequestMethod.POST)
	public void uplaodRASFile(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		// Internally hitting another Servlet

		// TODO:Spring Multipart enable it,Servlet disable it
		request.setAttribute("fileType", "RAS");
		request.getRequestDispatcher("/fileUpload.asspx").forward(request,
				response);

	}

	@RequestMapping(value = "/tscUpload.php", method = RequestMethod.GET)
	public String gotoTSCpage(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		return "opportunityTracker/tscUpload";

	}

	@RequestMapping(value = "/tscExcelUpload.php", method = RequestMethod.POST)
	public void uplaodTSCFile(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		// Internally hitting another Servlet

		// TODO:Spring Multipart enable it,Servlet disable it
		request.setAttribute("fileType", "TSC");
		request.getRequestDispatcher("/fileUpload.asspx").forward(request,
				response);

	}

	@RequestMapping(value = "/rasExcelReadSave.php", method = RequestMethod.POST)
	public String rasExcelRedingAndSaving(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		RASService rasService = new RASServiceImpl();
		boolean resultFlag = rasService.saveRASDump(
				(String) request.getAttribute("filePath"),
				ExcelSheetConstants.RASSHEETNAME,
				ExcelSheetConstants.RASTABLENAME, jdbcTemplate);
		String excaliburSaveResult = resultFlag == true ? "Successfully Uploaded!!!"
				: "Error!!!Uploading the File";
		request.setAttribute("uploadDataSaveResult", excaliburSaveResult);
		return "opportunityTracker/rasUpload";

	}

	@RequestMapping(value = "/tscExcelReadSave.php", method = RequestMethod.POST)
	public String tscExcelRedingAndSaving(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		TSCService tscService = new TSCServiceImpl();
		boolean resultFlag = tscService.saveTSCDump(
				(String) request.getAttribute("filePath"),
				ExcelSheetConstants.TSCSHEETNAME,
				ExcelSheetConstants.TSCTABLEMANE, jdbcTemplate);
		String tscSaveResutl = resultFlag == true ? "Saved Successfully!!!"
				: "Error!!!Uplaoding File";
		request.setAttribute("tscResult", tscSaveResutl);
		return "opportunityTracker/tscUpload";

	}


	@RequestMapping(value = "/srRASMapping.php")
	public String srRASMappingPage(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
try{
		RASService rasService = new RASServiceImpl();
		SRMappingService srMappingService = new SRMappingServiceImpl();
		List<Object[]> rasData = rasService.getRASDataWithNOSRMapped(
				jdbcTemplate, request.getSession().getAttribute("managerId") + "");
		List<String> srIDs = srMappingService.getSRData(jdbcTemplate, request
				.getSession().getAttribute("managerId") + "");
		// System.out.println(rasData);
		request.setAttribute("rasDataList", rasData);
		request.setAttribute("srDataList", srIDs);
}
catch(Exception e){
	return"forward:../../pmoAutomation/Login/errorPage.php";
}
		return "opportunityTracker/srRASMapping";

	}

	@RequestMapping(value = "/getSRDetails.php", method = RequestMethod.GET)
	public void getSRDetail(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		SRMappingDao srMappingDao = new SRMappingDaoImpl();

		response.getWriter().print(
				srMappingDao.getSRDetail(jdbcTemplate,
						(String) request.getParameter("srID")));

	}

	@RequestMapping(value = "/srRASMappingSave.php", method = {RequestMethod.GET,RequestMethod.POST })
	public String saveSRRASMapping(Model model,HttpServletRequest request,
			HttpServletResponse response) throws Exception, ServletException, IOException {
		RASService rasService = new RASServiceImpl();
try{
		int sapCode = Integer.parseInt(request.getParameter("rasSAPID"));
		String srID = request.getParameter("srID"
				+ (String) request.getParameter("id"));
		System.out.println(sapCode + "  " + (String) request.getParameter("id")
				+ "        " + srID);
		boolean resultFlag = rasService.saveSRRASMapping(jdbcTemplate, sapCode,
				srID);

		if (resultFlag) {
			request.setAttribute("srRASMappingResult",
					"Successfully Updated!!!");
		} else {
			request.setAttribute("srRASMappingResult",
					"Error!!! Problem In Updation");
		}
}
catch(Exception e){
	return "forward:../../pmoAutomation/Login/errorPage.php";
}
		return "forward:../../pmoAutomation/OpportunityTracker/srRASMapping.php";

	}

	@RequestMapping(value = "/rasTSCMapping.php", method = RequestMethod.GET)
	public String tasTSCMappingPage(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		TSCService tscService = new TSCServiceImpl();
		List<Object[]> tscDEtails = tscService.getTSCDataH(jdbcTemplate);

		return "opportunityTracker/srRASMapping";

	}

	@RequestMapping(value = "/excaliburView.php", method = RequestMethod.GET)
	public String excaliburViewPage(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		return "opportunityTracker/exCaliburView";

	}
	
	@RequestMapping(value = "/srView.php", method = {RequestMethod.GET,RequestMethod.POST })
	public String srViewPage(Model model,HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException,Exception {

	/*	
		try {
			List<SmartRecruit> smartRecruits=new SRMappingServiceImpl().fetchAllSrData(jdbcTemplate,request.getSession().getAttribute("managerId").toString());
			request.setAttribute("srViewList", smartRecruits);
			return "opportunityTracker/srView";
		} catch (Exception e) {
			return "forward:../../pmoAutomation/Login/errorPage.php";
		}*/
		try{
		HttpSession session = request.getSession();
		 int profile =  (int) session.getAttribute("managerId");
		 System.out.println(profile);
		String start=request.getParameter("date_ex");
		String end=request.getParameter("date_ex1");
		
		SRMappingDaoImpl obj= new SRMappingDaoImpl();
		List<srExcal> view=obj.srexcalview(profile, convert2Date(start), convert2Date(end), jdbcTemplate);
		 request.setAttribute("srexview", view);
		 System.out.println(view);
	
		
		
		return "opportunityTracker/srExcalView";
		}
		catch(Exception e){
			return "forward:../../pmoAutomation/Login/errorPage.php";
		}
	}
	
	@RequestMapping(value = "/srViewVIEW.php", method = RequestMethod.GET)
	public String srViewPageVIEW(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		return "opportunityTracker/srExcalView";
	}

	@RequestMapping(value = "/srExcalView.php", method = RequestMethod.GET)
	public String srExcalViewPage(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		
		try {
			List<SmartRecruit> smartRecruits=new SRMappingServiceImpl().fetchAllSrData(jdbcTemplate,request.getSession().getAttribute("managerId").toString());
			request.setAttribute("srViewList", smartRecruits);
			return "opportunityTracker/srView";
		} catch (Exception e) {
			return "forward:../../pmoAutomation/Login/errorPage.php";
		}

	}
	Date convert2Date(String date)
    {

           SimpleDateFormat simDate = null;
           java.util.Date dateobj1 = null;
           java.sql.Date newDate = null;

           try 
           {
                  
                  if (date.indexOf("/")>0)
                  {
                        simDate=new SimpleDateFormat("MM/dd/yyyy");
                        dateobj1 = simDate.parse(date);         
                        newDate = new java.sql.Date(dateobj1.getTime());
                  
                  }
                  else if(date.indexOf("-")>0)
                  {
                        simDate = new SimpleDateFormat("yyyy-MM-dd");
                        dateobj1 = simDate.parse(date);         
                        newDate = new java.sql.Date(dateobj1.getTime());
           
                        
                  }
                  else{
                        date=null;
                  }
                  

           }
           catch(Exception e)
           {
                  e.printStackTrace();
           }             
           
           return newDate;
    }


}

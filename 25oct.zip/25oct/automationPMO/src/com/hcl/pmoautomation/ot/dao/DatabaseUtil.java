package com.hcl.pmoautomation.ot.dao;

import java.sql.DriverManager;

import com.mysql.jdbc.Connection;

public class DatabaseUtil {

	public synchronized static Connection getConnection() {

		Connection connection = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = (Connection) DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/mydb", "root", "root");

		} catch (Exception e) {
			e.printStackTrace();
		}
		return connection;
	}

	public synchronized static void databaseClose(Connection connection) {

		try {
			if (!connection.isClosed()) {

//				connection.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

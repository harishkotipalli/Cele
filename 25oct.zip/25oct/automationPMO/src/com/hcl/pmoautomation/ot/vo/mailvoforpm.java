package com.hcl.pmoautomation.ot.vo;

public class mailvoforpm {
	private String pm_mail_id;

	public String getPm_mail_id() {
		return pm_mail_id;
	}

	public void setPm_mail_id(String pm_mail_id) {
		this.pm_mail_id = pm_mail_id;
	}

	@Override
	public String toString() {
		return pm_mail_id ;
	}

	
	
	
}

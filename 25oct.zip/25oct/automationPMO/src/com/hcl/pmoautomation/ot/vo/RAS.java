package com.hcl.pmoautomation.ot.vo;

public class RAS {

	public String currentDay;
	public String empName;
	public String sapCode;
	public String band;	
	public String subBand;
	public String fresherLateralTP;
	public String designation;
	public String repMgrCode;
	public String repMgrName;
	public String LOBCode;
	public String SBUCode;
	public String BUCode;
	public String totalExperience;
	public String relEx;
	public String LOBDesc;
	public String SBUDesc;
	public String BUDesc;
	public String Location;
	public String onSiteOffShore;
	public String projcount;
	public String projectCode;
	public String projectName;
	public String resStartDate;
	public String resEndDate;
	public String lastbilled;
	public String proj_LobCode;
	public String proj_LOBDesc;
	public String proj_SBUCode;
	public String proj_SBUDesc;
	public String proj_BUCode;
	public String proj_BuDesc;
	public String lastbilled_amt;
	public String billed_YTD;
	public String billed_tilldate;
	public String PMCode;
	public String PMName;
	public String SPMCode;
	public String SPMName;
	public String CustCode;
	public String CustName;
	public String billedReasons;
	public String billedStatus;
	public String allocation;
	public String GFTE;
	
	
	public RAS() {
		// TODO Auto-generated constructor stub
	}
	
	public RAS(String currentDay, String empName, String sapCode, String band,
			String subBand, String fresherLateralTP, String designation,
			String repMgrCode, String repMgrName, String lOBCode,
			String sBUCode, String bUCode, String totalExperience,
			String relEx, String lOBDesc, String sBUDesc, String bUDesc,
			String location, String onSiteOffShore, String projcount,
			String projectCode, String projectName, String resStartDate,
			String resEndDate, String lastbilled, String proj_LobCode,
			String proj_LOBDesc, String proj_SBUCode, String proj_SBUDesc,
			String proj_BUCode, String proj_BuDesc, String lastbilled_amt,
			String billed_YTD, String billed_tilldate, String pMCode,
			String pMName, String sPMCode, String sPMName, String custCode,
			String custName, String billedReasons, String billedStatus,
			String allocation, String gFTE) {
		super();
		this.currentDay = currentDay;
		this.empName = empName;
		this.sapCode = sapCode;
		this.band = band;
		this.subBand = subBand;
		this.fresherLateralTP = fresherLateralTP;
		this.designation = designation;
		this.repMgrCode = repMgrCode;
		this.repMgrName = repMgrName;
		LOBCode = lOBCode;
		SBUCode = sBUCode;
		BUCode = bUCode;
		this.totalExperience = totalExperience;
		this.relEx = relEx;
		LOBDesc = lOBDesc;
		SBUDesc = sBUDesc;
		BUDesc = bUDesc;
		Location = location;
		this.onSiteOffShore = onSiteOffShore;
		this.projcount = projcount;
		this.projectCode = projectCode;
		this.projectName = projectName;
		this.resStartDate = resStartDate;
		this.resEndDate = resEndDate;
		this.lastbilled = lastbilled;
		this.proj_LobCode = proj_LobCode;
		this.proj_LOBDesc = proj_LOBDesc;
		this.proj_SBUCode = proj_SBUCode;
		this.proj_SBUDesc = proj_SBUDesc;
		this.proj_BUCode = proj_BUCode;
		this.proj_BuDesc = proj_BuDesc;
		this.lastbilled_amt = lastbilled_amt;
		this.billed_YTD = billed_YTD;
		this.billed_tilldate = billed_tilldate;
		PMCode = pMCode;
		PMName = pMName;
		SPMCode = sPMCode;
		SPMName = sPMName;
		CustCode = custCode;
		CustName = custName;
		this.billedReasons = billedReasons;
		this.billedStatus = billedStatus;
		this.allocation = allocation;
		GFTE = gFTE;
	}
	public String getCurrentDay() {
		return currentDay;
	}
	public void setCurrentDay(String currentDay) {
		this.currentDay = currentDay;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getSapCode() {
		return sapCode;
	}
	public void setSapCode(String sapCode) {
		this.sapCode = sapCode;
	}
	public String getBand() {
		return band;
	}
	public void setBand(String band) {
		this.band = band;
	}
	public String getSubBand() {
		return subBand;
	}
	public void setSubBand(String subBand) {
		this.subBand = subBand;
	}
	public String getFresherLateralTP() {
		return fresherLateralTP;
	}
	public void setFresherLateralTP(String fresherLateralTP) {
		this.fresherLateralTP = fresherLateralTP;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getRepMgrCode() {
		return repMgrCode;
	}
	public void setRepMgrCode(String repMgrCode) {
		this.repMgrCode = repMgrCode;
	}
	public String getRepMgrName() {
		return repMgrName;
	}
	public void setRepMgrName(String repMgrName) {
		this.repMgrName = repMgrName;
	}
	public String getLOBCode() {
		return LOBCode;
	}
	public void setLOBCode(String lOBCode) {
		LOBCode = lOBCode;
	}
	public String getSBUCode() {
		return SBUCode;
	}
	public void setSBUCode(String sBUCode) {
		SBUCode = sBUCode;
	}
	public String getBUCode() {
		return BUCode;
	}
	public void setBUCode(String bUCode) {
		BUCode = bUCode;
	}
	public String getTotalExperience() {
		return totalExperience;
	}
	public void setTotalExperience(String totalExperience) {
		this.totalExperience = totalExperience;
	}
	public String getRelEx() {
		return relEx;
	}
	public void setRelEx(String relEx) {
		this.relEx = relEx;
	}
	public String getLOBDesc() {
		return LOBDesc;
	}
	public void setLOBDesc(String lOBDesc) {
		LOBDesc = lOBDesc;
	}
	public String getSBUDesc() {
		return SBUDesc;
	}
	public void setSBUDesc(String sBUDesc) {
		SBUDesc = sBUDesc;
	}
	public String getBUDesc() {
		return BUDesc;
	}
	public void setBUDesc(String bUDesc) {
		BUDesc = bUDesc;
	}
	public String getLocation() {
		return Location;
	}
	public void setLocation(String location) {
		Location = location;
	}
	public String getOnSiteOffShore() {
		return onSiteOffShore;
	}
	public void setOnSiteOffShore(String onSiteOffShore) {
		this.onSiteOffShore = onSiteOffShore;
	}
	public String getProjcount() {
		return projcount;
	}
	public void setProjcount(String projcount) {
		this.projcount = projcount;
	}
	public String getProjectCode() {
		return projectCode;
	}
	public void setProjectCode(String projectCode) {
		this.projectCode = projectCode;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getResStartDate() {
		return resStartDate;
	}
	public void setResStartDate(String resStartDate) {
		this.resStartDate = resStartDate;
	}
	public String getResEndDate() {
		return resEndDate;
	}
	public void setResEndDate(String resEndDate) {
		this.resEndDate = resEndDate;
	}
	public String getLastbilled() {
		return lastbilled;
	}
	public void setLastbilled(String lastbilled) {
		this.lastbilled = lastbilled;
	}
	public String getProj_LobCode() {
		return proj_LobCode;
	}
	public void setProj_LobCode(String proj_LobCode) {
		this.proj_LobCode = proj_LobCode;
	}
	public String getProj_LOBDesc() {
		return proj_LOBDesc;
	}
	public void setProj_LOBDesc(String proj_LOBDesc) {
		this.proj_LOBDesc = proj_LOBDesc;
	}
	public String getProj_SBUCode() {
		return proj_SBUCode;
	}
	public void setProj_SBUCode(String proj_SBUCode) {
		this.proj_SBUCode = proj_SBUCode;
	}
	public String getProj_SBUDesc() {
		return proj_SBUDesc;
	}
	public void setProj_SBUDesc(String proj_SBUDesc) {
		this.proj_SBUDesc = proj_SBUDesc;
	}
	public String getProj_BUCode() {
		return proj_BUCode;
	}
	public void setProj_BUCode(String proj_BUCode) {
		this.proj_BUCode = proj_BUCode;
	}
	public String getProj_BuDesc() {
		return proj_BuDesc;
	}
	public void setProj_BuDesc(String proj_BuDesc) {
		this.proj_BuDesc = proj_BuDesc;
	}
	public String getLastbilled_amt() {
		return lastbilled_amt;
	}
	public void setLastbilled_amt(String lastbilled_amt) {
		this.lastbilled_amt = lastbilled_amt;
	}
	public String getBilled_YTD() {
		return billed_YTD;
	}
	public void setBilled_YTD(String billed_YTD) {
		this.billed_YTD = billed_YTD;
	}
	public String getBilled_tilldate() {
		return billed_tilldate;
	}
	public void setBilled_tilldate(String billed_tilldate) {
		this.billed_tilldate = billed_tilldate;
	}
	public String getPMCode() {
		return PMCode;
	}
	public void setPMCode(String pMCode) {
		PMCode = pMCode;
	}
	public String getPMName() {
		return PMName;
	}
	public void setPMName(String pMName) {
		PMName = pMName;
	}
	public String getSPMCode() {
		return SPMCode;
	}
	public void setSPMCode(String sPMCode) {
		SPMCode = sPMCode;
	}
	public String getSPMName() {
		return SPMName;
	}
	public void setSPMName(String sPMName) {
		SPMName = sPMName;
	}
	public String getCustCode() {
		return CustCode;
	}
	public void setCustCode(String custCode) {
		CustCode = custCode;
	}
	public String getCustName() {
		return CustName;
	}
	public void setCustName(String custName) {
		CustName = custName;
	}
	public String getBilledReasons() {
		return billedReasons;
	}
	public void setBilledReasons(String billedReasons) {
		this.billedReasons = billedReasons;
	}
	public String getBilledStatus() {
		return billedStatus;
	}
	public void setBilledStatus(String billedStatus) {
		this.billedStatus = billedStatus;
	}
	public String getAllocation() {
		return allocation;
	}
	public void setAllocation(String allocation) {
		this.allocation = allocation;
	}
	public String getGFTE() {
		return GFTE;
	}
	public void setGFTE(String gFTE) {
		GFTE = gFTE;
	}
	@Override
	public String toString() {
		return "RAS [currentDay=" + currentDay + ", empName=" + empName
				+ ", sapCode=" + sapCode + ", band=" + band + ", subBand="
				+ subBand + ", fresherLateralTP=" + fresherLateralTP
				+ ", designation=" + designation + ", repMgrCode=" + repMgrCode
				+ ", repMgrName=" + repMgrName + ", LOBCode=" + LOBCode
				+ ", SBUCode=" + SBUCode + ", BUCode=" + BUCode
				+ ", totalExperience=" + totalExperience + ", relEx=" + relEx
				+ ", LOBDesc=" + LOBDesc + ", SBUDesc=" + SBUDesc + ", BUDesc="
				+ BUDesc + ", Location=" + Location + ", onSiteOffShore="
				+ onSiteOffShore + ", projcount=" + projcount
				+ ", projectCode=" + projectCode + ", projectName="
				+ projectName + ", resStartDate=" + resStartDate
				+ ", resEndDate=" + resEndDate + ", lastbilled=" + lastbilled
				+ ", proj_LobCode=" + proj_LobCode + ", proj_LOBDesc="
				+ proj_LOBDesc + ", proj_SBUCode=" + proj_SBUCode
				+ ", proj_SBUDesc=" + proj_SBUDesc + ", proj_BUCode="
				+ proj_BUCode + ", proj_BuDesc=" + proj_BuDesc
				+ ", lastbilled_amt=" + lastbilled_amt + ", billed_YTD="
				+ billed_YTD + ", billed_tilldate=" + billed_tilldate
				+ ", PMCode=" + PMCode + ", PMName=" + PMName + ", SPMCode="
				+ SPMCode + ", SPMName=" + SPMName + ", CustCode=" + CustCode
				+ ", CustName=" + CustName + ", billedReasons=" + billedReasons
				+ ", billedStatus=" + billedStatus + ", allocation="
				+ allocation + ", GFTE=" + GFTE + "]";
	}
	
	
	


}

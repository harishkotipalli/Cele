package com.hcl.pmoautomation.ot.service;

import java.io.IOException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.hcl.pmoautomation.ot.dao.RASDao;
import com.hcl.pmoautomation.ot.dao.RASDaoImpl;
import com.hcl.pmoautomation.ot.dao.TSCDao;
import com.hcl.pmoautomation.ot.dao.TSCDaoImpl;
import com.hcl.pmoautomation.ot.utility.ExcelGenericReader;


public class TSCServiceImpl implements TSCService{

	@Override
	public boolean saveTSCDump(String tscFilePath, String tscSheetName,
			String tscTableName, JdbcTemplate jdbcTemplate) {
		TSCDao tscDao = new TSCDaoImpl();
		boolean resultFlag = false;
		try {
			resultFlag = tscDao.saveTSCDumpData(ExcelGenericReader
					.readExcelAllDynamically(tscFilePath, tscSheetName,
							tscTableName, jdbcTemplate), tscTableName,
					jdbcTemplate);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return resultFlag;
	}

	@Override
	public List<Object[]> getTSCDataH(JdbcTemplate jdbcTemplate) {
		TSCDao tscDao=new TSCDaoImpl();
		return tscDao.getTSCDataH(jdbcTemplate) ;
	}

}

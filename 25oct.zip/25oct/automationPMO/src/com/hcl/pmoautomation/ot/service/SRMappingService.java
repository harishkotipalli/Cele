package com.hcl.pmoautomation.ot.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;

import com.hcl.pmoautomation.ot.vo.Excalibur;

public interface SRMappingService {
	
	public List<Excalibur>  getALLExcaliburData(String loginname,JdbcTemplate jdbcTemplate);

	public List<String> fecthPMNames();

	public boolean saveExcalibur(String pm, String excaliburID, JdbcTemplate jdbcTemplate);

	

	public boolean saveSRDump(String attribute, String srSheetName,
			String srTableName, JdbcTemplate jdbcTemplate);

	

	

	List<String> getALLExcaliburData(JdbcTemplate jdbcTemplate, String attribute);

	List<Map<String, Object>> getAllSRData(JdbcTemplate jdbcTemplate,
			String attribute);

	public List<Map<String, Object>> getAMDMName(JdbcTemplate jdbcTemplate, String attribute);

	public boolean saveSRExcaliburMapping(JdbcTemplate jdbcTemplate,
			String srID, String excaliburID, String pmCode);

	public List<String> getSRData(JdbcTemplate jdbcTemplate,String pmCode);



}

package com.hcl.pmoautomation.ot.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.hcl.pmoautomation.ot.dao.RASDao;
import com.hcl.pmoautomation.ot.dao.RASDaoImpl;
import com.hcl.pmoautomation.ot.utility.ExcelGenericReader;

public class RASServiceImpl implements RASService {

	@Override
	public boolean saveRASDump(String rasFilePath, String rasSheetName,
			String rasTableName, JdbcTemplate jdbcTemplate) {

		RASDao rasDao = new RASDaoImpl();
		boolean resultFlag = false;
		try {
			resultFlag = rasDao.saveRASDumpData(ExcelGenericReader
					.readExcelAllDynamically(rasFilePath, rasSheetName,
							rasTableName, jdbcTemplate), rasTableName,
					jdbcTemplate);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return resultFlag;
	}

	@Override
	public List<Object[]> getRASDataWithNOSRMapped(JdbcTemplate jdbcTemplate,
			String pmCode) {
		
		RASDao rasDao=new RASDaoImpl();
		
				return rasDao.getRASDataWithNOSRMapped(jdbcTemplate,pmCode);
		
		
	}

	@Override
	public boolean saveSRRASMapping(JdbcTemplate jdbcTemplate, int sapCode,String srID) {
	
		RASDao rasDao=new RASDaoImpl();
		return rasDao.saveSRRASMapping(jdbcTemplate,sapCode,srID);
		
		
	}
}

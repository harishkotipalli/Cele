package com.hcl.pmoautomation.ot.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;


public interface ExcaliburService {

	public boolean saveExcalibur(String filePath, String tableName,
			String sheetName,JdbcTemplate jdbcTemplate);

	

//	public List<ArrayList<String>> viewExcalibur();
//
//	
//
//	public Map<String, Boolean> getMandatoryFieldNames(String filePath,
//			String tableName, String sheetName);
//
//	public boolean checkMandatoryFields(String filePath, String tableName,
//			String sheetName);
//
//	public boolean saveExcalibur(String filePath, String tableName,
//			String sheetName, Map<String, Boolean> mandatoryFieldList);

}

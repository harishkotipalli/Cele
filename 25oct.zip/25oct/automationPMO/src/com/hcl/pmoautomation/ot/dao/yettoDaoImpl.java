package com.hcl.pmoautomation.ot.dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;

public class yettoDaoImpl implements yettoDao{

	
	
	


	








	@Override
	public boolean saveRASDumpData(List<ArrayList<String>> readExcelAllDynamically, String rasTableName,
			JdbcTemplate jdbcTemplate) throws ParseException {

		// JdbcTemplate jdbcTemplate = new JdbcTemplate();
		int count = 0;
		boolean resultFlag = false;
		String[] returnData = null;
		List<Map<String, Object>> columnNames = getAllColumnNamesDynamically(
				rasTableName, jdbcTemplate);

		StringBuilder sqlQuery = new StringBuilder();
		//sqlQuery = sqlQuery.append("insert into " + rasTableName + "(");
		sqlQuery = sqlQuery.append("call yettojoin  (");
/*
		for (Map columnMapRowData : columnNames) {
			String tempData = (String) columnMapRowData.get("column_name");

			if (count == columnNames.size() - 1) {
				sqlQuery.append("`" + tempData.trim() + "`,`MODIFIED_DATE`) values (");
				break;
			}
			sqlQuery.append("`" + tempData.trim() + "`,");

			count++;
		}*/

		// For Adding the Values
		count = 0;
		
		for (Map columnMapRowData : columnNames) 
		{
			System.out.println("Index:" + count + " Value:"+columnMapRowData);
			if (count == columnNames.size() -1 ) {
				//sqlQuery.append("?" + ",?)");
				sqlQuery.append("?" +")");
				break;
			}
			sqlQuery.append("?" + ",");

			count++;
		}
		//
		System.out.println("sqlQuery 1 :" + sqlQuery);
		// final Object[] objects =
		// setAllDataDynamically(readExcelAllDynamically,
		// columnNames);
		final List<Object[]> objects2 = setAllDataDynamically(
				readExcelAllDynamically, columnNames);
		/*for (ArrayList<String> ps : readExcelAllDynamically) {
			// System.out.println(ps);
		}
		for (Object[] objects : objects2) {
			System.out.println(Arrays.toString(objects));
		}*/
		// System.out.println("Size :" + objects2.size());
		final List<String> columnDataTypes = new ArrayList<String>();
	
		for (Map map : columnNames) 
		{
			columnDataTypes.add((String) map.get("COLUMN_DATATYPE"));
		}
		try {
			// resultFlag= jdbcTemplate.update(
			// sqlQuery.toString(),
			// setAllDataDynamically(readExcelAllDynamically,
			// columnNames))>0?true:false;
			System.out.println("sqlQuery 2:"+sqlQuery);

			resultFlag = (jdbcTemplate.batchUpdate(sqlQuery.toString(),
					new BatchPreparedStatementSetter() 
			{

						@Override
						public void setValues(java.sql.PreparedStatement ps,
								int j) throws SQLException {
							Object[] objects = objects2.get(j);

							ps.setString(1, (String) objects[0]);
							ps.setString(2, (String) objects[1]);
							ps.setString(3, (String) objects[2]);
							ps.setString(4, (String) objects[3]);
							ps.setString(5, (String) objects[4]);
							ps.setString(6, (String) objects[5]);
							ps.setString(7, (String) objects[6]);
							//ps.setString(8, (String) objects[7]);
							if (!(objects[7] == null)) {
								ps.setDate(8, new java.sql.Date(
										((Date) objects[7]).getTime()));
							}
							if ((objects[7] == null)) {
								ps.setDate(8, null);
							}
							
							if (!(objects[8] == null)) {
								ps.setDate(9, new java.sql.Date(
										((Date) objects[8]).getTime()));
							}
							if ((objects[8] == null)) {
								ps.setDate(9, null);
							}
							
							
							
							if (!(objects[9] == null)) {
								ps.setDate(10, new java.sql.Date(
										((Date) objects[9]).getTime()));
							}
							if ((objects[9] == null)) {
								ps.setDate(10, null);
							}
							
							if (!(objects[10] == null)) {
								ps.setDate(11, new java.sql.Date(
										((Date) objects[10]).getTime()));
							}
							if ((objects[10] == null)) {
								ps.setDate(11, null);
							}
							
							
							if (!(objects[11] == null)) {
								ps.setDate(12, new java.sql.Date(
										((Date) objects[11]).getTime()));
							}
							if ((objects[11] == null)) {
								ps.setDate(12, null);
							}
							
							
							if (!(objects[12] == null)) {
								ps.setDate(13, new java.sql.Date(
										((Date) objects[12]).getTime()));
							}
							if ((objects[12] == null)) {
								ps.setDate(13, null);
							}
							
							
							
							
							/*if (!(objects[13] == null)) {
								ps.setDate(14, new java.sql.Date(
										((Date) objects[13]).getTime()));
							}
							if ((objects[13] == null)) {
								ps.setDate(14, null);
							}*/
							
							/*if (!(objects[17] == null)) {
								ps.setDate(18, new java.sql.Date(
										((Date) objects[17]).getTime()));
							}
							if ((objects[17] == null)) {
								ps.setDate(18, null);
							}*/
							
							
							
							ps.setString(14, (String) objects[13]);
							ps.setString(15, (String) objects[14]);
							ps.setString(16, (String) objects[15]);
							ps.setString(17, (String) objects[16]);
							ps.setString(18, (String) objects[17]);
							ps.setString(19, (String) objects[18]);
							ps.setString(20, (String) objects[19]);
							ps.setString(21, (String) objects[20]);
							ps.setString(22, (String) objects[21]);
							ps.setString(23, (String) objects[22]);
							ps.setString(24, (String) objects[23]);
							ps.setString(25, (String) objects[24]);
							ps.setString(26, (String) objects[25]);
							ps.setString(27, (String) objects[26]);
							ps.setString(28, (String) objects[27]);
							ps.setString(29, (String) objects[28]);
							ps.setString(30, (String) objects[29]);
							ps.setString(31, (String) objects[30]);
							ps.setString(32, (String) objects[31]);
							ps.setString(33, (String) objects[32]);
							if (!(objects[33] == null)) {
								ps.setDate(34, new java.sql.Date(
										((Date) objects[33]).getTime()));
							}
							if ((objects[33] == null)) {
								ps.setDate(34, null);
							}
							
							
							
							
							ps.setString(35, (String) objects[34]);
							ps.setString(36, (String) objects[35]);
							ps.setString(37, (String) objects[36]);
							
						    ps.setString(38, (String) objects[37]);
						    ps.setString(39, (String) objects[38]);
						    ps.setString(40, (String) objects[39]);	
						    ps.setString(41, (String) objects[40]);
						    ps.setString(42, (String) objects[41]);
							
							
							ps.setString(43, (String) objects[42]);
							ps.setString(44, (String) objects[43]);
							ps.setString(45, (String) objects[44]);
							ps.setString(46, (String) objects[45]);
							
							
							ps.setString(47, (String) objects[46]);
							ps.setString(48, (String) objects[47]);
							
							
							
							if (!(objects[48] == null)) {
								ps.setDate(49, new java.sql.Date(
										((Date) objects[48]).getTime()));
							}
							if ((objects[48] == null)) {
								ps.setDate(49, null);
							}
							ps.setString(50, (String) objects[49]);
							ps.setString(51, (String) objects[50]);
							ps.setString(52, (String) objects[51]);
							ps.setString(53, (String) objects[52]);
							ps.setString(54, (String) objects[53]);
							ps.setString(55, (String) objects[54]);
							ps.setString(56, (String) objects[55]);
							if (!(objects[56] == null)) {
								ps.setDate(57, new java.sql.Date(
										((Date) objects[56]).getTime()));
							}
							if ((objects[56] == null)) {
								ps.setDate(57, null);
							}
							if (!(objects[57] == null)) {
								ps.setDate(58, new java.sql.Date(
										((Date) objects[57]).getTime()));
							}
							if ((objects[57] == null)) {
								ps.setDate(58, null);
							}
							
							ps.setString(59, (String) objects[58]);
							ps.setString(60, (String) objects[59]);
							ps.setString(61, (String) objects[60]);
							ps.setString(62, (String) objects[61]);
							
						}
						
						

						@Override
						public int getBatchSize() 
						{

							return objects2.size();
						}
					})).length >=1 ? true : false;

		} catch (Exception e) {
			
			e.printStackTrace();
		}

		// TODO:LOGIC TO SENT MAIL

		return resultFlag;
		
		
		
	}



	public List<Map<String, Object>> getAllColumnNamesDynamically(
			String tableName, JdbcTemplate jdbcTemplate) 
	{
		System.out.println("Table Name : " + tableName);

		String queryToFetchColumns = DatabaseQuery.QUERY_FETCH_COLUMNS1
				+ tableName + DatabaseQuery.QUERY_FETCH_COLUMNS2;

		System.out.println("queryToFetchColumns:" + queryToFetchColumns);
		// jdbcTemplate=new JdbcTemplate();
		// System.out.println(getJdbcTemplate());
		return jdbcTemplate.queryForList(queryToFetchColumns);
	}
	
	@SuppressWarnings("deprecation")
	private List<Object[]> setAllDataDynamically(
			
			List<ArrayList<String>> arrayLists,
			List<Map<String, Object>> columnNames) throws ParseException 
	{
		List<Object[]> objects = new ArrayList<Object[]>();
		Object[] objectData = null;
		// ArrayList<String> excaliburData = arrayLists.get(0);
		// System.out.println(excaliburData);
		// System.out.println(arrayLists.size());
		int tempCount = 0;
		for (ArrayList<String> excaliburData : arrayLists) 
		{
			objectData = new Object[columnNames.size()];
			for (Map columnMapRowData : columnNames) {
//				 System.out.println(columnMapRowData);
				 System.out.println(excaliburData);
				if (((String) columnMapRowData.get("column_datatype"))
						.equalsIgnoreCase("STRING")) {
					objectData[tempCount] = excaliburData.get(tempCount);
				}
				if (((String) columnMapRowData.get("column_datatype"))
						.equalsIgnoreCase("INT")) {
					if (!(excaliburData.get(tempCount) == null)) {
						objectData[tempCount] = Integer.parseInt(excaliburData
								.get(tempCount));

					}
					if (excaliburData.get(tempCount) == null) {
						objectData[tempCount] = 0;
					}
				}
				if (((String) columnMapRowData.get("column_datatype"))
						.equalsIgnoreCase("Date")) {

					if (!(excaliburData.get(tempCount) == null)) {
						objectData[tempCount] = new Date(new java.util.Date(
								excaliburData.get(tempCount)).getTime());
						
						//String deliverydate="02-SEP-2012";
						/*SimpleDateFormat sdf=new SimpleDateFormat("dd-MMM-yyyy");

						Date date=sdf.parse(excaliburData.get(tempCount));

						sdf=new SimpleDateFormat("MM/dd/yyyy");
						objectData[tempCount] = sdf.format(date);
						System.out.println(sdf.format(date));*/
						//objectData[tempCount] =	new SimpleDateFormat("yyyy-MMM-dd").parse(excaliburData.get(tempCount)).getTime(); 
					}

					if (excaliburData.get(tempCount) == null) {
						objectData[tempCount] = null;
					}
				}

				// System.out.println(objectData[tempCount]);
				tempCount++;

			}

			tempCount = 0;
			objects.add(objectData);

		}
		// System.out.println("Ending Setter");

		return objects;
	}





	@Override
	public List<Object[]> getRASDataWithNOSRMapped(JdbcTemplate jdbcTemplate, String pmCode) {
		// TODO Auto-generated method stub
		return null;
	}








	@Override
	public boolean saveSRRASMapping(JdbcTemplate jdbcTemplate, int sapCode, String srID) {
		// TODO Auto-generated method stub
		return false;
	}

	
	
}

package com.hcl.pmoautomation.ot.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

public interface RASDao {
	
	boolean saveRASDumpData(List<ArrayList<String>> readExcelAllDynamically,
			String rasTableName, JdbcTemplate jdbcTemplate);

	List<Object[]> getRASDataWithNOSRMapped(JdbcTemplate jdbcTemplate, String pmCode);

	boolean saveSRRASMapping(JdbcTemplate jdbcTemplate, int sapCode, String srID);

}

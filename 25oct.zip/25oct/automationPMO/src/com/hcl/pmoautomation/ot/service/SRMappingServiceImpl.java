package com.hcl.pmoautomation.ot.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;

import com.hcl.pmoautomation.ot.dao.DatabaseUtil;
import com.hcl.pmoautomation.ot.dao.SRMappingDao;
import com.hcl.pmoautomation.ot.dao.SRMappingDaoImpl;
import com.hcl.pmoautomation.ot.utility.ExcelGenericReader;
import com.hcl.pmoautomation.ot.vo.Excalibur;
import com.hcl.pmoautomation.ot.vo.SmartRecruit;
import com.mysql.jdbc.Connection;

public class SRMappingServiceImpl implements SRMappingService {

	private SRMappingDao srMappingDao;

	@Override
	public List<Excalibur> getALLExcaliburData(String loginname,JdbcTemplate jdbcTemplate) {

		srMappingDao = new SRMappingDaoImpl();
		List<Excalibur> excaliburData = srMappingDao
				.getExcaliburData(loginname, jdbcTemplate);
		return excaliburData;
	}

	@Override
	public List<String> fecthPMNames() {
		srMappingDao = new SRMappingDaoImpl();

		return srMappingDao.fetchPMName();
	}

	@Override
	public boolean saveExcalibur(String parameter, String excaliburID,
			JdbcTemplate jdbcTemplate) {
		srMappingDao = new SRMappingDaoImpl();

		return srMappingDao.saveExcalibur(parameter, excaliburID, jdbcTemplate);
	}

	@Override
	public boolean saveSRDump(String attribute, String srSheetName,
			String srTableName, JdbcTemplate jdbcTemplate) {
		srMappingDao = new SRMappingDaoImpl();
	boolean flag=false;
		try {
			flag=srMappingDao.saveSRDumpData(ExcelGenericReader
					.readExcelAllDynamically(attribute, srSheetName,
							srTableName, jdbcTemplate), srTableName,
					jdbcTemplate);
		} catch (Exception e) {
			// TODO: handle exception
		}
		return flag;

	}

	@Override
	public List<Map<String, Object>> getAllSRData(JdbcTemplate jdbcTemplate, String attribute) {
		srMappingDao=new SRMappingDaoImpl();
	return	srMappingDao.getAllSRData(jdbcTemplate,attribute);
		
	}

	@Override
	public List<String> getALLExcaliburData(JdbcTemplate jdbcTemplate,
			String attribute) {
		srMappingDao=new SRMappingDaoImpl();
	
		return	srMappingDao.getAllExcaliburData(jdbcTemplate,attribute);
	}

	@Override
	public List<Map<String, Object>> getAMDMName(JdbcTemplate jdbcTemplate,
			String attribute) {
		srMappingDao=new SRMappingDaoImpl();
		
		return srMappingDao.getAMDMName(jdbcTemplate,attribute);
	}

	@Override
	public boolean saveSRExcaliburMapping(JdbcTemplate jdbcTemplate,
			 String srID, String excaliburID,String pmCode) {
		srMappingDao=new SRMappingDaoImpl();
		
		return srMappingDao.saveSRExcaliburMapping(jdbcTemplate,srID,excaliburID,pmCode);
	}

	@Override
	public List<String> getSRData(JdbcTemplate jdbcTemplate,String pmCode) {
		srMappingDao=new SRMappingDaoImpl();
		
		return srMappingDao.getSRData(jdbcTemplate,pmCode);
	}

	public List<SmartRecruit> fetchAllSrData(JdbcTemplate jdbcTemplate, String managerId) {
		
		return new SRMappingDaoImpl().fetchAllSrData(jdbcTemplate,managerId);
	}

}

package com.hcl.pmoautomation.ot.service;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.hcl.pmoautomation.ot.dao.ExcaliburDao;
import com.hcl.pmoautomation.ot.dao.ExcaliburDaoImpl;
import com.hcl.pmoautomation.ot.dao.yettoDao;
import com.hcl.pmoautomation.ot.dao.yettoDaoImpl;
import com.hcl.pmoautomation.ot.utility.ExcelGenericReader;

public class YTJServiceImpl implements YTJService{

	@Override
	public boolean saveExcalibur(String filePath, String sheetName, String tableName, JdbcTemplate jdbcTemplate) {
		boolean resultFlag=false;
		yettoDao excaliburDao=new yettoDaoImpl();
			 try {
			resultFlag=excaliburDao.saveRASDumpData(ExcelGenericReader
						.readExcelAllDynamically(filePath, sheetName, tableName,jdbcTemplate),
						tableName,jdbcTemplate);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		return resultFlag;
	}



}

package com.hcl.pmoautomation.ot.utility;

public interface ExcelSheetConstants {
	
	public String EXCALIBUR_SHEET_NAME="Excal1";
	public String EXCALIBUR_TABLE_NAME="excalibur1";
	//public int[] EXCALIBUR_MANDATORY_FIELDS_INDEXS={3,6,7,8,9,10,11,12,13,14,25};
	public int[] SR_MANDATORY_FIELDS_INDEXS={16,17,18,19,20,21,22,23,24};
	public String KEY_FIELD_EXCALIBURID="EXCALIBUR / SFA ID";
	public String SR_SHEET_NAME = "SR";
	public String SR_TABLE_NAME = "sr";
	public String RASSHEETNAME = "RAS";
	public String RASTABLENAME = "ras";
	public String TSCSHEETNAME = "Joiner_Pipeline";
	public String TSCTABLEMANE = "tsc";
	
	public String YTJSHEETNAME = "Basedata";
	public String YTJTABLENAME = "yettojoin";

}

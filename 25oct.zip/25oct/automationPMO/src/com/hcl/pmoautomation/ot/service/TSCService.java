package com.hcl.pmoautomation.ot.service;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

public interface TSCService {
	
	

	boolean saveTSCDump(String tscFilePath, String tscSheetName,
			String tscTableName, JdbcTemplate jdbcTemplate);

	List<Object[]> getTSCDataH(JdbcTemplate jdbcTemplate);

}

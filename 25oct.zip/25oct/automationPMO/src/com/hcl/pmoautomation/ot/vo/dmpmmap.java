package com.hcl.pmoautomation.ot.vo;

public class dmpmmap {
	private int dmsap;
	private String dmname;
	private int pmsap;
	private String pmname;
	public int getDmsap() {
		return dmsap;
	}
	public void setDmsap(int dmsap) {
		this.dmsap = dmsap;
	}
	public String getDmname() {
		return dmname;
	}
	public void setDmname(String dmname) {
		this.dmname = dmname;
	}
	public int getPmsap() {
		return pmsap;
	}
	public void setPmsap(int pmsap) {
		this.pmsap = pmsap;
	}
	public String getPmname() {
		return pmname;
	}
	public void setPmname(String pmname) {
		this.pmname = pmname;
	}
	@Override
	public String toString() {
		return "dmpmmap [dmsap=" + dmsap + ", dmname=" + dmname + ", pmsap=" + pmsap + ", pmname=" + pmname + "]";
	}
	
	
}

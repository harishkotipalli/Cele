package com.hcl.pmoautomation.admin.service;

import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;

import com.hcl.pmoautomation.admin.dao.adminRolesDaoI;
import com.hcl.pmoautomation.admin.dao.adminRolesDaoImpl;
import com.hcl.pmoautomation.admin.vo.EmployeeDetails;



public class adminserviceimpl implements adminserviceI {

	@Override
	public EmployeeDetails getAlladminRoles(int managerId, JdbcTemplate jdbcTemplet) {
		adminRolesDaoI adminRoles = new adminRolesDaoImpl();
	  return adminRoles.getAlladminRoles(managerId, jdbcTemplet);
	}


}

package com.hcl.pmoautomation.admin.vo;

import java.util.List;

public class EmployeeDetails {
	
	
	private List<EmployeeRoleAssign> employeeroleassign;
	

	public List<EmployeeRoleAssign> getEmployeeroleassign() {
		return employeeroleassign;
	}

	public void setEmployeeroleassign(List<EmployeeRoleAssign> employeeroleassign) {
		this.employeeroleassign = employeeroleassign;
	}

	@Override
	public String toString() {
		return "EmployeeDetails [employeeroleassign=" + employeeroleassign + "]";
	}
	
	
	

}

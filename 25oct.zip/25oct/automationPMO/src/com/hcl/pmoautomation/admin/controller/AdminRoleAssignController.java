package com.hcl.pmoautomation.admin.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


import com.hcl.pmoautomation.admin.service.adminserviceimpl;

@Controller
@RequestMapping(value =  "pmoAutomation/AdminRoleAccess")


public class AdminRoleAssignController {
	
	@ExceptionHandler(NullPointerException.class)
    public ModelAndView myError(Exception exception) {
    ModelAndView e = new ModelAndView();
    e.addObject("exception", exception);
    e.setViewName("Login/Error");
    return e;
}
	
	@Autowired(required = true)
	JdbcTemplate jdbcTemplate;
	@ExceptionHandler
	@RequestMapping(value =  "/AdminRole.php")
	public ModelAndView getAdminRole(HttpServletRequest request) throws NullPointerException {
		try{
		System.out.println(request.getSession().getAttribute("managerId"));
		System.out.println(request.getAttribute("getAlladminStatus"));
		}
		catch(Exception e){
			
			
		}
		return new ModelAndView("Admin/RoleAssign","listofadminroles",(new adminserviceimpl().getAlladminRoles((int) request
				.getSession().getAttribute("managerId"), jdbcTemplate)));

}
	@RequestMapping(value = "/roleSubmit.php", method = {RequestMethod.POST,RequestMethod.GET})
	public String viewSearch(Model model,HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException,Exception {
			try{	
		String admindetail=request.getParameter("sapAdmin"+request.getParameter("sapHid"));
		System.out.println(request.getParameter("sapHid"));
		String role=request.getParameter("item");
		System.out.println(admindetail);
		/*roleAcessDao rau=new roleAcessDao();
		rau.edit(admindetail, role, jdbcTemplate);
		*/
		
		String updQuery = "update mydb.login set role=? ,ASSIGNED_ROLE='Y' where sapcode=?;";
		this.jdbcTemplate.update(updQuery,  new Object[] {role,admindetail});
			}
			catch(Exception e){
				 return "forward:../../pmoAutomation/Login/errorPage.php";
			}
		/*new adminserviceimpl().getAlladminRoles((int) request
				.getSession().getAttribute("managerId"), jdbcTemplate);*/
				return "forward:../../pmoAutomation/AdminRoleAccess/AdminRole.php";
		
	}

	
}

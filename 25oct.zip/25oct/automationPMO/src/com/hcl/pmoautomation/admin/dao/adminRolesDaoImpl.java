package com.hcl.pmoautomation.admin.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.hcl.pmoautomation.admin.vo.EmployeeDetails;
import com.hcl.pmoautomation.admin.vo.EmployeeRoleAssign;

public class adminRolesDaoImpl implements adminRolesDaoI{

	

	@Override
	public EmployeeDetails getAlladminRoles(int managerId, JdbcTemplate jdbcTemplet) {
		 EmployeeDetails empdetails = new EmployeeDetails();
		 try{
			empdetails.setEmployeeroleassign(getAllNewAdminRoles(managerId, jdbcTemplet)); 
		 }
			 
		 catch(Exception e){
				e.printStackTrace();
			
		 }
		return empdetails;
	}
	
	@Override
	public List<EmployeeRoleAssign> getAllNewAdminRoles(int managerId, JdbcTemplate jdbcTemplet) {
		
        return jdbcTemplet.query(AdminSql.getAdminRoles, new AdminRolesRowMapper());
	}

	

}

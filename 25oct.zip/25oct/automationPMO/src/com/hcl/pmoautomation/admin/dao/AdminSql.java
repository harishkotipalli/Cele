package com.hcl.pmoautomation.admin.dao;

public interface AdminSql {
	public final String getAdminRoles = "select SAPCODE,NAME,USERNAME,Hcl_Mail_Id from login where ASSIGNED_ROLE='N'";
	public final String updaterole="update mydb.login set role='";
			public final String updaterole2=" where sapcode=";
}

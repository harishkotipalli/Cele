package com.hcl.pmoautomation.admin.dao;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.hcl.pmoautomation.admin.vo.EmployeeRoleAssign;

public class AdminRolesRowMapper implements RowMapper<EmployeeRoleAssign>, Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public EmployeeRoleAssign mapRow(ResultSet neJoingResultSet, int arg1) throws SQLException {
		EmployeeRoleAssign emproles = new EmployeeRoleAssign();
		emproles.setSap_code(neJoingResultSet.getInt("SAPCODE"));
		emproles.setName(neJoingResultSet.getString("NAME"));
		emproles.setUsername(neJoingResultSet.getString("USERNAME"));
		emproles.setHcl_mail_id(neJoingResultSet.getString("Hcl_Mail_Id"));
		return emproles;
	}

}

package com.hcl.pmoautomation.admin.service;

import org.springframework.jdbc.core.JdbcTemplate;

import com.hcl.pmoautomation.admin.vo.EmployeeDetails;

public interface adminserviceI {

	public EmployeeDetails getAlladminRoles(int managerId, JdbcTemplate jdbcTemplet);
	

}

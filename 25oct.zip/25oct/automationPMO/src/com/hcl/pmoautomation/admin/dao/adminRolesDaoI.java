package com.hcl.pmoautomation.admin.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.hcl.pmoautomation.admin.vo.EmployeeDetails;
import com.hcl.pmoautomation.admin.vo.EmployeeRoleAssign;




public interface adminRolesDaoI {
	public EmployeeDetails getAlladminRoles (int managerId,JdbcTemplate jdbcTemplet);
	public List<EmployeeRoleAssign> getAllNewAdminRoles(int managerId,JdbcTemplate jdbcTemplate);
			
		
	
}

package com.hcl.pmoautomation.admin.vo;

import java.io.Serializable;
@SuppressWarnings("serial")
public class EmployeeRoleAssign implements Serializable {

private String username;
 private String name;
 private String hcl_mail_id;
 private int sap_code;
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getHcl_mail_id() {
	return hcl_mail_id;
}
public void setHcl_mail_id(String hcl_mail_id) {
	this.hcl_mail_id = hcl_mail_id;
}
public int getSap_code() {
	return sap_code;
}
public void setSap_code(int sap_code) {
	this.sap_code = sap_code;
}
@Override
public String toString() {
	return "EmployeeRoleAssign [username=" + username + ", name=" + name + ", hcl_mail_id=" + hcl_mail_id
			+ ", sap_code=" + sap_code + "]";
}
 
}

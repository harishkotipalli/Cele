package com.hcl.pmoautomation.login.dao;

import com.hcl.pmoautomation.login.controller.loginpassEncry;

public class CDF {

	public static void main(String[] args) {
  System.out.println(new 		loginpassEncry().run("Welcome123")); 
//  System.out.println(new 		loginpassEncry().run("Welcome123").toUpperCase().equals("L�y��^?̹7�y���l".toUpperCase()));;

	}

}

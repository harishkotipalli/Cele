package com.hcl.pmoautomation.login.service;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;

public class MAILASE {

  public static void main(String args[]) {

    try {

	String url = "<![CDATA[ <IMG SRC=\"  javascript:document.vulnerable=true;\"> ]]>";

	String encodedUrl = URLEncoder.encode(url, "UTF-8");

	System.out.println("Encoded URL " + encodedUrl);

	String decodedUrl = URLDecoder.decode(url, "UTF-8");

	System.out.println("Dncoded URL " + decodedUrl);

	} catch (UnsupportedEncodingException e) {

		System.err.println(e);

	}
    }
}
/*
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

public class loginpassEncry {
    public String passencry(String passencryption){
    	  String passencrypted=null;
        try{
            KeyGenerator keygenerator = KeyGenerator.getInstance("DES");
            SecretKey myDesKey = keygenerator.generateKey();

            Cipher desCipher;
            desCipher = Cipher.getInstance("DES");


            byte[] text = passencryption.getBytes("UTF8");


            desCipher.init(Cipher.ENCRYPT_MODE, myDesKey);
            byte[] textEncrypted = desCipher.doFinal(text);

            passencrypted = new String(textEncrypted);
            System.out.println(textEncrypted);

           
        }catch(Exception e)
        {
            System.out.println("Exception");
        }
		return passencrypted;
    }
    
    public String passdencry(String passdencryption){
		String passdecrypted=null;
    	 try{
             KeyGenerator keygenerator = KeyGenerator.getInstance("DES");
             SecretKey myDesKey = keygenerator.generateKey();

             Cipher desCipher;
             desCipher = Cipher.getInstance("DES");
             byte[] text = passdencryption.getBytes("UTF8");
             desCipher.init(Cipher.DECRYPT_MODE, myDesKey);
             byte[] textDecrypted = desCipher.doFinal(text);
            

             passdecrypted = new String(textDecrypted);
             System.out.println(passdecrypted);
         }catch(Exception e)
         {
             System.out.println("Exception");
         }
    	
    	return passdecrypted;
    	
    }
    
}
*/

/*package com.hcl.pmoautomation.login.controller;

import java.security.InvalidKeyException;
import java.security.Key;
import java.security.spec.KeySpec;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class loginpassEncry 
{
	 private static final String UNICODE_FORMAT = "UTF8";
	    public static final String DESEDE_ENCRYPTION_SCHEME = "DESede";
	    private KeySpec ks;
	    private SecretKeyFactory skf;
	    private Cipher cipher;
	    byte[] arrayBytes;
	    private String myEncryptionKey;
	    private String myEncryptionScheme;
	    SecretKey key;

	  public loginpassEncry() throws Exception {
	        myEncryptionKey = "ThisIsSpartaThisIsSparta";
	        myEncryptionScheme = DESEDE_ENCRYPTION_SCHEME;
	        arrayBytes = myEncryptionKey.getBytes(UNICODE_FORMAT);
	        ks = new DESedeKeySpec(arrayBytes);
	        skf = SecretKeyFactory.getInstance(myEncryptionScheme);
	        cipher = Cipher.getInstance(myEncryptionScheme);
	        key = skf.generateSecret(ks);
	    }

	
	 public String decrypt() throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		 
		 String text = "?��2��1j�����";
		 String key = "Bar12345Bar12345";
		 Key aesKey = new SecretKeySpec(key.getBytes(), "AES");
	        String decryptedText="?��2��1j�����";
	        Base64.Decoder decoder = Base64.getDecoder();
	        cipher.init(Cipher.DECRYPT_MODE, aesKey);
	        String decrypted = new String(cipher.doFinal(decoder.decode(decryptedText)));
	        System.out.println(decrypted);
	        return decryptedText;
	    }

    public static void main(String[] args) throws Exception 
    {
    	loginpassEncry app = new loginpassEncry();
        app.decrypt();
    }
}



*/
 
package com.hcl.pmoautomation.login.controller;
import java.security.Key;


import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import org.apache.xmlbeans.impl.util.Base64;




public class loginpassEncry 
{
    public static String run(String logpass) 
    {
    	byte[] encrypted=null;
        try 
        {
          //  String text = "hi";
            String key = "Bar12345Bar12345"; // 128 bit key
            // Create key and cipher
            Key aesKey = new SecretKeySpec(key.getBytes(), "AES");
            Cipher cipher = Cipher.getInstance("AES");
            // encrypt the text
            cipher.init(Cipher.ENCRYPT_MODE, aesKey);
            encrypted = cipher.doFinal(logpass.getBytes());
//            System.err.println(new String(encrypted));
          /*  Base64.Encoder encoder = Base64.getEncoder();
            String encryptedString = encoder.encodeToString(encrypted);
           // System.out.println("2222"+encryptedString);
            // decrypt the text
            cipher.init(Cipher.DECRYPT_MODE, aesKey);
            String decrypted = new String(cipher.doFinal(encrypted));
            System.err.println("333"+decrypted);*/
        }
        catch(Exception e) 
        {
            e.printStackTrace();
            		
        }
		return new String(Base64.encode(logpass.getBytes()));
    }
   /* public static void main(String[] args) 
    {
    	loginpassEncry app = new loginpassEncry();
        app.run();
    }*/
}

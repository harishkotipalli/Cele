/*package com.hcl.pmoautomation.login.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;


public class Encry_Spring {
	

	
	
	public String encry123(String loginPass,String dbPass){
	//String password = "6786786";
		
	BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
	String hashedPassword = passwordEncoder.encode(loginPass);

	System.out.println(hashedPassword);
	
	Boolean b= passwordEncoder.matches(loginPass,dbPass );
		System.out.println(b);
		return hashedPassword;
	}
}
*/

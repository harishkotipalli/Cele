package com.hcl.pmoautomation.login.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.Validate;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.hcl.pmoautomation.login.dao.LoginDaoImpl;
import com.hcl.pmoautomation.login.service.LoginServiceImpl;
import com.hcl.pmoautomation.login.service.OTPHelperUtility;
import com.hcl.pmoautomation.login.vo.Login;

@Controller
@SessionAttributes
@RequestMapping(value = "pmoAutomation/Login")

public class LoginController {
/*	@ExceptionHandler(NullPointerException.class)
    public ModelAndView myError(Exception exception) {
    ModelAndView e = new ModelAndView();
    e.addObject("exception", exception);
    e.setViewName("Login/Error");
    return e;
}*/
	
	@ExceptionHandler(Exception.class)
	public ModelAndView handleException(Exception ex, HttpServletRequest request, HttpServletResponse response) {
	    ModelAndView modelAndView = new ModelAndView();
	    modelAndView.addObject("errorMessage", ex.getMessage());
	    modelAndView.addObject("errorDetails", ExceptionUtils.getStackTrace(ex));
	    modelAndView.setViewName("Login/Error");

	    return modelAndView;
	}
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
  
	@RequestMapping(value="/loginHome.php",method = {RequestMethod.GET,RequestMethod.POST })
	public String validate(Model model,HttpServletRequest request,
			HttpServletResponse response)throws Exception {
		int co;
		String sapid;
		
		
		
		try{
		 co=(int) request.getSession().getAttribute("countTOChk");
		 sapid= request.getParameter("sapID");
		 HttpSession session = request.getSession();
		   
		    session.setAttribute("loginsap", sapid);

		 
	
		 
		System.out.println(co);
		System.out.println(sapid);
		
		if(co==0){
			request.setAttribute("ERRORADMIN", "PLEASE CONATCT ADMIN,YOUR ACCOUNT IS BLOCKED!!!");
jdbcTemplate.update("update login set ACCOUNT_BLOCK=?   where sapcode=?",new Object[]{new String("Y"),request.getParameter("sapID")});
request.getSession().invalidate();
			return "forward:../../pmoAutomation/Login/loginHomePage1.php";
		}
		co--;
		request.getSession().setAttribute("countTOChk", co);
		}
		catch( Exception e){
			request.setAttribute("ERRORADMIN", "PLEASE CONATCT ADMIN,YOUR ACCOUNT IS BLOCKED!!!");
			return "forward:../../pmoAutomation/Login/loginHomePage1.php";
		}
//		logOut.php
		
		
		
		try{
		LoginServiceImpl loginServiceImpl = new LoginServiceImpl();
		int block=new LoginDaoImpl().validateAndGetRoleBLOCKUSER(Integer.parseInt(request.getParameter("sapID")), jdbcTemplate);
		if(block==1){
			request.setAttribute("ERRORADMIN_2", "PLEASE CONATCT ADMIN,YOUR ACCOUNT IS BLOCKED!!!");
			return "redirect:../../pmoAutomation/Login/loginHomePage1.php";
		}
		List<Map<String,Object>> maps=loginServiceImpl.validateAndGetRole(Integer.parseInt(request.getParameter("sapID")),
				request.getParameter("password"), jdbcTemplate);
		request.getSession().setAttribute("roleAccessAll",maps);
		request.getSession().setAttribute("LOGINNAME",maps.get(0).get("NAME"));
		request.getSession().setAttribute("managerId",maps.get(0).get("SAPCODE"));
		request.getSession().setAttribute("roleAccess",maps.get(0).get("role"));
		request.getSession().setAttribute("hclmail", maps.get(0).get("Hcl_Mail_Id"));
		request.getSession().setAttribute("logPass", maps.get(0).get("PASSWORD"));
		request.setAttribute("LOGINNAME",maps.get(0).get("NAME"));
		 
		
		}
		catch(Exception e){
			request.setAttribute("ERRORADMIN_1", "INVALID CREDENTIALS!!! ATTEMPT "+co+" LEFT");
			return "forward:../../pmoAutomation/Login/loginHomePage1.php";
		}
		InetAddress ip=null;
		try {
			 ip=InetAddress.getLocalHost();
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(ip.getHostName());
		System.out.println(ip.getHostAddress());
		System.out.println(ip.getCanonicalHostName());
		
//		TODO :Cookies logic still to be written
//		Remember Me
		String cookieEnable=request.getParameter("remember_me");
		
		if(cookieEnable!=null &&cookieEnable.equalsIgnoreCase("store") ){
			
			
		Cookie cookie=new Cookie("passWord",request.getParameter("password")) ;
		cookie.setMaxAge(24*60*60);
		response.addCookie(cookie);
			
		}
		
		return "Access/Home";
	}
	
	@RequestMapping(value="/logOut.php")
	public String logOut(HttpServletRequest request,
			HttpServletResponse response) {
		
	    System.out.println(request.getSession().getId());
	    System.out.println((request.getSession()));
	    
		request.getSession().invalidate();
		
		//request.getSession(false);
		
		System.out.println(request.getSession(false));
		
		/*if ( request.getSession().getId() != null){
			System.out.println("Session is not fully closed");
		}*/
		
		System.out.println(request.getSession().getId());
		
		if(request.getSession().getId() == null){
			System.out.println("Session becomes null");
			
		}
		
		
		
		
		return "redirect:../../pmoAutomation/Login/logOutHome.php";
	}
	
	@RequestMapping(value="/loginHomePage.php",method=RequestMethod.GET)
	public String getHomePage(HttpServletRequest request) {
		System.out.println(request.getSession().getId());
		HttpSession session = request.getSession(false);
		session.setAttribute("countTOChk", 3);
		//request.getSession().setAttribute("countTOChk", 3);
		 
		//System.out.println(request.getSession().setAttribute("countTOChk", 3));
//		loginHomePage2.out.println("tytytytytytytytyt");
		return "Login/Login";
	}
	
	@RequestMapping(value="/loginHomePage1.php",method=RequestMethod.POST)
	public String getHomePage1(HttpServletRequest request) {
//		request.getSession().setAttribute("countTOChk", 4);
//		loginHomePage2.out.println("tytytytytytytytyt");
		return "Login/Login";
	}

	@RequestMapping(value="/loginSiteMap.php",method=RequestMethod.GET)
	public String getSiteMap() {


		return "Login/SiteMap";
	}
	
	@RequestMapping(value="/generalHomePage.php",method=RequestMethod.GET)
	public String getGeneralHomePage(HttpServletRequest request) {

//		System.out.println("tytytytytytytytyt");
		String loginName = (String)request.getSession().getAttribute("LOGINNAME");
		request.setAttribute("LOGINNAME", loginName);
		int sapid=(int) request.getSession().getAttribute("managerId");
		request.setAttribute("managerId", sapid);
		System.out.println(sapid);
		System.out.println(loginName);
		/*HttpSession session = request.getSession();
		String loginName = (String) request.getSession().getAttribute("LOGINNAME");
		
		session.setAttribute("LOGINNAME", loginName);
		
	    System.out.println(loginName);
	    
	   */
		//request.getSession().setAttribute("LOGINNAME",maps.get(0).get("NAME"));
		/*HttpSession session = request.getSession();
        System.out.println("hello");
		String s=" hiiiiiiiiiiiiiiiiiii"+session.getAttribute("LOGINNAME");
		
		//String LOGINNAME= (String) session.getAttribute("managerId");
		request.setAttribute("LOGINNAME", s);
		//System.out.println(LOGINNAME);
*/		return "Access/Home";
	}
	@RequestMapping(value="/logOutHome.php",method=RequestMethod.GET)
	public String logOutHomePage() {
		

//		System.out.println("tytytytytytytytyt");
		return "Login/LogOut";
	}
	
	@RequestMapping(value="/errorPage.php",method=RequestMethod.GET)
	public String errorPage(HttpServletRequest request) {
		request.getSession().invalidate();
//		System.out.println("tytytytytytytytyt");
		return "Login/Error";
	}

	@RequestMapping(value="/loginerrorPage.php",method=RequestMethod.GET)
	public String loginerrorPage(HttpServletRequest request) {
		request.getSession().invalidate();
//		System.out.println("tytytytytytytytyt");
		return "Login/loginerror";
	}
	
	@RequestMapping(value="/registerUser.php",method=RequestMethod.GET)
	public String registerUser(HttpServletRequest request) {
	

		return "Login/Register";
	}
	
	@RequestMapping(value="/saveUser.php",method=RequestMethod.POST)
	public String saveUser(HttpServletRequest request) {
	
		try{
		LoginServiceImpl loginServiceImpl=new LoginServiceImpl();
		String[] data=new String[7];
		data[0]=request.getParameter("userName");
		data[1]=request.getParameter("sapID");
		data[2]=request.getParameter("hclmail");
		data[3]=request.getParameter("usrnm");
		data[4]=request.getParameter("pass2");
		data[5]=request.getParameter("secQues");
		data[6]=request.getParameter("secAns");
		System.out.println(Arrays.asList(data));
		loginServiceImpl.saveUser(jdbcTemplate,data);
		}
		catch(Exception e){
			request.setAttribute("wronguser", "User already exists");
			return "Login/Register";
		}
		return "Login/SignUpSuccess";
	}
	
	@RequestMapping(value="/changepass.php",method=RequestMethod.GET)
	public String passchange(HttpServletRequest request) {
	

		return "Login/changepassword";
	}
	@RequestMapping(value="/changeoldpass.php",method=RequestMethod.POST)
	public String oldpasschange(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		 out.println("<html>");
		String oldpass=request.getParameter("oldpass");
	    String confirmpass=request.getParameter("confirmpass");
      	
	    int loginid=(int) request.getSession().getAttribute("managerId");
	    String presentpass=(String) request.getSession().getAttribute("logPass");
        
        System.out.println("old one "+oldpass+" new one"+confirmpass+" present one "+presentpass+" login id "+loginid);
        String oldpassencrp=loginpassEncry.run(oldpass);
        String confirmpassencrp=loginpassEncry.run(confirmpass);
        System.out.println("old one "+oldpassencrp+" new one"+confirmpassencrp+" present one "+presentpass+" login id "+loginid);
    if(oldpassencrp.equals(presentpass)){
    	
    	 if(confirmpassencrp.equals(oldpassencrp)){
         	System.out.println("checkinnng");
     		request.setAttribute("loginpassbothError", "Old and New passwords must not be same"); // Will be available as ${message}
     		return"Login/changepassword";
    	 }
    	System.out.println("equalsssssssssss");
    	jdbcTemplate.update("update mydb.login set PASSWORD="+"'"+confirmpassencrp+"'"+" where PASSWORD="+"'"+oldpassencrp+"'"+" and SAPCODE="+loginid);
    	 
    }
      	
   
    else{
    	
    	System.out.println("not equalsssssssss");
      /*   out.println("<script type=\"text/javascript\">");
         out.println("alert('Old Password is Incorrect');");
         out.println("location='changepassword.jsp';");
         out.println("</script>");
         out.println("<html>");*/
    	//out.println ("<html><body><script>alert('Old Password is Incorrect');</script></body></html>");
    	//request.setAttribute("loginpassError","Old Password is Incorrect");
    	
    	request.setAttribute("loginpassError", "Old Password is Incorrect"); // Will be available as ${message}
    	//request.getRequestDispatcher("login.jsp").forward(request,response);
    	return"Login/changepassword";

    }
		return "Login/LogOut";
	}
	
	@RequestMapping(value="/forgetPasswordUser.php",method=RequestMethod.POST)
	public String forgetPass(HttpServletRequest request) {
	

		return "Login/ForgotPassword";
	}
	
	@RequestMapping(value="/checkSAP.php")
	public String checkSAP(HttpServletRequest request) {
	
//saveNewPassword
		return "Login/CheckSapcode";
	}
	
	@RequestMapping(value="/saveNewPassword.php",method=RequestMethod.POST)
	public String saveNewPassword(HttpServletRequest request) {
	System.out.println(request.getParameter("newPassword")+"----"+request.getSession().getAttribute("sapIDCHECK"));
jdbcTemplate.update("update login set PASSWORD=?  where sapcode=?",new Object[]{loginpassEncry.run(request.getParameter("newPassword")),request.getSession().getAttribute("sapIDCHECK")});
		//return "redirect:../../pmoAutomation/Login/loginHomePage.php";
return "Login/forgorsubmitalert";
	}
	
	
	@RequestMapping(value="/checkOTP.php",method=RequestMethod.POST)
	public String checkOTP(HttpServletRequest request) {
	
//checkOTP
		String otp=(String)request.getSession().getAttribute("otp");
		if(otp.equals(request.getParameter("OTP"))){
//			System.out.println(otp);
//System.out.println(request.getParameter("OTP"));
			return "Login/PChange";
		}
		request.setAttribute("INVALIDotpmsg", "Invalid OTP!");
		return "Login/CheckingOtp";
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/checkAnswer.php",method=RequestMethod.POST)
	public String checkAnswer(HttpServletRequest request) {
	
System.out.println(((List<Login>)request.getSession().getAttribute("dataQ")).get(0).getMail());
String dbans=((List<Login>)request.getSession().getAttribute("dataQ")).get(0).getAns();
	String userans=request.getParameter("checkANS");
	if(dbans.equals(userans)){
		String otp=	OTPHelperUtility.sendM(((List<Login>)request.getSession().getAttribute("dataQ")).get(0).getMail());
		request.getSession().setAttribute("otp", otp);
		return "Login/CheckingOtp";
	}
	else{
		request.setAttribute("INVALIDansmsg", "Answer Invalid !");
		return "Login/ForgotPassword";
	}
	}
	
	@RequestMapping(value="/checkSAPloginHome.php",method=RequestMethod.POST)
	public String checkSAPloginHome(HttpServletRequest request) {
	request.getSession().setAttribute("sapIDCHECK", request.getParameter("sapIDCHECK"));
List<Login> flagSAP=new LoginDaoImpl().checkSAP(jdbcTemplate,request.getParameter("sapIDCHECK"));
if(!flagSAP.isEmpty()){
	request.setAttribute("dataQ",flagSAP);
	request.getSession().setAttribute("dataQ", flagSAP);
	return "forward:../../pmoAutomation/Login/forgetPasswordUser.php";
	
}	else{
	request.setAttribute("showSAPMSg", "SAPCODE DOESN'T EXISTS!!!");
	return "Login/CheckSapcode"; 
}	


	}

}

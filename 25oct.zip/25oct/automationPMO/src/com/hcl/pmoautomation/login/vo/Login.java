package com.hcl.pmoautomation.login.vo;

import java.io.Serializable;

public class Login implements Serializable {
	
	private String name;
	private String quest;
	private String ans;
	private String mail;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getQuest() {
		return quest;
	}
	public void setQuest(String quest) {
		this.quest = quest;
	}
	public String getAns() {
		return ans;
	}
	public void setAns(String ans) {
		this.ans = ans;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	@Override
	public String toString() {
		return "Login [name=" + name + ", quest=" + quest + ", ans=" + ans + ", mail=" + mail + "]";
	}
	

	

}

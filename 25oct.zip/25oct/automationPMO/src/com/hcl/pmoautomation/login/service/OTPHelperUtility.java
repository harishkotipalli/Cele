package com.hcl.pmoautomation.login.service;

import java.util.Properties;
import java.util.UUID;

import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class OTPHelperUtility {

	
	public static String sendM(String to){
		
	
		
		Properties properties = System.getProperties();  
		      properties.setProperty("mail.smtp.host", "10.98.134.29"); //new server
		//    properties.setProperty("mail.smtp.host", "10.150.5.86"); //old server
		      Session session = Session.getDefaultInstance(properties); 
		      OtpMainProgram ot= new OtpMainProgram();
		     
		      String otp= ot.getSaltString();
		    		  //UUID.randomUUID().toString();
		     try {
		    	 MimeMessage message = new MimeMessage(session);  
	              message.setFrom(new InternetAddress("celeritas@hcl.com"));  
	              message.addRecipient(javax.mail.Message.RecipientType.TO,new InternetAddress(to));  
	               message.setSubject("Change Password OTP");  
	            message.setText(otp);  
	        
	              // Send message  
	             Transport.send(message);  
			} catch (Exception e) {
				e.printStackTrace();
			}


        return  otp;
       
		
		
	}
}

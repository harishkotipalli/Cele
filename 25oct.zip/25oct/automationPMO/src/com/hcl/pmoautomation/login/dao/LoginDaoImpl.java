package com.hcl.pmoautomation.login.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

//import com.hcl.pmoautomation.login.controller.Encry_Spring;
import com.hcl.pmoautomation.login.controller.lodindetailsVo;
import com.hcl.pmoautomation.login.controller.loginpassEncry;
import com.hcl.pmoautomation.login.vo.Login;



public class LoginDaoImpl {

	public List<Map<String, Object>> validateAndGetRole(int sapID,
			String password, JdbcTemplate jdbcTemplate) {
		LoginDaoImpl ld=new LoginDaoImpl();
		List<lodindetailsVo> encry=ld.logincredentials(sapID, jdbcTemplate);
		System.out.println("passwor od encry"+encry.get(0));
		System.out.println("first    "+password);
		String[] array = new String[encry.size()];
		int index = 0;
		for (Object value : encry) {
			array[index] = String.valueOf( value );
			System.out.println("hiiiiiiiiiiii "+array[index]);
		
		/*
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		String hashedPassword = passwordEncoder.encode(password);

		
		
		Boolean b= passwordEncoder.matches(password,array[index] );
		System.out.println("passsssssss"+password);
		System.out.println("h22222222"+array[index]);
			System.out.println(b);*/
			
			
		}
		/*Encry_Spring ec=new  Encry_Spring();
		ec.encry123(password, array[index]);
		*/
		loginpassEncry lpe=new loginpassEncry();
		String encryPass=lpe.run(password);
		System.out.println(encryPass);
		System.out.println(array[index]);
		if(array[index].equals(encryPass)){
			System.out.println("working");
			List l=jdbcTemplate
					
					.queryForList(
							"select role,name,SAPCODE,Hcl_Mail_Id,PASSWORD from login where SAPCODE=? and password=?",
										new Object[] { sapID, array[index]});
			return l; 
		}
		
		else{
			return null;
		}
		

	}

	public boolean saveUser(JdbcTemplate jdbcTemplate, String[] data) {

		return jdbcTemplate
				.update(
						"INSERT INTO login (NAME,SAPCODE,Hcl_Mail_Id,USERNAME,PASSWORD,SECURITY_QUESTION,SECURITY_ANSWER) VALUES (?,?,?,?,?,?,?)",
						//"INSERT INTO login(NAME,SAPCODE,USERNAME,PASSWORD,SECURITY_QUESTION,SECURITY_ANSWER)VALUES(?,?,?,?,?,?)",
						new Object[] { data[0],Integer.parseInt(data[1]),data[2],data[3],new loginpassEncry().run(data[4]),data[5],data[6] }) == 1 ? true : false;
	}

	
	public List<lodindetailsVo> logincredentials(int sapID,
			 JdbcTemplate jdbcTemplate) 
	{
		String sql = "select PASSWORD from login where SAPCODE="+sapID;
		
	System.out.println("logincredentialsdetails------------"+sql);
		
		
	    		 List<lodindetailsVo> listaa = jdbcTemplate.query(sql, new RowMapper<lodindetailsVo>() 
	
	    				 {
			@Override
			public lodindetailsVo mapRow(ResultSet rs, int rowNum) throws SQLException 
			{
				lodindetailsVo aa = new lodindetailsVo();
				
				aa.setPassword(rs.getString("PASSWORD"));
				
				
				
				
				
				return aa;
			}
	 
			
			
			
			
			
			
	    });//---------------new Object[]{year, month});
	    		
	    		
	    return listaa;
	    
	    }
	
	public int validateAndGetRoleBLOCKUSER(int sapID, JdbcTemplate jdbcTemplate) {

		return jdbcTemplate.queryForObject("select count(*) from login where SAPCODE=?  and ACCOUNT_BLOCK='Y'",
				new Object[] { sapID},Integer.class);

	}
	
public List<Login> checkSAP(JdbcTemplate jdbcTemplate, String parameter) {
		
		
		
		
		List<Login> ll = new ArrayList<Login>();

		List<Map<String, Object>> rows = jdbcTemplate.queryForList("select name,SECURITY_QUESTION,SECURITY_ANSWER,Hcl_Mail_Id from login where sapcode=?",new Object[]{Integer.parseInt(parameter)});
		for (Map row : rows) {
			Login l = new Login();
			l.setName((String)(row.get("NAME")));
			l.setQuest((String)row.get("SECURITY_QUESTION"));
			l.setAns((String)row.get("SECURITY_ANSWER"));
			l.setMail((String)row.get("Hcl_Mail_Id"));
			ll.add(l);
		}
System.out.println(ll+"+++++++++++++");
		
		return ll;
	}
}

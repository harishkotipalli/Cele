package com.hcl.pmoautomation.login.service;

import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;

import com.hcl.pmoautomation.login.dao.LoginDaoImpl;

public class LoginServiceImpl {
	
	
	public List<Map<String, Object>> validateAndGetRole(int sapID,String password, JdbcTemplate jdbcTemplate){
		LoginDaoImpl loginDaoImpl=new LoginDaoImpl();
		
	return	loginDaoImpl.validateAndGetRole(sapID,password,jdbcTemplate);
		
	}

	public boolean saveUser(JdbcTemplate jdbcTemplate, String[] data) {
		
		
		return new LoginDaoImpl().saveUser(jdbcTemplate,data);
		
	}

	
	
	
	
	

}

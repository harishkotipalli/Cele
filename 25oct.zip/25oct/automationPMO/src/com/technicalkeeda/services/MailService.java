package com.technicalkeeda.services;


	
	
	import com.hcl.pmoautomation.email.vo.Mail;
	
	public interface MailService {
	   public void sendEmail(Mail mail,String vm);
	}



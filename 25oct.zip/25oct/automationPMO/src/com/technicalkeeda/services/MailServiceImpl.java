package com.technicalkeeda.services;
 
import java.io.File;
import java.util.Map;


import javax.mail.MessagingException;
import javax.mail.Quota.Resource;
import javax.mail.internet.MimeMessage;

import org.apache.velocity.app.VelocityEngine;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.ui.velocity.VelocityEngineUtils;

import com.hcl.pmoautomation.email.vo.Mail;
 
@Service("mailService")
public class MailServiceImpl implements MailService {
 
    @Autowired
    JavaMailSender mailSender;
 
    @Autowired
    VelocityEngine velocityEngine;
 
    

	public void setMailSender(JavaMailSender mailSender) {
		this.mailSender = mailSender;
	}

	
	public void setVelocityEngine(VelocityEngine velocityEngine) {
		this.velocityEngine = velocityEngine;
	}

	public void sendEmail(Mail mail, String vm1) {
        MimeMessage mimeMessage = mailSender.createMimeMessage();
 
        try {
 
            MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage, true);
 
            mimeMessageHelper.setSubject(mail.getMailSubject());
            mimeMessageHelper.setFrom(mail.getMailFrom());
            mimeMessageHelper.setTo(mail.getMailTo());
            mail.setMailContent(geContentFromTemplate(mail.getModel(),vm1));
            mimeMessageHelper.setText(mail.getMailContent(), true);
        //    mimeMessageHelper.addInline("cid",mail.getEmbed());
           /* ApplicationContext appContext = new FileSystemXmlApplicationContext();
            Resource resource = (Resource) appContext.getResource( "com/technicalkeeda111/beans/0.PNG" );
            mimeMessageHelper.addInline("imageContent",
                    new File( resource.ge));*/
            FileSystemResource file = new FileSystemResource(mail.getContentType());
            mimeMessageHelper.addAttachment(file.getFilename(), file);

            mailSender.send(mimeMessageHelper.getMimeMessage());
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }
 
    public String geContentFromTemplate(Map < String, Object > model ,String vm) {
        StringBuffer content = new StringBuffer();
        try {
            content.append(VelocityEngineUtils.mergeTemplateIntoString(velocityEngine, "./com/hcl/pmoautomation/email/vm"+vm, model));
        } catch (Exception e) {
           e.printStackTrace();
       }
        return content.toString();
    }
 
}
